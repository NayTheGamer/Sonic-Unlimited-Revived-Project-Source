SegaJingle_Header:
	smpsHeaderStartSong 1
	smpsHeaderVoice     SegaJingle_Voices
	smpsHeaderChan      $06, $03
	smpsHeaderTempo     $01, $00

	smpsHeaderDAC       SegaJingle_DAC
	smpsHeaderFM        SegaJingle_FM1,	$00, $00
	smpsHeaderFM        SegaJingle_FM2,	$00, $00
	smpsHeaderFM        SegaJingle_FM3,	$00, $00
	smpsHeaderFM        SegaJingle_FM4,	$00, $00
	smpsHeaderFM        SegaJingle_FM5,	$00, $00
	smpsHeaderPSG       SegaJingle_PSG1,	$00, $00, $00, $00
	smpsHeaderPSG       SegaJingle_PSG2,	$00, $00, $00, $00
	smpsHeaderPSG       SegaJingle_PSG3,	$00, $00, $00, $00

; PSG1 Data
SegaJingle_PSG1:
; PSG2 Data
SegaJingle_PSG2:
	smpsStop

; FM1 Data
SegaJingle_FM1:
	smpsPan             panCenter, $00
	dc.b	nRst, $03
	smpsSetvoice        $00
	smpsAlterVol        $1A
	smpsPan             panLeft, $00
	dc.b	nA3
	smpsAlterVol        $01
	dc.b	smpsNoAttack, nA3
	smpsAlterVol        $FF
	dc.b	nAb3
	smpsAlterVol        $01
	dc.b	smpsNoAttack, nAb3
	smpsAlterVol        $FF
	dc.b	nA3, $06
	smpsAlterVol        $09
	dc.b	smpsNoAttack, nA3, $03
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nA3
	smpsAlterVol        $EA
	dc.b	nA4, $09
	smpsAlterVol        $01
	dc.b	smpsNoAttack, nA4, $03
	smpsAlterVol        $07
	dc.b	nA4, $06
	smpsAlterVol        $01
	dc.b	smpsNoAttack, nA4, $03
	smpsAlterVol        $01
	dc.b	smpsNoAttack, nA4, $03
	smpsAlterVol        $F6
	dc.b	nA3, $06
	smpsAlterVol        $09
	dc.b	smpsNoAttack, nA3, $03
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nA3
	smpsAlterVol        $EA
	dc.b	nA3, $09
	smpsAlterVol        $01
	dc.b	smpsNoAttack, nA3, $03
	smpsAlterVol        $07
	dc.b	nA3, $06
	smpsAlterVol        $01
	dc.b	smpsNoAttack, nA3, $03
	smpsAlterVol        $01
	dc.b	smpsNoAttack, nA3, $03
	smpsAlterVol        $F6
	dc.b	nBb3, $09
	smpsAlterVol        $01
	dc.b	smpsNoAttack, nBb3, $03
	smpsAlterVol        $07
	dc.b	nBb3, $06
	smpsAlterVol        $01
	dc.b	smpsNoAttack, nBb3, $03
	smpsAlterVol        $01
	dc.b	smpsNoAttack, nBb3, $03
	smpsAlterVol        $F6
	dc.b	nA3, $06
	smpsAlterVol        $09
	dc.b	smpsNoAttack, nA3, $03
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nA3
	smpsAlterVol        $EA
	dc.b	nF3, $06
	smpsAlterVol        $09
	dc.b	smpsNoAttack, nF3, $03
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nF3
	smpsAlterVol        $EA
	dc.b	nG3, $06
	smpsAlterVol        $09
	dc.b	smpsNoAttack, nG3, $03
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nG3
	smpsAlterVol        $EA
	dc.b	nA3, $1E
	smpsAlterVol        $01
	dc.b	smpsNoAttack, nA3, $0C
	smpsAlterVol        $01
	dc.b	smpsNoAttack, nA3, $09
	smpsAlterVol        $01
	dc.b	smpsNoAttack, nA3
	smpsAlterVol        $01
	dc.b	smpsNoAttack, nA3, $06
	smpsAlterVol        $01
	dc.b	smpsNoAttack, nA3, $09
	smpsAlterVol        $01
	dc.b	smpsNoAttack, nA3, $03
	smpsAlterVol        $01
	dc.b	smpsNoAttack, nA3
	smpsAlterVol        $02
	dc.b	smpsNoAttack, nA3
	smpsAlterVol        $1A
	dc.b	smpsNoAttack, nA3
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nA3
	smpsAlterVol        $0E
	dc.b	smpsNoAttack, nA3
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nA3
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nA3
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nA3, $7F, smpsNoAttack, $0E
	smpsStop

; FM2 Data
SegaJingle_FM2:
	smpsPan             panCenter, $00
	dc.b	nRst, $03
	smpsSetvoice        $00
	smpsAlterVol        $1A
	smpsPan             panRight, $00
	dc.b	nCs4
	smpsAlterVol        $01
	dc.b	smpsNoAttack, nCs4
	smpsAlterVol        $FF
	dc.b	nC4
	smpsAlterVol        $01
	dc.b	smpsNoAttack, nC4
	smpsAlterVol        $FF
	dc.b	nCs4, $06
	smpsAlterVol        $09
	dc.b	smpsNoAttack, nCs4, $03
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nCs4
	smpsAlterVol        $EA
	dc.b	nCs5, $09
	smpsAlterVol        $01
	dc.b	smpsNoAttack, nCs5, $03
	smpsAlterVol        $07
	dc.b	nCs5, $06
	smpsAlterVol        $01
	dc.b	smpsNoAttack, nCs5, $03
	smpsAlterVol        $01
	dc.b	smpsNoAttack, nCs5, $03
	smpsAlterVol        $F6
	dc.b	nCs4, $06
	smpsAlterVol        $09
	dc.b	smpsNoAttack, nCs4, $03
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nCs4
	smpsAlterVol        $EA
	dc.b	nCs4, $09
	smpsAlterVol        $01
	dc.b	smpsNoAttack, nCs4, $03
	smpsAlterVol        $07
	dc.b	nCs4, $06
	smpsAlterVol        $01
	dc.b	smpsNoAttack, nCs4, $03
	smpsAlterVol        $01
	dc.b	smpsNoAttack, nCs4, $03
	smpsAlterVol        $F6
	dc.b	nD4, $09
	smpsAlterVol        $01
	dc.b	smpsNoAttack, nD4, $03
	smpsAlterVol        $07
	dc.b	nD4, $06
	smpsAlterVol        $01
	dc.b	smpsNoAttack, nD4, $03
	smpsAlterVol        $01
	dc.b	smpsNoAttack, nD4, $03
	smpsAlterVol        $F6
	dc.b	nCs4, $06
	smpsAlterVol        $09
	dc.b	smpsNoAttack, nCs4, $03
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nCs4
	smpsAlterVol        $EA
	dc.b	nA3, $06
	smpsAlterVol        $09
	dc.b	smpsNoAttack, nA3, $03
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nA3
	smpsAlterVol        $EA
	dc.b	nB3, $06
	smpsAlterVol        $09
	dc.b	smpsNoAttack, nB3, $03
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nB3
	smpsAlterVol        $EA
	dc.b	nCs4, $1E
	smpsAlterVol        $01
	dc.b	smpsNoAttack, nCs4, $0C
	smpsAlterVol        $01
	dc.b	smpsNoAttack, nCs4, $09
	smpsAlterVol        $01
	dc.b	smpsNoAttack, nCs4
	smpsAlterVol        $01
	dc.b	smpsNoAttack, nCs4, $06
	smpsAlterVol        $01
	dc.b	smpsNoAttack, nCs4, $09
	smpsAlterVol        $01
	dc.b	smpsNoAttack, nCs4, $03
	smpsAlterVol        $01
	dc.b	smpsNoAttack, nCs4
	smpsAlterVol        $02
	dc.b	smpsNoAttack, nCs4
	smpsAlterVol        $1A
	dc.b	smpsNoAttack, nCs4
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nCs4
	smpsAlterVol        $0E
	dc.b	smpsNoAttack, nCs4
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nCs4
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nCs4
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nCs4, $7F, smpsNoAttack, $0E
	smpsStop

; FM3 Data
SegaJingle_FM3:
	smpsPan             panCenter, $00
	dc.b	nRst, $0F
	smpsSetvoice        $01
	smpsAlterVol        $23
	smpsAlterNote       $FA
	dc.b	nA4, $0C
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nA4, $03
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nA4
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nA4
	smpsAlterVol        $0E
	dc.b	smpsNoAttack, nA4
	smpsAlterVol        $CB
	dc.b	nA5, $0C
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nA5, $03
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nA5
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nA5
	smpsAlterVol        $0E
	dc.b	smpsNoAttack, nA5
	smpsAlterVol        $CB
	smpsAlterNote       $FC
	dc.b	nE5, $06
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nE5, $03
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nE5
	smpsAlterVol        $E6
	smpsAlterNote       $FD
	dc.b	nCs5, $0C
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nCs5, $03
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nCs5
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nCs5
	smpsAlterVol        $0E
	dc.b	smpsNoAttack, nCs5
	smpsAlterVol        $CB
	smpsAlterNote       $FC
	dc.b	nD5, $0C
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nD5, $03
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nD5
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nD5
	smpsAlterVol        $0E
	dc.b	smpsNoAttack, nD5
	smpsAlterVol        $CB
	dc.b	nE5, $06
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nE5, $03
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nE5
	smpsAlterVol        $E6
	dc.b	nFs5, $06
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nFs5, $03
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nFs5
	smpsAlterVol        $E6
	smpsAlterNote       $FB
	dc.b	nAb5, $06
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nAb5, $03
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nAb5
	smpsAlterVol        $E6
	smpsAlterNote       $FA
	dc.b	nA5, $16, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $07
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $06
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $F5
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $ED
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $EC
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $F1
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $07
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $05
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $F4
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $ED
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $EC
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $F1
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $07
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $05
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $F4
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $ED
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $EC
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $F1
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $07
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $05
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $F4
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $ED
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $EC
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $F1
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $07
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $05
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $FD
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $F4
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $ED
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $EC
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $F1
	dc.b	nA5, $01
	smpsAlterVol        $0D
	dc.b	smpsNoAttack
	smpsAlterNote       $FB
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $07
	dc.b	nA5, $01
	smpsAlterVol        $0D
	dc.b	smpsNoAttack
	smpsAlterNote       $05
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $FD
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $F3
	dc.b	nA5, $01
	smpsAlterVol        $0D
	dc.b	smpsNoAttack
	smpsAlterNote       $ED
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $EC
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $F2
	dc.b	nA5, $01
	smpsAlterVol        $0E
	dc.b	smpsNoAttack
	smpsAlterNote       $FB
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $04
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $08
	dc.b	nA5, $01
	smpsAlterVol        $0D
	dc.b	smpsNoAttack
	smpsAlterNote       $05
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $FD
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $F3
	dc.b	nA5, $01
	smpsAlterVol        $0D
	dc.b	smpsNoAttack
	smpsAlterNote       $ED
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $EC
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $F2
	dc.b	nA5, $01
	smpsAlterVol        $0D
	dc.b	nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01
	dc.b	nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01
	dc.b	nRst, $01, nRst, $01, nRst, $01, nRst, $02, nRst, $01, nRst, $01
	dc.b	nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $02
	dc.b	nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01
	dc.b	nRst, $01, nRst, $02, nRst, $01, nRst, $01, nRst, $01, nRst, $01
	dc.b	nRst, $01, nRst, $01, nRst, $01, nRst, $02, nRst, $01, nRst, $01
	dc.b	nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01
	dc.b	nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01
	dc.b	nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01
	dc.b	nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01
	dc.b	nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01
	dc.b	nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01
	dc.b	nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01
	dc.b	nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01
	dc.b	nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01
	dc.b	nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01
	dc.b	nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01
	dc.b	nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01
	dc.b	nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01
	dc.b	nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01
	dc.b	nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01
	dc.b	nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01
	dc.b	nRst, $01, nRst, $01
	smpsStop

; FM4 Data
SegaJingle_FM4:
	smpsPan             panCenter, $00
	dc.b	nRst, $03
	smpsSetvoice        $01
	smpsAlterVol        $16
	dc.b	nA4, $0C
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nA4, $03
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nA4
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nA4
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nA4
	smpsAlterVol        $CC
	dc.b	nA5, $0C
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nA5, $03
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nA5
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nA5
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nA5
	smpsAlterVol        $CC
	dc.b	nE5, $06
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nE5, $03
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nE5
	smpsAlterVol        $E6
	dc.b	nCs5, $0C
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nCs5, $03
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nCs5
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nCs5
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nCs5
	smpsAlterVol        $CC
	dc.b	nD5, $0C
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nD5, $03
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nD5
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nD5
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nD5
	smpsAlterVol        $CC
	dc.b	nE5, $06
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nE5, $03
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nE5
	smpsAlterVol        $E6
	dc.b	nFs5, $06
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nFs5, $03
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nFs5
	smpsAlterVol        $E6
	dc.b	nAb5, $06
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nAb5, $03
	smpsAlterVol        $0D
	dc.b	smpsNoAttack, nAb5
	smpsAlterVol        $E6
	dc.b	nA5, $16, smpsNoAttack
	smpsAlterNote       $08
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $0D
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $0B
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $04
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $FB
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $F4
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $F2
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $F7
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $08
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $0D
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $0B
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $04
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $F3
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $F2
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $F7
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $09
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $0D
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $0B
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $04
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $F3
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $F2
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $F7
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $09
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $0D
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $0B
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $F3
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $F2
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $F7
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $09
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $0D
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $0B
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $F3
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $F2
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $F8
	dc.b	nA5, $01
	smpsAlterVol        $0D
	dc.b	smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $09
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $0D
	dc.b	nA5, $01
	smpsAlterVol        $0D
	dc.b	smpsNoAttack
	smpsAlterNote       $0B
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	nA5, $01
	smpsAlterVol        $0D
	dc.b	smpsNoAttack
	smpsAlterNote       $F3
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $F2
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $F8
	dc.b	nA5, $01
	smpsAlterVol        $0D
	dc.b	smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $09
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $0D
	dc.b	nA5, $01
	smpsAlterVol        $0E
	dc.b	smpsNoAttack
	smpsAlterNote       $0B
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $F9
	dc.b	nA5, $01
	smpsAlterVol        $0D
	dc.b	smpsNoAttack
	smpsAlterNote       $F3
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $F2
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $F8
	dc.b	nA5, $01
	smpsAlterVol        $0D
	dc.b	smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $09
	dc.b	nA5, $01, smpsNoAttack
	smpsAlterNote       $0D
	dc.b	nA5, $01
	smpsAlterVol        $0D
	dc.b	nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01
	dc.b	nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01
	dc.b	nRst, $02, nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01
	dc.b	nRst, $01, nRst, $01, nRst, $02, nRst, $01, nRst, $01, nRst, $01
	dc.b	nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $02, nRst, $01
	dc.b	nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01
	dc.b	nRst, $02, nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01
	dc.b	nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01
	dc.b	nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01
	dc.b	nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01
	dc.b	nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01
	dc.b	nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01
	dc.b	nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01
	dc.b	nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01
	dc.b	nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01
	dc.b	nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01
	dc.b	nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01
	dc.b	nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01
	dc.b	nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01
	dc.b	nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01
	dc.b	nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01
	dc.b	nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01
	dc.b	nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01
	dc.b	nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01
	dc.b	nRst, $01, nRst, $01, nRst, $01, nRst, $01, nRst, $01
	smpsStop

; FM5 Data
SegaJingle_FM5:
	smpsPan             panCenter, $00
	dc.b	nRst, $03
	smpsSetvoice        $02
	smpsAlterVol        $10
	dc.b	nA2, $18, nE2, nCs3, $0C, nA2, nA2, nD3, $18, nE3, $0C, nFs3
	dc.b	nAb3, nA3, $5A
	smpsAlterVol        $0E
	dc.b	smpsNoAttack, nA3, $03
	smpsAlterVol        $0F
	dc.b	smpsNoAttack, nA3
	smpsAlterVol        $0E
	dc.b	smpsNoAttack, nA3
	smpsAlterVol        $0F
	dc.b	smpsNoAttack, nA3
	smpsAlterVol        $0E
	dc.b	smpsNoAttack, nA3
	smpsAlterVol        $0E
	dc.b	smpsNoAttack, nA3
	smpsAlterVol        $0F
	dc.b	smpsNoAttack, nA3
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, nA3, $7F, smpsNoAttack, $02
	smpsStop

; PSG3 Data
SegaJingle_PSG3:
	dc.b	nRst, $7F, $14
	smpsPSGAlterVol     $02
	smpsPSGform         $E7
	smpsAlterNote       $08
	dc.b	nMaxPSG, $04
	smpsPSGAlterVol     $01
	smpsAlterNote       $08
	dc.b	nMaxPSG
	smpsPSGAlterVol     $01
	smpsAlterNote       $08
	dc.b	nMaxPSG
	smpsPSGAlterVol     $01
	smpsAlterNote       $08
	dc.b	nMaxPSG
	smpsPSGAlterVol     $01
	smpsAlterNote       $08
	dc.b	nMaxPSG
	smpsPSGAlterVol     $01
	smpsAlterNote       $08
	dc.b	nMaxPSG
	smpsPSGAlterVol     $01
	smpsAlterNote       $08
	dc.b	nMaxPSG
	smpsPSGAlterVol     $01
	smpsAlterNote       $08
	dc.b	nMaxPSG
	smpsPSGAlterVol     $01
	smpsAlterNote       $08
	dc.b	nMaxPSG
	smpsPSGAlterVol     $01
	smpsAlterNote       $08
	dc.b	nMaxPSG
	smpsPSGAlterVol     $01
	smpsAlterNote       $08
	dc.b	nMaxPSG
	smpsPSGAlterVol     $01
	smpsAlterNote       $08
	dc.b	nMaxPSG
	smpsPSGAlterVol     $01
	smpsAlterNote       $08
	dc.b	nMaxPSG, nRst, $7F, $3D
	smpsStop

; DAC Data
SegaJingle_DAC:
	dc.b	nRst, $03, dKick, $0C, dSnare, $06, dSnare, dKick, $18, dSnare, $0C, dSnare
	dc.b	$06, dSnare, dKick, dClap, dClap, $0C, dSnare, dKick, dSnare, dSnare, dSnare, $7F
	dc.b	nRst, $71
	smpsStop

SegaJingle_Voices:
;	Voice $00
;	$3D
;	$11, $21, $51, $11, 	$12, $14, $14, $0F, 	$0A, $05, $05, $05
;	$00, $00, $00, $00, 	$2B, $2B, $2B, $1B, 	$19, $00, $00, $00
	smpsVcAlgorithm     $05
	smpsVcFeedback      $07
	smpsVcUnusedBits    $00
	smpsVcDetune        $01, $05, $02, $01
	smpsVcCoarseFreq    $01, $01, $01, $01
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $0F, $14, $14, $12
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $05, $05, $05, $0A
	smpsVcDecayRate2    $00, $00, $00, $00
	smpsVcDecayLevel    $01, $02, $02, $02
	smpsVcReleaseRate   $0B, $0B, $0B, $0B
	smpsVcTotalLevel    $00, $00, $00, $19

;	Voice $01
;	$3D
;	$71, $70, $71, $73, 	$1F, $1F, $1F, $1F, 	$10, $06, $06, $06
;	$01, $06, $06, $06, 	$35, $1A, $18, $1A, 	$12, $07, $07, $00
	smpsVcAlgorithm     $05
	smpsVcFeedback      $07
	smpsVcUnusedBits    $00
	smpsVcDetune        $07, $07, $07, $07
	smpsVcCoarseFreq    $03, $01, $00, $01
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $1F, $1F, $1F, $1F
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $06, $06, $06, $10
	smpsVcDecayRate2    $06, $06, $06, $01
	smpsVcDecayLevel    $01, $01, $01, $03
	smpsVcReleaseRate   $0A, $08, $0A, $05
	smpsVcTotalLevel    $00, $07, $07, $12

;	Voice $02
;	$3B
;	$1C, $11, $10, $10, 	$18, $1F, $1F, $1F, 	$13, $10, $09, $09
;	$00, $00, $00, $00, 	$EF, $7F, $3F, $7F, 	$12, $1B, $0D, $00
	smpsVcAlgorithm     $03
	smpsVcFeedback      $07
	smpsVcUnusedBits    $00
	smpsVcDetune        $01, $01, $01, $01
	smpsVcCoarseFreq    $00, $00, $01, $0C
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $1F, $1F, $1F, $18
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $09, $09, $10, $13
	smpsVcDecayRate2    $00, $00, $00, $00
	smpsVcDecayLevel    $07, $03, $07, $0E
	smpsVcReleaseRate   $0F, $0F, $0F, $0F
	smpsVcTotalLevel    $00, $0D, $1B, $12

