Song_Header:
	smpsHeaderStartSong 1
	smpsHeaderVoice     Song_Voices
	smpsHeaderChan      $07, $03
	smpsHeaderTempo     $01, $00

	smpsHeaderDAC       Song_DAC,	$00, $F2
	smpsHeaderFM        Song_FM1,	$00, $00
	smpsHeaderFM        Song_FM2,	$00, $00
	smpsHeaderFM        Song_FM3,	$00, $00
	smpsHeaderFM        Song_FM4,	$00, $00
	smpsHeaderFM        Song_FM5,	$00, $00
	smpsHeaderFM        Song_FM6,	$00, $00
	smpsHeaderPSG       Song_PSG1,	$00, $00, $00, $00
	smpsHeaderPSG       Song_PSG2,	$00, $00, $00, $00
	smpsHeaderPSG       Song_PSG3,	$00, $00, $00, $00

; DAC Data
Song_DAC:
; FM1 Data
Song_FM1:
	smpsPan             panCenter, $00
	dc.b	nRst, $17
	smpsSetvoice        $00
	smpsAlterVol        $7F
	dc.b	smpsNoAttack, nRst, $02
	smpsSetvoice        $03
	smpsAlterVol        $8B
	dc.b	smpsNoAttack, nRst, $04
	smpsPan             panLeft, $00
	dc.b	nE5, $31, nRst, $11
	smpsSetvoice        $04
	smpsAlterVol        $0C
	smpsPan             panCenter, $00
	dc.b	nE4, $21, nC4, $4C
	smpsStop

; FM2 Data
Song_FM2:
	smpsPan             panCenter, $00
	dc.b	nRst, $17
	smpsSetvoice        $00
	smpsAlterVol        $7F
	smpsPan             panLeft, $00
	dc.b	smpsNoAttack, nRst, $02
	smpsSetvoice        $03
	smpsAlterVol        $8B
	smpsPan             panCenter, $00
	dc.b	smpsNoAttack, nRst, $09
	smpsPan             panLeft, $00
	dc.b	nG5, $2E, nRst, $0E
	smpsSetvoice        $04
	smpsAlterVol        $0C
	dc.b	nC5, $21, nG4, $4C, nRst, $01
	smpsStop

; FM3 Data
Song_FM3:
	smpsPan             panCenter, $00
	dc.b	nRst, $17
	smpsSetvoice        $00
	smpsAlterVol        $7F
	smpsPan             panRight, $00
	dc.b	smpsNoAttack, nRst, $02
	smpsSetvoice        $03
	smpsAlterVol        $8B
	smpsPan             panCenter, $00
	dc.b	smpsNoAttack, nRst, $0E
	smpsPan             panLeft, $00
	dc.b	nC6, $2B, nRst, $0C
	smpsSetvoice        $04
	smpsAlterVol        $0C
	smpsPan             panRight, $00
	dc.b	nG5, $21, nE5, $4C, nRst, $01
	smpsStop

; FM4 Data
Song_FM4:
	smpsPan             panCenter, $00
	dc.b	nRst, $17
	smpsSetvoice        $01
	smpsAlterVol        $7F
	dc.b	smpsNoAttack, nRst, $02
	smpsSetvoice        $03
	smpsAlterVol        $8B
	dc.b	smpsNoAttack, nRst, $13
	smpsPan             panRight, $00
	dc.b	nE5, $32
	smpsSetvoice        $05
	smpsPan             panCenter, $00
	dc.b	nE3, $21, nC3, $4C, nRst, $01
	smpsStop

; FM5 Data
Song_FM5:
	smpsPan             panCenter, $00
	dc.b	nRst, $17
	smpsSetvoice        $02
	smpsAlterVol        $7F
	smpsPan             panRight, $00
	dc.b	smpsNoAttack, nRst, $02
	smpsSetvoice        $03
	smpsAlterVol        $8B
	smpsPan             panCenter, $00
	dc.b	smpsNoAttack, nRst, $19
	smpsPan             panRight, $00
	dc.b	nG5, $2A, nRst, $70
	smpsStop

; FM6 Data
Song_FM6:
	smpsPan             panCenter, $00
	dc.b	nRst, $17
	smpsSetvoice        $02
	smpsAlterVol        $7F
	smpsPan             panRight, $00
	dc.b	smpsNoAttack, nRst, $02
	smpsSetvoice        $03
	smpsAlterVol        $8B
	smpsPan             panCenter, $00
	dc.b	smpsNoAttack, nRst, $1E
	smpsPan             panRight, $00
	dc.b	nC6, $2B, nRst, $6A
	smpsStop

; PSG1 Data
Song_PSG1:
	dc.b	nRst, $5F
	smpsPSGAlterVol     $05
	dc.b	nG2, $21, nE2, $4C
	smpsStop

; PSG2 Data
Song_PSG2:
	dc.b	nRst, $5F
	smpsPSGAlterVol     $05
	dc.b	nC2, $21, nG1, $4C
	smpsStop

; PSG3 Data
Song_PSG3:
	dc.b	nRst, $17
	smpsPSGform         $E7
	dc.b	nRst, $7F, $36
	smpsStop

Song_Voices:
;	Voice $00
;	$3D
;	$01, $02, $00, $01, 	$1F, $0E, $0E, $0E, 	$07, $1F, $1F, $1F
;	$00, $00, $00, $00, 	$1F, $0F, $0F, $0F, 	$7F, $00, $00, $00
	smpsVcAlgorithm     $05
	smpsVcFeedback      $07
	smpsVcUnusedBits    $00
	smpsVcDetune        $00, $00, $00, $00
	smpsVcCoarseFreq    $01, $00, $02, $01
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $0E, $0E, $0E, $1F
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $1F, $1F, $1F, $07
	smpsVcDecayRate2    $00, $00, $00, $00
	smpsVcDecayLevel    $00, $00, $00, $01
	smpsVcReleaseRate   $0F, $0F, $0F, $0F
	smpsVcTotalLevel    $00, $00, $00, $7F

;	Voice $01
;	$08
;	$0A, $70, $30, $00, 	$1F, $1F, $5F, $5F, 	$12, $0E, $0A, $0A
;	$00, $04, $04, $03, 	$2F, $2F, $2F, $2F, 	$7F, $7F, $7F, $00
	smpsVcAlgorithm     $00
	smpsVcFeedback      $01
	smpsVcUnusedBits    $00
	smpsVcDetune        $00, $03, $07, $00
	smpsVcCoarseFreq    $00, $00, $00, $0A
	smpsVcRateScale     $01, $01, $00, $00
	smpsVcAttackRate    $1F, $1F, $1F, $1F
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $0A, $0A, $0E, $12
	smpsVcDecayRate2    $03, $04, $04, $00
	smpsVcDecayLevel    $02, $02, $02, $02
	smpsVcReleaseRate   $0F, $0F, $0F, $0F
	smpsVcTotalLevel    $00, $7F, $7F, $7F

;	Voice $02
;	$04
;	$37, $72, $77, $49, 	$1F, $1F, $1F, $1F, 	$07, $0A, $07, $0D
;	$00, $0B, $00, $0B, 	$1F, $0F, $1F, $0F, 	$7F, $00, $7F, $00
	smpsVcAlgorithm     $04
	smpsVcFeedback      $00
	smpsVcUnusedBits    $00
	smpsVcDetune        $04, $07, $07, $03
	smpsVcCoarseFreq    $09, $07, $02, $07
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $1F, $1F, $1F, $1F
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $0D, $07, $0A, $07
	smpsVcDecayRate2    $0B, $00, $0B, $00
	smpsVcDecayLevel    $00, $01, $00, $01
	smpsVcReleaseRate   $0F, $0F, $0F, $0F
	smpsVcTotalLevel    $00, $7F, $00, $7F

;	Voice $03
;	$04
;	$37, $72, $77, $49, 	$1F, $1F, $1F, $1F, 	$07, $0A, $07, $0D
;	$00, $0B, $00, $0B, 	$1F, $0F, $1F, $0F, 	$23, $00, $23, $00
	smpsVcAlgorithm     $04
	smpsVcFeedback      $00
	smpsVcUnusedBits    $00
	smpsVcDetune        $04, $07, $07, $03
	smpsVcCoarseFreq    $09, $07, $02, $07
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $1F, $1F, $1F, $1F
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $0D, $07, $0A, $07
	smpsVcDecayRate2    $0B, $00, $0B, $00
	smpsVcDecayLevel    $00, $01, $00, $01
	smpsVcReleaseRate   $0F, $0F, $0F, $0F
	smpsVcTotalLevel    $00, $23, $00, $23

;	Voice $04
;	$3D
;	$01, $02, $00, $01, 	$1F, $0E, $0E, $0E, 	$07, $1F, $1F, $1F
;	$00, $00, $00, $00, 	$1F, $0F, $0F, $0F, 	$17, $01, $00, $00
	smpsVcAlgorithm     $05
	smpsVcFeedback      $07
	smpsVcUnusedBits    $00
	smpsVcDetune        $00, $00, $00, $00
	smpsVcCoarseFreq    $01, $00, $02, $01
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $0E, $0E, $0E, $1F
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $1F, $1F, $1F, $07
	smpsVcDecayRate2    $00, $00, $00, $00
	smpsVcDecayLevel    $00, $00, $00, $01
	smpsVcReleaseRate   $0F, $0F, $0F, $0F
	smpsVcTotalLevel    $00, $00, $01, $17

;	Voice $05
;	$08
;	$0A, $70, $30, $00, 	$1F, $1F, $5F, $5F, 	$12, $0E, $0A, $0A
;	$00, $04, $04, $03, 	$2F, $2F, $2F, $2F, 	$24, $2D, $13, $00
	smpsVcAlgorithm     $00
	smpsVcFeedback      $01
	smpsVcUnusedBits    $00
	smpsVcDetune        $00, $03, $07, $00
	smpsVcCoarseFreq    $00, $00, $00, $0A
	smpsVcRateScale     $01, $01, $00, $00
	smpsVcAttackRate    $1F, $1F, $1F, $1F
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $0A, $0A, $0E, $12
	smpsVcDecayRate2    $03, $04, $04, $00
	smpsVcDecayLevel    $02, $02, $02, $02
	smpsVcReleaseRate   $0F, $0F, $0F, $0F
	smpsVcTotalLevel    $00, $13, $2D, $24

