SegaJingle_Header:
	smpsHeaderStartSong 1
	smpsHeaderVoice     SegaJingle_Voices
	smpsHeaderChan      $06, $03
	smpsHeaderTempo     $01, $00

	smpsHeaderDAC       SegaJingle_DAC
	smpsHeaderFM        SegaJingle_FM1,	$00, $00
	smpsHeaderFM        SegaJingle_FM2,	$00, $00
	smpsHeaderFM        SegaJingle_FM3,	$00, $00
	smpsHeaderFM        SegaJingle_FM4,	$00, $00
	smpsHeaderFM        SegaJingle_FM5,	$00, $00
	smpsHeaderPSG       SegaJingle_PSG1,	$00, $00, $00, $00
	smpsHeaderPSG       SegaJingle_PSG2,	$00, $00, $00, $00
	smpsHeaderPSG       SegaJingle_PSG3,	$00, $00, $00, $00

; FM1 Data
SegaJingle_FM1:
	smpsSetvoice        $00
	smpsAlterVol        $15

SegaJingle_Loop16:
	smpsPan             panCenter, $00
	dc.b	nC5, $07, nRst
	smpsPan             panRight, $00
	dc.b	nG5

SegaJingle_Loop15:
	dc.b	nRst
	smpsPan             panCenter, $00
	dc.b	nG4, $04, nRst, $03
	smpsPan             panRight, $00
	dc.b	nG5, $07, nRst
	smpsPan             panCenter, $00
	dc.b	nC5, $04, nRst, $03
	smpsPan             panRight, $00
	dc.b	nG5, $07
	smpsLoop            $00, $02, SegaJingle_Loop15
	dc.b	nRst
	smpsLoop            $01, $02, SegaJingle_Loop16
	smpsPan             panCenter, $00
	dc.b	nC5, nRst
	smpsPan             panRight, $00
	dc.b	nG5

SegaJingle_Loop17:
	dc.b	nRst
	smpsPan             panCenter, $00
	dc.b	nG4, $04, nRst, $03
	smpsPan             panRight, $00
	dc.b	nG5, $07, nRst
	smpsPan             panCenter, $00
	dc.b	nC5, $04, nRst, $03
	smpsPan             panRight, $00
	dc.b	nG5, $07
	smpsLoop            $00, $02, SegaJingle_Loop17
	dc.b	nRst, $77

SegaJingle_Loop19:
	smpsPan             panCenter, $00
	dc.b	nC5, $07, nRst
	smpsPan             panRight, $00
	dc.b	nG5

SegaJingle_Loop18:
	dc.b	nRst
	smpsPan             panCenter, $00
	dc.b	nG4, $04, nRst, $03
	smpsPan             panRight, $00
	dc.b	nG5, $07, nRst
	smpsPan             panCenter, $00
	dc.b	nC5, $04, nRst, $03
	smpsPan             panRight, $00
	dc.b	nG5, $07
	smpsLoop            $00, $02, SegaJingle_Loop18
	dc.b	nRst
	smpsLoop            $01, $07, SegaJingle_Loop19
	smpsPan             panCenter, $00
	dc.b	nC5, nRst
	smpsPan             panRight, $00
	dc.b	nG5

SegaJingle_Loop1A:
	dc.b	nRst
	smpsPan             panCenter, $00
	dc.b	nG4, $04, nRst, $03
	smpsPan             panRight, $00
	dc.b	nG5, $07, nRst
	smpsPan             panCenter, $00
	dc.b	nC5, $04, nRst, $03
	smpsPan             panRight, $00
	dc.b	nG5, $07
	smpsLoop            $00, $02, SegaJingle_Loop1A
	dc.b	nRst, $15
	smpsSetvoice        $04
	smpsAlterVol        $F7
	dc.b	nD4, $0B, nRst, $03, nG3, $07, nD4, nRst, nG3, nD4, nRst, nG3
	dc.b	nD4, nF3, nG3, nF3, nC3, nC2, nRst, nG3, $0B, nRst, $03, nC3
	dc.b	$07, nG3, nRst, nC3, nG3, nRst, nG3, nG3, nBb3, nC4, nBb3, nG3
	dc.b	nRst, $0E, nD4, $0B, nRst, $03, nG3, $07, nD4, nRst, nG3, nD4
	dc.b	nRst, nG3, nD4, nF3, nG3, nF3, nC3, nRst, $70
	smpsSetvoice        $00
	smpsAlterVol        $09

SegaJingle_Loop1C:
	smpsPan             panCenter, $00
	dc.b	nC5, $07, nRst
	smpsPan             panRight, $00
	dc.b	nG5

SegaJingle_Loop1B:
	dc.b	nRst
	smpsPan             panCenter, $00
	dc.b	nG4, $04, nRst, $03
	smpsPan             panRight, $00
	dc.b	nG5, $07, nRst
	smpsPan             panCenter, $00
	dc.b	nC5, $04, nRst, $03
	smpsPan             panRight, $00
	dc.b	nG5, $07
	smpsLoop            $00, $02, SegaJingle_Loop1B
	dc.b	nRst
	smpsLoop            $01, $07, SegaJingle_Loop1C
	smpsPan             panCenter, $00
	dc.b	nC5, nRst
	smpsPan             panRight, $00
	dc.b	nG5

SegaJingle_Loop1D:
	dc.b	nRst
	smpsPan             panCenter, $00
	dc.b	nG4, $04, nRst, $03
	smpsPan             panRight, $00
	dc.b	nG5, $07, nRst
	smpsPan             panCenter, $00
	dc.b	nC5, $04, nRst, $03
	smpsPan             panRight, $00
	dc.b	nG5, $07
	smpsLoop            $00, $02, SegaJingle_Loop1D
	dc.b	nRst, $15
	smpsSetvoice        $04
	smpsAlterVol        $F7

SegaJingle_Loop1E:
	dc.b	nD4, $0B, nRst, $03, nG3, $07, nD4, nRst, nG3, nD4, nRst, nG3
	dc.b	nD4, nF3, nG3, nF3, nC3, nC2, nRst, nG3, $0B, nRst, $03, nC3
	dc.b	$07, nG3, nRst, nC3, nG3, nRst, nG3, nG3, nBb3, nC4, nBb3, nG3
	dc.b	nRst, $0E
	smpsLoop            $00, $02, SegaJingle_Loop1E
	dc.b	nD4, $0B, nRst, $03, nG3, $07, nD4, nRst, nG3, nD4, nRst, nG3
	dc.b	nD4, nF3, nG3, nF3, nC3, nRst, $70
	smpsJump SegaJingle_FM1

; FM2 Data
SegaJingle_FM2:
	smpsPan             panCenter, $00
	dc.b	nRst, $0E
	smpsSetvoice        $00
	smpsAlterVol        $15
	smpsPan             panLeft, $00

SegaJingle_Loop10:
	dc.b	nE5, $07, nRst, $0E
	smpsLoop            $00, $04, SegaJingle_Loop10
	dc.b	nE5, $07, nRst, $15
	smpsLoop            $01, $02, SegaJingle_Loop10

SegaJingle_Loop11:
	dc.b	nE5, $07, nRst, $0E
	smpsLoop            $00, $04, SegaJingle_Loop11
	dc.b	nE5, $07, nRst, $7F, $06

SegaJingle_Loop12:
	dc.b	nE5, $07, nRst, $0E
	smpsLoop            $00, $04, SegaJingle_Loop12
	dc.b	nE5, $07, nRst, $15
	smpsLoop            $01, $08, SegaJingle_Loop12
	smpsSetvoice        $04
	smpsAlterVol        $F7
	dc.b	nF3, $0B, nRst, $0A, nF3, $07, nRst, $0E, nF3, $07, nRst, $0E
	dc.b	nF3, $07, nRst, $2A, nD3, $0B, nRst, $0A, nD3, $07, nRst, $0E
	dc.b	nD3, $07, nRst, nD3, nRst, $31, nF3, $0B, nRst, $0A, nF3, $07
	dc.b	nRst, $0E, nF3, $07, nRst, $0E, nF3, $07, nRst, $7F, $0D
	smpsAlterVol        $03
	dc.b	smpsNoAttack, $0E
	smpsSetvoice        $00
	smpsAlterVol        $06

SegaJingle_Loop13:
	dc.b	nE5, $07, nRst, $0E
	smpsLoop            $00, $04, SegaJingle_Loop13
	dc.b	nE5, $07, nRst, $15
	smpsLoop            $01, $08, SegaJingle_Loop13
	smpsSetvoice        $04
	smpsAlterVol        $F7

SegaJingle_Loop14:
	dc.b	nF3, $0B, nRst, $0A, nF3, $07, nRst, $0E, nF3, $07, nRst, $0E
	dc.b	nF3, $07, nRst, $2A, nD3, $0B, nRst, $0A, nD3, $07, nRst, $0E
	dc.b	nD3, $07, nRst, nD3, nRst, $31
	smpsLoop            $00, $02, SegaJingle_Loop14
	dc.b	nF3, $0B, nRst, $0A, nF3, $07, nRst, $0E, nF3, $07, nRst, $0E
	dc.b	nF3, $07, nRst, $7F, $0D
	smpsJump SegaJingle_FM2

; FM3 Data
SegaJingle_FM3:
	smpsSetvoice        $01
	smpsAlterVol        $0D
	smpsPan             panCenter, $00

SegaJingle_Loop0F:
	dc.b	nE5, $0E, nEb5, nD5, $07, nCs5, $0E, nC5, nC5, $07, nB4, $0E
	dc.b	nBb4, nA4
	smpsLoop            $00, $03, SegaJingle_Loop0F
	dc.b	nC5, $54
	smpsSetvoice        $03
	dc.b	$08, smpsNoAttack
	smpsAlterNote       $13
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1B
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $12
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $EB
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E4
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $EE
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $03
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $15
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1B
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $10
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FB
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E9
	dc.b	$01
	smpsAlterNote       $00
	dc.b	nB4, $07, nD5, $0B, nRst, $03, nC5, $0B, nRst, $03, nB4, $0B
	dc.b	nRst, $03, nC5, $0B, nRst, $03, nG4, $0B, nRst, $03, nA4, $0B
	dc.b	nRst, $03, nC5, $0E, nB4, nG4, nRst, nG4, $0F, smpsNoAttack
	smpsAlterNote       $13
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1B
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $12
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $EB
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1B
	dc.b	nFs4, smpsNoAttack
	smpsAlterNote       $EE
	dc.b	nG4, smpsNoAttack
	smpsAlterNote       $03
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $15
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1B
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $10
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FB
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E9
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E5
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F1
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $06
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $17
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1A
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0D
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F8
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E7
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E6
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F4
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $09
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $18
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $19
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0A
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F5
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E6
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E7
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F7
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0C
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1A
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $18
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $07
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F2
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E5
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E8
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0F
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1A
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $16
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $04
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $EF
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1B
	dc.b	nFs4, smpsNoAttack
	smpsAlterNote       $EA
	dc.b	nG4, smpsNoAttack
	smpsAlterNote       $FD
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $11
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1B
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $14
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $01
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $ED
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1B
	dc.b	nFs4, smpsNoAttack
	smpsAlterNote       $EC
	dc.b	nG4, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01, nRst, $0E
	smpsSetvoice        $01
	dc.b	nE5, nEb5, nD5, $07, nCs5, $0E, nC5, nC5, $07, nB4, $0E, nBb4
	dc.b	nA4, $1C
	smpsSetvoice        $04
	smpsAlterVol        $FE
	dc.b	$04, nBb4, $11, nA4, $15, nG4, $08, smpsNoAttack
	smpsAlterNote       $13
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1B
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $12
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $EB
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1B
	dc.b	nFs4, smpsNoAttack
	smpsAlterNote       $EE
	dc.b	nG4, smpsNoAttack
	smpsAlterNote       $03
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $15
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1B
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $10
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FB
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E9
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E5
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F1
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $06
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $17
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1A
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0D
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F8
	dc.b	$01
	smpsSetvoice        $03
	smpsAlterVol        $02
	smpsAlterNote       $00
	dc.b	nC5, $08, smpsNoAttack
	smpsAlterNote       $13
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1B
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $12
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $EB
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E4
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $EE
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $03
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $15
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1B
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $10
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FB
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E9
	dc.b	$01
	smpsAlterNote       $00
	dc.b	nB4, $07, nD5, $0B, nRst, $03, nC5, $0B, nRst, $03, nB4, $0B
	dc.b	nRst, $03, nC5, $0B, nRst, $03, nG4, $0B, nRst, $03, nA4, $0B
	dc.b	nRst, $03, nC5, $0E, nB4, nG4, nRst, nG4, $0F, smpsNoAttack
	smpsAlterNote       $13
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1B
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $12
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $EB
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1B
	dc.b	nFs4, smpsNoAttack
	smpsAlterNote       $EE
	dc.b	nG4, smpsNoAttack
	smpsAlterNote       $03
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $15
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1B
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $10
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FB
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E9
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E5
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F1
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $06
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $17
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1A
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0D
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F8
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E7
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E6
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F4
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $09
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $18
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $19
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0A
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F5
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E6
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E7
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F7
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0C
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1A
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $18
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $07
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F2
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E5
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E8
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0F
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1A
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $16
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $04
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $EF
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1B
	dc.b	nFs4, smpsNoAttack
	smpsAlterNote       $EA
	dc.b	nG4, smpsNoAttack
	smpsAlterNote       $FD
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $11
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1B
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $14
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $01
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $ED
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1B
	dc.b	nFs4, smpsNoAttack
	smpsAlterNote       $EC
	dc.b	nG4, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01, nRst, $0E
	smpsSetvoice        $01
	dc.b	nE5, nEb5, nD5, $07, nCs5, $0E, nC5, nC5, $07, nB4, $0E, nBb4
	dc.b	nA4, $1C
	smpsSetvoice        $04
	smpsAlterVol        $FE
	dc.b	$04, nBb4, $11, nB4, $15, nC5, $08, smpsNoAttack
	smpsAlterNote       $13
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1B
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $12
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $EB
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E4
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $EE
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $03
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $15
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1B
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $10
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FB
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E9
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E5
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F1
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $06
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $17
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1A
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0D
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F8
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E7
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E6
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F4
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $09
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $18
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $19
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0A
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F5
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E6
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E7
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F7
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0C
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1A
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $18
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $07
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F2
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E5
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E8
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0F
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1A
	dc.b	$01
	smpsSetvoice        $05
	smpsAlterNote       $00
	dc.b	nD5, $07, nG5, $0B, nRst, $03, nFs5, $0B, nRst, $03, nF5, $06
	dc.b	nRst, $01, nFs5, $06, nRst, $01, nF5, $06, nRst, $01, nE5, $06
	dc.b	nRst, $01, nEb5, $0B, nRst, $03, nD5, $0B, nRst, $03, nCs5, $06
	dc.b	nRst, $01, nD5, $06, nRst, $01, nCs5, $06, nRst, $01, nC5, $06
	dc.b	nRst, $01, nB4, $0B, nRst, $03, nBb4, $0B, nRst, $03, nA4, $06
	dc.b	nRst, $01, nBb4, $06, nRst, $01, nA4, $06, nRst, $01, nAb4, $06
	dc.b	nRst, $01, nG4, $0F, smpsNoAttack
	smpsAlterNote       $0D
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $12
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0C
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F2
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $ED
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F4
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $02
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0E
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $12
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0A
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FC
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F0
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $EE
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F6
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $04
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0F
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $11
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $08
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $EF
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $EE
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F8
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $06
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $10
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $06
	dc.b	$01, nRst, $07
	smpsAlterNote       $00
	dc.b	nD5, nG5, $0B, nRst, $03, nFs5, $0B, nRst, $03, nF5, $06, nRst
	dc.b	$01, nFs5, $06, nRst, $01, nF5, $06, nRst, $01, nE5, $06, nRst
	dc.b	$01, nEb5, $0B, nRst, $03, nD5, $0B, nRst, $03, nCs5, $06, nRst
	dc.b	$01, nD5, $06, nRst, $01, nCs5, $06, nRst, $01, nC5, $06, nRst
	dc.b	$01
	smpsSetvoice        $01
	smpsAlterVol        $02
	dc.b	nC5, $54
	smpsSetvoice        $03
	dc.b	$08, smpsNoAttack
	smpsAlterNote       $13
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1B
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $12
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $EB
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E4
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $EE
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $03
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $15
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1B
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $10
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FB
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E9
	dc.b	$01
	smpsAlterNote       $00
	dc.b	nB4, $07, nD5, $0B, nRst, $03, nC5, $0B, nRst, $03, nB4, $0B
	dc.b	nRst, $03, nC5, $0B, nRst, $03, nG4, $0B, nRst, $03, nA4, $0B
	dc.b	nRst, $03, nC5, $0E, nB4, nG4, nRst, nG4, $0F, smpsNoAttack
	smpsAlterNote       $13
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1B
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $12
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $EB
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1B
	dc.b	nFs4, smpsNoAttack
	smpsAlterNote       $EE
	dc.b	nG4, smpsNoAttack
	smpsAlterNote       $03
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $15
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1B
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $10
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FB
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E9
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E5
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F1
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $06
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $17
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1A
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0D
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F8
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E7
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E6
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F4
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $09
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $18
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $19
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0A
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F5
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E6
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E7
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F7
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0C
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1A
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $18
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $07
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F2
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E5
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E8
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0F
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1A
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $16
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $04
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $EF
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1B
	dc.b	nFs4, smpsNoAttack
	smpsAlterNote       $EA
	dc.b	nG4, smpsNoAttack
	smpsAlterNote       $FD
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $11
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1B
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $14
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $01
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $ED
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1B
	dc.b	nFs4, smpsNoAttack
	smpsAlterNote       $EC
	dc.b	nG4, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01, nRst, $0E
	smpsSetvoice        $01
	dc.b	nE5, nEb5, nD5, $07, nCs5, $0E, nC5, nC5, $07, nB4, $0E, nBb4
	dc.b	nA4, $1C
	smpsSetvoice        $04
	smpsAlterVol        $FE
	dc.b	$04, nBb4, $11, nA4, $15, nG4, $08, smpsNoAttack
	smpsAlterNote       $13
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1B
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $12
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $EB
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1B
	dc.b	nFs4, smpsNoAttack
	smpsAlterNote       $EE
	dc.b	nG4, smpsNoAttack
	smpsAlterNote       $03
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $15
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1B
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $10
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FB
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E9
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E5
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F1
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $06
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $17
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1A
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0D
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F8
	dc.b	$01
	smpsSetvoice        $03
	smpsAlterVol        $02
	smpsAlterNote       $00
	dc.b	nC5, $08, smpsNoAttack
	smpsAlterNote       $13
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1B
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $12
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $EB
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E4
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $EE
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $03
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $15
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1B
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $10
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FB
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E9
	dc.b	$01
	smpsAlterNote       $00
	dc.b	nB4, $07, nD5, $0B, nRst, $03, nC5, $0B, nRst, $03, nB4, $0B
	dc.b	nRst, $03, nC5, $0B, nRst, $03, nG4, $0B, nRst, $03, nA4, $0B
	dc.b	nRst, $03, nC5, $0E, nB4, nG4, nRst, nG4, $0F, smpsNoAttack
	smpsAlterNote       $13
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1B
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $12
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $EB
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1B
	dc.b	nFs4, smpsNoAttack
	smpsAlterNote       $EE
	dc.b	nG4, smpsNoAttack
	smpsAlterNote       $03
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $15
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1B
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $10
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FB
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E9
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E5
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F1
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $06
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $17
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1A
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0D
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F8
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E7
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E6
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F4
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $09
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $18
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $19
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0A
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F5
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E6
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E7
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F7
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0C
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1A
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $18
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $07
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F2
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E5
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E8
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0F
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1A
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $16
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $04
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $EF
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1B
	dc.b	nFs4, smpsNoAttack
	smpsAlterNote       $EA
	dc.b	nG4, smpsNoAttack
	smpsAlterNote       $FD
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $11
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1B
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $14
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $01
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $ED
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1B
	dc.b	nFs4, smpsNoAttack
	smpsAlterNote       $EC
	dc.b	nG4, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01, nRst, $0E
	smpsSetvoice        $01
	dc.b	nE5, nEb5, nD5, $07, nCs5, $0E, nC5, nC5, $07, nB4, $0E, nBb4
	dc.b	nA4, $1C
	smpsSetvoice        $04
	smpsAlterVol        $FE
	dc.b	$04, nBb4, $11, nB4, $15, nC5, $08, smpsNoAttack
	smpsAlterNote       $13
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1B
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $12
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $EB
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E4
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $EE
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $03
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $15
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1B
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $10
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FB
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E9
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E5
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F1
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $06
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $17
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1A
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0D
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F8
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E7
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E6
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F4
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $09
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $18
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $19
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0A
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F5
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E6
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E7
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F7
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0C
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1A
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $18
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $07
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F2
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E5
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E8
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0F
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1A
	dc.b	$01
	smpsSetvoice        $05
	smpsAlterNote       $00
	dc.b	nD5, $07, nG5, $0B, nRst, $03, nFs5, $0B, nRst, $03, nF5, $06
	dc.b	nRst, $01, nFs5, $06, nRst, $01, nF5, $06, nRst, $01, nE5, $06
	dc.b	nRst, $01, nEb5, $0B, nRst, $03, nD5, $0B, nRst, $03, nCs5, $06
	dc.b	nRst, $01, nD5, $06, nRst, $01, nCs5, $06, nRst, $01, nC5, $06
	dc.b	nRst, $01, nB4, $0B, nRst, $03, nBb4, $0B, nRst, $03, nBb4, $06
	dc.b	nRst, $01, nB4, $06, nRst, $01, nC5, $06, nRst, $01, nCs5, $06
	dc.b	nRst, $01, nD5, $0F, smpsNoAttack
	smpsAlterNote       $0D
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $12
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0C
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F2
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $ED
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F4
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $02
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0E
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $12
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0A
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FC
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F0
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $EE
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F6
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $04
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0F
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $11
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $08
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $EF
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $EE
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F8
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $06
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $10
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $06
	dc.b	$01, nRst, $07
	smpsAlterNote       $00
	dc.b	nD5, nG5, $0B, nRst, $03, nFs5, $0B, nRst, $03, nF5, $06, nRst
	dc.b	$01, nFs5, $06, nRst, $01, nF5, $06, nRst, $01, nE5, $06, nRst
	dc.b	$01, nEb5, $0B, nRst, $03, nD5, $0B, nRst, $03, nCs5, $06, nRst
	dc.b	$01, nD5, $06, nRst, $01, nCs5, $06, nRst, $01, nC5, $06, nRst
	dc.b	$01, nB4, $0B, nRst, $03, nBb4, $0B, nRst, $03, nA4, $06, nRst
	dc.b	$01, nBb4, $06, nRst, $01, nA4, $06, nRst, $01, nAb4, $06, nRst
	dc.b	$01, nG4, $0F, smpsNoAttack
	smpsAlterNote       $0D
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $12
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0C
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F2
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $ED
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F4
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $02
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0E
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $12
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0A
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FC
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F0
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $EE
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F6
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $04
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0F
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $11
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $08
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $EF
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $EE
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F8
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $06
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $10
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $06
	dc.b	$01, nRst, $07
	smpsAlterNote       $00
	dc.b	nD5, nG5, $0B, nRst, $03, nFs5, $0B, nRst, $03, nF5, $06, nRst
	dc.b	$01, nFs5, $06, nRst, $01, nF5, $06, nRst, $01, nE5, $06, nRst
	dc.b	$01, nEb5, $0B, nRst, $03, nD5, $0B, nRst, $03, nCs5, $06, nRst
	dc.b	$01, nD5, $06, nRst, $01, nCs5, $06, nRst, $01, nC5, $06, nRst
	dc.b	$01
	smpsSetvoice        $01
	smpsAlterVol        $02
	dc.b	nC5, $09, nG4, $0A, nC5, $09, nCs5, nAb4, $0A, nCs5, $09, nD5
	dc.b	nA4, $0A, nD5, $09, nEb5, nBb4, $0A, nEb5, $09
	smpsJump SegaJingle_FM3

; FM4 Data
SegaJingle_FM4:
	smpsSetvoice        $01
	smpsAlterVol        $10
	smpsPan             panCenter, $00

SegaJingle_Loop0D:
	dc.b	nC5, $0E, nB4, nBb4, $07, nA4, $0E, nAb4, nAb4, $07, nG4, $0E
	dc.b	nFs4, nF4
	smpsLoop            $00, $03, SegaJingle_Loop0D
	dc.b	nFs4, $54
	smpsSetvoice        $03
	smpsAlterVol        $05
	smpsAlterNote       $02
	dc.b	nC6, $15
	smpsAlterNote       $04
	dc.b	nB5, $07
	smpsAlterNote       $02
	dc.b	nD6, $0B, nRst, $03, nC6, $0B, nRst, $03
	smpsAlterNote       $04
	dc.b	nB5, $0B, nRst, $03
	smpsAlterNote       $02
	dc.b	nC6, $0B, nRst, $03, nG5, $0B, nRst, $03
	smpsAlterNote       $03
	dc.b	nA5, $0B, nRst, $03
	smpsAlterNote       $02
	dc.b	nC6, $0E
	smpsAlterNote       $04
	dc.b	nB5
	smpsAlterNote       $02
	dc.b	nG5, nRst, nG5, $46, nRst, $0E
	smpsSetvoice        $01
	smpsAlterVol        $FB
	dc.b	nC5
	smpsAlterNote       $04
	dc.b	nB4
	smpsAlterNote       $03
	dc.b	nBb4, $07, nA4, $0E, nAb4, nAb4, $07
	smpsAlterNote       $02
	dc.b	nG4, $0E
	smpsAlterNote       $03
	dc.b	nFs4, nF4, $2A
	smpsSetvoice        $04
	smpsAlterVol        $02
	dc.b	nA4, $04, nBb4, $11, nA4, $15
	smpsAlterNote       $02
	dc.b	nG4, $0E
	smpsSetvoice        $03
	smpsAlterVol        $03
	dc.b	nC6, $15
	smpsAlterNote       $04
	dc.b	nB5, $07
	smpsAlterNote       $02
	dc.b	nD6, $0B, nRst, $03, nC6, $0B, nRst, $03
	smpsAlterNote       $04
	dc.b	nB5, $0B, nRst, $03
	smpsAlterNote       $02
	dc.b	nC6, $0B, nRst, $03, nG5, $0B, nRst, $03
	smpsAlterNote       $03
	dc.b	nA5, $0B, nRst, $03
	smpsAlterNote       $02
	dc.b	nC6, $0E
	smpsAlterNote       $04
	dc.b	nB5
	smpsAlterNote       $02
	dc.b	nG5, nRst, nG5, $46, nRst, $0E
	smpsSetvoice        $01
	smpsAlterVol        $FB
	dc.b	nC5
	smpsAlterNote       $04
	dc.b	nB4
	smpsAlterNote       $03
	dc.b	nBb4, $07, nA4, $0E, nAb4, nAb4, $07
	smpsAlterNote       $02
	dc.b	nG4, $0E
	smpsAlterNote       $03
	dc.b	nFs4, nF4, $2A
	smpsSetvoice        $04
	smpsAlterVol        $02
	dc.b	nA4, $04, nBb4, $11
	smpsAlterNote       $04
	dc.b	nB4, $15
	smpsAlterNote       $02
	dc.b	nC5, $2A, nRst, $0E
	smpsAlterNote       $03
	dc.b	nA4, $0B, nRst, $0A, nA4, $07, nRst, $0E, nA4, $07, nRst, $0E
	dc.b	nA4, $07, nRst, $2A, nF4, $0B, nRst, $0A, nF4, $07, nRst, $0E
	smpsAlterNote       $02
	dc.b	nE4, $07, nRst, nE4, nRst, $31
	smpsAlterNote       $03
	dc.b	nA4, $0B, nRst, $0A, nA4, $07, nRst, $0E, nA4, $07, nRst, $0E
	dc.b	nA4, $07, nRst, $1C
	smpsSetvoice        $01
	smpsAlterVol        $04
	dc.b	nFs4, $54
	smpsSetvoice        $03
	smpsAlterVol        $FF
	smpsAlterNote       $02
	dc.b	nC6, $15
	smpsAlterNote       $04
	dc.b	nB5, $07
	smpsAlterNote       $02
	dc.b	nD6, $0B, nRst, $03, nC6, $0B, nRst, $03
	smpsAlterNote       $04
	dc.b	nB5, $0B, nRst, $03
	smpsAlterNote       $02
	dc.b	nC6, $0B, nRst, $03, nG5, $0B, nRst, $03
	smpsAlterNote       $03
	dc.b	nA5, $0B, nRst, $03
	smpsAlterNote       $02
	dc.b	nC6, $0E
	smpsAlterNote       $04
	dc.b	nB5
	smpsAlterNote       $02
	dc.b	nG5, nRst, nG5, $46, nRst, $0E
	smpsSetvoice        $01
	smpsAlterVol        $FB
	dc.b	nC5
	smpsAlterNote       $04
	dc.b	nB4
	smpsAlterNote       $03
	dc.b	nBb4, $07, nA4, $0E, nAb4, nAb4, $07
	smpsAlterNote       $02
	dc.b	nG4, $0E
	smpsAlterNote       $03
	dc.b	nFs4, nF4, $2A
	smpsSetvoice        $04
	smpsAlterVol        $02
	dc.b	nA4, $04, nBb4, $11, nA4, $15
	smpsAlterNote       $02
	dc.b	nG4, $0E
	smpsSetvoice        $03
	smpsAlterVol        $03
	dc.b	nC6, $15
	smpsAlterNote       $04
	dc.b	nB5, $07
	smpsAlterNote       $02
	dc.b	nD6, $0B, nRst, $03, nC6, $0B, nRst, $03
	smpsAlterNote       $04
	dc.b	nB5, $0B, nRst, $03
	smpsAlterNote       $02
	dc.b	nC6, $0B, nRst, $03, nG5, $0B, nRst, $03
	smpsAlterNote       $03
	dc.b	nA5, $0B, nRst, $03
	smpsAlterNote       $02
	dc.b	nC6, $0E
	smpsAlterNote       $04
	dc.b	nB5
	smpsAlterNote       $02
	dc.b	nG5, nRst, nG5, $46, nRst, $0E
	smpsSetvoice        $01
	smpsAlterVol        $FB
	dc.b	nC5
	smpsAlterNote       $04
	dc.b	nB4
	smpsAlterNote       $03
	dc.b	nBb4, $07, nA4, $0E, nAb4, nAb4, $07
	smpsAlterNote       $02
	dc.b	nG4, $0E
	smpsAlterNote       $03
	dc.b	nFs4, nF4, $2A
	smpsSetvoice        $04
	smpsAlterVol        $02
	dc.b	nA4, $04, nBb4, $11
	smpsAlterNote       $04
	dc.b	nB4, $15
	smpsAlterNote       $02
	dc.b	nC5, $2A, nRst, $0E

SegaJingle_Loop0E:
	smpsAlterNote       $03
	dc.b	nA4, $0B, nRst, $0A, nA4, $07, nRst, $0E, nA4, $07, nRst, $0E
	dc.b	nA4, $07, nRst, $2A, nF4, $0B, nRst, $0A, nF4, $07, nRst, $0E
	smpsAlterNote       $02
	dc.b	nE4, $07, nRst, nE4, nRst, $31
	smpsLoop            $00, $02, SegaJingle_Loop0E
	smpsAlterNote       $03
	dc.b	nA4, $0B, nRst, $0A, nA4, $07, nRst, $0E, nA4, $07, nRst, $0E
	dc.b	nA4, $07, nRst, $1C
	smpsSetvoice        $01
	smpsAlterVol        $FE
	smpsAlterNote       $02
	dc.b	nE4, $09, nC4, $0A, nE4, $09
	smpsAlterNote       $03
	dc.b	nF4
	smpsAlterNote       $02
	dc.b	nCs4, $0A
	smpsAlterNote       $03
	dc.b	nF4, $09, nFs4
	smpsAlterNote       $02
	dc.b	nD4, $0A
	smpsAlterNote       $03
	dc.b	nFs4, $09
	smpsAlterNote       $02
	dc.b	nG4, nEb4, $0A, nG4, $09
	smpsJump SegaJingle_FM4

; FM5 Data
SegaJingle_FM5:
	smpsSetvoice        $02
	smpsAlterVol        $11
	smpsPan             panCenter, $00

SegaJingle_Loop02:
	dc.b	nC2, $0B
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $01
	smpsAlterVol        $F6
	dc.b	nB1, $0B
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $01
	smpsAlterVol        $F6
	dc.b	nBb1, $04
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $01
	smpsAlterVol        $F6
	dc.b	nA1, $0B
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $01
	smpsAlterVol        $F6
	dc.b	nC2, $0B
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $01
	smpsAlterVol        $F6
	dc.b	nC2, $04
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $01
	smpsAlterVol        $F6
	dc.b	nB1, $0B
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $01
	smpsAlterVol        $F6
	dc.b	nBb1, $0B
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $01
	smpsAlterVol        $F6
	dc.b	nA1, $0B
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $01
	smpsAlterVol        $F6
	smpsLoop            $00, $03, SegaJingle_Loop02
	dc.b	nC2, $0E, nRst, $62

SegaJingle_Loop03:
	dc.b	nC2, $0B
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $0F
	smpsAlterVol        $F6
	dc.b	nG1, $0B
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $08
	smpsAlterVol        $F6
	dc.b	nC2, $0B
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $01
	smpsAlterVol        $F6
	dc.b	nC2, $04
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $01
	smpsAlterVol        $F6
	dc.b	nG1, $0B
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $01
	smpsAlterVol        $F6
	dc.b	nBb1, $0B
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $01
	smpsAlterVol        $F6
	dc.b	nG1, $0B
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $01
	smpsAlterVol        $F6
	smpsLoop            $00, $07, SegaJingle_Loop03
	dc.b	nC2, $0B
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $0F
	smpsAlterVol        $F6
	dc.b	nG1, $0B
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $08
	smpsAlterVol        $F6
	dc.b	nC2, $0B
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $01
	smpsAlterVol        $F6
	dc.b	nC2, $04
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $01
	smpsAlterVol        $F6
	dc.b	nG1, $0B

SegaJingle_Loop04:
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $01
	smpsAlterVol        $F6
	dc.b	nBb1, $0B
	smpsLoop            $00, $02, SegaJingle_Loop04

SegaJingle_Loop05:
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $01
	smpsAlterVol        $F6
	dc.b	nG2, $0B
	smpsLoop            $00, $02, SegaJingle_Loop05
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $08
	smpsAlterVol        $F6
	dc.b	nG2, $0B
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $01
	smpsAlterVol        $F6
	dc.b	nG1, $20
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $01
	smpsAlterVol        $F6
	dc.b	nF2, $0B
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $01
	smpsAlterVol        $F6
	dc.b	nFs2, $0B

SegaJingle_Loop06:
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $01
	smpsAlterVol        $F6
	dc.b	nG2, $0B
	smpsLoop            $00, $02, SegaJingle_Loop06
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $08
	smpsAlterVol        $F6
	dc.b	nG2, $0B
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $01
	smpsAlterVol        $F6
	dc.b	nG1, $0B
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $01
	smpsAlterVol        $F6
	dc.b	nG2, $04
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $01
	smpsAlterVol        $F6
	dc.b	nG2, $0B
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $01
	smpsAlterVol        $F6
	dc.b	nF2, $0B
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $01
	smpsAlterVol        $F6
	dc.b	nFs2, $0B

SegaJingle_Loop07:
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $01
	smpsAlterVol        $F6
	dc.b	nG2, $0B
	smpsLoop            $00, $02, SegaJingle_Loop07
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $08
	smpsAlterVol        $F6
	dc.b	nG2, $0B
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $01
	smpsAlterVol        $F6
	dc.b	nG1, $20
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $01
	smpsAlterVol        $F6
	dc.b	nF2, $0B
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $01
	smpsAlterVol        $F6
	dc.b	nFs2, $0B
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $01
	smpsAlterVol        $F6
	dc.b	nC2, $0E, nRst, $62

SegaJingle_Loop08:
	dc.b	nC2, $0B
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $0F
	smpsAlterVol        $F6
	dc.b	nG1, $0B
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $08
	smpsAlterVol        $F6
	dc.b	nC2, $0B
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $01
	smpsAlterVol        $F6
	dc.b	nC2, $04
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $01
	smpsAlterVol        $F6
	dc.b	nG1, $0B
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $01
	smpsAlterVol        $F6
	dc.b	nBb1, $0B
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $01
	smpsAlterVol        $F6
	dc.b	nG1, $0B
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $01
	smpsAlterVol        $F6
	smpsLoop            $00, $07, SegaJingle_Loop08
	dc.b	nC2, $0B
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $0F
	smpsAlterVol        $F6
	dc.b	nG1, $0B
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $08
	smpsAlterVol        $F6
	dc.b	nC2, $0B
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $01
	smpsAlterVol        $F6
	dc.b	nC2, $04
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $01
	smpsAlterVol        $F6
	dc.b	nG1, $0B

SegaJingle_Loop09:
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $01
	smpsAlterVol        $F6
	dc.b	nBb1, $0B
	smpsLoop            $00, $02, SegaJingle_Loop09

SegaJingle_Loop0A:
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $01
	smpsAlterVol        $F6
	dc.b	nG2, $0B
	smpsLoop            $00, $02, SegaJingle_Loop0A
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $08
	smpsAlterVol        $F6
	dc.b	nG2, $0B
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $01
	smpsAlterVol        $F6
	dc.b	nG1, $20
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $01
	smpsAlterVol        $F6
	dc.b	nF2, $0B
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $01
	smpsAlterVol        $F6
	dc.b	nFs2, $0B

SegaJingle_Loop0B:
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $01
	smpsAlterVol        $F6
	dc.b	nG2, $0B
	smpsLoop            $00, $02, SegaJingle_Loop0B
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $08
	smpsAlterVol        $F6
	dc.b	nG2, $0B
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $01
	smpsAlterVol        $F6
	dc.b	nG1, $0B
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $01
	smpsAlterVol        $F6
	dc.b	nG2, $04
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $01
	smpsAlterVol        $F6
	dc.b	nG2, $0B
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $01
	smpsAlterVol        $F6
	dc.b	nF2, $0B
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $01
	smpsAlterVol        $F6
	dc.b	nFs2, $0B
	smpsLoop            $01, $02, SegaJingle_Loop0A

SegaJingle_Loop0C:
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $01
	smpsAlterVol        $F6
	dc.b	nG2, $0B
	smpsLoop            $00, $02, SegaJingle_Loop0C
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $08
	smpsAlterVol        $F6
	dc.b	nG2, $0B
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $01
	smpsAlterVol        $F6
	dc.b	nG1, $20
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $01
	smpsAlterVol        $F6
	dc.b	nF2, $0B
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $01
	smpsAlterVol        $F6
	dc.b	nFs2, $0B
	smpsAlterVol        $0A
	dc.b	smpsNoAttack, $02, nRst, $01
	smpsAlterVol        $F6
	dc.b	nC2, $1C, nCs2, nD2, nEb2
	smpsJump SegaJingle_FM5

; PSG1 Data
SegaJingle_PSG1:
	smpsPSGAlterVol     $07

SegaJingle_Loop3F:
	dc.b	nC2, $07, nRst, nG2

SegaJingle_Loop3E:
	dc.b	nRst, nG1, $04, nRst, $03, nG2, $07, nRst, nC2, $04, nRst, $03
	dc.b	nG2, $07
	smpsLoop            $00, $02, SegaJingle_Loop3E
	dc.b	nRst
	smpsLoop            $01, $02, SegaJingle_Loop3F
	dc.b	nC2, nRst, nG2

SegaJingle_Loop40:
	dc.b	nRst, nG1, $04, nRst, $03, nG2, $07, nRst, nC2, $04, nRst, $03
	dc.b	nG2, $07
	smpsLoop            $00, $02, SegaJingle_Loop40
	dc.b	nRst, $77
	smpsPSGAlterVol     $FE

SegaJingle_Loop41:
	smpsAlterNote       $01
	dc.b	nC1, $07, nRst
	smpsAlterNote       $00
	dc.b	nE1, nRst, nF1, nG1, nF1
	smpsAlterNote       $01
	dc.b	nC1, $0E, nRst, $07
	smpsAlterNote       $00
	dc.b	nF1, nG1, nF1
	smpsAlterNote       $01
	dc.b	nBb1
	smpsAlterNote       $00
	dc.b	nG1, nRst
	smpsLoop            $00, $03, SegaJingle_Loop41
	smpsAlterNote       $01
	dc.b	nC1, nRst
	smpsAlterNote       $00
	dc.b	nE1, nRst, nF1, nG1, nF1
	smpsAlterNote       $01
	dc.b	nC1, $0E, nRst, $07
	smpsAlterNote       $00
	dc.b	nF1, nG1, nF1
	smpsAlterNote       $01
	dc.b	nBb1
	smpsAlterNote       $00
	dc.b	nC2
	smpsAlterNote       $01
	dc.b	nE2

SegaJingle_Loop42:
	dc.b	nC1, nRst
	smpsAlterNote       $00
	dc.b	nE1, nRst, nF1, nG1, nF1
	smpsAlterNote       $01
	dc.b	nC1, $0E, nRst, $07
	smpsAlterNote       $00
	dc.b	nF1, nG1, nF1
	smpsAlterNote       $01
	dc.b	nBb1
	smpsAlterNote       $00
	dc.b	nG1, nRst
	smpsAlterNote       $01
	smpsLoop            $00, $03, SegaJingle_Loop42
	dc.b	nC1, nRst
	smpsAlterNote       $00
	dc.b	nE1, nRst, nF1, nG1, nF1
	smpsAlterNote       $01
	dc.b	nC1, $0E, nRst, $07
	smpsAlterNote       $00
	dc.b	nF1, nG1, nF1
	smpsAlterNote       $01
	dc.b	nBb1
	smpsAlterNote       $00
	dc.b	nC2, nD4, nG4, $0B, nRst, $03, nFs4, $0B, nRst, $03, nF4, $07
	dc.b	nFs4, nF4
	smpsAlterNote       $FF
	dc.b	nE4
	smpsAlterNote       $00
	dc.b	nEb4, $0B, nRst, $03, nD4, $0B, nRst, $03
	smpsAlterNote       $FF
	dc.b	nCs4, $07
	smpsAlterNote       $00
	dc.b	nD4
	smpsAlterNote       $FF
	dc.b	nCs4, nC4
	smpsAlterNote       $00
	dc.b	nB3, $0B, nRst, $03, nBb3, $0B, nRst, $03
	smpsAlterNote       $FF
	dc.b	nA3, $07
	smpsAlterNote       $00
	dc.b	nBb3
	smpsAlterNote       $FF
	dc.b	nA3
	smpsAlterNote       $00
	dc.b	nAb3, nG3, $2A, nRst, $07, nD4, nG4, $0B, nRst, $03, nFs4, $0B
	dc.b	nRst, $03, nF4, $07, nFs4, nF4
	smpsAlterNote       $FF
	dc.b	nE4
	smpsAlterNote       $00
	dc.b	nEb4, $0B, nRst, $03, nD4, $0B, nRst, $03
	smpsAlterNote       $FF
	dc.b	nCs4, $07
	smpsAlterNote       $00
	dc.b	nD4
	smpsAlterNote       $FF
	dc.b	nCs4, nC4, nRst, $70

SegaJingle_Loop43:
	smpsAlterNote       $01
	dc.b	nC1, $07, nRst
	smpsAlterNote       $00
	dc.b	nE1, nRst, nF1, nG1, nF1
	smpsAlterNote       $01
	dc.b	nC1, $0E, nRst, $07
	smpsAlterNote       $00
	dc.b	nF1, nG1, nF1
	smpsAlterNote       $01
	dc.b	nBb1
	smpsAlterNote       $00
	dc.b	nG1, nRst
	smpsLoop            $00, $03, SegaJingle_Loop43
	smpsAlterNote       $01
	dc.b	nC1, nRst
	smpsAlterNote       $00
	dc.b	nE1, nRst, nF1, nG1, nF1
	smpsAlterNote       $01
	dc.b	nC1, $0E, nRst, $07
	smpsAlterNote       $00
	dc.b	nF1, nG1, nF1
	smpsAlterNote       $01
	dc.b	nBb1
	smpsAlterNote       $00
	dc.b	nC2
	smpsAlterNote       $01
	dc.b	nE2

SegaJingle_Loop44:
	dc.b	nC1, nRst
	smpsAlterNote       $00
	dc.b	nE1, nRst, nF1, nG1, nF1
	smpsAlterNote       $01
	dc.b	nC1, $0E, nRst, $07
	smpsAlterNote       $00
	dc.b	nF1, nG1, nF1
	smpsAlterNote       $01
	dc.b	nBb1
	smpsAlterNote       $00
	dc.b	nG1, nRst
	smpsAlterNote       $01
	smpsLoop            $00, $03, SegaJingle_Loop44
	dc.b	nC1, nRst
	smpsAlterNote       $00
	dc.b	nE1, nRst, nF1, nG1, nF1
	smpsAlterNote       $01
	dc.b	nC1, $0E, nRst, $07
	smpsAlterNote       $00
	dc.b	nF1, nG1, nF1
	smpsAlterNote       $01
	dc.b	nBb1
	smpsAlterNote       $00
	dc.b	nC2, nD4, nG4, $0B, nRst, $03, nFs4, $0B, nRst, $03, nF4, $07
	dc.b	nFs4, nF4
	smpsAlterNote       $FF
	dc.b	nE4
	smpsAlterNote       $00
	dc.b	nEb4, $0B, nRst, $03, nD4, $0B, nRst, $03
	smpsAlterNote       $FF
	dc.b	nCs4, $07
	smpsAlterNote       $00
	dc.b	nD4
	smpsAlterNote       $FF
	dc.b	nCs4, nC4
	smpsAlterNote       $00
	dc.b	nB3, $0B, nRst, $03, nBb3, $0B, nRst, $03, nBb3, $07, nB3
	smpsAlterNote       $FF
	dc.b	nC4, nCs4
	smpsAlterNote       $00
	dc.b	nD4, $2A, nRst, $07
	smpsAlterNote       $00
	dc.b	nD4, nG4, $0B, nRst, $03, nFs4, $0B, nRst, $03, nF4, $07, nFs4
	dc.b	nF4
	smpsAlterNote       $FF
	dc.b	nE4
	smpsAlterNote       $00
	dc.b	nEb4, $0B, nRst, $03, nD4, $0B, nRst, $03
	smpsAlterNote       $FF
	dc.b	nCs4, $07
	smpsAlterNote       $00
	dc.b	nD4
	smpsAlterNote       $FF
	dc.b	nCs4, nC4
	smpsAlterNote       $00
	dc.b	nB3, $0B, nRst, $03, nBb3, $0B, nRst, $03
	smpsAlterNote       $FF
	dc.b	nA3, $07
	smpsAlterNote       $00
	dc.b	nBb3
	smpsAlterNote       $FF
	dc.b	nA3
	smpsAlterNote       $00
	dc.b	nAb3, nG3, $2A, nRst, $07, nD4, nG4, $0B, nRst, $03, nFs4, $0B
	dc.b	nRst, $03, nF4, $07, nFs4, nF4
	smpsAlterNote       $FF
	dc.b	nE4
	smpsAlterNote       $00
	dc.b	nEb4, $0B, nRst, $03, nD4, $0B, nRst, $03
	smpsAlterNote       $FF
	dc.b	nCs4, $07
	smpsAlterNote       $00
	dc.b	nD4
	smpsAlterNote       $FF
	dc.b	nCs4, nC4, nRst, $70
	smpsJump SegaJingle_PSG1

; PSG2 Data
SegaJingle_PSG2:
	dc.b	nRst, $0E
	smpsPSGAlterVol     $07

SegaJingle_Loop36:
	smpsAlterNote       $01
	dc.b	nE2, $07, nRst, $0E
	smpsLoop            $00, $04, SegaJingle_Loop36
	smpsAlterNote       $01
	dc.b	nE2, $07, nRst, $15

SegaJingle_Loop37:
	smpsAlterNote       $01
	dc.b	nE2, $07, nRst, $0E
	smpsLoop            $00, $04, SegaJingle_Loop37
	smpsPSGAlterVol     $FE
	smpsAlterNote       $01
	dc.b	nE2, $07, nRst, $15
	smpsPSGAlterVol     $02

SegaJingle_Loop38:
	smpsAlterNote       $01
	dc.b	nE2, $07, nRst, $0E
	smpsLoop            $00, $04, SegaJingle_Loop38
	smpsAlterNote       $01
	dc.b	nE2, $07, nRst, $77
	smpsPSGAlterVol     $FE

SegaJingle_Loop39:
	dc.b	nG0, $07, nRst, nC1, nRst
	smpsAlterNote       $00
	dc.b	nD1, nE1, nD1
	smpsAlterNote       $01
	dc.b	nG0, $0E, nRst, $07
	smpsAlterNote       $00
	dc.b	nD1, nE1, nD1, nG1, nE1, nRst
	smpsAlterNote       $01
	smpsLoop            $00, $03, SegaJingle_Loop39
	dc.b	nG0, nRst, nC1, nRst
	smpsAlterNote       $00
	dc.b	nD1, nE1, nD1
	smpsAlterNote       $01
	dc.b	nG0, $0E, nRst, $07
	smpsAlterNote       $00
	dc.b	nD1, nE1, nD1, nG1, $0E, nC2, $07

SegaJingle_Loop3A:
	smpsAlterNote       $01
	dc.b	nG0, nRst, nC1, nRst
	smpsAlterNote       $00
	dc.b	nD1, nE1, nD1
	smpsAlterNote       $01
	dc.b	nG0, $0E, nRst, $07
	smpsAlterNote       $00
	dc.b	nD1, nE1, nD1, nG1, nE1, nRst
	smpsLoop            $00, $03, SegaJingle_Loop3A
	smpsAlterNote       $01
	dc.b	nG0, nRst, nC1, nRst
	smpsAlterNote       $00
	dc.b	nD1, nE1, nD1
	smpsAlterNote       $01
	dc.b	nG0, $0E, nRst, $07
	smpsAlterNote       $00
	dc.b	nD1, nE1, nD1, nG1, $0E, nC2, $07
	smpsPSGAlterVol     $FE
	dc.b	nG2, $04, nRst, $03, nAb2, $04, nRst, $03, nA2, $04, nRst, $03
	dc.b	nBb2, $04, nRst, $03, nB2, $04, nRst, $03, nC3, $04, nRst, $03
	dc.b	nCs3, $04, nRst, $03, nD3, $04, nRst, $03, nEb3, $04, nRst, $03
	dc.b	nE3, $04, nRst, $03, nF3, $04, nRst, $03
	smpsAlterNote       $01
	dc.b	nFs3, $04, nRst, $03
	smpsAlterNote       $00
	dc.b	nG3, $04, nRst, $03, nAb3, $04, nRst, $03, nA3, $04, nRst, $03
	dc.b	nBb3, $04, nRst, $03, nB3, $04, nRst, $03, nBb3, $04, nRst, $03
	dc.b	nA3, $04, nRst, $03, nAb3, $04, nRst, $03, nG3, $04, nRst, $03
	smpsAlterNote       $01
	dc.b	nFs3, $04, nRst, $03
	smpsAlterNote       $00
	dc.b	nF3, $04, nRst, $03, nE3, $04, nRst, $03, nEb3, $04, nRst, $03
	dc.b	nD3, $04, nRst, $03, nCs3, $04, nRst, $03, nC3, $04, nRst, $03
	dc.b	nB2, $04, nRst, $03, nBb2, $04, nRst, $03, nA2, $04, nRst, $03
	dc.b	nAb2, $04, nRst, $03, nG2, $04, nRst, $03, nAb2, $04, nRst, $03
	dc.b	nA2, $04, nRst, $03, nBb2, $04, nRst, $03, nB2, $04, nRst, $03
	dc.b	nC3, $04, nRst, $03, nCs3, $04, nRst, $03, nD3, $04, nRst, $03
	dc.b	nEb3, $04, nRst, $03, nE3, $04, nRst, $03, nF3, $04, nRst, $03
	smpsAlterNote       $01
	dc.b	nFs3, $04, nRst, $03
	smpsAlterNote       $00
	dc.b	nG3, $04, nRst, $03, nAb3, $04, nRst, $03, nA3, $04, nRst, $03
	dc.b	nBb3, $04, nRst, $73
	smpsPSGAlterVol     $02

SegaJingle_Loop3B:
	smpsAlterNote       $01
	dc.b	nG0, $07, nRst, nC1, nRst
	smpsAlterNote       $00
	dc.b	nD1, nE1, nD1
	smpsAlterNote       $01
	dc.b	nG0, $0E, nRst, $07
	smpsAlterNote       $00
	dc.b	nD1, nE1, nD1, nG1, nE1, nRst
	smpsLoop            $00, $03, SegaJingle_Loop3B
	smpsAlterNote       $01
	dc.b	nG0, nRst, nC1, nRst
	smpsAlterNote       $00
	dc.b	nD1, nE1, nD1
	smpsAlterNote       $01
	dc.b	nG0, $0E, nRst, $07
	smpsAlterNote       $00
	dc.b	nD1, nE1, nD1, nG1, $0E, nC2, $07

SegaJingle_Loop3C:
	smpsAlterNote       $01
	dc.b	nG0, nRst, nC1, nRst
	smpsAlterNote       $00
	dc.b	nD1, nE1, nD1
	smpsAlterNote       $01
	dc.b	nG0, $0E, nRst, $07
	smpsAlterNote       $00
	dc.b	nD1, nE1, nD1, nG1, nE1, nRst
	smpsLoop            $00, $03, SegaJingle_Loop3C
	smpsAlterNote       $01
	dc.b	nG0, nRst, nC1, nRst
	smpsAlterNote       $00
	dc.b	nD1, nE1, nD1
	smpsAlterNote       $01
	dc.b	nG0, $0E, nRst, $07
	smpsAlterNote       $00
	dc.b	nD1, nE1, nD1, nG1, $0E, nC2, $07
	smpsPSGAlterVol     $FE

SegaJingle_Loop3D:
	dc.b	nG2, $04, nRst, $03, nAb2, $04, nRst, $03, nA2, $04, nRst, $03
	dc.b	nBb2, $04, nRst, $03, nB2, $04, nRst, $03, nC3, $04, nRst, $03
	dc.b	nCs3, $04, nRst, $03, nD3, $04, nRst, $03, nEb3, $04, nRst, $03
	dc.b	nE3, $04, nRst, $03, nF3, $04, nRst, $03
	smpsAlterNote       $01
	dc.b	nFs3, $04, nRst, $03
	smpsAlterNote       $00
	dc.b	nG3, $04, nRst, $03, nAb3, $04, nRst, $03, nA3, $04, nRst, $03
	dc.b	nBb3, $04, nRst, $03, nB3, $04, nRst, $03, nBb3, $04, nRst, $03
	dc.b	nA3, $04, nRst, $03, nAb3, $04, nRst, $03, nG3, $04, nRst, $03
	smpsAlterNote       $01
	dc.b	nFs3, $04, nRst, $03
	smpsAlterNote       $00
	dc.b	nF3, $04, nRst, $03, nE3, $04, nRst, $03, nEb3, $04, nRst, $03
	dc.b	nD3, $04, nRst, $03, nCs3, $04, nRst, $03, nC3, $04, nRst, $03
	dc.b	nB2, $04, nRst, $03, nBb2, $04, nRst, $03, nA2, $04, nRst, $03
	dc.b	nAb2, $04, nRst, $03
	smpsLoop            $00, $02, SegaJingle_Loop3D
	dc.b	nG2, $04, nRst, $03, nAb2, $04, nRst, $03, nA2, $04, nRst, $03
	dc.b	nBb2, $04, nRst, $03, nB2, $04, nRst, $03, nC3, $04, nRst, $03
	dc.b	nCs3, $04, nRst, $03, nD3, $04, nRst, $03, nEb3, $04, nRst, $03
	dc.b	nE3, $04, nRst, $03, nF3, $04, nRst, $03
	smpsAlterNote       $01
	dc.b	nFs3, $04, nRst, $03
	smpsAlterNote       $00
	dc.b	nG3, $04, nRst, $03, nAb3, $04, nRst, $03, nA3, $04, nRst, $03
	dc.b	nBb3, $04, nRst, $73
	smpsJump SegaJingle_PSG2

; PSG3 Data
SegaJingle_PSG3:
	smpsPSGAlterVol     $01
	smpsPSGform         $E7

SegaJingle_Loop1F:
	smpsAlterNote       $01
	dc.b	nMaxPSG, $01
	smpsPSGAlterVol     $06
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $03
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $02
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $02
	smpsAlterNote       $01
	dc.b	nMaxPSG, nRst, $02
	smpsPSGAlterVol     $F3
	smpsLoop            $00, $02, SegaJingle_Loop1F
	smpsAlterNote       $01
	dc.b	nMaxPSG, $01

SegaJingle_Loop21:
	smpsPSGAlterVol     $04
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $04
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $02
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $01
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $01
	smpsAlterNote       $01
	dc.b	$02
	smpsPSGAlterVol     $01
	smpsAlterNote       $01
	dc.b	$07
	smpsPSGAlterVol     $F3
	smpsAlterNote       $01
	dc.b	$01

SegaJingle_Loop20:
	smpsPSGAlterVol     $06
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $03
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $02
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $02
	smpsAlterNote       $01
	dc.b	nMaxPSG, nRst, $02
	smpsPSGAlterVol     $F3
	smpsAlterNote       $01
	dc.b	nMaxPSG, $01
	smpsLoop            $00, $06, SegaJingle_Loop20
	smpsLoop            $01, $05, SegaJingle_Loop21
	smpsPSGAlterVol     $04
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $04
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $02
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $01
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $01
	smpsAlterNote       $01
	dc.b	$02
	smpsPSGAlterVol     $01
	smpsAlterNote       $01
	dc.b	$07
	smpsPSGAlterVol     $F3
	smpsAlterNote       $01
	dc.b	$01

SegaJingle_Loop22:
	smpsPSGAlterVol     $06
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $03
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $02
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $02
	smpsAlterNote       $01
	dc.b	nMaxPSG, nRst, $02
	smpsPSGAlterVol     $F3
	smpsAlterNote       $01
	dc.b	nMaxPSG, $01
	smpsLoop            $00, $04, SegaJingle_Loop22
	smpsPSGAlterVol     $06
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $03
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $02
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $02
	smpsAlterNote       $01
	dc.b	nMaxPSG, nRst, $17

SegaJingle_Loop23:
	smpsPSGAlterVol     $FF
	smpsAlterNote       $01
	dc.b	nMaxPSG, $01, nRst, $06
	smpsLoop            $00, $05, SegaJingle_Loop23
	smpsPSGAlterVol     $FF

SegaJingle_Loop24:
	smpsAlterNote       $01
	dc.b	nMaxPSG, $01
	smpsPSGAlterVol     $06
	smpsAlterNote       $01
	dc.b	nMaxPSG, nRst, $05
	smpsPSGAlterVol     $F9
	smpsLoop            $00, $03, SegaJingle_Loop24

SegaJingle_Loop25:
	smpsAlterNote       $01
	dc.b	nMaxPSG, $01
	smpsPSGAlterVol     $06
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $03
	smpsAlterNote       $01
	dc.b	nMaxPSG, nRst, $04
	smpsPSGAlterVol     $F6
	smpsLoop            $00, $02, SegaJingle_Loop25

SegaJingle_Loop26:
	smpsAlterNote       $01
	dc.b	nMaxPSG, $01
	smpsPSGAlterVol     $06
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $03
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $02
	smpsAlterNote       $01
	dc.b	nMaxPSG, nRst, $03
	smpsPSGAlterVol     $F4
	smpsLoop            $00, $02, SegaJingle_Loop26

SegaJingle_Loop27:
	smpsAlterNote       $01
	dc.b	nMaxPSG, $01
	smpsPSGAlterVol     $06
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $03
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $02
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $02
	smpsAlterNote       $01
	dc.b	nMaxPSG, nRst, $02
	smpsPSGAlterVol     $F3
	smpsLoop            $00, $02, SegaJingle_Loop27
	smpsAlterNote       $01
	dc.b	nMaxPSG, $01

SegaJingle_Loop29:
	smpsPSGAlterVol     $04
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $04
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $02
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $01
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $01
	smpsAlterNote       $01
	dc.b	$02
	smpsPSGAlterVol     $01
	smpsAlterNote       $01
	dc.b	$07
	smpsPSGAlterVol     $F3
	smpsAlterNote       $01
	dc.b	$01

SegaJingle_Loop28:
	smpsPSGAlterVol     $06
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $03
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $02
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $02
	smpsAlterNote       $01
	dc.b	nMaxPSG, nRst, $02
	smpsPSGAlterVol     $F3
	smpsAlterNote       $01
	dc.b	nMaxPSG, $01
	smpsLoop            $00, $06, SegaJingle_Loop28
	smpsLoop            $01, $15, SegaJingle_Loop29
	smpsPSGAlterVol     $04
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $04
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $02
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $01
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $01
	smpsAlterNote       $01
	dc.b	$02
	smpsPSGAlterVol     $01
	smpsAlterNote       $01
	dc.b	$07
	smpsPSGAlterVol     $F3
	smpsAlterNote       $01
	dc.b	$01

SegaJingle_Loop2A:
	smpsPSGAlterVol     $06
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $03
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $02
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $02
	smpsAlterNote       $01
	dc.b	nMaxPSG, nRst, $02
	smpsPSGAlterVol     $F3
	smpsAlterNote       $01
	dc.b	nMaxPSG, $01
	smpsLoop            $00, $04, SegaJingle_Loop2A
	smpsPSGAlterVol     $06
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $03
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $02
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $02
	smpsAlterNote       $01
	dc.b	nMaxPSG, nRst, $17

SegaJingle_Loop2B:
	smpsPSGAlterVol     $FF
	smpsAlterNote       $01
	dc.b	nMaxPSG, $01, nRst, $06
	smpsLoop            $00, $05, SegaJingle_Loop2B
	smpsPSGAlterVol     $FF

SegaJingle_Loop2C:
	smpsAlterNote       $01
	dc.b	nMaxPSG, $01
	smpsPSGAlterVol     $06
	smpsAlterNote       $01
	dc.b	nMaxPSG, nRst, $05
	smpsPSGAlterVol     $F9
	smpsLoop            $00, $03, SegaJingle_Loop2C

SegaJingle_Loop2D:
	smpsAlterNote       $01
	dc.b	nMaxPSG, $01
	smpsPSGAlterVol     $06
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $03
	smpsAlterNote       $01
	dc.b	nMaxPSG, nRst, $04
	smpsPSGAlterVol     $F6
	smpsLoop            $00, $02, SegaJingle_Loop2D

SegaJingle_Loop2E:
	smpsAlterNote       $01
	dc.b	nMaxPSG, $01
	smpsPSGAlterVol     $06
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $03
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $02
	smpsAlterNote       $01
	dc.b	nMaxPSG, nRst, $03
	smpsPSGAlterVol     $F4
	smpsLoop            $00, $02, SegaJingle_Loop2E

SegaJingle_Loop2F:
	smpsAlterNote       $01
	dc.b	nMaxPSG, $01
	smpsPSGAlterVol     $06
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $03
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $02
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $02
	smpsAlterNote       $01
	dc.b	nMaxPSG, nRst, $02
	smpsPSGAlterVol     $F3
	smpsLoop            $00, $02, SegaJingle_Loop2F
	smpsAlterNote       $01
	dc.b	nMaxPSG, $01

SegaJingle_Loop31:
	smpsPSGAlterVol     $04
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $04
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $02
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $01
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $01
	smpsAlterNote       $01
	dc.b	$02
	smpsPSGAlterVol     $01
	smpsAlterNote       $01
	dc.b	$07
	smpsPSGAlterVol     $F3
	smpsAlterNote       $01
	dc.b	$01

SegaJingle_Loop30:
	smpsPSGAlterVol     $06
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $03
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $02
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $02
	smpsAlterNote       $01
	dc.b	nMaxPSG, nRst, $02
	smpsPSGAlterVol     $F3
	smpsAlterNote       $01
	dc.b	nMaxPSG, $01
	smpsLoop            $00, $06, SegaJingle_Loop30
	smpsLoop            $01, $19, SegaJingle_Loop31
	smpsPSGAlterVol     $04
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $04
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $02
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $01
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $01
	smpsAlterNote       $01
	dc.b	$02
	smpsPSGAlterVol     $01
	smpsAlterNote       $01
	dc.b	$07
	smpsPSGAlterVol     $F3
	smpsAlterNote       $01
	dc.b	$01

SegaJingle_Loop32:
	smpsPSGAlterVol     $06
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $03
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $02
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $02
	smpsAlterNote       $01
	dc.b	nMaxPSG, nRst, $02
	smpsPSGAlterVol     $F3
	smpsAlterNote       $01
	dc.b	nMaxPSG, $01
	smpsLoop            $00, $04, SegaJingle_Loop32
	smpsPSGAlterVol     $06
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $03
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $02
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $02
	smpsAlterNote       $01
	dc.b	nMaxPSG, nRst, $17

SegaJingle_Loop33:
	smpsPSGAlterVol     $FF
	smpsAlterNote       $01
	dc.b	nMaxPSG, $01, nRst, $06
	smpsLoop            $00, $05, SegaJingle_Loop33
	smpsPSGAlterVol     $FF

SegaJingle_Loop34:
	smpsAlterNote       $01
	dc.b	nMaxPSG, $01
	smpsPSGAlterVol     $06
	smpsAlterNote       $01
	dc.b	nMaxPSG, nRst, $05
	smpsPSGAlterVol     $F9
	smpsLoop            $00, $03, SegaJingle_Loop34

SegaJingle_Loop35:
	smpsAlterNote       $01
	dc.b	nMaxPSG, $01
	smpsPSGAlterVol     $06
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $03
	smpsAlterNote       $01
	dc.b	nMaxPSG, nRst, $04
	smpsPSGAlterVol     $F6
	smpsLoop            $00, $02, SegaJingle_Loop35
	smpsAlterNote       $01
	dc.b	nMaxPSG, $01
	smpsPSGAlterVol     $06
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $03
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $02
	smpsAlterNote       $01
	dc.b	nMaxPSG, nRst, $03
	smpsPSGAlterVol     $F4
	smpsAlterNote       $01
	dc.b	nMaxPSG, $01
	smpsPSGAlterVol     $06
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $03
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $02
	smpsAlterNote       $01
	dc.b	nMaxPSG, nRst, $03
	smpsJump SegaJingle_PSG3

; DAC Data
SegaJingle_DAC:
	dc.b	dKick, $07, dClap, dSnare, $0E, dKick, $07, $84, dClap, $84, dKick, dClap
	dc.b	dSnare, $0E, dKick, $07, dClap, $84, $84
	smpsLoop            $00, $02, SegaJingle_DAC
	dc.b	dKick, dClap, dSnare, $0E, dKick, $07, $84, dClap, $84, dKick, dClap, dSnare
	dc.b	$0E, dKick, $07, dSnare, dSnare, dSnare, $85, $31, dKick, $07, $0E, dKick
	dc.b	$86, $1C, dKick, $0E, dClap, dSnare, dClap, $07, dKick, $0E, dSnare, $07
	dc.b	dKick, $0E, dSnare, dClap, dKick, dClap, dSnare, dClap, $07, dKick, $0E, dSnare
	dc.b	$07, dKick, $0E, dSnare, $84, dKick, dClap, dSnare, dClap, $07, dKick, $0E
	dc.b	dClap, $07, dKick, $0E, dSnare, dClap, dKick, dClap, dSnare, dClap, $07, dKick
	dc.b	$0E, dClap, $07, dKick, $0E, dSnare, dSnare, $07, dSnare, dKick, $0E, dClap
	dc.b	dSnare, dClap, $07, dKick, $0E, dSnare, $07, dKick, $0E, dSnare, dClap, dKick
	dc.b	dClap, dSnare, dClap, $07, dKick, $0E, dSnare, $07, dKick, $0E, dSnare, $84
	dc.b	dKick, dClap, dSnare, dClap, $07, dKick, $0E, dClap, $07, dKick, $0E, dSnare
	dc.b	dClap, dKick, dClap, dSnare, dClap, $07, dKick, $0E, dSnare, $07, dClap, $84
	dc.b	dSnare, dSnare, dSnare, dSnare

SegaJingle_Loop00:
	dc.b	dKick, $0E, dClap, dSnare, dClap, $07, dSnare, $0E, $07, dKick, $0E, dSnare
	dc.b	$84, $07, $84
	smpsLoop            $00, $02, SegaJingle_Loop00
	dc.b	dKick, $0E, dClap, dSnare, dClap, $07, dSnare, $0E, $07, dKick, $0E, dSnare
	dc.b	$07, $84, dSnare, dSnare, $85, $31, dKick, $07, $0E, dKick, $86, $1C
	dc.b	dKick, $0E, dClap, dSnare, dClap, $07, dKick, $0E, dSnare, $07, dKick, $0E
	dc.b	dSnare, dClap, dKick, dClap, dSnare, dClap, $07, dKick, $0E, dSnare, $07, dKick
	dc.b	$0E, dSnare, $84, dKick, dClap, dSnare, dClap, $07, dKick, $0E, dClap, $07
	dc.b	dKick, $0E, dSnare, dClap, dKick, dClap, dSnare, dClap, $07, dKick, $0E, dClap
	dc.b	$07, dKick, $0E, dSnare, dSnare, $07, dSnare, dKick, $0E, dClap, dSnare, dClap
	dc.b	$07, dKick, $0E, dSnare, $07, dKick, $0E, dSnare, dClap, dKick, dClap, dSnare
	dc.b	dClap, $07, dKick, $0E, dSnare, $07, dKick, $0E, dSnare, $84, dKick, dClap
	dc.b	dSnare, dClap, $07, dKick, $0E, dClap, $07, dKick, $0E, dSnare, dClap, dKick
	dc.b	dClap, dSnare, dClap, $07, dKick, $0E, dSnare, $07, dClap, $84, dSnare, dSnare
	dc.b	dSnare, dSnare

SegaJingle_Loop01:
	dc.b	dKick, $0E, dClap, dSnare, dClap, $07, dSnare, $0E, $07, dKick, $0E, dSnare
	dc.b	$84, $07, $84
	smpsLoop            $00, $05, SegaJingle_Loop01
	dc.b	$85, $1C, $85, $85, $15, dKick, $07, $85, $0E, dKick
	smpsJump SegaJingle_DAC

SegaJingle_Voices:
;	Voice $00
;	$3A
;	$34, $24, $73, $01, 	$5F, $1F, $1F, $9F, 	$0A, $0A, $04, $05
;	$03, $04, $02, $02, 	$2F, $2F, $1F, $2F, 	$1F, $2C, $22, $00
	smpsVcAlgorithm     $02
	smpsVcFeedback      $07
	smpsVcUnusedBits    $00
	smpsVcDetune        $00, $07, $02, $03
	smpsVcCoarseFreq    $01, $03, $04, $04
	smpsVcRateScale     $02, $00, $00, $01
	smpsVcAttackRate    $1F, $1F, $1F, $1F
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $05, $04, $0A, $0A
	smpsVcDecayRate2    $02, $02, $04, $03
	smpsVcDecayLevel    $02, $01, $02, $02
	smpsVcReleaseRate   $0F, $0F, $0F, $0F
	smpsVcTotalLevel    $00, $22, $2C, $1F

;	Voice $01
;	$03
;	$02, $03, $10, $11, 	$15, $10, $12, $18, 	$10, $0C, $1C, $0D
;	$00, $1A, $00, $16, 	$3F, $5F, $6F, $5B, 	$0F, $18, $1C, $00
	smpsVcAlgorithm     $03
	smpsVcFeedback      $00
	smpsVcUnusedBits    $00
	smpsVcDetune        $01, $01, $00, $00
	smpsVcCoarseFreq    $01, $00, $03, $02
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $18, $12, $10, $15
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $0D, $1C, $0C, $10
	smpsVcDecayRate2    $16, $00, $1A, $00
	smpsVcDecayLevel    $05, $06, $05, $03
	smpsVcReleaseRate   $0B, $0F, $0F, $0F
	smpsVcTotalLevel    $00, $1C, $18, $0F

;	Voice $02
;	$25
;	$31, $12, $0A, $22, 	$1F, $1F, $1F, $1F, 	$0E, $0B, $10, $0E
;	$10, $00, $00, $00, 	$E7, $3F, $3F, $3F, 	$0B, $00, $00, $00
	smpsVcAlgorithm     $05
	smpsVcFeedback      $04
	smpsVcUnusedBits    $00
	smpsVcDetune        $02, $00, $01, $03
	smpsVcCoarseFreq    $02, $0A, $02, $01
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $1F, $1F, $1F, $1F
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $0E, $10, $0B, $0E
	smpsVcDecayRate2    $00, $00, $00, $10
	smpsVcDecayLevel    $03, $03, $03, $0E
	smpsVcReleaseRate   $0F, $0F, $0F, $07
	smpsVcTotalLevel    $00, $00, $00, $0B

;	Voice $03
;	$3B
;	$01, $02, $04, $02, 	$18, $1B, $19, $16, 	$1C, $19, $1D, $1F
;	$0A, $02, $02, $03, 	$0F, $1F, $1F, $1E, 	$26, $1B, $1B, $00
	smpsVcAlgorithm     $03
	smpsVcFeedback      $07
	smpsVcUnusedBits    $00
	smpsVcDetune        $00, $00, $00, $00
	smpsVcCoarseFreq    $02, $04, $02, $01
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $16, $19, $1B, $18
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $1F, $1D, $19, $1C
	smpsVcDecayRate2    $03, $02, $02, $0A
	smpsVcDecayLevel    $01, $01, $01, $00
	smpsVcReleaseRate   $0E, $0F, $0F, $0F
	smpsVcTotalLevel    $00, $1B, $1B, $26

;	Voice $04
;	$3B
;	$04, $05, $03, $02, 	$59, $1C, $1E, $1F, 	$0C, $04, $08, $07
;	$02, $03, $03, $04, 	$EF, $DF, $DF, $DF, 	$10, $2C, $2A, $00
	smpsVcAlgorithm     $03
	smpsVcFeedback      $07
	smpsVcUnusedBits    $00
	smpsVcDetune        $00, $00, $00, $00
	smpsVcCoarseFreq    $02, $03, $05, $04
	smpsVcRateScale     $00, $00, $00, $01
	smpsVcAttackRate    $1F, $1E, $1C, $19
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $07, $08, $04, $0C
	smpsVcDecayRate2    $04, $03, $03, $02
	smpsVcDecayLevel    $0D, $0D, $0D, $0E
	smpsVcReleaseRate   $0F, $0F, $0F, $0F
	smpsVcTotalLevel    $00, $2A, $2C, $10

;	Voice $05
;	$3B
;	$72, $02, $32, $02, 	$4C, $1B, $12, $12, 	$05, $07, $02, $10
;	$03, $00, $00, $00, 	$EF, $FF, $2F, $1F, 	$2A, $27, $30, $00
	smpsVcAlgorithm     $03
	smpsVcFeedback      $07
	smpsVcUnusedBits    $00
	smpsVcDetune        $00, $03, $00, $07
	smpsVcCoarseFreq    $02, $02, $02, $02
	smpsVcRateScale     $00, $00, $00, $01
	smpsVcAttackRate    $12, $12, $1B, $0C
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $10, $02, $07, $05
	smpsVcDecayRate2    $00, $00, $00, $03
	smpsVcDecayLevel    $01, $02, $0F, $0E
	smpsVcReleaseRate   $0F, $0F, $0F, $0F
	smpsVcTotalLevel    $00, $30, $27, $2A

