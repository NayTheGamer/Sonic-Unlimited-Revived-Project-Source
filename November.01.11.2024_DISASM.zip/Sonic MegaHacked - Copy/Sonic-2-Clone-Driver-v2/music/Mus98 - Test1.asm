SegaJingle_Header:
	smpsHeaderStartSong 1
	smpsHeaderVoice     SegaJingle_Voices
	smpsHeaderChan      $07, $03
	smpsHeaderTempo     $02, $00

	smpsHeaderDAC       SegaJingle_DAC
	smpsHeaderFM        SegaJingle_FM1,	$00, $0E
	smpsHeaderFM        SegaJingle_FM2,	$00, $15
	smpsHeaderFM        SegaJingle_FM3,	$00, $1A
	smpsHeaderFM        SegaJingle_FM4,	$00, $15
	smpsHeaderFM        SegaJingle_FM5,	$00, $0E
	smpsHeaderFM        SegaJingle_FM6,	$00, $1B
	smpsHeaderPSG       SegaJingle_PSG1,	$00, $06, $00, $00
	smpsHeaderPSG       SegaJingle_PSG2,	$00, $05, $00, $00
	smpsHeaderPSG       SegaJingle_PSG3,	$00, $00, $00, fTone_02

; DAC Data
SegaJingle_DAC:
	smpsPan             panRight, $00
	dc.b	$85, $06, dKick, $06, dSnare, $06, dKick, $06, dSnare, $06, dKick, $06
	dc.b	dSnare, $06, dKick, $06, dSnare, $06, dKick, $06, dSnare, $06, dKick, $06
	dc.b	dSnare, $06, dKick, $06, dSnare, $06, dKick, $06, dSnare, $06, dKick, $06
	dc.b	dSnare, $06, dKick, $06, dSnare, $06, dKick, $06, dSnare, $06, dKick, $06
	dc.b	dSnare, $06, dKick, $06, dSnare, $06, dKick, $09, dKick, $03, dKick, $03
	dc.b	dSnare, $09, dKick, $03, dSnare, $03, $85, $06, dKick, $06, dSnare, $06
	dc.b	dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06
	dc.b	dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06
	dc.b	dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06
	dc.b	dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06
	dc.b	dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06
	dc.b	dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06
	dc.b	dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06
	dc.b	dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06
	dc.b	dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06
	dc.b	dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06
	dc.b	dKick, $06, $85, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06
	dc.b	dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06
	dc.b	dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06
	dc.b	dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06
	dc.b	dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06
	dc.b	dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06
	dc.b	dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06
	dc.b	dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06
	dc.b	dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06
	dc.b	dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06
	dc.b	dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06, $85, $06
	dc.b	dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06
	dc.b	dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06
	dc.b	dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06
	dc.b	dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06
	dc.b	dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06
	dc.b	dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06
	dc.b	dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06
	dc.b	dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06
	dc.b	dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06
	dc.b	dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06
	dc.b	dSnare, $06, dSnare, $03, dSnare, $03, dKick, $06, $85, $06, dKick, $06
	dc.b	dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06
	dc.b	dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06
	dc.b	dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06
	dc.b	dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06
	dc.b	dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06
	dc.b	dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06
	dc.b	dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06
	dc.b	dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06
	dc.b	dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06
	dc.b	dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $03, dSnare, $03
	dc.b	dKick, $03, dSnare, $03, dSnare, $03, dSnare, $03, dKick, $03, dSnare, $03
	dc.b	$85, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06
	dc.b	dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06
	dc.b	dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06
	dc.b	dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06
	dc.b	dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06
	dc.b	dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06
	dc.b	dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06
	dc.b	dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06
	dc.b	dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06
	dc.b	dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06
	dc.b	dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06
	dc.b	dSnare, $06, dKick, $0C, dKick, $06, dSnare, $06, dKick, $06, dKick, $06
	dc.b	dKick, $06, dSnare, $06, dKick, $0C, dKick, $06, dSnare, $06, dKick, $06
	dc.b	dKick, $06, dKick, $06, dSnare, $06, dKick, $0C, dKick, $06, dSnare, $06
	dc.b	dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $0C, dKick, $06
	dc.b	dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $0C
	dc.b	dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06
	dc.b	dKick, $0C, dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06
	dc.b	dSnare, $06, dKick, $0C, dKick, $06, dSnare, $06, dKick, $06, dKick, $06
	dc.b	dKick, $06, dSnare, $06, dKick, $0C, dKick, $06, dSnare, $06, dKick, $06
	dc.b	dKick, $06, dKick, $06, dSnare, $06, dKick, $0C, dKick, $06, dSnare, $06
	dc.b	dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $0C, dKick, $06
	dc.b	dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $0C
	dc.b	dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06
	dc.b	dKick, $06, dSnare, $03, dSnare, $03, dSnare, $03, dSnare, $03, dSnare, $06
	dc.b	dSnare, $03, dSnare, $03, $85, $06, dKick, $06, dSnare, $06, dKick, $06
	dc.b	dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06
	dc.b	dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06
	dc.b	dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06
	dc.b	dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06
	dc.b	dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06
	dc.b	dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06
	dc.b	dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06
	dc.b	dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06
	dc.b	dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06
	dc.b	dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06
	dc.b	$85, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06
	dc.b	dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06
	dc.b	dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06
	dc.b	dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06
	dc.b	dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06
	dc.b	dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06
	dc.b	dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06
	dc.b	dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06
	dc.b	dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06
	dc.b	dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06
	dc.b	dKick, $06, dKick, $06, dSnare, $06, dKick, $06, $85, $06, dKick, $06
	dc.b	dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06
	dc.b	dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06
	dc.b	dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06
	dc.b	dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06
	dc.b	dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06
	dc.b	dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06
	dc.b	dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06
	dc.b	dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06
	dc.b	dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06
	dc.b	dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dSnare, $06
	dc.b	dSnare, $03, dSnare, $03, dKick, $06, $85, $06, dKick, $06, dSnare, $06
	dc.b	dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06
	dc.b	dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06
	dc.b	dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06
	dc.b	dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06
	dc.b	dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06
	dc.b	dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06
	dc.b	dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06
	dc.b	dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06
	dc.b	dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06
	dc.b	dKick, $06, dSnare, $06, dKick, $06, dKick, $03, dSnare, $03, dKick, $03
	dc.b	dSnare, $03, dSnare, $03, dSnare, $03, dKick, $03, dSnare, $03, $85, $06
	dc.b	dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06
	dc.b	dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06
	dc.b	dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06
	dc.b	dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06
	dc.b	dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06
	dc.b	dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06
	dc.b	dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06
	dc.b	dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06
	dc.b	dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06
	dc.b	dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06
	dc.b	dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06
	dc.b	dKick, $0C, dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06
	dc.b	dSnare, $06, dKick, $0C, dKick, $06, dSnare, $06, dKick, $06, dKick, $06
	dc.b	dKick, $06, dSnare, $06, dKick, $0C, dKick, $06, dSnare, $06, dKick, $06
	dc.b	dKick, $06, dKick, $06, dSnare, $06, dKick, $0C, dKick, $06, dSnare, $06
	dc.b	dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $0C, dKick, $06
	dc.b	dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $0C
	dc.b	dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06
	dc.b	dKick, $0C, dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06
	dc.b	dSnare, $06, dKick, $0C, dKick, $06, dSnare, $06, dKick, $06, dKick, $06
	dc.b	dKick, $06, dSnare, $06, dKick, $0C, dKick, $06, dSnare, $06, dKick, $06
	dc.b	dKick, $06, dKick, $06, dSnare, $06, dKick, $0C, dKick, $06, dSnare, $06
	dc.b	dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $0C, dKick, $06
	dc.b	dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06
	dc.b	dSnare, $03, dSnare, $03, dSnare, $03, dSnare, $03, dSnare, $06, dSnare, $03
	dc.b	dSnare, $03, $85, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06
	dc.b	dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06
	dc.b	dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06
	dc.b	dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06
	dc.b	dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06
	dc.b	dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06
	dc.b	dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06
	dc.b	dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06
	dc.b	dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06
	dc.b	dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06
	dc.b	dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06, $85, $06
	dc.b	dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06
	dc.b	dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06
	dc.b	dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06
	dc.b	dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06
	dc.b	dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06
	dc.b	dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06
	dc.b	dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06
	dc.b	dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06
	dc.b	dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06
	dc.b	dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06
	dc.b	dKick, $06, dSnare, $06, dKick, $06, $85, $06, dKick, $06, dSnare, $06
	dc.b	dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06
	dc.b	dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06
	dc.b	dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06
	dc.b	dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06
	dc.b	dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06
	dc.b	dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06
	dc.b	dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06
	dc.b	dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06
	dc.b	dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06
	dc.b	dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dSnare, $06, dSnare, $03
	dc.b	dSnare, $03, dKick, $06, $85, $06, dKick, $06, dSnare, $06, dKick, $06
	dc.b	dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06
	dc.b	dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06
	dc.b	dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06
	dc.b	dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06
	dc.b	dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06
	dc.b	dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06
	dc.b	dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06
	dc.b	dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06
	dc.b	dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06
	dc.b	dSnare, $06, dKick, $06, dKick, $03, dSnare, $03, dKick, $03, dSnare, $03
	dc.b	dSnare, $03, dSnare, $03, dKick, $03, dSnare, $03, $85, $06, dKick, $06
	dc.b	dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06
	dc.b	dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06
	dc.b	dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06
	dc.b	dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06
	dc.b	dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06
	dc.b	dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06
	dc.b	dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06
	dc.b	dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06
	dc.b	dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06
	dc.b	dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06
	dc.b	dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $0C
	dc.b	dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06
	dc.b	dKick, $0C, dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06
	dc.b	dSnare, $06, dKick, $0C, dKick, $06, dSnare, $06, dKick, $06, dKick, $06
	dc.b	dKick, $06, dSnare, $06, dKick, $0C, dKick, $06, dSnare, $06, dKick, $06
	dc.b	dKick, $06, dKick, $06, dSnare, $06, dKick, $0C, dKick, $06, dSnare, $06
	dc.b	dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $0C, dKick, $06
	dc.b	dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $0C
	dc.b	dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06, dSnare, $06
	dc.b	dKick, $0C, dKick, $06, dSnare, $06, dKick, $06, dKick, $06, dKick, $06
	dc.b	dSnare, $06, dKick, $0C, dKick, $06, dSnare, $06, dKick, $06, dKick, $06
	dc.b	dKick, $06, dSnare, $06, dKick, $0C, dKick, $06, dSnare, $06, dKick, $06
	dc.b	dKick, $06, dKick, $06, dSnare, $06, dKick, $0C, dKick, $06, dSnare, $06
	dc.b	dKick, $06, dKick, $06, dKick, $06, dSnare, $06, dKick, $06, dSnare, $03
	dc.b	dSnare, $03, dSnare, $03, dSnare, $03, dSnare, $06, dSnare, $03, dSnare, $09
	smpsStop

; FM1 Data
SegaJingle_FM1:
	smpsSetvoice        $00
	dc.b	nD2, $06, nRst, $06, nD2, $09, nRst, $09, nD2, $06, nRst, $06
	dc.b	nE2, $06, nRst, $06, nE2, $05, nRst, $01, nG2, $05, nRst, $01
	dc.b	nE2, $05, nRst, $01, nC3, $05, nRst, $01, nD3, $05, nRst, $01
	dc.b	nE3, $0C, nF2, $06, nRst, $06, nF2, $09, nRst, $09, nF2, $06
	dc.b	nRst, $06, nG2, $06, nRst, $06, nG3, $05, nRst, $01, nB2, $05
	dc.b	nRst, $01, nG2, $05, nRst, $01, nB2, $05, nRst, $01, nD3, $05
	dc.b	nRst, $01, nG3, $05, nRst, $01, nG2, $05, nRst, $01, nA2, $0C
	dc.b	nG2, $06, nA2, $0C, nG2, $06, nA2, $06, nG2, $06, nD3, $03
	dc.b	nRst, $03, nD3, $03, nRst, $03, nCs3, $06, nD3, $0C, nCs3, $06
	dc.b	nD3, $06, nA2, $06, nE2, $03, nRst, $03, nE2, $03, nRst, $03
	dc.b	nD2, $06, nE2, $0C, nD2, $06, nE2, $06, nD2, $06, nA2, $03
	dc.b	nRst, $03, nA2, $09, nE2, $03, nG2, $0C, nG2, $06, nE2, $0C
	dc.b	nA2, $03, nRst, $03, nA2, $06, nG2, $06, nA2, $0C, nG2, $06
	dc.b	nA2, $06, nG2, $06, nD3, $03, nRst, $03, nD3, $03, nRst, $03
	dc.b	nCs3, $06, nD3, $0C, nCs3, $06, nD3, $06, nA2, $06, nG2, $03
	dc.b	nRst, $03, nG2, $03, nRst, $03, nFs2, $06, nG2, $09, nRst, $03
	dc.b	nG2, $06, nFs2, $06, nG2, $06, nE2, $05, nRst, $01, nE2, $05
	dc.b	nRst, $01, nFs2, $05, nRst, $01, nFs2, $05, nRst, $01, nG2, $05
	dc.b	nRst, $01, nG2, $05, nRst, $01, nAb2, $05, nRst, $01, nAb2, $05
	dc.b	nRst, $01, nA2, $03, nRst, $03, nA2, $06, nG2, $06, nA2, $0C
	dc.b	nG2, $06, nA2, $06, nG2, $06, nD3, $03, nRst, $03, nD3, $03
	dc.b	nRst, $03, nCs3, $06, nD3, $0C, nCs3, $06, nD3, $06, nA2, $06
	dc.b	nE2, $03, nRst, $03, nE2, $03, nRst, $03, nD2, $06, nE2, $0C
	dc.b	nD2, $06, nE2, $06, nD2, $06, nA2, $03, nRst, $03, nA2, $09
	dc.b	nE2, $03, nG2, $0C, nG2, $06, nE2, $0C, nA2, $03, nRst, $03
	dc.b	nA2, $06, nG2, $06, nA2, $0C, nG2, $06, nA2, $06, nG2, $06
	dc.b	nD3, $03, nRst, $03, nD3, $03, nRst, $03, nCs3, $06, nD3, $0C
	dc.b	nCs3, $06, nD3, $06, nA2, $06, nG2, $03, nRst, $03, nG2, $03
	dc.b	nRst, $03, nFs2, $06, nG2, $09, nRst, $03, nG2, $06, nFs2, $06
	dc.b	nG2, $06, nE2, $05, nRst, $01, nE2, $05, nRst, $01, nFs2, $05
	dc.b	nRst, $01, nFs2, $05, nRst, $01, nG2, $05, nRst, $01, nG2, $05
	dc.b	nRst, $01, nAb2, $05, nRst, $01, nAb2, $05, nRst, $01, nA2, $0C
	dc.b	nG2, $06, nA2, $0C, nG2, $06, nA2, $06, nG2, $06, nD3, $03
	dc.b	nRst, $03, nD3, $03, nRst, $03, nCs3, $06, nD3, $0C, nCs3, $06
	dc.b	nD3, $06, nA2, $06, nE2, $03, nRst, $03, nE2, $03, nRst, $03
	dc.b	nD2, $06, nE2, $0C, nD2, $06, nE2, $06, nD2, $06, nA2, $03
	dc.b	nRst, $03, nA2, $09, nE2, $03, nG2, $0C, nG2, $06, nE2, $0C
	dc.b	nA2, $03, nRst, $03, nA2, $06, nG2, $06, nA2, $0C, nG2, $06
	dc.b	nA2, $06, nG2, $06, nD3, $03, nRst, $03, nD3, $03, nRst, $03
	dc.b	nCs3, $06, nD3, $0C, nCs3, $06, nD3, $06, nA2, $06, nG2, $03
	dc.b	nRst, $03, nG2, $03, nRst, $03, nFs2, $06, nG2, $09, nRst, $03
	dc.b	nG2, $06, nFs2, $06, nG2, $06, nE3, $05, nRst, $01, nE3, $05
	dc.b	nRst, $01, nD3, $05, nRst, $01, nD3, $05, nRst, $01, nCs3, $05
	dc.b	nRst, $01, nCs3, $05, nRst, $01, nB2, $05, nRst, $01, nB2, $05
	dc.b	nRst, $01, nD3, $03, nRst, $03, nD3, $06, nCs3, $06, nD3, $09
	dc.b	nRst, $03, nCs3, $06, nD3, $06, nA2, $06, nD3, $03, nRst, $03
	dc.b	nD3, $06, nCs3, $06, nD3, $0C, nD3, $06, nB2, $06, nE2, $06
	dc.b	nA2, $03, nRst, $03, nA2, $06, nG2, $06, nA2, $09, nRst, $03
	dc.b	nG2, $06, nA2, $06, nG2, $06, nA2, $03, nRst, $03, nA2, $09
	dc.b	nFs2, $03, nA2, $0C, nA2, $06, nFs2, $06, nD2, $06, nD3, $03
	dc.b	nRst, $03, nD3, $06, nC3, $06, nD3, $09, nRst, $03, nC3, $06
	dc.b	nD3, $06, nA2, $06, nD3, $03, nRst, $03, nD3, $06, nC3, $06
	dc.b	nD3, $0C, nC3, $06, nD3, $06, nA2, $06, nG2, $03, nRst, $03
	dc.b	nG2, $06, nFs2, $06, nG2, $09, nRst, $03, nG2, $06, nFs2, $06
	dc.b	nG2, $06, nE2, $03, nRst, $03, nE2, $06, nFs2, $03, nRst, $03
	dc.b	nFs2, $06, nG2, $03, nRst, $03, nG2, $06, nAb2, $03, nRst, $03
	dc.b	nAb2, $06, nA2, $0C, nG2, $06, nA2, $0C, nG2, $06, nA2, $06
	dc.b	nG2, $06, nD3, $03, nRst, $03, nD3, $03, nRst, $03, nCs3, $06
	dc.b	nD3, $0C, nCs3, $06, nD3, $06, nA2, $06, nE2, $03, nRst, $03
	dc.b	nE2, $03, nRst, $03, nD2, $06, nE2, $0C, nD2, $06, nE2, $06
	dc.b	nD2, $06, nA2, $03, nRst, $03, nA2, $09, nE2, $03, nG2, $0C
	dc.b	nG2, $06, nE2, $0C, nA2, $03, nRst, $03, nA2, $06, nG2, $06
	dc.b	nA2, $0C, nG2, $06, nA2, $06, nG2, $06, nD3, $03, nRst, $03
	dc.b	nD3, $03, nRst, $03, nCs3, $06, nD3, $0C, nCs3, $06, nD3, $06
	dc.b	nA2, $06, nG2, $03, nRst, $03, nG2, $03, nRst, $03, nFs2, $06
	dc.b	nG2, $09, nRst, $03, nG2, $06, nFs2, $06, nG2, $06, nE3, $05
	dc.b	nRst, $01, nE3, $05, nRst, $01, nD3, $05, nRst, $01, nD3, $05
	dc.b	nRst, $01, nCs3, $05, nRst, $01, nCs3, $05, nRst, $01, nB2, $05
	dc.b	nRst, $01, nB2, $05, nRst, $01, nD2, $06, nRst, $06, nD2, $09
	dc.b	nRst, $09, nD2, $06, nRst, $06, nE2, $06, nRst, $06, nE2, $05
	dc.b	nRst, $01, nG2, $05, nRst, $01, nE2, $05, nRst, $01, nC3, $05
	dc.b	nRst, $01, nD3, $05, nRst, $01, nE3, $0C, nF2, $06, nRst, $06
	dc.b	nF2, $09, nRst, $09, nF2, $06, nRst, $06, nG2, $06, nRst, $06
	dc.b	nG3, $05, nRst, $01, nB2, $05, nRst, $01, nG2, $05, nRst, $01
	dc.b	nB2, $05, nRst, $01, nD3, $05, nRst, $01, nG3, $05, nRst, $01
	dc.b	nG2, $05, nRst, $01, nA2, $06, nRst, $06, nA2, $09, nRst, $09
	dc.b	nA2, $06, nRst, $06, nBb2, $06, nRst, $06, nBb2, $05, nRst, $01
	dc.b	nD3, $05, nRst, $01, nBb2, $05, nRst, $01, nF3, $05, nRst, $01
	dc.b	nG3, $05, nRst, $01, nBb3, $0C, nC3, $06, nRst, $06, nC3, $09
	dc.b	nRst, $09, nC3, $06, nRst, $06, nD3, $06, nRst, $06, nD4, $05
	dc.b	nRst, $01, nA3, $05, nRst, $01, nD3, $05, nRst, $01, nFs3, $05
	dc.b	nRst, $01, nA3, $05, nRst, $01, nD4, $05, nRst, $01, nD3, $05
	dc.b	nRst, $01, nE2, $06, nRst, $06, nE2, $09, nRst, $09, nE2, $06
	dc.b	nRst, $06, nE2, $06, nRst, $06, nE2, $05, nRst, $01, nG2, $05
	dc.b	nRst, $01, nE2, $05, nRst, $01, nC3, $05, nRst, $01, nD3, $05
	dc.b	nRst, $01, nE3, $0C, nE2, $06, nRst, $06, nE2, $09, nRst, $09
	dc.b	nE2, $06, nRst, $06, nE2, $06, nRst, $06, nE2, $05, nRst, $01
	dc.b	nG2, $05, nRst, $01, nE2, $05, nRst, $01, nC3, $05, nRst, $01
	dc.b	nD3, $05, nRst, $01, nE3, $0C, nA2, $0C, nG2, $06, nA2, $0C
	dc.b	nG2, $06, nA2, $06, nG2, $06, nD3, $03, nRst, $03, nD3, $03
	dc.b	nRst, $03, nCs3, $06, nD3, $0C, nCs3, $06, nD3, $06, nA2, $06
	dc.b	nE2, $03, nRst, $03, nE2, $03, nRst, $03, nD2, $06, nE2, $0C
	dc.b	nD2, $06, nE2, $06, nD2, $06, nA2, $03, nRst, $03, nA2, $09
	dc.b	nE2, $03, nG2, $0C, nG2, $06, nE2, $0C, nA2, $03, nRst, $03
	dc.b	nA2, $06, nG2, $06, nA2, $0C, nG2, $06, nA2, $06, nG2, $06
	dc.b	nD3, $03, nRst, $03, nD3, $03, nRst, $03, nCs3, $06, nD3, $0C
	dc.b	nCs3, $06, nD3, $06, nA2, $06, nG2, $03, nRst, $03, nG2, $03
	dc.b	nRst, $03, nFs2, $06, nG2, $09, nRst, $03, nG2, $06, nFs2, $06
	dc.b	nG2, $06, nE2, $05, nRst, $01, nE2, $05, nRst, $01, nFs2, $05
	dc.b	nRst, $01, nFs2, $05, nRst, $01, nG2, $05, nRst, $01, nG2, $05
	dc.b	nRst, $01, nAb2, $05, nRst, $01, nAb2, $05, nRst, $01, nA2, $03
	dc.b	nRst, $03, nA2, $06, nG2, $06, nA2, $0C, nG2, $06, nA2, $06
	dc.b	nG2, $06, nD3, $03, nRst, $03, nD3, $03, nRst, $03, nCs3, $06
	dc.b	nD3, $0C, nCs3, $06, nD3, $06, nA2, $06, nE2, $03, nRst, $03
	dc.b	nE2, $03, nRst, $03, nD2, $06, nE2, $0C, nD2, $06, nE2, $06
	dc.b	nD2, $06, nA2, $03, nRst, $03, nA2, $09, nE2, $03, nG2, $0C
	dc.b	nG2, $06, nE2, $0C, nA2, $03, nRst, $03, nA2, $06, nG2, $06
	dc.b	nA2, $0C, nG2, $06, nA2, $06, nG2, $06, nD3, $03, nRst, $03
	dc.b	nD3, $03, nRst, $03, nCs3, $06, nD3, $0C, nCs3, $06, nD3, $06
	dc.b	nA2, $06, nG2, $03, nRst, $03, nG2, $03, nRst, $03, nFs2, $06
	dc.b	nG2, $09, nRst, $03, nG2, $06, nFs2, $06, nG2, $06, nE2, $05
	dc.b	nRst, $01, nE2, $05, nRst, $01, nFs2, $05, nRst, $01, nFs2, $05
	dc.b	nRst, $01, nG2, $05, nRst, $01, nG2, $05, nRst, $01, nAb2, $05
	dc.b	nRst, $01, nAb2, $05, nRst, $01, nA2, $0C, nG2, $06, nA2, $0C
	dc.b	nG2, $06, nA2, $06, nG2, $06, nD3, $03, nRst, $03, nD3, $03
	dc.b	nRst, $03, nCs3, $06, nD3, $0C, nCs3, $06, nD3, $06, nA2, $06
	dc.b	nE2, $03, nRst, $03, nE2, $03, nRst, $03, nD2, $06, nE2, $0C
	dc.b	nD2, $06, nE2, $06, nD2, $06, nA2, $03, nRst, $03, nA2, $09
	dc.b	nE2, $03, nG2, $0C, nG2, $06, nE2, $0C, nA2, $03, nRst, $03
	dc.b	nA2, $06, nG2, $06, nA2, $0C, nG2, $06, nA2, $06, nG2, $06
	dc.b	nD3, $03, nRst, $03, nD3, $03, nRst, $03, nCs3, $06, nD3, $0C
	dc.b	nCs3, $06, nD3, $06, nA2, $06, nG2, $03, nRst, $03, nG2, $03
	dc.b	nRst, $03, nFs2, $06, nG2, $09, nRst, $03, nG2, $06, nFs2, $06
	dc.b	nG2, $06, nE3, $05, nRst, $01, nE3, $05, nRst, $01, nD3, $05
	dc.b	nRst, $01, nD3, $05, nRst, $01, nCs3, $05, nRst, $01, nCs3, $05
	dc.b	nRst, $01, nB2, $05, nRst, $01, nB2, $05, nRst, $01, nD3, $03
	dc.b	nRst, $03, nD3, $06, nCs3, $06, nD3, $09, nRst, $03, nCs3, $06
	dc.b	nD3, $06, nA2, $06, nD3, $03, nRst, $03, nD3, $06, nCs3, $06
	dc.b	nD3, $0C, nD3, $06, nB2, $06, nE2, $06, nA2, $03, nRst, $03
	dc.b	nA2, $06, nG2, $06, nA2, $09, nRst, $03, nG2, $06, nA2, $06
	dc.b	nG2, $06, nA2, $03, nRst, $03, nA2, $09, nFs2, $03, nA2, $0C
	dc.b	nA2, $06, nFs2, $06, nD2, $06, nD3, $03, nRst, $03, nD3, $06
	dc.b	nC3, $06, nD3, $09, nRst, $03, nC3, $06, nD3, $06, nA2, $06
	dc.b	nD3, $03, nRst, $03, nD3, $06, nC3, $06, nD3, $0C, nC3, $06
	dc.b	nD3, $06, nA2, $06, nG2, $03, nRst, $03, nG2, $06, nFs2, $06
	dc.b	nG2, $09, nRst, $03, nG2, $06, nFs2, $06, nG2, $06, nE2, $03
	dc.b	nRst, $03, nE2, $06, nFs2, $03, nRst, $03, nFs2, $06, nG2, $03
	dc.b	nRst, $03, nG2, $06, nAb2, $03, nRst, $03, nAb2, $06, nA2, $0C
	dc.b	nG2, $06, nA2, $0C, nG2, $06, nA2, $06, nG2, $06, nD3, $03
	dc.b	nRst, $03, nD3, $03, nRst, $03, nCs3, $06, nD3, $0C, nCs3, $06
	dc.b	nD3, $06, nA2, $06, nE2, $03, nRst, $03, nE2, $03, nRst, $03
	dc.b	nD2, $06, nE2, $0C, nD2, $06, nE2, $06, nD2, $06, nA2, $03
	dc.b	nRst, $03, nA2, $09, nE2, $03, nG2, $0C, nG2, $06, nE2, $0C
	dc.b	nA2, $03, nRst, $03, nA2, $06, nG2, $06, nA2, $0C, nG2, $06
	dc.b	nA2, $06, nG2, $06, nD3, $03, nRst, $03, nD3, $03, nRst, $03
	dc.b	nCs3, $06, nD3, $0C, nCs3, $06, nD3, $06, nA2, $06, nG2, $03
	dc.b	nRst, $03, nG2, $03, nRst, $03, nFs2, $06, nG2, $09, nRst, $03
	dc.b	nG2, $06, nFs2, $06, nG2, $06, nE3, $05, nRst, $01, nE3, $05
	dc.b	nRst, $01, nD3, $05, nRst, $01, nD3, $05, nRst, $01, nCs3, $05
	dc.b	nRst, $01, nCs3, $05, nRst, $01, nB2, $05, nRst, $01, nB2, $05
	dc.b	nRst, $01, nD2, $06, nRst, $06, nD2, $09, nRst, $09, nD2, $06
	dc.b	nRst, $06, nE2, $06, nRst, $06, nE2, $05, nRst, $01, nG2, $05
	dc.b	nRst, $01, nE2, $05, nRst, $01, nC3, $05, nRst, $01, nD3, $05
	dc.b	nRst, $01, nE3, $0C, nF2, $06, nRst, $06, nF2, $09, nRst, $09
	dc.b	nF2, $06, nRst, $06, nG2, $06, nRst, $06, nG3, $05, nRst, $01
	dc.b	nB2, $05, nRst, $01, nG2, $05, nRst, $01, nB2, $05, nRst, $01
	dc.b	nD3, $05, nRst, $01, nG3, $05, nRst, $01, nG2, $05, nRst, $01
	dc.b	nA2, $06, nRst, $06, nA2, $09, nRst, $09, nA2, $06, nRst, $06
	dc.b	nBb2, $06, nRst, $06, nBb2, $05, nRst, $01, nD3, $05, nRst, $01
	dc.b	nBb2, $05, nRst, $01, nF3, $05, nRst, $01, nG3, $05, nRst, $01
	dc.b	nBb3, $0C, nC3, $06, nRst, $06, nC3, $09, nRst, $09, nC3, $06
	dc.b	nRst, $06, nD3, $06, nRst, $06, nD4, $05, nRst, $01, nA3, $05
	dc.b	nRst, $01, nD3, $05, nRst, $01, nFs3, $05, nRst, $01, nA3, $05
	dc.b	nRst, $01, nD4, $05, nRst, $01, nD3, $05, nRst, $01, nE2, $06
	dc.b	nRst, $06, nE2, $09, nRst, $09, nE2, $06, nRst, $06, nE2, $06
	dc.b	nRst, $06, nE2, $05, nRst, $01, nG2, $05, nRst, $01, nE2, $05
	dc.b	nRst, $01, nC3, $05, nRst, $01, nD3, $05, nRst, $01, nE3, $0C
	dc.b	nE2, $06, nRst, $06, nE2, $09, nRst, $09, nE2, $06, nRst, $06
	dc.b	nE2, $06, nRst, $06, nE2, $05, nRst, $01, nG2, $05, nRst, $01
	dc.b	nE2, $05, nRst, $01, nC3, $05, nRst, $01, nD3, $05, nRst, $01
	dc.b	nE3, $0C, nA2, $0C, nG2, $06, nA2, $0C, nG2, $06, nA2, $06
	dc.b	nG2, $06, nD3, $03, nRst, $03, nD3, $03, nRst, $03, nCs3, $06
	dc.b	nD3, $0C, nCs3, $06, nD3, $06, nA2, $06, nE2, $03, nRst, $03
	dc.b	nE2, $03, nRst, $03, nD2, $06, nE2, $0C, nD2, $06, nE2, $06
	dc.b	nD2, $06, nA2, $03, nRst, $03, nA2, $09, nE2, $03, nG2, $0C
	dc.b	nG2, $06, nE2, $0C, nA2, $03, nRst, $03, nA2, $06, nG2, $06
	dc.b	nA2, $0C, nG2, $06, nA2, $06, nG2, $06, nD3, $03, nRst, $03
	dc.b	nD3, $03, nRst, $03, nCs3, $06, nD3, $0C, nCs3, $06, nD3, $06
	dc.b	nA2, $06, nG2, $03, nRst, $03, nG2, $03, nRst, $03, nFs2, $06
	dc.b	nG2, $09, nRst, $03, nG2, $06, nFs2, $06, nG2, $06, nE2, $05
	dc.b	nRst, $01, nE2, $05, nRst, $01, nFs2, $05, nRst, $01, nFs2, $05
	dc.b	nRst, $01, nG2, $05, nRst, $01, nG2, $05, nRst, $01, nAb2, $05
	dc.b	nRst, $01, nAb2, $05, nRst, $01, nA2, $03, nRst, $03, nA2, $06
	dc.b	nG2, $06, nA2, $0C, nG2, $06, nA2, $06, nG2, $06, nD3, $03
	dc.b	nRst, $03, nD3, $03, nRst, $03, nCs3, $06, nD3, $0C, nCs3, $06
	dc.b	nD3, $06, nA2, $06, nE2, $03, nRst, $03, nE2, $03, nRst, $03
	dc.b	nD2, $06, nE2, $0C, nD2, $06, nE2, $06, nD2, $06, nA2, $03
	dc.b	nRst, $03, nA2, $09, nE2, $03, nG2, $0C, nG2, $06, nE2, $0C
	dc.b	nA2, $03, nRst, $03, nA2, $06, nG2, $06, nA2, $0C, nG2, $06
	dc.b	nA2, $06, nG2, $06, nD3, $03, nRst, $03, nD3, $03, nRst, $03
	dc.b	nCs3, $06, nD3, $0C, nCs3, $06, nD3, $06, nA2, $06, nG2, $03
	dc.b	nRst, $03, nG2, $03, nRst, $03, nFs2, $06, nG2, $09, nRst, $03
	dc.b	nG2, $06, nFs2, $06, nG2, $06, nE2, $05, nRst, $01, nE2, $05
	dc.b	nRst, $01, nFs2, $05, nRst, $01, nFs2, $05, nRst, $01, nG2, $05
	dc.b	nRst, $01, nG2, $05, nRst, $01, nAb2, $05, nRst, $01, nAb2, $05
	dc.b	nRst, $01, nA2, $0C, nG2, $06, nA2, $0C, nG2, $06, nA2, $06
	dc.b	nG2, $06, nD3, $03, nRst, $03, nD3, $03, nRst, $03, nCs3, $06
	dc.b	nD3, $0C, nCs3, $06, nD3, $06, nA2, $06, nE2, $03, nRst, $03
	dc.b	nE2, $03, nRst, $03, nD2, $06, nE2, $0C, nD2, $06, nE2, $06
	dc.b	nD2, $06, nA2, $03, nRst, $03, nA2, $09, nE2, $03, nG2, $0C
	dc.b	nG2, $06, nE2, $0C, nA2, $03, nRst, $03, nA2, $06, nG2, $06
	dc.b	nA2, $0C, nG2, $06, nA2, $06, nG2, $06, nD3, $03, nRst, $03
	dc.b	nD3, $03, nRst, $03, nCs3, $06, nD3, $0C, nCs3, $06, nD3, $06
	dc.b	nA2, $06, nG2, $03, nRst, $03, nG2, $03, nRst, $03, nFs2, $06
	dc.b	nG2, $09, nRst, $03, nG2, $06, nFs2, $06, nG2, $06, nE3, $05
	dc.b	nRst, $01, nE3, $05, nRst, $01, nD3, $05, nRst, $01, nD3, $05
	dc.b	nRst, $01, nCs3, $05, nRst, $01, nCs3, $05, nRst, $01, nB2, $05
	dc.b	nRst, $01, nB2, $05, nRst, $01, nD3, $03, nRst, $03, nD3, $06
	dc.b	nCs3, $06, nD3, $09, nRst, $03, nCs3, $06, nD3, $06, nA2, $06
	dc.b	nD3, $03, nRst, $03, nD3, $06, nCs3, $06, nD3, $0C, nD3, $06
	dc.b	nB2, $06, nE2, $06, nA2, $03, nRst, $03, nA2, $06, nG2, $06
	dc.b	nA2, $09, nRst, $03, nG2, $06, nA2, $06, nG2, $06, nA2, $03
	dc.b	nRst, $03, nA2, $09, nFs2, $03, nA2, $0C, nA2, $06, nFs2, $06
	dc.b	nD2, $06, nD3, $03, nRst, $03, nD3, $06, nC3, $06, nD3, $09
	dc.b	nRst, $03, nC3, $06, nD3, $06, nA2, $06, nD3, $03, nRst, $03
	dc.b	nD3, $06, nC3, $06, nD3, $0C, nC3, $06, nD3, $06, nA2, $06
	dc.b	nG2, $03, nRst, $03, nG2, $06, nFs2, $06, nG2, $09, nRst, $03
	dc.b	nG2, $06, nFs2, $06, nG2, $06, nE2, $03, nRst, $03, nE2, $06
	dc.b	nFs2, $03, nRst, $03, nFs2, $06, nG2, $03, nRst, $03, nG2, $06
	dc.b	nAb2, $03, nRst, $03, nAb2, $06, nA2, $0C, nG2, $06, nA2, $0C
	dc.b	nG2, $06, nA2, $06, nG2, $06, nD3, $03, nRst, $03, nD3, $03
	dc.b	nRst, $03, nCs3, $06, nD3, $0C, nCs3, $06, nD3, $06, nA2, $06
	dc.b	nE2, $03, nRst, $03, nE2, $03, nRst, $03, nD2, $06, nE2, $0C
	dc.b	nD2, $06, nE2, $06, nD2, $06, nA2, $03, nRst, $03, nA2, $09
	dc.b	nE2, $03, nG2, $0C, nG2, $06, nE2, $0C, nA2, $03, nRst, $03
	dc.b	nA2, $06, nG2, $06, nA2, $0C, nG2, $06, nA2, $06, nG2, $06
	dc.b	nD3, $03, nRst, $03, nD3, $03, nRst, $03, nCs3, $06, nD3, $0C
	dc.b	nCs3, $06, nD3, $06, nA2, $06, nG2, $03, nRst, $03, nG2, $03
	dc.b	nRst, $03, nFs2, $06, nG2, $09, nRst, $03, nG2, $06, nFs2, $06
	dc.b	nG2, $06, nE3, $05, nRst, $01, nE3, $05, nRst, $01, nD3, $05
	dc.b	nRst, $01, nD3, $05, nRst, $01, nCs3, $05, nRst, $01, nCs3, $05
	dc.b	nRst, $01, nB2, $05, nRst, $01, nB2, $05, nRst, $01, nD2, $06
	dc.b	nRst, $06, nD2, $09, nRst, $09, nD2, $06, nRst, $06, nE2, $06
	dc.b	nRst, $06, nE2, $05, nRst, $01, nG2, $05, nRst, $01, nE2, $05
	dc.b	nRst, $01, nC3, $05, nRst, $01, nD3, $05, nRst, $01, nE3, $0C
	dc.b	nF2, $06, nRst, $06, nF2, $09, nRst, $09, nF2, $06, nRst, $06
	dc.b	nG2, $06, nRst, $06, nG3, $05, nRst, $01, nB2, $05, nRst, $01
	dc.b	nG2, $05, nRst, $01, nB2, $05, nRst, $01, nD3, $05, nRst, $01
	dc.b	nG3, $05, nRst, $01, nG2, $05, nRst, $01, nA2, $06, nRst, $06
	dc.b	nA2, $09, nRst, $09, nA2, $06, nRst, $06, nBb2, $06, nRst, $06
	dc.b	nBb2, $05, nRst, $01, nD3, $05, nRst, $01, nBb2, $05, nRst, $01
	dc.b	nF3, $05, nRst, $01, nG3, $05, nRst, $01, nBb3, $0C, nC3, $06
	dc.b	nRst, $06, nC3, $09, nRst, $09, nC3, $06, nRst, $06, nD3, $06
	dc.b	nRst, $06, nD4, $05, nRst, $01, nA3, $05, nRst, $01, nD3, $05
	dc.b	nRst, $01, nFs3, $05, nRst, $01, nA3, $05, nRst, $01, nD4, $05
	dc.b	nRst, $01, nD3, $05, nRst, $01, nE2, $06, nRst, $06, nE2, $09
	dc.b	nRst, $09, nE2, $06, nRst, $06, nE2, $06, nRst, $06, nE2, $05
	dc.b	nRst, $01, nG2, $05, nRst, $01, nE2, $05, nRst, $01, nC3, $05
	dc.b	nRst, $01, nD3, $05, nRst, $01, nE3, $0C, nE2, $06, nRst, $06
	dc.b	nE2, $09, nRst, $09, nE2, $06, nRst, $06, nE2, $06, nRst, $06
	dc.b	nE2, $05, nRst, $01, nG2, $05, nRst, $01, nE2, $05, nRst, $01
	dc.b	nC3, $05, nRst, $01, nD3, $05, nRst, $01, nE3, $0C
	smpsStop

; FM2 Data
SegaJingle_FM2:
	smpsPan             panRight, $00
	smpsSetvoice        $01
	dc.b	nD2, $06, nRst, $06, nD2, $09, nRst, $09, nD2, $06, nRst, $06
	dc.b	nE2, $06, nRst, $06, nE2, $05, nRst, $01, nG2, $05, nRst, $01
	dc.b	nE2, $05, nRst, $01, nC3, $05, nRst, $01, nD3, $05, nRst, $01
	dc.b	nE3, $0C, nF2, $06, nRst, $06, nF2, $09, nRst, $09, nF2, $06
	dc.b	nRst, $06, nG2, $06, nRst, $06, nG3, $05, nRst, $01, nB2, $05
	dc.b	nRst, $01, nG2, $05, nRst, $01, nB2, $05, nRst, $01, nD3, $05
	dc.b	nRst, $01, nG3, $05, nRst, $01, nG2, $05, nRst, $01, nA2, $0C
	dc.b	nG2, $06, nA2, $0C, nG2, $06, nA2, $06, nG2, $06, nD3, $03
	dc.b	nRst, $03, nD3, $03, nRst, $03, nCs3, $06, nD3, $0C, nCs3, $06
	dc.b	nD3, $06, nA2, $06, nE2, $03, nRst, $03, nE2, $03, nRst, $03
	dc.b	nD2, $06, nE2, $0C, nD2, $06, nE2, $06, nD2, $06, nA2, $03
	dc.b	nRst, $03, nA2, $09, nE2, $03, nG2, $0C, nG2, $06, nE2, $0C
	dc.b	nA2, $03, nRst, $03, nA2, $06, nG2, $06, nA2, $0C, nG2, $06
	dc.b	nA2, $06, nG2, $06, nD3, $03, nRst, $03, nD3, $03, nRst, $03
	dc.b	nCs3, $06, nD3, $0C, nCs3, $06, nD3, $06, nA2, $06, nG2, $03
	dc.b	nRst, $03, nG2, $03, nRst, $03, nFs2, $06, nG2, $09, nRst, $03
	dc.b	nG2, $06, nFs2, $06, nG2, $06, nE2, $05, nRst, $01, nE2, $05
	dc.b	nRst, $01, nFs2, $05, nRst, $01, nFs2, $05, nRst, $01, nG2, $05
	dc.b	nRst, $01, nG2, $05, nRst, $01, nAb2, $05, nRst, $01, nAb2, $05
	dc.b	nRst, $01, nA2, $03, nRst, $03, nA2, $06, nG2, $06, nA2, $0C
	dc.b	nG2, $06, nA2, $06, nG2, $06, nD3, $03, nRst, $03, nD3, $03
	dc.b	nRst, $03, nCs3, $06, nD3, $0C, nCs3, $06, nD3, $06, nA2, $06
	dc.b	nE2, $03, nRst, $03, nE2, $03, nRst, $03, nD2, $06, nE2, $0C
	dc.b	nD2, $06, nE2, $06, nD2, $06, nA2, $03, nRst, $03, nA2, $09
	dc.b	nE2, $03, nG2, $0C, nG2, $06, nE2, $0C, nA2, $03, nRst, $03
	dc.b	nA2, $06, nG2, $06, nA2, $0C, nG2, $06, nA2, $06, nG2, $06
	dc.b	nD3, $03, nRst, $03, nD3, $03, nRst, $03, nCs3, $06, nD3, $0C
	dc.b	nCs3, $06, nD3, $06, nA2, $06, nG2, $03, nRst, $03, nG2, $03
	dc.b	nRst, $03, nFs2, $06, nG2, $09, nRst, $03, nG2, $06, nFs2, $06
	dc.b	nG2, $06, nE2, $05, nRst, $01, nE2, $05, nRst, $01, nFs2, $05
	dc.b	nRst, $01, nFs2, $05, nRst, $01, nG2, $05, nRst, $01, nG2, $05
	dc.b	nRst, $01, nAb2, $05, nRst, $01, nAb2, $05, nRst, $01, nA2, $0C
	dc.b	nG2, $06, nA2, $0C, nG2, $06, nA2, $06, nG2, $06, nD3, $03
	dc.b	nRst, $03, nD3, $03, nRst, $03, nCs3, $06, nD3, $0C, nCs3, $06
	dc.b	nD3, $06, nA2, $06, nE2, $03, nRst, $03, nE2, $03, nRst, $03
	dc.b	nD2, $06, nE2, $0C, nD2, $06, nE2, $06, nD2, $06, nA2, $03
	dc.b	nRst, $03, nA2, $09, nE2, $03, nG2, $0C, nG2, $06, nE2, $0C
	dc.b	nA2, $03, nRst, $03, nA2, $06, nG2, $06, nA2, $0C, nG2, $06
	dc.b	nA2, $06, nG2, $06, nD3, $03, nRst, $03, nD3, $03, nRst, $03
	dc.b	nCs3, $06, nD3, $0C, nCs3, $06, nD3, $06, nA2, $06, nG2, $03
	dc.b	nRst, $03, nG2, $03, nRst, $03, nFs2, $06, nG2, $09, nRst, $03
	dc.b	nG2, $06, nFs2, $06, nG2, $06, nE3, $05, nRst, $01, nE3, $05
	dc.b	nRst, $01, nD3, $05, nRst, $01, nD3, $05, nRst, $01, nCs3, $05
	dc.b	nRst, $01, nCs3, $05, nRst, $01, nB2, $05, nRst, $01, nB2, $05
	dc.b	nRst, $01, nD3, $03, nRst, $03, nD3, $06, nCs3, $06, nD3, $09
	dc.b	nRst, $03, nCs3, $06, nD3, $06, nA2, $06, nD3, $03, nRst, $03
	dc.b	nD3, $06, nCs3, $06, nD3, $0C, nD3, $06, nB2, $06, nE2, $06
	dc.b	nA2, $03, nRst, $03, nA2, $06, nG2, $06, nA2, $09, nRst, $03
	dc.b	nG2, $06, nA2, $06, nG2, $06, nA2, $03, nRst, $03, nA2, $09
	dc.b	nFs2, $03, nA2, $0C, nA2, $06, nFs2, $06, nD2, $06, nD3, $03
	dc.b	nRst, $03, nD3, $06, nC3, $06, nD3, $09, nRst, $03, nC3, $06
	dc.b	nD3, $06, nA2, $06, nD3, $03, nRst, $03, nD3, $06, nC3, $06
	dc.b	nD3, $0C, nC3, $06, nD3, $06, nA2, $06, nG2, $03, nRst, $03
	dc.b	nG2, $06, nFs2, $06, nG2, $09, nRst, $03, nG2, $06, nFs2, $06
	dc.b	nG2, $06, nE2, $03, nRst, $03, nE2, $06, nFs2, $03, nRst, $03
	dc.b	nFs2, $06, nG2, $03, nRst, $03, nG2, $06, nAb2, $03, nRst, $03
	dc.b	nAb2, $06, nA2, $0C, nG2, $06, nA2, $0C, nG2, $06, nA2, $06
	dc.b	nG2, $06, nD3, $03, nRst, $03, nD3, $03, nRst, $03, nCs3, $06
	dc.b	nD3, $0C, nCs3, $06, nD3, $06, nA2, $06, nE2, $03, nRst, $03
	dc.b	nE2, $03, nRst, $03, nD2, $06, nE2, $0C, nD2, $06, nE2, $06
	dc.b	nD2, $06, nA2, $03, nRst, $03, nA2, $09, nE2, $03, nG2, $0C
	dc.b	nG2, $06, nE2, $0C, nA2, $03, nRst, $03, nA2, $06, nG2, $06
	dc.b	nA2, $0C, nG2, $06, nA2, $06, nG2, $06, nD3, $03, nRst, $03
	dc.b	nD3, $03, nRst, $03, nCs3, $06, nD3, $0C, nCs3, $06, nD3, $06
	dc.b	nA2, $06, nG2, $03, nRst, $03, nG2, $03, nRst, $03, nFs2, $06
	dc.b	nG2, $09, nRst, $03, nG2, $06, nFs2, $06, nG2, $06, nE3, $05
	dc.b	nRst, $01, nE3, $05, nRst, $01, nD3, $05, nRst, $01, nD3, $05
	dc.b	nRst, $01, nCs3, $05, nRst, $01, nCs3, $05, nRst, $01, nB2, $05
	dc.b	nRst, $01, nB2, $05, nRst, $01, nD2, $06, nRst, $06, nD2, $09
	dc.b	nRst, $09, nD2, $06, nRst, $06, nE2, $06, nRst, $06, nE2, $05
	dc.b	nRst, $01, nG2, $05, nRst, $01, nE2, $05, nRst, $01, nC3, $05
	dc.b	nRst, $01, nD3, $05, nRst, $01, nE3, $0C, nF2, $06, nRst, $06
	dc.b	nF2, $09, nRst, $09, nF2, $06, nRst, $06, nG2, $06, nRst, $06
	dc.b	nG3, $05, nRst, $01, nB2, $05, nRst, $01, nG2, $05, nRst, $01
	dc.b	nB2, $05, nRst, $01, nD3, $05, nRst, $01, nG3, $05, nRst, $01
	dc.b	nG2, $05, nRst, $01, nA2, $06, nRst, $06, nA2, $09, nRst, $09
	dc.b	nA2, $06, nRst, $06, nBb2, $06, nRst, $06, nBb2, $05, nRst, $01
	dc.b	nD3, $05, nRst, $01, nBb2, $05, nRst, $01, nF3, $05, nRst, $01
	dc.b	nG3, $05, nRst, $01, nBb3, $0C, nC3, $06, nRst, $06, nC3, $09
	dc.b	nRst, $09, nC3, $06, nRst, $06, nD3, $06, nRst, $06, nD4, $05
	dc.b	nRst, $01, nA3, $05, nRst, $01, nD3, $05, nRst, $01, nFs3, $05
	dc.b	nRst, $01, nA3, $05, nRst, $01, nD4, $05, nRst, $01, nD3, $05
	dc.b	nRst, $01, nE1, $06, nRst, $06, nE1, $09, nRst, $09, nE1, $06
	dc.b	nRst, $06, nE1, $06, nRst, $06, nE1, $05, nRst, $01, nG1, $05
	dc.b	nRst, $01, nE1, $05, nRst, $01, nC2, $05, nRst, $01, nD2, $05
	dc.b	nRst, $01, nE2, $0C, nE1, $06, nRst, $06, nE1, $09, nRst, $09
	dc.b	nE1, $06, nRst, $06, nE1, $06, nRst, $06, nE1, $05, nRst, $01
	dc.b	nG1, $05, nRst, $01, nE1, $05, nRst, $01, nC2, $05, nRst, $01
	dc.b	nD2, $05, nRst, $01, nE2, $0C, nA1, $0C, nG1, $06, nA1, $0C
	dc.b	nG1, $06, nA1, $06, nG1, $06, nD2, $03, nRst, $03, nD2, $03
	dc.b	nRst, $03, nCs2, $06, nD2, $0C, nCs2, $06, nD2, $06, nA1, $06
	dc.b	nE1, $03, nRst, $03, nE1, $03, nRst, $03, nD1, $06, nE1, $0C
	dc.b	nD1, $06, nE1, $06, nD1, $06, nA1, $03, nRst, $03, nA1, $09
	dc.b	nE1, $03, nG1, $0C, nG1, $06, nE1, $0C, nA1, $03, nRst, $03
	dc.b	nA1, $06, nG1, $06, nA1, $0C, nG1, $06, nA1, $06, nG1, $06
	dc.b	nD2, $03, nRst, $03, nD2, $03, nRst, $03, nCs2, $06, nD2, $0C
	dc.b	nCs2, $06, nD2, $06, nA1, $06, nG1, $03, nRst, $03, nG1, $03
	dc.b	nRst, $03, nFs1, $06, nG1, $09, nRst, $03, nG1, $06, nFs1, $06
	dc.b	nG1, $06, nE1, $05, nRst, $01, nE1, $05, nRst, $01, nFs1, $05
	dc.b	nRst, $01, nFs1, $05, nRst, $01, nG1, $05, nRst, $01, nG1, $05
	dc.b	nRst, $01, nAb1, $05, nRst, $01, nAb1, $05, nRst, $01, nA1, $03
	dc.b	nRst, $03, nA1, $06, nG1, $06, nA1, $0C, nG1, $06, nA1, $06
	dc.b	nG1, $06, nD2, $03, nRst, $03, nD2, $03, nRst, $03, nCs2, $06
	dc.b	nD2, $0C, nCs2, $06, nD2, $06, nA1, $06, nE1, $03, nRst, $03
	dc.b	nE1, $03, nRst, $03, nD1, $06, nE1, $0C, nD1, $06, nE1, $06
	dc.b	nD1, $06, nA1, $03, nRst, $03, nA1, $09, nE1, $03, nG1, $0C
	dc.b	nG1, $06, nE1, $0C, nA1, $03, nRst, $03, nA1, $06, nG1, $06
	dc.b	nA1, $0C, nG1, $06, nA1, $06, nG1, $06, nD2, $03, nRst, $03
	dc.b	nD2, $03, nRst, $03, nCs2, $06, nD2, $0C, nCs2, $06, nD2, $06
	dc.b	nA1, $06, nG1, $03, nRst, $03, nG1, $03, nRst, $03, nFs1, $06
	dc.b	nG1, $09, nRst, $03, nG1, $06, nFs1, $06, nG1, $06, nE1, $05
	dc.b	nRst, $01, nE1, $05, nRst, $01, nFs1, $05, nRst, $01, nFs1, $05
	dc.b	nRst, $01, nG1, $05, nRst, $01, nG1, $05, nRst, $01, nAb1, $05
	dc.b	nRst, $01, nAb1, $05, nRst, $01, nA1, $0C, nG1, $06, nA1, $0C
	dc.b	nG1, $06, nA1, $06, nG1, $06, nD2, $03, nRst, $03, nD2, $03
	dc.b	nRst, $03, nCs2, $06, nD2, $0C, nCs2, $06, nD2, $06, nA1, $06
	dc.b	nE1, $03, nRst, $03, nE1, $03, nRst, $03, nD1, $06, nE1, $0C
	dc.b	nD1, $06, nE1, $06, nD1, $06, nA1, $03, nRst, $03, nA1, $09
	dc.b	nE1, $03, nG1, $0C, nG1, $06, nE1, $0C, nA1, $03, nRst, $03
	dc.b	nA1, $06, nG1, $06, nA1, $0C, nG1, $06, nA1, $06, nG1, $06
	dc.b	nD2, $03, nRst, $03, nD2, $03, nRst, $03, nCs2, $06, nD2, $0C
	dc.b	nCs2, $06, nD2, $06, nA1, $06, nG1, $03, nRst, $03, nG1, $03
	dc.b	nRst, $03, nFs1, $06, nG1, $09, nRst, $03, nG1, $06, nFs1, $06
	dc.b	nG1, $06, nE2, $05, nRst, $01, nE2, $05, nRst, $01, nD2, $05
	dc.b	nRst, $01, nD2, $05, nRst, $01, nCs2, $05, nRst, $01, nCs2, $05
	dc.b	nRst, $01, nB1, $05, nRst, $01, nB1, $05, nRst, $01, nD2, $03
	dc.b	nRst, $03, nD2, $06, nCs2, $06, nD2, $09, nRst, $03, nCs2, $06
	dc.b	nD2, $06, nA1, $06, nD2, $03, nRst, $03, nD2, $06, nCs2, $06
	dc.b	nD2, $0C, nD2, $06, nB1, $06, nE1, $06, nA1, $03, nRst, $03
	dc.b	nA1, $06, nG1, $06, nA1, $09, nRst, $03, nG1, $06, nA1, $06
	dc.b	nG1, $06, nA1, $03, nRst, $03, nA1, $09, nFs1, $03, nA1, $0C
	dc.b	nA1, $06, nFs1, $06, nD1, $06, nD2, $03, nRst, $03, nD2, $06
	dc.b	nC2, $06, nD2, $09, nRst, $03, nC2, $06, nD2, $06, nA1, $06
	dc.b	nD2, $03, nRst, $03, nD2, $06, nC2, $06, nD2, $0C, nC2, $06
	dc.b	nD2, $06, nA1, $06, nG1, $03, nRst, $03, nG1, $06, nFs1, $06
	dc.b	nG1, $09, nRst, $03, nG1, $06, nFs1, $06, nG1, $06, nE1, $03
	dc.b	nRst, $03, nE1, $06, nFs1, $03, nRst, $03, nFs1, $06, nG1, $03
	dc.b	nRst, $03, nG1, $06, nAb1, $03, nRst, $03, nAb1, $06, nA1, $0C
	dc.b	nG1, $06, nA1, $0C, nG1, $06, nA1, $06, nG1, $06, nD2, $03
	dc.b	nRst, $03, nD2, $03, nRst, $03, nCs2, $06, nD2, $0C, nCs2, $06
	dc.b	nD2, $06, nA1, $06, nE1, $03, nRst, $03, nE1, $03, nRst, $03
	dc.b	nD1, $06, nE1, $0C, nD1, $06, nE1, $06, nD1, $06, nA1, $03
	dc.b	nRst, $03, nA1, $09, nE1, $03, nG1, $0C, nG1, $06, nE1, $0C
	dc.b	nA1, $03, nRst, $03, nA1, $06, nG1, $06, nA1, $0C, nG1, $06
	dc.b	nA1, $06, nG1, $06, nD2, $03, nRst, $03, nD2, $03, nRst, $03
	dc.b	nCs2, $06, nD2, $0C, nCs2, $06, nD2, $06, nA1, $06, nG1, $03
	dc.b	nRst, $03, nG1, $03, nRst, $03, nFs1, $06, nG1, $09, nRst, $03
	dc.b	nG1, $06, nFs1, $06, nG1, $06, nE2, $05, nRst, $01, nE2, $05
	dc.b	nRst, $01, nD2, $05, nRst, $01, nD2, $05, nRst, $01, nCs2, $05
	dc.b	nRst, $01, nCs2, $05, nRst, $01, nB1, $05, nRst, $01, nB1, $05
	dc.b	nRst, $01, nD1, $06, nRst, $06, nD1, $09, nRst, $09, nD1, $06
	dc.b	nRst, $06, nE1, $06, nRst, $06, nE1, $05, nRst, $01, nG1, $05
	dc.b	nRst, $01, nE1, $05, nRst, $01, nC2, $05, nRst, $01, nD2, $05
	dc.b	nRst, $01, nE2, $0C, nF1, $06, nRst, $06, nF1, $09, nRst, $09
	dc.b	nF1, $06, nRst, $06, nG1, $06, nRst, $06, nG2, $05, nRst, $01
	dc.b	nB1, $05, nRst, $01, nG1, $05, nRst, $01, nB1, $05, nRst, $01
	dc.b	nD2, $05, nRst, $01, nG2, $05, nRst, $01, nG1, $05, nRst, $01
	dc.b	nA1, $06, nRst, $06, nA1, $09, nRst, $09, nA1, $06, nRst, $06
	dc.b	nBb1, $06, nRst, $06, nBb1, $05, nRst, $01, nD2, $05, nRst, $01
	dc.b	nBb1, $05, nRst, $01, nF2, $05, nRst, $01, nG2, $05, nRst, $01
	dc.b	nBb2, $0C, nC2, $06, nRst, $06, nC2, $09, nRst, $09, nC2, $06
	dc.b	nRst, $06, nD2, $06, nRst, $06, nD3, $05, nRst, $01, nA2, $05
	dc.b	nRst, $01, nD2, $05, nRst, $01, nFs2, $05, nRst, $01, nA2, $05
	dc.b	nRst, $01, nD3, $05, nRst, $01, nD2, $05, nRst, $01, nE1, $06
	dc.b	nRst, $06, nE1, $09, nRst, $09, nE1, $06, nRst, $06, nE1, $06
	dc.b	nRst, $06, nE1, $05, nRst, $01, nG1, $05, nRst, $01, nE1, $05
	dc.b	nRst, $01, nC2, $05, nRst, $01, nD2, $05, nRst, $01, nE2, $0C
	dc.b	nE1, $06, nRst, $06, nE1, $09, nRst, $09, nE1, $06, nRst, $06
	dc.b	nE1, $06, nRst, $06, nE1, $05, nRst, $01, nG1, $05, nRst, $01
	dc.b	nE1, $05, nRst, $01, nC2, $05, nRst, $01, nD2, $05, nRst, $01
	dc.b	nE2, $0C, nA1, $0C, nG1, $06, nA1, $0C, nG1, $06, nA1, $06
	dc.b	nG1, $06, nD2, $03, nRst, $03, nD2, $03, nRst, $03, nCs2, $06
	dc.b	nD2, $0C, nCs2, $06, nD2, $06, nA1, $06, nE1, $03, nRst, $03
	dc.b	nE1, $03, nRst, $03, nD1, $06, nE1, $0C, nD1, $06, nE1, $06
	dc.b	nD1, $06, nA1, $03, nRst, $03, nA1, $09, nE1, $03, nG1, $0C
	dc.b	nG1, $06, nE1, $0C, nA1, $03, nRst, $03, nA1, $06, nG1, $06
	dc.b	nA1, $0C, nG1, $06, nA1, $06, nG1, $06, nD2, $03, nRst, $03
	dc.b	nD2, $03, nRst, $03, nCs2, $06, nD2, $0C, nCs2, $06, nD2, $06
	dc.b	nA1, $06, nG1, $03, nRst, $03, nG1, $03, nRst, $03, nFs1, $06
	dc.b	nG1, $09, nRst, $03, nG1, $06, nFs1, $06, nG1, $06, nE1, $05
	dc.b	nRst, $01, nE1, $05, nRst, $01, nFs1, $05, nRst, $01, nFs1, $05
	dc.b	nRst, $01, nG1, $05, nRst, $01, nG1, $05, nRst, $01, nAb1, $05
	dc.b	nRst, $01, nAb1, $05, nRst, $01, nA1, $03, nRst, $03, nA1, $06
	dc.b	nG1, $06, nA1, $0C, nG1, $06, nA1, $06, nG1, $06, nD2, $03
	dc.b	nRst, $03, nD2, $03, nRst, $03, nCs2, $06, nD2, $0C, nCs2, $06
	dc.b	nD2, $06, nA1, $06, nE1, $03, nRst, $03, nE1, $03, nRst, $03
	dc.b	nD1, $06, nE1, $0C, nD1, $06, nE1, $06, nD1, $06, nA1, $03
	dc.b	nRst, $03, nA1, $09, nE1, $03, nG1, $0C, nG1, $06, nE1, $0C
	dc.b	nA1, $03, nRst, $03, nA1, $06, nG1, $06, nA1, $0C, nG1, $06
	dc.b	nA1, $06, nG1, $06, nD2, $03, nRst, $03, nD2, $03, nRst, $03
	dc.b	nCs2, $06, nD2, $0C, nCs2, $06, nD2, $06, nA1, $06, nG1, $03
	dc.b	nRst, $03, nG1, $03, nRst, $03, nFs1, $06, nG1, $09, nRst, $03
	dc.b	nG1, $06, nFs1, $06, nG1, $06, nE1, $05, nRst, $01, nE1, $05
	dc.b	nRst, $01, nFs1, $05, nRst, $01, nFs1, $05, nRst, $01, nG1, $05
	dc.b	nRst, $01, nG1, $05, nRst, $01, nAb1, $05, nRst, $01, nAb1, $05
	dc.b	nRst, $01, nA1, $0C, nG1, $06, nA1, $0C, nG1, $06, nA1, $06
	dc.b	nG1, $06, nD2, $03, nRst, $03, nD2, $03, nRst, $03, nCs2, $06
	dc.b	nD2, $0C, nCs2, $06, nD2, $06, nA1, $06, nE1, $03, nRst, $03
	dc.b	nE1, $03, nRst, $03, nD1, $06, nE1, $0C, nD1, $06, nE1, $06
	dc.b	nD1, $06, nA1, $03, nRst, $03, nA1, $09, nE1, $03, nG1, $0C
	dc.b	nG1, $06, nE1, $0C, nA1, $03, nRst, $03, nA1, $06, nG1, $06
	dc.b	nA1, $0C, nG1, $06, nA1, $06, nG1, $06, nD2, $03, nRst, $03
	dc.b	nD2, $03, nRst, $03, nCs2, $06, nD2, $0C, nCs2, $06, nD2, $06
	dc.b	nA1, $06, nG1, $03, nRst, $03, nG1, $03, nRst, $03, nFs1, $06
	dc.b	nG1, $09, nRst, $03, nG1, $06, nFs1, $06, nG1, $06, nE2, $05
	dc.b	nRst, $01, nE2, $05, nRst, $01, nD2, $05, nRst, $01, nD2, $05
	dc.b	nRst, $01, nCs2, $05, nRst, $01, nCs2, $05, nRst, $01, nB1, $05
	dc.b	nRst, $01, nB1, $05, nRst, $01, nD2, $03, nRst, $03, nD2, $06
	dc.b	nCs2, $06, nD2, $09, nRst, $03, nCs2, $06, nD2, $06, nA1, $06
	dc.b	nD2, $03, nRst, $03, nD2, $06, nCs2, $06, nD2, $0C, nD2, $06
	dc.b	nB1, $06, nE1, $06, nA1, $03, nRst, $03, nA1, $06, nG1, $06
	dc.b	nA1, $09, nRst, $03, nG1, $06, nA1, $06, nG1, $06, nA1, $03
	dc.b	nRst, $03, nA1, $09, nFs1, $03, nA1, $0C, nA1, $06, nFs1, $06
	dc.b	nD1, $06, nD2, $03, nRst, $03, nD2, $06, nC2, $06, nD2, $09
	dc.b	nRst, $03, nC2, $06, nD2, $06, nA1, $06, nD2, $03, nRst, $03
	dc.b	nD2, $06, nC2, $06, nD2, $0C, nC2, $06, nD2, $06, nA1, $06
	dc.b	nG1, $03, nRst, $03, nG1, $06, nFs1, $06, nG1, $09, nRst, $03
	dc.b	nG1, $06, nFs1, $06, nG1, $06, nE1, $03, nRst, $03, nE1, $06
	dc.b	nFs1, $03, nRst, $03, nFs1, $06, nG1, $03, nRst, $03, nG1, $06
	dc.b	nAb1, $03, nRst, $03, nAb1, $06, nA1, $0C, nG1, $06, nA1, $0C
	dc.b	nG1, $06, nA1, $06, nG1, $06, nD2, $03, nRst, $03, nD2, $03
	dc.b	nRst, $03, nCs2, $06, nD2, $0C, nCs2, $06, nD2, $06, nA1, $06
	dc.b	nE1, $03, nRst, $03, nE1, $03, nRst, $03, nD1, $06, nE1, $0C
	dc.b	nD1, $06, nE1, $06, nD1, $06, nA1, $03, nRst, $03, nA1, $09
	dc.b	nE1, $03, nG1, $0C, nG1, $06, nE1, $0C, nA1, $03, nRst, $03
	dc.b	nA1, $06, nG1, $06, nA1, $0C, nG1, $06, nA1, $06, nG1, $06
	dc.b	nD2, $03, nRst, $03, nD2, $03, nRst, $03, nCs2, $06, nD2, $0C
	dc.b	nCs2, $06, nD2, $06, nA1, $06, nG1, $03, nRst, $03, nG1, $03
	dc.b	nRst, $03, nFs1, $06, nG1, $09, nRst, $03, nG1, $06, nFs1, $06
	dc.b	nG1, $06, nE2, $05, nRst, $01, nE2, $05, nRst, $01, nD2, $05
	dc.b	nRst, $01, nD2, $05, nRst, $01, nCs2, $05, nRst, $01, nCs2, $05
	dc.b	nRst, $01, nB1, $05, nRst, $01, nB1, $05, nRst, $01, nD1, $06
	dc.b	nRst, $06, nD1, $09, nRst, $09, nD1, $06, nRst, $06, nE1, $06
	dc.b	nRst, $06, nE1, $05, nRst, $01, nG1, $05, nRst, $01, nE1, $05
	dc.b	nRst, $01, nC2, $05, nRst, $01, nD2, $05, nRst, $01, nE2, $0C
	dc.b	nF1, $06, nRst, $06, nF1, $09, nRst, $09, nF1, $06, nRst, $06
	dc.b	nG1, $06, nRst, $06, nG2, $05, nRst, $01, nB1, $05, nRst, $01
	dc.b	nG1, $05, nRst, $01, nB1, $05, nRst, $01, nD2, $05, nRst, $01
	dc.b	nG2, $05, nRst, $01, nG1, $05, nRst, $01, nA1, $06, nRst, $06
	dc.b	nA1, $09, nRst, $09, nA1, $06, nRst, $06, nBb1, $06, nRst, $06
	dc.b	nBb1, $05, nRst, $01, nD2, $05, nRst, $01, nBb1, $05, nRst, $01
	dc.b	nF2, $05, nRst, $01, nG2, $05, nRst, $01, nBb2, $0C, nC2, $06
	dc.b	nRst, $06, nC2, $09, nRst, $09, nC2, $06, nRst, $06, nD2, $06
	dc.b	nRst, $06, nD3, $05, nRst, $01, nA2, $05, nRst, $01, nD2, $05
	dc.b	nRst, $01, nFs2, $05, nRst, $01, nA2, $05, nRst, $01, nD3, $05
	dc.b	nRst, $01, nD2, $05, nRst, $01, nE1, $06, nRst, $06, nE1, $09
	dc.b	nRst, $09, nE1, $06, nRst, $06, nE1, $06, nRst, $06, nE1, $05
	dc.b	nRst, $01, nG1, $05, nRst, $01, nE1, $05, nRst, $01, nC2, $05
	dc.b	nRst, $01, nD2, $05, nRst, $01, nE2, $0C, nE1, $06, nRst, $06
	dc.b	nE1, $09, nRst, $09, nE1, $06, nRst, $06, nE1, $06, nRst, $06
	dc.b	nE1, $05, nRst, $01, nG1, $05, nRst, $01, nE1, $05, nRst, $01
	dc.b	nC2, $05, nRst, $01, nD2, $05, nRst, $01, nE2, $0C
	smpsStop

; FM3 Data
SegaJingle_FM3:
	smpsPan             panLeft, $00
	smpsSetvoice        $02
	dc.b	nRst, $7F, $2F, nG2, $0C, nRst, $06
	smpsAlterVol        $F8
	dc.b	nA1, $0C
	smpsAlterVol        $0A
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nB0, $03, nRst, $03
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nD2, $0C, nB0, $03
	dc.b	nRst, $03, nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nCs3, $06, nD3, $06
	smpsAlterVol        $0A
	dc.b	nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nE2, $06, nRst, $06, nE2, $06, nRst, $06, nD2, $06, nCs2, $06
	dc.b	nB1, $06, nCs2, $0C
	smpsAlterVol        $0A
	smpsAlterVol        $FE
	dc.b	nA2, $06
	smpsAlterVol        $02
	dc.b	nE1, $03, nRst, $03
	smpsAlterVol        $FE
	dc.b	nG2, $06
	smpsAlterVol        $F8
	dc.b	nG3, $06, nRst, $06
	smpsAlterVol        $0A
	dc.b	nE1, $03, nRst, $03, nB0, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nA1, $0C
	smpsAlterVol        $0A
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nB0, $03, nRst, $03
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nD2, $0C, nB0, $03
	dc.b	nRst, $03, nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nCs3, $06, nD3, $06
	smpsAlterVol        $0A
	dc.b	nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nG2, $06, nRst, $06, nG2, $06, nRst, $06, nFs2, $06, nG2, $06
	dc.b	nRst, $06, nE2, $06
	smpsAlterVol        $0A
	dc.b	nE1, $03, nRst, $03, nE1, $03, nRst, $03, nE1, $03, nRst, $03
	dc.b	nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nEb2, $06, nE2, $06
	smpsAlterVol        $0A
	dc.b	nE1, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nA1, $0C
	smpsAlterVol        $0A
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nB0, $03, nRst, $03
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nD2, $0C, nB0, $03
	dc.b	nRst, $03, nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nCs3, $06, nD3, $06
	smpsAlterVol        $0A
	dc.b	nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nE2, $06, nRst, $06, nE2, $06, nRst, $06, nD2, $06, nCs2, $06
	dc.b	nB1, $06, nCs2, $0C
	smpsAlterVol        $0A
	smpsAlterVol        $FE
	dc.b	nA2, $06
	smpsAlterVol        $02
	dc.b	nE1, $03, nRst, $03
	smpsAlterVol        $FE
	dc.b	nG2, $06
	smpsAlterVol        $F8
	dc.b	nG3, $06, nRst, $06
	smpsAlterVol        $0A
	dc.b	nE1, $03, nRst, $03, nB0, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nA1, $0C
	smpsAlterVol        $0A
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nB0, $03, nRst, $03
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nD2, $0C, nB0, $03
	dc.b	nRst, $03, nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nCs3, $06, nD3, $06
	smpsAlterVol        $0A
	dc.b	nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nG2, $06, nRst, $06, nG2, $06, nRst, $06, nFs2, $06, nG2, $06
	dc.b	nRst, $06, nE2, $06
	smpsAlterVol        $0A
	dc.b	nE1, $03, nRst, $03, nE1, $03, nRst, $03, nE1, $03, nRst, $03
	dc.b	nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nEb2, $06, nE2, $06
	smpsAlterVol        $0A
	dc.b	nE1, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nA1, $0C
	smpsAlterVol        $0A
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nB0, $03, nRst, $03
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nD2, $0C, nB0, $03
	dc.b	nRst, $03, nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nCs3, $06, nD3, $06
	smpsAlterVol        $0A
	dc.b	nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nE2, $06, nRst, $06, nE2, $06, nRst, $06, nD2, $06, nCs2, $06
	dc.b	nB1, $06, nCs2, $0C
	smpsAlterVol        $0A
	smpsAlterVol        $FE
	dc.b	nA2, $06
	smpsAlterVol        $02
	dc.b	nE1, $03, nRst, $03
	smpsAlterVol        $FE
	dc.b	nG2, $06
	smpsAlterVol        $F8
	dc.b	nG3, $06, nRst, $06
	smpsAlterVol        $0A
	dc.b	nE1, $03, nRst, $03, nB0, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nA1, $0C
	smpsAlterVol        $0A
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nB0, $03, nRst, $03
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nD2, $0C, nB0, $03
	dc.b	nRst, $03, nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nCs3, $06, nD3, $06
	smpsAlterVol        $0A
	dc.b	nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nG2, $06, nRst, $06, nG2, $06, nRst, $06, nFs2, $06, nG2, $06
	dc.b	nRst, $06, nE2, $06
	smpsAlterVol        $0A
	dc.b	nE1, $03, nRst, $03, nE1, $03, nRst, $03, nE1, $03, nRst, $03
	dc.b	nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nEb2, $06, nE2, $06
	smpsAlterVol        $0A
	dc.b	nE1, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nD2, $06, nRst, $06, nD2, $06, nRst, $06, nD2, $06, nRst, $06
	dc.b	nD2, $06, nRst, $06, nCs2, $06, nD2, $06, nRst, $06, nD3, $06
	dc.b	nRst, $06, nCs3, $03, nRst, $03, nD3, $09, nRst, $03, nA1, $06
	dc.b	nRst, $06, nA1, $06, nRst, $06, nA1, $06, nRst, $06, nA1, $06
	dc.b	nRst, $06, nAb2, $06, nA2, $06, nRst, $06, nA2, $06, nRst, $06
	dc.b	nAb1, $03, nRst, $03, nA2, $09, nRst, $03, nD2, $06, nRst, $06
	dc.b	nD2, $06, nRst, $06, nD2, $06, nRst, $06, nD2, $06, nRst, $06
	dc.b	nCs2, $06, nD2, $06, nRst, $06, nD3, $06, nRst, $06, nCs3, $03
	dc.b	nRst, $03, nD3, $09, nRst, $03, nG2, $06, nRst, $06, nG2, $06
	dc.b	nRst, $06, nG2, $06, nRst, $06, nG2, $06, nE2, $0C, nE2, $0C
	dc.b	nE2, $06, nCs3, $03, nRst, $03, nCs3, $03, nRst, $03, nB2, $03
	dc.b	nRst, $03, nB2, $03, nRst, $03, nA1, $0C
	smpsAlterVol        $0A
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nB0, $03, nRst, $03
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nD2, $0C, nB0, $03
	dc.b	nRst, $03, nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nCs3, $06, nD3, $06
	smpsAlterVol        $0A
	dc.b	nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nE2, $06, nRst, $06, nE2, $06, nRst, $06, nD2, $06, nCs2, $06
	dc.b	nB1, $06, nCs2, $0C
	smpsAlterVol        $0A
	smpsAlterVol        $FE
	dc.b	nA2, $06
	smpsAlterVol        $02
	dc.b	nE1, $03, nRst, $03
	smpsAlterVol        $FE
	dc.b	nG2, $06
	smpsAlterVol        $F8
	dc.b	nG3, $06, nRst, $06
	smpsAlterVol        $0A
	dc.b	nE1, $03, nRst, $03, nB0, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nA1, $0C
	smpsAlterVol        $0A
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nB0, $03, nRst, $03
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nD2, $0C, nB0, $03
	dc.b	nRst, $03, nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nCs3, $06, nD3, $06
	smpsAlterVol        $0A
	dc.b	nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nG2, $06, nRst, $06, nG2, $06, nRst, $06, nFs2, $06, nG2, $06
	dc.b	nRst, $06, nE2, $06
	smpsAlterVol        $0A
	dc.b	nE1, $03, nRst, $03, nE1, $03, nRst, $03, nE1, $03, nRst, $03
	dc.b	nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nEb2, $06, nE2, $06
	smpsAlterVol        $0A
	dc.b	nE1, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nD2, $06, nD1, $03, nRst, $03, nD2, $06, nD1, $03, nRst, $03
	dc.b	nD2, $03, nRst, $03, nD2, $09, nRst, $03, nE2, $0C, nE1, $03
	dc.b	nRst, $03, nE2, $06, nE1, $03, nRst, $03, nE2, $03, nRst, $03
	dc.b	nE2, $09, nRst, $03, nE1, $03, nRst, $03, nF2, $06, nF1, $03
	dc.b	nRst, $03, nF2, $06, nF1, $03, nRst, $03, nF2, $03, nRst, $03
	dc.b	nF2, $09, nRst, $03, nG2, $0C, nG1, $03, nRst, $03, nG2, $06
	dc.b	nG1, $03, nRst, $03, nG2, $03, nRst, $03, nG2, $09, nRst, $03
	dc.b	nG1, $03, nRst, $03, nA2, $06, nA1, $03, nRst, $03, nA2, $06
	dc.b	nA1, $03, nRst, $03, nA2, $06, nG2, $06, nA2, $06, nBb2, $06
	dc.b	nBb1, $03, nRst, $03, nBb2, $06, nBb1, $03, nRst, $03, nBb2, $06
	dc.b	nBb1, $03, nRst, $03, nBb2, $06, nA2, $06, nBb2, $06, nC3, $06
	dc.b	nC2, $03, nRst, $03, nC3, $06, nC2, $03, nRst, $03, nC3, $06
	dc.b	nBb2, $06, nC3, $06, nD3, $06, nD2, $03, nRst, $03, nD3, $06
	dc.b	nD2, $03, nRst, $03, nD3, $06, nD2, $03, nRst, $03, nD3, $06
	dc.b	nC3, $06, nD3, $06, nE3, $06, nE2, $03, nRst, $03, nE3, $06
	dc.b	nE2, $03, nRst, $03, nD3, $06, nD2, $03, nRst, $03, nD3, $06
	dc.b	nD2, $03, nRst, $03, nCs3, $06, nCs2, $03, nRst, $03, nCs3, $03
	dc.b	nRst, $03, nB2, $0C, nB1, $03, nRst, $03, nB2, $06, nB1, $03
	dc.b	nRst, $03, nE3, $06, nE2, $03, nRst, $03, nE3, $06, nE2, $03
	dc.b	nRst, $03, nD3, $06, nD2, $03, nRst, $03, nD3, $06, nD2, $03
	dc.b	nRst, $03, nCs3, $06, nCs2, $03, nRst, $03, nCs3, $03, nRst, $03
	dc.b	nB2, $0C, nB1, $03, nRst, $03, nB2, $06, nB1, $03, nRst, $03
	dc.b	nA1, $0C
	smpsAlterVol        $0A
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nB0, $03, nRst, $03
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nD2, $0C, nB0, $03
	dc.b	nRst, $03, nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nCs3, $06, nD3, $06
	smpsAlterVol        $0A
	dc.b	nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nE2, $06, nRst, $06, nE2, $06, nRst, $06, nD2, $06, nCs2, $06
	dc.b	nB1, $06, nCs2, $0C
	smpsAlterVol        $0A
	smpsAlterVol        $FE
	dc.b	nA2, $06
	smpsAlterVol        $02
	dc.b	nE1, $03, nRst, $03
	smpsAlterVol        $FE
	dc.b	nG2, $06
	smpsAlterVol        $F8
	dc.b	nG3, $06, nRst, $06
	smpsAlterVol        $0A
	dc.b	nE1, $03, nRst, $03, nB0, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nA1, $0C
	smpsAlterVol        $0A
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nB0, $03, nRst, $03
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nD2, $0C, nB0, $03
	dc.b	nRst, $03, nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nCs3, $06, nD3, $06
	smpsAlterVol        $0A
	dc.b	nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nG2, $06, nRst, $06, nG2, $06, nRst, $06, nFs2, $06, nG2, $06
	dc.b	nRst, $06, nE2, $06
	smpsAlterVol        $0A
	dc.b	nE1, $03, nRst, $03, nE1, $03, nRst, $03, nE1, $03, nRst, $03
	dc.b	nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nEb2, $06, nE2, $06
	smpsAlterVol        $0A
	dc.b	nE1, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nA1, $0C
	smpsAlterVol        $0A
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nB0, $03, nRst, $03
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nD2, $0C, nB0, $03
	dc.b	nRst, $03, nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nCs3, $06, nD3, $06
	smpsAlterVol        $0A
	dc.b	nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nE2, $06, nRst, $06, nE2, $06, nRst, $06, nD2, $06, nCs2, $06
	dc.b	nB1, $06, nCs2, $0C
	smpsAlterVol        $0A
	smpsAlterVol        $FE
	dc.b	nA2, $06
	smpsAlterVol        $02
	dc.b	nE1, $03, nRst, $03
	smpsAlterVol        $FE
	dc.b	nG2, $06
	smpsAlterVol        $F8
	dc.b	nG3, $06, nRst, $06
	smpsAlterVol        $0A
	dc.b	nE1, $03, nRst, $03, nB0, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nA1, $0C
	smpsAlterVol        $0A
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nB0, $03, nRst, $03
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nD2, $0C, nB0, $03
	dc.b	nRst, $03, nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nCs3, $06, nD3, $06
	smpsAlterVol        $0A
	dc.b	nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nG2, $06, nRst, $06, nG2, $06, nRst, $06, nFs2, $06, nG2, $06
	dc.b	nRst, $06, nE2, $06
	smpsAlterVol        $0A
	dc.b	nE1, $03, nRst, $03, nE1, $03, nRst, $03, nE1, $03, nRst, $03
	dc.b	nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nEb2, $06, nE2, $06
	smpsAlterVol        $0A
	dc.b	nE1, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nA1, $0C
	smpsAlterVol        $0A
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nB0, $03, nRst, $03
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nD2, $0C, nB0, $03
	dc.b	nRst, $03, nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nCs3, $06, nD3, $06
	smpsAlterVol        $0A
	dc.b	nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nE2, $06, nRst, $06, nE2, $06, nRst, $06, nD2, $06, nCs2, $06
	dc.b	nB1, $06, nCs2, $0C
	smpsAlterVol        $0A
	smpsAlterVol        $FE
	dc.b	nA2, $06
	smpsAlterVol        $02
	dc.b	nE1, $03, nRst, $03
	smpsAlterVol        $FE
	dc.b	nG2, $06
	smpsAlterVol        $F8
	dc.b	nG3, $06, nRst, $06
	smpsAlterVol        $0A
	dc.b	nE1, $03, nRst, $03, nB0, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nA1, $0C
	smpsAlterVol        $0A
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nB0, $03, nRst, $03
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nD2, $0C, nB0, $03
	dc.b	nRst, $03, nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nCs3, $06, nD3, $06
	smpsAlterVol        $0A
	dc.b	nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nG2, $06, nRst, $06, nG2, $06, nRst, $06, nFs2, $06, nG2, $06
	dc.b	nRst, $06, nE2, $06
	smpsAlterVol        $0A
	dc.b	nE1, $03, nRst, $03, nE1, $03, nRst, $03, nE1, $03, nRst, $03
	dc.b	nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nEb2, $06, nE2, $06
	smpsAlterVol        $0A
	dc.b	nE1, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nD2, $06, nRst, $06, nD2, $06, nRst, $06, nD2, $06, nRst, $06
	dc.b	nD2, $06, nRst, $06, nCs2, $06, nD2, $06, nRst, $06, nD3, $06
	dc.b	nRst, $06, nCs3, $03, nRst, $03, nD3, $09, nRst, $03, nA1, $06
	dc.b	nRst, $06, nA1, $06, nRst, $06, nA1, $06, nRst, $06, nA1, $06
	dc.b	nRst, $06, nAb2, $06, nA2, $06, nRst, $06, nA2, $06, nRst, $06
	dc.b	nAb1, $03, nRst, $03, nA2, $09, nRst, $03, nD2, $06, nRst, $06
	dc.b	nD2, $06, nRst, $06, nD2, $06, nRst, $06, nD2, $06, nRst, $06
	dc.b	nCs2, $06, nD2, $06, nRst, $06, nD3, $06, nRst, $06, nCs3, $03
	dc.b	nRst, $03, nD3, $09, nRst, $03, nG2, $06, nRst, $06, nG2, $06
	dc.b	nRst, $06, nG2, $06, nRst, $06, nG2, $06, nE2, $0C, nE2, $0C
	dc.b	nE2, $06, nCs3, $03, nRst, $03, nCs3, $03, nRst, $03, nB2, $03
	dc.b	nRst, $03, nB2, $03, nRst, $03, nA1, $0C
	smpsAlterVol        $0A
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nB0, $03, nRst, $03
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nD2, $0C, nB0, $03
	dc.b	nRst, $03, nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nCs3, $06, nD3, $06
	smpsAlterVol        $0A
	dc.b	nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nE2, $06, nRst, $06, nE2, $06, nRst, $06, nD2, $06, nCs2, $06
	dc.b	nB1, $06, nCs2, $0C
	smpsAlterVol        $0A
	smpsAlterVol        $FE
	dc.b	nA2, $06
	smpsAlterVol        $02
	dc.b	nE1, $03, nRst, $03
	smpsAlterVol        $FE
	dc.b	nG2, $06
	smpsAlterVol        $F8
	dc.b	nG3, $06, nRst, $06
	smpsAlterVol        $0A
	dc.b	nE1, $03, nRst, $03, nB0, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nA1, $0C
	smpsAlterVol        $0A
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nB0, $03, nRst, $03
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nD2, $0C, nB0, $03
	dc.b	nRst, $03, nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nCs3, $06, nD3, $06
	smpsAlterVol        $0A
	dc.b	nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nG2, $06, nRst, $06, nG2, $06, nRst, $06, nFs2, $06, nG2, $06
	dc.b	nRst, $06, nE2, $06
	smpsAlterVol        $0A
	dc.b	nE1, $03, nRst, $03, nE1, $03, nRst, $03, nE1, $03, nRst, $03
	dc.b	nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nEb2, $06, nE2, $06
	smpsAlterVol        $0A
	dc.b	nE1, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nD2, $06, nD1, $03, nRst, $03, nD2, $06, nD1, $03, nRst, $03
	dc.b	nD2, $03, nRst, $03, nD2, $09, nRst, $03, nE2, $0C, nE1, $03
	dc.b	nRst, $03, nE2, $06, nE1, $03, nRst, $03, nE2, $03, nRst, $03
	dc.b	nE2, $09, nRst, $03, nE1, $03, nRst, $03, nF2, $06, nF1, $03
	dc.b	nRst, $03, nF2, $06, nF1, $03, nRst, $03, nF2, $03, nRst, $03
	dc.b	nF2, $09, nRst, $03, nG2, $0C, nG1, $03, nRst, $03, nG2, $06
	dc.b	nG1, $03, nRst, $03, nG2, $03, nRst, $03, nG2, $09, nRst, $03
	dc.b	nG1, $03, nRst, $03, nA2, $06, nA1, $03, nRst, $03, nA2, $06
	dc.b	nA1, $03, nRst, $03, nA2, $06, nG2, $06, nA2, $06, nBb2, $06
	dc.b	nBb1, $03, nRst, $03, nBb2, $06, nBb1, $03, nRst, $03, nBb2, $06
	dc.b	nBb1, $03, nRst, $03, nBb2, $06, nA2, $06, nBb2, $06, nC3, $06
	dc.b	nC2, $03, nRst, $03, nC3, $06, nC2, $03, nRst, $03, nC3, $06
	dc.b	nBb2, $06, nC3, $06, nD3, $06, nD2, $03, nRst, $03, nD3, $06
	dc.b	nD2, $03, nRst, $03, nD3, $06, nD2, $03, nRst, $03, nD3, $06
	dc.b	nC3, $06, nD3, $06, nE3, $06, nE2, $03, nRst, $03, nE3, $06
	dc.b	nE2, $03, nRst, $03, nD3, $06, nD2, $03, nRst, $03, nD3, $06
	dc.b	nD2, $03, nRst, $03, nCs3, $06, nCs2, $03, nRst, $03, nCs3, $03
	dc.b	nRst, $03, nB2, $0C, nB1, $03, nRst, $03, nB2, $06, nB1, $03
	dc.b	nRst, $03, nE3, $06, nE2, $03, nRst, $03, nE3, $06, nE2, $03
	dc.b	nRst, $03, nD3, $06, nD2, $03, nRst, $03, nD3, $06, nD2, $03
	dc.b	nRst, $03, nCs3, $06, nCs2, $03, nRst, $03, nCs3, $03, nRst, $03
	dc.b	nB2, $0C, nB1, $03, nRst, $03, nB2, $06, nB1, $03, nRst, $03
	dc.b	nA1, $0C
	smpsAlterVol        $0A
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nB0, $03, nRst, $03
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nD2, $0C, nB0, $03
	dc.b	nRst, $03, nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nCs3, $06, nD3, $06
	smpsAlterVol        $0A
	dc.b	nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nE2, $06, nRst, $06, nE2, $06, nRst, $06, nD2, $06, nCs2, $06
	dc.b	nB1, $06, nCs2, $0C
	smpsAlterVol        $0A
	smpsAlterVol        $FE
	dc.b	nA2, $06
	smpsAlterVol        $02
	dc.b	nE1, $03, nRst, $03
	smpsAlterVol        $FE
	dc.b	nG2, $06
	smpsAlterVol        $F8
	dc.b	nG3, $06, nRst, $06
	smpsAlterVol        $0A
	dc.b	nE1, $03, nRst, $03, nB0, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nA1, $0C
	smpsAlterVol        $0A
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nB0, $03, nRst, $03
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nD2, $0C, nB0, $03
	dc.b	nRst, $03, nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nCs3, $06, nD3, $06
	smpsAlterVol        $0A
	dc.b	nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nG2, $06, nRst, $06, nG2, $06, nRst, $06, nFs2, $06, nG2, $06
	dc.b	nRst, $06, nE2, $06
	smpsAlterVol        $0A
	dc.b	nE1, $03, nRst, $03, nE1, $03, nRst, $03, nE1, $03, nRst, $03
	dc.b	nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nEb2, $06, nE2, $06
	smpsAlterVol        $0A
	dc.b	nE1, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nA1, $0C
	smpsAlterVol        $0A
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nB0, $03, nRst, $03
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nD2, $0C, nB0, $03
	dc.b	nRst, $03, nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nCs3, $06, nD3, $06
	smpsAlterVol        $0A
	dc.b	nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nE2, $06, nRst, $06, nE2, $06, nRst, $06, nD2, $06, nCs2, $06
	dc.b	nB1, $06, nCs2, $0C
	smpsAlterVol        $0A
	smpsAlterVol        $FE
	dc.b	nA2, $06
	smpsAlterVol        $02
	dc.b	nE1, $03, nRst, $03
	smpsAlterVol        $FE
	dc.b	nG2, $06
	smpsAlterVol        $F8
	dc.b	nG3, $06, nRst, $06
	smpsAlterVol        $0A
	dc.b	nE1, $03, nRst, $03, nB0, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nA1, $0C
	smpsAlterVol        $0A
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nB0, $03, nRst, $03
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nD2, $0C, nB0, $03
	dc.b	nRst, $03, nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nCs3, $06, nD3, $06
	smpsAlterVol        $0A
	dc.b	nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nG2, $06, nRst, $06, nG2, $06, nRst, $06, nFs2, $06, nG2, $06
	dc.b	nRst, $06, nE2, $06
	smpsAlterVol        $0A
	dc.b	nE1, $03, nRst, $03, nE1, $03, nRst, $03, nE1, $03, nRst, $03
	dc.b	nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nEb2, $06, nE2, $06
	smpsAlterVol        $0A
	dc.b	nE1, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nA1, $0C
	smpsAlterVol        $0A
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nB0, $03, nRst, $03
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nD2, $0C, nB0, $03
	dc.b	nRst, $03, nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nCs3, $06, nD3, $06
	smpsAlterVol        $0A
	dc.b	nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nE2, $06, nRst, $06, nE2, $06, nRst, $06, nD2, $06, nCs2, $06
	dc.b	nB1, $06, nCs2, $0C
	smpsAlterVol        $0A
	smpsAlterVol        $FE
	dc.b	nA2, $06
	smpsAlterVol        $02
	dc.b	nE1, $03, nRst, $03
	smpsAlterVol        $FE
	dc.b	nG2, $06
	smpsAlterVol        $F8
	dc.b	nG3, $06, nRst, $06
	smpsAlterVol        $0A
	dc.b	nE1, $03, nRst, $03, nB0, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nA1, $0C
	smpsAlterVol        $0A
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nB0, $03, nRst, $03
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nD2, $0C, nB0, $03
	dc.b	nRst, $03, nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nCs3, $06, nD3, $06
	smpsAlterVol        $0A
	dc.b	nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nG2, $06, nRst, $06, nG2, $06, nRst, $06, nFs2, $06, nG2, $06
	dc.b	nRst, $06, nE2, $06
	smpsAlterVol        $0A
	dc.b	nE1, $03, nRst, $03, nE1, $03, nRst, $03, nE1, $03, nRst, $03
	dc.b	nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nEb2, $06, nE2, $06
	smpsAlterVol        $0A
	dc.b	nE1, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nD2, $06, nRst, $06, nD2, $06, nRst, $06, nD2, $06, nRst, $06
	dc.b	nD2, $06, nRst, $06, nCs2, $06, nD2, $06, nRst, $06, nD3, $06
	dc.b	nRst, $06, nCs3, $03, nRst, $03, nD3, $09, nRst, $03, nA1, $06
	dc.b	nRst, $06, nA1, $06, nRst, $06, nA1, $06, nRst, $06, nA1, $06
	dc.b	nRst, $06, nAb2, $06, nA2, $06, nRst, $06, nA2, $06, nRst, $06
	dc.b	nAb1, $03, nRst, $03, nA2, $09, nRst, $03, nD2, $06, nRst, $06
	dc.b	nD2, $06, nRst, $06, nD2, $06, nRst, $06, nD2, $06, nRst, $06
	dc.b	nCs2, $06, nD2, $06, nRst, $06, nD3, $06, nRst, $06, nCs3, $03
	dc.b	nRst, $03, nD3, $09, nRst, $03, nG2, $06, nRst, $06, nG2, $06
	dc.b	nRst, $06, nG2, $06, nRst, $06, nG2, $06, nE2, $0C, nE2, $0C
	dc.b	nE2, $06, nCs3, $03, nRst, $03, nCs3, $03, nRst, $03, nB2, $03
	dc.b	nRst, $03, nB2, $03, nRst, $03, nA1, $0C
	smpsAlterVol        $0A
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nB0, $03, nRst, $03
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nD2, $0C, nB0, $03
	dc.b	nRst, $03, nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nCs3, $06, nD3, $06
	smpsAlterVol        $0A
	dc.b	nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nE2, $06, nRst, $06, nE2, $06, nRst, $06, nD2, $06, nCs2, $06
	dc.b	nB1, $06, nCs2, $0C
	smpsAlterVol        $0A
	smpsAlterVol        $FE
	dc.b	nA2, $06
	smpsAlterVol        $02
	dc.b	nE1, $03, nRst, $03
	smpsAlterVol        $FE
	dc.b	nG2, $06
	smpsAlterVol        $F8
	dc.b	nG3, $06, nRst, $06
	smpsAlterVol        $0A
	dc.b	nE1, $03, nRst, $03, nB0, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nA1, $0C
	smpsAlterVol        $0A
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nB0, $03, nRst, $03
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nD2, $0C, nB0, $03
	dc.b	nRst, $03, nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nCs3, $06, nD3, $06
	smpsAlterVol        $0A
	dc.b	nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nG2, $06, nRst, $06, nG2, $06, nRst, $06, nFs2, $06, nG2, $06
	dc.b	nRst, $06, nE2, $06
	smpsAlterVol        $0A
	dc.b	nE1, $03, nRst, $03, nE1, $03, nRst, $03, nE1, $03, nRst, $03
	dc.b	nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nEb2, $06, nE2, $06
	smpsAlterVol        $0A
	dc.b	nE1, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F6
	dc.b	nD2, $06, nD1, $03, nRst, $03, nD2, $06, nD1, $03, nRst, $03
	dc.b	nD2, $03, nRst, $03, nD2, $09, nRst, $03, nE2, $0C, nE1, $03
	dc.b	nRst, $03, nE2, $06, nE1, $03, nRst, $03, nE2, $03, nRst, $03
	dc.b	nE2, $09, nRst, $03, nE1, $03, nRst, $03, nF2, $06, nF1, $03
	dc.b	nRst, $03, nF2, $06, nF1, $03, nRst, $03, nF2, $03, nRst, $03
	dc.b	nF2, $09, nRst, $03, nG2, $0C, nG1, $03, nRst, $03, nG2, $06
	dc.b	nG1, $03, nRst, $03, nG2, $03, nRst, $03, nG2, $09, nRst, $03
	dc.b	nG1, $03, nRst, $03, nA2, $06, nA1, $03, nRst, $03, nA2, $06
	dc.b	nA1, $03, nRst, $03, nA2, $06, nG2, $06, nA2, $06, nBb2, $06
	dc.b	nBb1, $03, nRst, $03, nBb2, $06, nBb1, $03, nRst, $03, nBb2, $06
	dc.b	nBb1, $03, nRst, $03, nBb2, $06, nA2, $06, nBb2, $06, nC3, $06
	dc.b	nC2, $03, nRst, $03, nC3, $06, nC2, $03, nRst, $03, nC3, $06
	dc.b	nBb2, $06, nC3, $06, nD3, $06, nD2, $03, nRst, $03, nD3, $06
	dc.b	nD2, $03, nRst, $03, nD3, $06, nD2, $03, nRst, $03, nD3, $06
	dc.b	nC3, $06, nD3, $06, nE3, $06, nE2, $03, nRst, $03, nE3, $06
	dc.b	nE2, $03, nRst, $03, nD3, $06, nD2, $03, nRst, $03, nD3, $06
	dc.b	nD2, $03, nRst, $03, nCs3, $06, nCs2, $03, nRst, $03, nCs3, $03
	dc.b	nRst, $03, nB2, $0C, nB1, $03, nRst, $03, nB2, $06, nB1, $03
	dc.b	nRst, $03, nE3, $06, nE2, $03, nRst, $03, nE3, $06, nE2, $03
	dc.b	nRst, $03, nD3, $06, nD2, $03, nRst, $03, nD3, $06, nD2, $03
	dc.b	nRst, $03, nCs3, $06, nCs2, $03, nRst, $03, nCs3, $03, nRst, $03
	dc.b	nB2, $0C, nB1, $03, nRst, $03, nB2, $06, nB1, $03
	smpsStop

; FM4 Data
SegaJingle_FM4:
	smpsPan             panRight, $00
	smpsSetvoice        $03
	dc.b	nRst, $7F, $2F, nG2, $0C, nRst, $06
	smpsAlterVol        $F8
	dc.b	nA1, $0C
	smpsAlterVol        $0B
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nB0, $03, nRst, $03
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nD2, $0C, nB0, $03
	dc.b	nRst, $03, nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nCs3, $06, nD3, $06
	smpsAlterVol        $0B
	dc.b	nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nE2, $06, nRst, $06, nE2, $06, nRst, $06, nD2, $06, nCs2, $06
	dc.b	nB1, $06, nCs2, $0C
	smpsAlterVol        $0B
	smpsAlterVol        $FD
	dc.b	nA2, $06
	smpsAlterVol        $03
	dc.b	nE1, $03, nRst, $03
	smpsAlterVol        $FD
	dc.b	nG2, $06
	smpsAlterVol        $F8
	dc.b	nG3, $06, nRst, $06
	smpsAlterVol        $0B
	dc.b	nE1, $03, nRst, $03, nB0, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nA1, $0C
	smpsAlterVol        $0B
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nB0, $03, nRst, $03
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nD2, $0C, nB0, $03
	dc.b	nRst, $03, nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nCs3, $06, nD3, $06
	smpsAlterVol        $0B
	dc.b	nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nG2, $06, nRst, $06, nG2, $06, nRst, $06, nFs2, $06, nG2, $06
	dc.b	nRst, $06, nE2, $06
	smpsAlterVol        $0B
	dc.b	nE1, $03, nRst, $03, nE1, $03, nRst, $03, nE1, $03, nRst, $03
	dc.b	nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nEb2, $06, nE2, $06
	smpsAlterVol        $0B
	dc.b	nE1, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nA1, $0C
	smpsAlterVol        $0B
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nB0, $03, nRst, $03
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nD2, $0C, nB0, $03
	dc.b	nRst, $03, nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nCs3, $06, nD3, $06
	smpsAlterVol        $0B
	dc.b	nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nE2, $06, nRst, $06, nE2, $06, nRst, $06, nD2, $06, nCs2, $06
	dc.b	nB1, $06, nCs2, $0C
	smpsAlterVol        $0B
	smpsAlterVol        $FD
	dc.b	nA2, $06
	smpsAlterVol        $03
	dc.b	nE1, $03, nRst, $03
	smpsAlterVol        $FD
	dc.b	nG2, $06
	smpsAlterVol        $F8
	dc.b	nG3, $06, nRst, $06
	smpsAlterVol        $0B
	dc.b	nE1, $03, nRst, $03, nB0, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nA1, $0C
	smpsAlterVol        $0B
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nB0, $03, nRst, $03
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nD2, $0C, nB0, $03
	dc.b	nRst, $03, nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nCs3, $06, nD3, $06
	smpsAlterVol        $0B
	dc.b	nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nG2, $06, nRst, $06, nG2, $06, nRst, $06, nFs2, $06, nG2, $06
	dc.b	nRst, $06, nE2, $06
	smpsAlterVol        $0B
	dc.b	nE1, $03, nRst, $03, nE1, $03, nRst, $03, nE1, $03, nRst, $03
	dc.b	nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nEb2, $06, nE2, $06
	smpsAlterVol        $0B
	dc.b	nE1, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nA1, $0C
	smpsAlterVol        $0B
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nB0, $03, nRst, $03
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nD2, $0C, nB0, $03
	dc.b	nRst, $03, nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nCs3, $06, nD3, $06
	smpsAlterVol        $0B
	dc.b	nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nE2, $06, nRst, $06, nE2, $06, nRst, $06, nD2, $06, nCs2, $06
	dc.b	nB1, $06, nCs2, $0C
	smpsAlterVol        $0B
	smpsAlterVol        $FD
	dc.b	nA2, $06
	smpsAlterVol        $03
	dc.b	nE1, $03, nRst, $03
	smpsAlterVol        $FD
	dc.b	nG2, $06
	smpsAlterVol        $F8
	dc.b	nG3, $06, nRst, $06
	smpsAlterVol        $0B
	dc.b	nE1, $03, nRst, $03, nB0, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nA1, $0C
	smpsAlterVol        $0B
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nB0, $03, nRst, $03
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nD2, $0C, nB0, $03
	dc.b	nRst, $03, nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nCs3, $06, nD3, $06
	smpsAlterVol        $0B
	dc.b	nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nG2, $06, nRst, $06, nG2, $06, nRst, $06, nFs2, $06, nG2, $06
	dc.b	nRst, $06, nE2, $06
	smpsAlterVol        $0B
	dc.b	nE1, $03, nRst, $03, nE1, $03, nRst, $03, nE1, $03, nRst, $03
	dc.b	nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nEb2, $06, nE2, $06
	smpsAlterVol        $0B
	dc.b	nE1, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nD2, $06, nRst, $06, nD2, $06, nRst, $06, nD2, $06, nRst, $06
	dc.b	nD2, $06, nRst, $06, nCs2, $06, nD2, $06, nRst, $06, nD3, $06
	dc.b	nRst, $06, nCs3, $03, nRst, $03, nD3, $09, nRst, $03, nA1, $06
	dc.b	nRst, $06, nA1, $06, nRst, $06, nA1, $06, nRst, $06, nA1, $06
	dc.b	nRst, $06, nAb2, $06, nA2, $06, nRst, $06, nA2, $06, nRst, $06
	dc.b	nAb1, $03, nRst, $03, nA2, $09, nRst, $03, nD2, $06, nRst, $06
	dc.b	nD2, $06, nRst, $06, nD2, $06, nRst, $06, nD2, $06, nRst, $06
	dc.b	nCs2, $06, nD2, $06, nRst, $06, nD3, $06, nRst, $06, nCs3, $03
	dc.b	nRst, $03, nD3, $09, nRst, $03, nG2, $06, nRst, $06, nG2, $06
	dc.b	nRst, $06, nG2, $06, nRst, $06, nG2, $06, nE2, $0C, nE2, $0C
	dc.b	nE2, $06, nCs3, $03, nRst, $03, nCs3, $03, nRst, $03, nB2, $03
	dc.b	nRst, $03, nB2, $03, nRst, $03, nA1, $0C
	smpsAlterVol        $0B
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nB0, $03, nRst, $03
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nD2, $0C, nB0, $03
	dc.b	nRst, $03, nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nCs3, $06, nD3, $06
	smpsAlterVol        $0B
	dc.b	nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nE2, $06, nRst, $06, nE2, $06, nRst, $06, nD2, $06, nCs2, $06
	dc.b	nB1, $06, nCs2, $0C
	smpsAlterVol        $0B
	smpsAlterVol        $FD
	dc.b	nA2, $06
	smpsAlterVol        $03
	dc.b	nE1, $03, nRst, $03
	smpsAlterVol        $FD
	dc.b	nG2, $06
	smpsAlterVol        $F8
	dc.b	nG3, $06, nRst, $06
	smpsAlterVol        $0B
	dc.b	nE1, $03, nRst, $03, nB0, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nA1, $0C
	smpsAlterVol        $0B
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nB0, $03, nRst, $03
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nD2, $0C, nB0, $03
	dc.b	nRst, $03, nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nCs3, $06, nD3, $06
	smpsAlterVol        $0B
	dc.b	nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nG2, $06, nRst, $06, nG2, $06, nRst, $06, nFs2, $06, nG2, $06
	dc.b	nRst, $06, nE2, $06
	smpsAlterVol        $0B
	dc.b	nE1, $03, nRst, $03, nE1, $03, nRst, $03, nE1, $03, nRst, $03
	dc.b	nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nEb2, $06, nE2, $06
	smpsAlterVol        $0B
	dc.b	nE1, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nD2, $06, nD1, $03, nRst, $03, nD2, $06, nD1, $03, nRst, $03
	dc.b	nD2, $03, nRst, $03, nD2, $09, nRst, $03, nE2, $0C, nE1, $03
	dc.b	nRst, $03, nE2, $06, nE1, $03, nRst, $03, nE2, $03, nRst, $03
	dc.b	nE2, $09, nRst, $03, nE1, $03, nRst, $03, nF2, $06, nF1, $03
	dc.b	nRst, $03, nF2, $06, nF1, $03, nRst, $03, nF2, $03, nRst, $03
	dc.b	nF2, $09, nRst, $03, nG2, $0C, nG1, $03, nRst, $03, nG2, $06
	dc.b	nG1, $03, nRst, $03, nG2, $03, nRst, $03, nG2, $09, nRst, $03
	dc.b	nG1, $03, nRst, $03, nA2, $06, nA1, $03, nRst, $03, nA2, $06
	dc.b	nA1, $03, nRst, $03, nA2, $06, nG2, $06, nA2, $06, nBb2, $06
	dc.b	nBb1, $03, nRst, $03, nBb2, $06, nBb1, $03, nRst, $03, nBb2, $06
	dc.b	nBb1, $03, nRst, $03, nBb2, $06, nA2, $06, nBb2, $06, nC3, $06
	dc.b	nC2, $03, nRst, $03, nC3, $06, nC2, $03, nRst, $03, nC3, $06
	dc.b	nBb2, $06, nC3, $06, nD3, $06, nD2, $03, nRst, $03, nD3, $06
	dc.b	nD2, $03, nRst, $03, nD3, $06, nD2, $03, nRst, $03, nD3, $06
	dc.b	nC3, $06, nD3, $06, nE3, $06, nE2, $03, nRst, $03, nE3, $06
	dc.b	nE2, $03, nRst, $03, nD3, $06, nD2, $03, nRst, $03, nD3, $06
	dc.b	nD2, $03, nRst, $03, nCs3, $06, nCs2, $03, nRst, $03, nCs3, $03
	dc.b	nRst, $03, nB2, $0C, nB1, $03, nRst, $03, nB2, $06, nB1, $03
	dc.b	nRst, $03, nE3, $06, nE2, $03, nRst, $03, nE3, $06, nE2, $03
	dc.b	nRst, $03, nD3, $06, nD2, $03, nRst, $03, nD3, $06, nD2, $03
	dc.b	nRst, $03, nCs3, $06, nCs2, $03, nRst, $03, nCs3, $03, nRst, $03
	dc.b	nB2, $0C, nB1, $03, nRst, $03, nB2, $06, nB1, $03, nRst, $03
	dc.b	nA1, $0C
	smpsAlterVol        $0B
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nB0, $03, nRst, $03
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nD2, $0C, nB0, $03
	dc.b	nRst, $03, nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nCs3, $06, nD3, $06
	smpsAlterVol        $0B
	dc.b	nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nE2, $06, nRst, $06, nE2, $06, nRst, $06, nD2, $06, nCs2, $06
	dc.b	nB1, $06, nCs2, $0C
	smpsAlterVol        $0B
	smpsAlterVol        $FD
	dc.b	nA2, $06
	smpsAlterVol        $03
	dc.b	nE1, $03, nRst, $03
	smpsAlterVol        $FD
	dc.b	nG2, $06
	smpsAlterVol        $F8
	dc.b	nG3, $06, nRst, $06
	smpsAlterVol        $0B
	dc.b	nE1, $03, nRst, $03, nB0, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nA1, $0C
	smpsAlterVol        $0B
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nB0, $03, nRst, $03
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nD2, $0C, nB0, $03
	dc.b	nRst, $03, nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nCs3, $06, nD3, $06
	smpsAlterVol        $0B
	dc.b	nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nG2, $06, nRst, $06, nG2, $06, nRst, $06, nFs2, $06, nG2, $06
	dc.b	nRst, $06, nE2, $06
	smpsAlterVol        $0B
	dc.b	nE1, $03, nRst, $03, nE1, $03, nRst, $03, nE1, $03, nRst, $03
	dc.b	nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nEb2, $06, nE2, $06
	smpsAlterVol        $0B
	dc.b	nE1, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nA1, $0C
	smpsAlterVol        $0B
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nB0, $03, nRst, $03
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nD2, $0C, nB0, $03
	dc.b	nRst, $03, nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nCs3, $06, nD3, $06
	smpsAlterVol        $0B
	dc.b	nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nE2, $06, nRst, $06, nE2, $06, nRst, $06, nD2, $06, nCs2, $06
	dc.b	nB1, $06, nCs2, $0C
	smpsAlterVol        $0B
	smpsAlterVol        $FD
	dc.b	nA2, $06
	smpsAlterVol        $03
	dc.b	nE1, $03, nRst, $03
	smpsAlterVol        $FD
	dc.b	nG2, $06
	smpsAlterVol        $F8
	dc.b	nG3, $06, nRst, $06
	smpsAlterVol        $0B
	dc.b	nE1, $03, nRst, $03, nB0, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nA1, $0C
	smpsAlterVol        $0B
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nB0, $03, nRst, $03
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nD2, $0C, nB0, $03
	dc.b	nRst, $03, nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nCs3, $06, nD3, $06
	smpsAlterVol        $0B
	dc.b	nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nG2, $06, nRst, $06, nG2, $06, nRst, $06, nFs2, $06, nG2, $06
	dc.b	nRst, $06, nE2, $06
	smpsAlterVol        $0B
	dc.b	nE1, $03, nRst, $03, nE1, $03, nRst, $03, nE1, $03, nRst, $03
	dc.b	nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nEb2, $06, nE2, $06
	smpsAlterVol        $0B
	dc.b	nE1, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nA1, $0C
	smpsAlterVol        $0B
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nB0, $03, nRst, $03
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nD2, $0C, nB0, $03
	dc.b	nRst, $03, nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nCs3, $06, nD3, $06
	smpsAlterVol        $0B
	dc.b	nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nE2, $06, nRst, $06, nE2, $06, nRst, $06, nD2, $06, nCs2, $06
	dc.b	nB1, $06, nCs2, $0C
	smpsAlterVol        $0B
	smpsAlterVol        $FD
	dc.b	nA2, $06
	smpsAlterVol        $03
	dc.b	nE1, $03, nRst, $03
	smpsAlterVol        $FD
	dc.b	nG2, $06
	smpsAlterVol        $F8
	dc.b	nG3, $06, nRst, $06
	smpsAlterVol        $0B
	dc.b	nE1, $03, nRst, $03, nB0, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nA1, $0C
	smpsAlterVol        $0B
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nB0, $03, nRst, $03
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nD2, $0C, nB0, $03
	dc.b	nRst, $03, nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nCs3, $06, nD3, $06
	smpsAlterVol        $0B
	dc.b	nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nG2, $06, nRst, $06, nG2, $06, nRst, $06, nFs2, $06, nG2, $06
	dc.b	nRst, $06, nE2, $06
	smpsAlterVol        $0B
	dc.b	nE1, $03, nRst, $03, nE1, $03, nRst, $03, nE1, $03, nRst, $03
	dc.b	nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nEb2, $06, nE2, $06
	smpsAlterVol        $0B
	dc.b	nE1, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nD2, $06, nRst, $06, nD2, $06, nRst, $06, nD2, $06, nRst, $06
	dc.b	nD2, $06, nRst, $06, nCs2, $06, nD2, $06, nRst, $06, nD3, $06
	dc.b	nRst, $06, nCs3, $03, nRst, $03, nD3, $09, nRst, $03, nA1, $06
	dc.b	nRst, $06, nA1, $06, nRst, $06, nA1, $06, nRst, $06, nA1, $06
	dc.b	nRst, $06, nAb2, $06, nA2, $06, nRst, $06, nA2, $06, nRst, $06
	dc.b	nAb1, $03, nRst, $03, nA2, $09, nRst, $03, nD2, $06, nRst, $06
	dc.b	nD2, $06, nRst, $06, nD2, $06, nRst, $06, nD2, $06, nRst, $06
	dc.b	nCs2, $06, nD2, $06, nRst, $06, nD3, $06, nRst, $06, nCs3, $03
	dc.b	nRst, $03, nD3, $09, nRst, $03, nG2, $06, nRst, $06, nG2, $06
	dc.b	nRst, $06, nG2, $06, nRst, $06, nG2, $06, nE2, $0C, nE2, $0C
	dc.b	nE2, $06, nCs3, $03, nRst, $03, nCs3, $03, nRst, $03, nB2, $03
	dc.b	nRst, $03, nB2, $03, nRst, $03, nA1, $0C
	smpsAlterVol        $0B
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nB0, $03, nRst, $03
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nD2, $0C, nB0, $03
	dc.b	nRst, $03, nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nCs3, $06, nD3, $06
	smpsAlterVol        $0B
	dc.b	nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nE2, $06, nRst, $06, nE2, $06, nRst, $06, nD2, $06, nCs2, $06
	dc.b	nB1, $06, nCs2, $0C
	smpsAlterVol        $0B
	smpsAlterVol        $FD
	dc.b	nA2, $06
	smpsAlterVol        $03
	dc.b	nE1, $03, nRst, $03
	smpsAlterVol        $FD
	dc.b	nG2, $06
	smpsAlterVol        $F8
	dc.b	nG3, $06, nRst, $06
	smpsAlterVol        $0B
	dc.b	nE1, $03, nRst, $03, nB0, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nA1, $0C
	smpsAlterVol        $0B
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nB0, $03, nRst, $03
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nD2, $0C, nB0, $03
	dc.b	nRst, $03, nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nCs3, $06, nD3, $06
	smpsAlterVol        $0B
	dc.b	nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nG2, $06, nRst, $06, nG2, $06, nRst, $06, nFs2, $06, nG2, $06
	dc.b	nRst, $06, nE2, $06
	smpsAlterVol        $0B
	dc.b	nE1, $03, nRst, $03, nE1, $03, nRst, $03, nE1, $03, nRst, $03
	dc.b	nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nEb2, $06, nE2, $06
	smpsAlterVol        $0B
	dc.b	nE1, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nD2, $06, nD1, $03, nRst, $03, nD2, $06, nD1, $03, nRst, $03
	dc.b	nD2, $03, nRst, $03, nD2, $09, nRst, $03, nE2, $0C, nE1, $03
	dc.b	nRst, $03, nE2, $06, nE1, $03, nRst, $03, nE2, $03, nRst, $03
	dc.b	nE2, $09, nRst, $03, nE1, $03, nRst, $03, nF2, $06, nF1, $03
	dc.b	nRst, $03, nF2, $06, nF1, $03, nRst, $03, nF2, $03, nRst, $03
	dc.b	nF2, $09, nRst, $03, nG2, $0C, nG1, $03, nRst, $03, nG2, $06
	dc.b	nG1, $03, nRst, $03, nG2, $03, nRst, $03, nG2, $09, nRst, $03
	dc.b	nG1, $03, nRst, $03, nA2, $06, nA1, $03, nRst, $03, nA2, $06
	dc.b	nA1, $03, nRst, $03, nA2, $06, nG2, $06, nA2, $06, nBb2, $06
	dc.b	nBb1, $03, nRst, $03, nBb2, $06, nBb1, $03, nRst, $03, nBb2, $06
	dc.b	nBb1, $03, nRst, $03, nBb2, $06, nA2, $06, nBb2, $06, nC3, $06
	dc.b	nC2, $03, nRst, $03, nC3, $06, nC2, $03, nRst, $03, nC3, $06
	dc.b	nBb2, $06, nC3, $06, nD3, $06, nD2, $03, nRst, $03, nD3, $06
	dc.b	nD2, $03, nRst, $03, nD3, $06, nD2, $03, nRst, $03, nD3, $06
	dc.b	nC3, $06, nD3, $06, nE3, $06, nE2, $03, nRst, $03, nE3, $06
	dc.b	nE2, $03, nRst, $03, nD3, $06, nD2, $03, nRst, $03, nD3, $06
	dc.b	nD2, $03, nRst, $03, nCs3, $06, nCs2, $03, nRst, $03, nCs3, $03
	dc.b	nRst, $03, nB2, $0C, nB1, $03, nRst, $03, nB2, $06, nB1, $03
	dc.b	nRst, $03, nE3, $06, nE2, $03, nRst, $03, nE3, $06, nE2, $03
	dc.b	nRst, $03, nD3, $06, nD2, $03, nRst, $03, nD3, $06, nD2, $03
	dc.b	nRst, $03, nCs3, $06, nCs2, $03, nRst, $03, nCs3, $03, nRst, $03
	dc.b	nB2, $0C, nB1, $03, nRst, $03, nB2, $06, nB1, $03, nRst, $03
	dc.b	nA1, $0C
	smpsAlterVol        $0B
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nB0, $03, nRst, $03
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nD2, $0C, nB0, $03
	dc.b	nRst, $03, nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nCs3, $06, nD3, $06
	smpsAlterVol        $0B
	dc.b	nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nE2, $06, nRst, $06, nE2, $06, nRst, $06, nD2, $06, nCs2, $06
	dc.b	nB1, $06, nCs2, $0C
	smpsAlterVol        $0B
	smpsAlterVol        $FD
	dc.b	nA2, $06
	smpsAlterVol        $03
	dc.b	nE1, $03, nRst, $03
	smpsAlterVol        $FD
	dc.b	nG2, $06
	smpsAlterVol        $F8
	dc.b	nG3, $06, nRst, $06
	smpsAlterVol        $0B
	dc.b	nE1, $03, nRst, $03, nB0, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nA1, $0C
	smpsAlterVol        $0B
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nB0, $03, nRst, $03
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nD2, $0C, nB0, $03
	dc.b	nRst, $03, nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nCs3, $06, nD3, $06
	smpsAlterVol        $0B
	dc.b	nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nG2, $06, nRst, $06, nG2, $06, nRst, $06, nFs2, $06, nG2, $06
	dc.b	nRst, $06, nE2, $06
	smpsAlterVol        $0B
	dc.b	nE1, $03, nRst, $03, nE1, $03, nRst, $03, nE1, $03, nRst, $03
	dc.b	nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nEb2, $06, nE2, $06
	smpsAlterVol        $0B
	dc.b	nE1, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nA1, $0C
	smpsAlterVol        $0B
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nB0, $03, nRst, $03
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nD2, $0C, nB0, $03
	dc.b	nRst, $03, nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nCs3, $06, nD3, $06
	smpsAlterVol        $0B
	dc.b	nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nE2, $06, nRst, $06, nE2, $06, nRst, $06, nD2, $06, nCs2, $06
	dc.b	nB1, $06, nCs2, $0C
	smpsAlterVol        $0B
	smpsAlterVol        $FD
	dc.b	nA2, $06
	smpsAlterVol        $03
	dc.b	nE1, $03, nRst, $03
	smpsAlterVol        $FD
	dc.b	nG2, $06
	smpsAlterVol        $F8
	dc.b	nG3, $06, nRst, $06
	smpsAlterVol        $0B
	dc.b	nE1, $03, nRst, $03, nB0, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nA1, $0C
	smpsAlterVol        $0B
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nB0, $03, nRst, $03
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nD2, $0C, nB0, $03
	dc.b	nRst, $03, nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nCs3, $06, nD3, $06
	smpsAlterVol        $0B
	dc.b	nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nG2, $06, nRst, $06, nG2, $06, nRst, $06, nFs2, $06, nG2, $06
	dc.b	nRst, $06, nE2, $06
	smpsAlterVol        $0B
	dc.b	nE1, $03, nRst, $03, nE1, $03, nRst, $03, nE1, $03, nRst, $03
	dc.b	nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nEb2, $06, nE2, $06
	smpsAlterVol        $0B
	dc.b	nE1, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nA1, $0C
	smpsAlterVol        $0B
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nB0, $03, nRst, $03
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nD2, $0C, nB0, $03
	dc.b	nRst, $03, nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nCs3, $06, nD3, $06
	smpsAlterVol        $0B
	dc.b	nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nE2, $06, nRst, $06, nE2, $06, nRst, $06, nD2, $06, nCs2, $06
	dc.b	nB1, $06, nCs2, $0C
	smpsAlterVol        $0B
	smpsAlterVol        $FD
	dc.b	nA2, $06
	smpsAlterVol        $03
	dc.b	nE1, $03, nRst, $03
	smpsAlterVol        $FD
	dc.b	nG2, $06
	smpsAlterVol        $F8
	dc.b	nG3, $06, nRst, $06
	smpsAlterVol        $0B
	dc.b	nE1, $03, nRst, $03, nB0, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nA1, $0C
	smpsAlterVol        $0B
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nB0, $03, nRst, $03
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nD2, $0C, nB0, $03
	dc.b	nRst, $03, nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nCs3, $06, nD3, $06
	smpsAlterVol        $0B
	dc.b	nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nG2, $06, nRst, $06, nG2, $06, nRst, $06, nFs2, $06, nG2, $06
	dc.b	nRst, $06, nE2, $06
	smpsAlterVol        $0B
	dc.b	nE1, $03, nRst, $03, nE1, $03, nRst, $03, nE1, $03, nRst, $03
	dc.b	nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nEb2, $06, nE2, $06
	smpsAlterVol        $0B
	dc.b	nE1, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nD2, $06, nRst, $06, nD2, $06, nRst, $06, nD2, $06, nRst, $06
	dc.b	nD2, $06, nRst, $06, nCs2, $06, nD2, $06, nRst, $06, nD3, $06
	dc.b	nRst, $06, nCs3, $03, nRst, $03, nD3, $09, nRst, $03, nA1, $06
	dc.b	nRst, $06, nA1, $06, nRst, $06, nA1, $06, nRst, $06, nA1, $06
	dc.b	nRst, $06, nAb2, $06, nA2, $06, nRst, $06, nA2, $06, nRst, $06
	dc.b	nAb1, $03, nRst, $03, nA2, $09, nRst, $03, nD2, $06, nRst, $06
	dc.b	nD2, $06, nRst, $06, nD2, $06, nRst, $06, nD2, $06, nRst, $06
	dc.b	nCs2, $06, nD2, $06, nRst, $06, nD3, $06, nRst, $06, nCs3, $03
	dc.b	nRst, $03, nD3, $09, nRst, $03, nG2, $06, nRst, $06, nG2, $06
	dc.b	nRst, $06, nG2, $06, nRst, $06, nG2, $06, nE2, $0C, nE2, $0C
	dc.b	nE2, $06, nCs3, $03, nRst, $03, nCs3, $03, nRst, $03, nB2, $03
	dc.b	nRst, $03, nB2, $03, nRst, $03, nA1, $0C
	smpsAlterVol        $0B
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nB0, $03, nRst, $03
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nD2, $0C, nB0, $03
	dc.b	nRst, $03, nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nCs3, $06, nD3, $06
	smpsAlterVol        $0B
	dc.b	nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nE2, $06, nRst, $06, nE2, $06, nRst, $06, nD2, $06, nCs2, $06
	dc.b	nB1, $06, nCs2, $0C
	smpsAlterVol        $0B
	smpsAlterVol        $FD
	dc.b	nA2, $06
	smpsAlterVol        $03
	dc.b	nE1, $03, nRst, $03
	smpsAlterVol        $FD
	dc.b	nG2, $06
	smpsAlterVol        $F8
	dc.b	nG3, $06, nRst, $06
	smpsAlterVol        $0B
	dc.b	nE1, $03, nRst, $03, nB0, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nA1, $0C
	smpsAlterVol        $0B
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nB0, $03, nRst, $03
	dc.b	nB0, $03, nRst, $03, nB0, $03, nRst, $03, nD2, $0C, nB0, $03
	dc.b	nRst, $03, nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nCs3, $06, nD3, $06
	smpsAlterVol        $0B
	dc.b	nB0, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nG2, $06, nRst, $06, nG2, $06, nRst, $06, nFs2, $06, nG2, $06
	dc.b	nRst, $06, nE2, $06
	smpsAlterVol        $0B
	dc.b	nE1, $03, nRst, $03, nE1, $03, nRst, $03, nE1, $03, nRst, $03
	dc.b	nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nEb2, $06, nE2, $06
	smpsAlterVol        $0B
	dc.b	nE1, $03, nRst, $03, nE1, $03, nRst, $03
	smpsAlterVol        $F5
	dc.b	nD2, $06, nD1, $03, nRst, $03, nD2, $06, nD1, $03, nRst, $03
	dc.b	nD2, $03, nRst, $03, nD2, $09, nRst, $03, nE2, $0C, nE1, $03
	dc.b	nRst, $03, nE2, $06, nE1, $03, nRst, $03, nE2, $03, nRst, $03
	dc.b	nE2, $09, nRst, $03, nE1, $03, nRst, $03, nF2, $06, nF1, $03
	dc.b	nRst, $03, nF2, $06, nF1, $03, nRst, $03, nF2, $03, nRst, $03
	dc.b	nF2, $09, nRst, $03, nG2, $0C, nG1, $03, nRst, $03, nG2, $06
	dc.b	nG1, $03, nRst, $03, nG2, $03, nRst, $03, nG2, $09, nRst, $03
	dc.b	nG1, $03, nRst, $03, nA2, $06, nA1, $03, nRst, $03, nA2, $06
	dc.b	nA1, $03, nRst, $03, nA2, $06, nG2, $06, nA2, $06, nBb2, $06
	dc.b	nBb1, $03, nRst, $03, nBb2, $06, nBb1, $03, nRst, $03, nBb2, $06
	dc.b	nBb1, $03, nRst, $03, nBb2, $06, nA2, $06, nBb2, $06, nC3, $06
	dc.b	nC2, $03, nRst, $03, nC3, $06, nC2, $03, nRst, $03, nC3, $06
	dc.b	nBb2, $06, nC3, $06, nD3, $06, nD2, $03, nRst, $03, nD3, $06
	dc.b	nD2, $03, nRst, $03, nD3, $06, nD2, $03, nRst, $03, nD3, $06
	dc.b	nC3, $06, nD3, $06, nE3, $06, nE2, $03, nRst, $03, nE3, $06
	dc.b	nE2, $03, nRst, $03, nD3, $06, nD2, $03, nRst, $03, nD3, $06
	dc.b	nD2, $03, nRst, $03, nCs3, $06, nCs2, $03, nRst, $03, nCs3, $03
	dc.b	nRst, $03, nB2, $0C, nB1, $03, nRst, $03, nB2, $06, nB1, $03
	dc.b	nRst, $03, nE3, $06, nE2, $03, nRst, $03, nE3, $06, nE2, $03
	dc.b	nRst, $03, nD3, $06, nD2, $03, nRst, $03, nD3, $06, nD2, $03
	dc.b	nRst, $03, nCs3, $06, nCs2, $03, nRst, $03, nCs3, $03, nRst, $03
	dc.b	nB2, $0C, nB1, $03, nRst, $03, nB2, $06, nB1, $03
	smpsStop

; FM5 Data
SegaJingle_FM5:
	smpsSetvoice        $04
	dc.b	nA4, $02, nRst, $0A, nA4, $12, nF5, $03, nRst, $03, nA4, $02
	dc.b	nRst, $04, nB4, $30, nRst, $06, nC5, $05, nRst, $07, nC5, $12
	dc.b	nAb5, $03, nRst, $03, nC5, $03, nRst, $03, nB5, $30, nRst, $6B
	dc.b	$6B, $6B, $6B, $6B, $6B, $6B, $6B, $6B, $6B, $6B, $6B, $6B
	dc.b	$6B, $6B, $6B, $6B, $6B, nA4, $02, nRst, $0A, nA4, $12, nF5
	dc.b	$03, nRst, $03, nA4, $02, nRst, $04, nB4, $24, nFs5, $0C, nAb5
	dc.b	$03, nRst, $03, nA5, $1E, nAb5, $03, nRst, $03, nC5, $03, nRst
	dc.b	$03, nD5, $24, nA5, $0C, nB5, $03, nRst, $03, nE5, $1E, nB5
	dc.b	$03, nRst, $03, nE5, $03, nRst, $03, nF5, $24, nCs6, $0C, nD6
	dc.b	$03, nRst, $03, nE6, $1E, nD6, $03, nRst, $03, nE6, $03, nRst
	dc.b	$03, nFs6, $24
	smpsAlterVol        $0C
	dc.b	nE6, $09, nRst, $03
	smpsAlterVol        $F4
	smpsAlterVol        $0C
	dc.b	nFs6, $03, nRst, $03
	smpsAlterVol        $F4
	dc.b	nB5, $5A, nRst, $06, nE6, $5A, nRst, $6B, $6B, $6B, $6B, $6B
	dc.b	$6B, $6B, $6B, $6B, $6B, $6B, $6B, $6B, $6B, $6B, $6B, $6B
	dc.b	$6B, nA4, $02, nRst, $0A, nA4, $12, nF5, $03, nRst, $03, nA4
	dc.b	$02, nRst, $04, nB4, $24, nFs5, $0C, nAb5, $03, nRst, $03, nA5
	dc.b	$1E, nAb5, $03, nRst, $03, nC5, $03, nRst, $03, nD5, $24, nA5
	dc.b	$0C, nB5, $03, nRst, $03, nE5, $1E, nB5, $03, nRst, $03, nE5
	dc.b	$03, nRst, $03, nF5, $24, nCs6, $0C, nD6, $03, nRst, $03, nE6
	dc.b	$1E, nD6, $03, nRst, $03, nE6, $03, nRst, $03, nFs6, $24
	smpsAlterVol        $0C
	dc.b	nE6, $09, nRst, $03
	smpsAlterVol        $F4
	smpsAlterVol        $0C
	dc.b	nFs6, $03, nRst, $03
	smpsAlterVol        $F4
	dc.b	nB5, $5A, nRst, $06, nE6, $5A, nRst, $6B, $6B, $6B, $6B, $6B
	dc.b	$6B, $6B, $6B, $6B, $6B, $6B, $6B, $6B, $6B, $6B, $6B, $6B
	dc.b	$6B, nA4, $02, nRst, $0A, nA4, $12, nF5, $03, nRst, $03, nA4
	dc.b	$02, nRst, $04, nB4, $24, nFs5, $0C, nAb5, $03, nRst, $03, nA5
	dc.b	$1E, nAb5, $03, nRst, $03, nC5, $03, nRst, $03, nD5, $24, nA5
	dc.b	$0C, nB5, $03, nRst, $03, nE5, $1E, nB5, $03, nRst, $03, nE5
	dc.b	$03, nRst, $03, nF5, $24, nCs6, $0C, nD6, $03, nRst, $03, nE6
	dc.b	$1E, nD6, $03, nRst, $03, nE6, $03, nRst, $03, nFs6, $24
	smpsAlterVol        $0C
	dc.b	nE6, $09, nRst, $03
	smpsAlterVol        $F4
	smpsAlterVol        $0C
	dc.b	nFs6, $03, nRst, $03
	smpsAlterVol        $F4
	dc.b	nB5, $5A, nRst, $06, nE6, $5A
	smpsStop

; FM6 Data
SegaJingle_FM6:
	smpsPan             panRight, $00
	smpsSetvoice        $04
	dc.b	nRst, $06, nA4, $02, nRst, $0A, nA4, $12, nF5, $03, nRst, $03
	dc.b	nA4, $02, nRst, $04, nB4, $30, nRst, $06, nC5, $05, nRst, $07
	dc.b	nC5, $12, nAb5, $03, nRst, $03, nC5, $03, nRst, $03, nB5, $30
	dc.b	nRst, $6B, $6B, $6B, $6B, $6B, $6B, $6B, $6B, $6B, $6B, $6B
	dc.b	$6B, $6B, $6B, $6B, $6B, $6B, $6B, nA4, $02, nRst, $0A, nA4
	dc.b	$12, nF5, $03, nRst, $03, nA4, $02, nRst, $04, nB4, $24, nFs5
	dc.b	$0C, nAb5, $03, nRst, $03, nA5, $1E, nAb5, $03, nRst, $03, nC5
	dc.b	$03, nRst, $03, nD5, $24, nA5, $0C, nB5, $03, nRst, $03, nE5
	dc.b	$1E, nB5, $03, nRst, $03, nE5, $03, nRst, $03, nF5, $24, nCs6
	dc.b	$0C, nD6, $03, nRst, $03, nE6, $1E, nD6, $03, nRst, $03, nE6
	dc.b	$03, nRst, $03, nFs6, $24
	smpsAlterVol        $0C
	dc.b	nE6, $09, nRst, $03
	smpsAlterVol        $F4
	smpsAlterVol        $0C
	dc.b	nFs6, $03, nRst, $03
	smpsAlterVol        $F4
	dc.b	nB5, $5A, nRst, $06, nE6, $5A, nRst, $6B, $6B, $6B, $6B, $6B
	dc.b	$6B, $6B, $6B, $6B, $6B, $6B, $6B, $6B, $6B, $6B, $6B, $6B
	dc.b	$6B, nA4, $02, nRst, $0A, nA4, $12, nF5, $03, nRst, $03, nA4
	dc.b	$02, nRst, $04, nB4, $24, nFs5, $0C, nAb5, $03, nRst, $03, nA5
	dc.b	$1E, nAb5, $03, nRst, $03, nC5, $03, nRst, $03, nD5, $24, nA5
	dc.b	$0C, nB5, $03, nRst, $03, nE5, $1E, nB5, $03, nRst, $03, nE5
	dc.b	$03, nRst, $03, nF5, $24, nCs6, $0C, nD6, $03, nRst, $03, nE6
	dc.b	$1E, nD6, $03, nRst, $03, nE6, $03, nRst, $03, nFs6, $24
	smpsAlterVol        $0C
	dc.b	nE6, $09, nRst, $03
	smpsAlterVol        $F4
	smpsAlterVol        $0C
	dc.b	nFs6, $03, nRst, $03
	smpsAlterVol        $F4
	dc.b	nB5, $5A, nRst, $06, nE6, $5A, nRst, $6B, $6B, $6B, $6B, $6B
	dc.b	$6B, $6B, $6B, $6B, $6B, $6B, $6B, $6B, $6B, $6B, $6B, $6B
	dc.b	$6B, nA4, $02, nRst, $0A, nA4, $12, nF5, $03, nRst, $03, nA4
	dc.b	$02, nRst, $04, nB4, $24, nFs5, $0C, nAb5, $03, nRst, $03, nA5
	dc.b	$1E, nAb5, $03, nRst, $03, nC5, $03, nRst, $03, nD5, $24, nA5
	dc.b	$0C, nB5, $03, nRst, $03, nE5, $1E, nB5, $03, nRst, $03, nE5
	dc.b	$03, nRst, $03, nF5, $24, nCs6, $0C, nD6, $03, nRst, $03, nE6
	dc.b	$1E, nD6, $03, nRst, $03, nE6, $03, nRst, $03, nFs6, $24
	smpsAlterVol        $0C
	dc.b	nE6, $09, nRst, $03
	smpsAlterVol        $F4
	smpsAlterVol        $0C
	dc.b	nFs6, $03, nRst, $03
	smpsAlterVol        $F4
	dc.b	nB5, $5A, nRst, $06, nE6, $5A
	smpsStop

; PSG1 Data
SegaJingle_PSG1:
	dc.b	nRst, $7F, $41, nG1, $06, nRst, $06, nG1, $06, nRst, $06, nG1
	dc.b	$06, nFs1, $06, nE1, $06, nFs1, $09, nRst, $03, nCs1, $06, nRst
	dc.b	$06, nA0, $06, nRst, $06, nA0, $06, nCs1, $06, nD1, $06, nE1
	dc.b	$06, nRst, $06, nE1, $06, nRst, $06, nD1, $06, nCs1, $06, nB0
	dc.b	$06, nCs1, $09, nRst, $03, nA0, $06, nRst, $06, nG0, $06, nRst
	dc.b	$06, nA0, $06, nCs1, $06, nE1, $06, nG1, $06, nRst, $06, nG1
	dc.b	$06, nRst, $06, nG1, $06, nFs1, $06, nE1, $06, nFs1, $09, nRst
	dc.b	$03, nCs1, $06, nRst, $06, nA0, $06, nRst, $06, nA0, $06, nCs1
	dc.b	$06, nE1, $06, nG1, $06, nRst, $06, nG1, $06, nRst, $06, nFs1
	dc.b	$06, nG1, $06, nRst, $06, nE1, $06, nRst, $1E, nA1, $06, nCs2
	dc.b	$06, nE2, $06, nG2, $06, nRst, $06, nG2, $06, nRst, $06, nG2
	dc.b	$06, nFs2, $06, nE2, $06, nFs2, $09, nRst, $03, nCs2, $06, nRst
	dc.b	$06, nA1, $06, nRst, $06, nA1, $06, nCs2, $06, nD2, $06, nE2
	dc.b	$06, nRst, $06, nE2, $06, nRst, $06, nD2, $06, nCs2, $06, nB1
	dc.b	$06, nCs2, $09, nRst, $03, nA1, $06, nRst, $06, nG1, $06, nRst
	dc.b	$06, nA1, $06, nCs2, $06, nE2, $06, nG2, $06, nRst, $06, nG2
	dc.b	$06, nRst, $06, nG2, $06, nFs2, $06, nE2, $06, nFs2, $09, nRst
	dc.b	$03, nCs2, $06, nRst, $06, nA1, $06, nRst, $06, nA1, $06, nCs2
	dc.b	$06, nE2, $06, nG2, $06, nRst, $06, nG2, $06, nRst, $06, nFs2
	dc.b	$06, nG2, $06, nRst, $06, nE2, $06, nRst, $1E, nA2, $06, nCs3
	dc.b	$06, nE3, $06, nG3, $06, nRst, $06, nG3, $06, nRst, $06, nG3
	dc.b	$06, nFs3, $06, nE3, $06, nFs3, $09, nRst, $03, nCs3, $06, nRst
	dc.b	$06, nA2, $06, nRst, $06, nA2, $06, nCs3, $06, nD3, $06, nE3
	dc.b	$06, nRst, $06, nE3, $06, nRst, $06, nD3, $06, nCs3, $06, nB2
	dc.b	$06, nCs3, $09, nRst, $03, nA2, $06, nRst, $06, nG2, $06, nRst
	dc.b	$06, nA2, $06, nCs3, $06, nE3, $06, nG3, $06, nRst, $06, nG3
	dc.b	$06, nRst, $06, nG3, $06, nFs3, $06, nE3, $06, nFs3, $09, nRst
	dc.b	$03, nCs3, $06, nRst, $06, nA2, $06, nRst, $06, nA2, $06, nCs3
	dc.b	$06, nE3, $06, nG3, $06, nRst, $06, nG3, $06, nRst, $06, nFs3
	dc.b	$06, nG3, $06, nRst, $06, nE3, $06, nRst, $0C, nD3, $06, nRst
	dc.b	$06, nCs3, $06, nRst, $06, nB2, $06, nRst, $06, nD3, $06, nRst
	dc.b	$06, nC3, $06, nRst, $06, nB2, $06, nRst, $06, nA2, $06, nRst
	dc.b	$06, nBb2, $01, nC3, $05, nB2, $06, nA2, $03, nRst, $03, nD2
	dc.b	$09, nRst, $03, nD2, $06, nFs2, $06, nA2, $06, nC3, $06, nRst
	dc.b	$06, nB2, $06, nRst, $06, nA2, $06, nRst, $06, nE2, $06, nRst
	dc.b	$06, nC2, $01, nCs2, $05, nA1, $0C, nRst, $0C, nD2, $03, nRst
	dc.b	$03, nFs2, $06, nA2, $06, nD3, $06, nRst, $06, nC3, $06, nRst
	dc.b	$06, nB2, $06, nRst, $06, nA2, $06, nRst, $06, nBb2, $01, nC3
	dc.b	$05, nB2, $06, nA2, $03, nRst, $03, nD2, $09, nRst, $03, nD2
	dc.b	$06, nFs2, $06, nA2, $06, nD3, $06, nRst, $06, nD3, $06, nRst
	dc.b	$06, nCs3, $06, nD3, $06, nRst, $06, nE3, $06, nRst, $1E, nA2
	dc.b	$06, nCs3, $06, nE3, $06, nG3, $06, nRst, $06, nG3, $06, nRst
	dc.b	$06, nG3, $06, nFs3, $06, nE3, $06, nFs3, $09, nRst, $03, nCs3
	dc.b	$06, nRst, $06, nA2, $06, nRst, $06, nA2, $06, nCs3, $06, nD3
	dc.b	$06, nE3, $06, nRst, $06, nE3, $06, nRst, $06, nD3, $06, nCs3
	dc.b	$06, nB2, $06, nCs3, $09, nRst, $03, nA2, $06, nRst, $06, nG2
	dc.b	$06, nRst, $06, nA2, $06, nCs3, $06, nE3, $06, nG3, $06, nRst
	dc.b	$06, nG3, $06, nRst, $06, nG3, $06, nFs3, $06, nE3, $06, nFs3
	dc.b	$09, nRst, $03, nCs3, $06, nRst, $06, nA2, $06, nRst, $06, nA2
	dc.b	$06, nCs3, $06, nE3, $06, nG3, $06, nRst, $06, nG3, $06, nRst
	dc.b	$06, nFs3, $06, nG3, $06, nRst, $06, nE3, $06, nRst, $0C, nD3
	dc.b	$06, nRst, $06, nCs3, $06, nRst, $06, nB2, $06, nRst, $06, nCs2
	dc.b	$12, nB1, $12, nE2, $06, nCs2, $18, nA1, $12, nB1, $0C, nC2
	dc.b	$1E, nD2, $06, nE2, $06, nD2, $1E, nG2, $18, nG2, $02, nAb2
	dc.b	$01, nA2, $1B, nG2, $06, nA2, $06, nBb2, $1E, nB2, $02, nCs3
	dc.b	$01, nD3, $15, nC3, $1E, nBb2, $06, nC3, $06, nD3, $36, nE3
	dc.b	$4E, nD3, $0C, nCs3, $06, nB2, $60, nG1, $06, nRst, $06, nG1
	dc.b	$06, nRst, $06, nG1, $06, nFs1, $06, nE1, $06, nFs1, $09, nRst
	dc.b	$03, nCs1, $06, nRst, $06, nA0, $06, nRst, $06, nA0, $06, nCs1
	dc.b	$06, nD1, $06, nE1, $06, nRst, $06, nE1, $06, nRst, $06, nD1
	dc.b	$06, nCs1, $06, nB0, $06, nCs1, $09, nRst, $03, nA0, $06, nRst
	dc.b	$06, nG0, $06, nRst, $06, nA0, $06, nCs1, $06, nE1, $06, nG1
	dc.b	$06, nRst, $06, nG1, $06, nRst, $06, nG1, $06, nFs1, $06, nE1
	dc.b	$06, nFs1, $09, nRst, $03, nCs1, $06, nRst, $06, nA0, $06, nRst
	dc.b	$06, nA0, $06, nCs1, $06, nE1, $06, nG1, $06, nRst, $06, nG1
	dc.b	$06, nRst, $06, nFs1, $06, nG1, $06, nRst, $06, nE1, $06, nRst
	dc.b	$1E, nA1, $06, nCs2, $06, nE2, $06, nG2, $06, nRst, $06, nG2
	dc.b	$06, nRst, $06, nG2, $06, nFs2, $06, nE2, $06, nFs2, $09, nRst
	dc.b	$03, nCs2, $06, nRst, $06, nA1, $06, nRst, $06, nA1, $06, nCs2
	dc.b	$06, nD2, $06, nE2, $06, nRst, $06, nE2, $06, nRst, $06, nD2
	dc.b	$06, nCs2, $06, nB1, $06, nCs2, $09, nRst, $03, nA1, $06, nRst
	dc.b	$06, nG1, $06, nRst, $06, nA1, $06, nCs2, $06, nE2, $06, nG2
	dc.b	$06, nRst, $06, nG2, $06, nRst, $06, nG2, $06, nFs2, $06, nE2
	dc.b	$06, nFs2, $09, nRst, $03, nCs2, $06, nRst, $06, nA1, $06, nRst
	dc.b	$06, nA1, $06, nCs2, $06, nE2, $06, nG2, $06, nRst, $06, nG2
	dc.b	$06, nRst, $06, nFs2, $06, nG2, $06, nRst, $06, nE2, $06, nRst
	dc.b	$1E, nA2, $06, nCs3, $06, nE3, $06, nG3, $06, nRst, $06, nG3
	dc.b	$06, nRst, $06, nG3, $06, nFs3, $06, nE3, $06, nFs3, $09, nRst
	dc.b	$03, nCs3, $06, nRst, $06, nA2, $06, nRst, $06, nA2, $06, nCs3
	dc.b	$06, nD3, $06, nE3, $06, nRst, $06, nE3, $06, nRst, $06, nD3
	dc.b	$06, nCs3, $06, nB2, $06, nCs3, $09, nRst, $03, nA2, $06, nRst
	dc.b	$06, nG2, $06, nRst, $06, nA2, $06, nCs3, $06, nE3, $06, nG3
	dc.b	$06, nRst, $06, nG3, $06, nRst, $06, nG3, $06, nFs3, $06, nE3
	dc.b	$06, nFs3, $09, nRst, $03, nCs3, $06, nRst, $06, nA2, $06, nRst
	dc.b	$06, nA2, $06, nCs3, $06, nE3, $06, nG3, $06, nRst, $06, nG3
	dc.b	$06, nRst, $06, nFs3, $06, nG3, $06, nRst, $06, nE3, $06, nRst
	dc.b	$0C, nD3, $06, nRst, $06, nCs3, $06, nRst, $06, nB2, $06, nRst
	dc.b	$06, nD3, $06, nRst, $06, nC3, $06, nRst, $06, nB2, $06, nRst
	dc.b	$06, nA2, $06, nRst, $06, nBb2, $01, nC3, $05, nB2, $06, nA2
	dc.b	$03, nRst, $03, nD2, $09, nRst, $03, nD2, $06, nFs2, $06, nA2
	dc.b	$06, nC3, $06, nRst, $06, nB2, $06, nRst, $06, nA2, $06, nRst
	dc.b	$06, nE2, $06, nRst, $06, nC2, $01, nCs2, $05, nA1, $0C, nRst
	dc.b	$0C, nD2, $03, nRst, $03, nFs2, $06, nA2, $06, nD3, $06, nRst
	dc.b	$06, nC3, $06, nRst, $06, nB2, $06, nRst, $06, nA2, $06, nRst
	dc.b	$06, nBb2, $01, nC3, $05, nB2, $06, nA2, $03, nRst, $03, nD2
	dc.b	$09, nRst, $03, nD2, $06, nFs2, $06, nA2, $06, nD3, $06, nRst
	dc.b	$06, nD3, $06, nRst, $06, nCs3, $06, nD3, $06, nRst, $06, nE3
	dc.b	$06, nRst, $1E, nA2, $06, nCs3, $06, nE3, $06, nG3, $06, nRst
	dc.b	$06, nG3, $06, nRst, $06, nG3, $06, nFs3, $06, nE3, $06, nFs3
	dc.b	$09, nRst, $03, nCs3, $06, nRst, $06, nA2, $06, nRst, $06, nA2
	dc.b	$06, nCs3, $06, nD3, $06, nE3, $06, nRst, $06, nE3, $06, nRst
	dc.b	$06, nD3, $06, nCs3, $06, nB2, $06, nCs3, $09, nRst, $03, nA2
	dc.b	$06, nRst, $06, nG2, $06, nRst, $06, nA2, $06, nCs3, $06, nE3
	dc.b	$06, nG3, $06, nRst, $06, nG3, $06, nRst, $06, nG3, $06, nFs3
	dc.b	$06, nE3, $06, nFs3, $09, nRst, $03, nCs3, $06, nRst, $06, nA2
	dc.b	$06, nRst, $06, nA2, $06, nCs3, $06, nE3, $06, nG3, $06, nRst
	dc.b	$06, nG3, $06, nRst, $06, nFs3, $06, nG3, $06, nRst, $06, nE3
	dc.b	$06, nRst, $0C, nD3, $06, nRst, $06, nCs3, $06, nRst, $06, nB2
	dc.b	$06, nRst, $06, nCs2, $12, nB1, $12, nE2, $06, nCs2, $18, nA1
	dc.b	$12, nB1, $0C, nC2, $1E, nD2, $06, nE2, $06, nD2, $1E, nG2
	dc.b	$18, nG2, $02, nAb2, $01, nA2, $1B, nG2, $06, nA2, $06, nBb2
	dc.b	$1E, nB2, $02, nCs3, $01, nD3, $15, nC3, $1E, nBb2, $06, nC3
	dc.b	$06, nD3, $36, nE3, $4E, nD3, $0C, nCs3, $06, nB2, $60, nG1
	dc.b	$06, nRst, $06, nG1, $06, nRst, $06, nG1, $06, nFs1, $06, nE1
	dc.b	$06, nFs1, $09, nRst, $03, nCs1, $06, nRst, $06, nA0, $06, nRst
	dc.b	$06, nA0, $06, nCs1, $06, nD1, $06, nE1, $06, nRst, $06, nE1
	dc.b	$06, nRst, $06, nD1, $06, nCs1, $06, nB0, $06, nCs1, $09, nRst
	dc.b	$03, nA0, $06, nRst, $06, nG0, $06, nRst, $06, nA0, $06, nCs1
	dc.b	$06, nE1, $06, nG1, $06, nRst, $06, nG1, $06, nRst, $06, nG1
	dc.b	$06, nFs1, $06, nE1, $06, nFs1, $09, nRst, $03, nCs1, $06, nRst
	dc.b	$06, nA0, $06, nRst, $06, nA0, $06, nCs1, $06, nE1, $06, nG1
	dc.b	$06, nRst, $06, nG1, $06, nRst, $06, nFs1, $06, nG1, $06, nRst
	dc.b	$06, nE1, $06, nRst, $1E, nA1, $06, nCs2, $06, nE2, $06, nG2
	dc.b	$06, nRst, $06, nG2, $06, nRst, $06, nG2, $06, nFs2, $06, nE2
	dc.b	$06, nFs2, $09, nRst, $03, nCs2, $06, nRst, $06, nA1, $06, nRst
	dc.b	$06, nA1, $06, nCs2, $06, nD2, $06, nE2, $06, nRst, $06, nE2
	dc.b	$06, nRst, $06, nD2, $06, nCs2, $06, nB1, $06, nCs2, $09, nRst
	dc.b	$03, nA1, $06, nRst, $06, nG1, $06, nRst, $06, nA1, $06, nCs2
	dc.b	$06, nE2, $06, nG2, $06, nRst, $06, nG2, $06, nRst, $06, nG2
	dc.b	$06, nFs2, $06, nE2, $06, nFs2, $09, nRst, $03, nCs2, $06, nRst
	dc.b	$06, nA1, $06, nRst, $06, nA1, $06, nCs2, $06, nE2, $06, nG2
	dc.b	$06, nRst, $06, nG2, $06, nRst, $06, nFs2, $06, nG2, $06, nRst
	dc.b	$06, nE2, $06, nRst, $1E, nA2, $06, nCs3, $06, nE3, $06, nG3
	dc.b	$06, nRst, $06, nG3, $06, nRst, $06, nG3, $06, nFs3, $06, nE3
	dc.b	$06, nFs3, $09, nRst, $03, nCs3, $06, nRst, $06, nA2, $06, nRst
	dc.b	$06, nA2, $06, nCs3, $06, nD3, $06, nE3, $06, nRst, $06, nE3
	dc.b	$06, nRst, $06, nD3, $06, nCs3, $06, nB2, $06, nCs3, $09, nRst
	dc.b	$03, nA2, $06, nRst, $06, nG2, $06, nRst, $06, nA2, $06, nCs3
	dc.b	$06, nE3, $06, nG3, $06, nRst, $06, nG3, $06, nRst, $06, nG3
	dc.b	$06, nFs3, $06, nE3, $06, nFs3, $09, nRst, $03, nCs3, $06, nRst
	dc.b	$06, nA2, $06, nRst, $06, nA2, $06, nCs3, $06, nE3, $06, nG3
	dc.b	$06, nRst, $06, nG3, $06, nRst, $06, nFs3, $06, nG3, $06, nRst
	dc.b	$06, nE3, $06, nRst, $0C, nD3, $06, nRst, $06, nCs3, $06, nRst
	dc.b	$06, nB2, $06, nRst, $06, nD3, $06, nRst, $06, nC3, $06, nRst
	dc.b	$06, nB2, $06, nRst, $06, nA2, $06, nRst, $06, nBb2, $01, nC3
	dc.b	$05, nB2, $06, nA2, $03, nRst, $03, nD2, $09, nRst, $03, nD2
	dc.b	$06, nFs2, $06, nA2, $06, nC3, $06, nRst, $06, nB2, $06, nRst
	dc.b	$06, nA2, $06, nRst, $06, nE2, $06, nRst, $06, nC2, $01, nCs2
	dc.b	$05, nA1, $0C, nRst, $0C, nD2, $03, nRst, $03, nFs2, $06, nA2
	dc.b	$06, nD3, $06, nRst, $06, nC3, $06, nRst, $06, nB2, $06, nRst
	dc.b	$06, nA2, $06, nRst, $06, nBb2, $01, nC3, $05, nB2, $06, nA2
	dc.b	$03, nRst, $03, nD2, $09, nRst, $03, nD2, $06, nFs2, $06, nA2
	dc.b	$06, nD3, $06, nRst, $06, nD3, $06, nRst, $06, nCs3, $06, nD3
	dc.b	$06, nRst, $06, nE3, $06, nRst, $1E, nA2, $06, nCs3, $06, nE3
	dc.b	$06, nG3, $06, nRst, $06, nG3, $06, nRst, $06, nG3, $06, nFs3
	dc.b	$06, nE3, $06, nFs3, $09, nRst, $03, nCs3, $06, nRst, $06, nA2
	dc.b	$06, nRst, $06, nA2, $06, nCs3, $06, nD3, $06, nE3, $06, nRst
	dc.b	$06, nE3, $06, nRst, $06, nD3, $06, nCs3, $06, nB2, $06, nCs3
	dc.b	$09, nRst, $03, nA2, $06, nRst, $06, nG2, $06, nRst, $06, nA2
	dc.b	$06, nCs3, $06, nE3, $06, nG3, $06, nRst, $06, nG3, $06, nRst
	dc.b	$06, nG3, $06, nFs3, $06, nE3, $06, nFs3, $09, nRst, $03, nCs3
	dc.b	$06, nRst, $06, nA2, $06, nRst, $06, nA2, $06, nCs3, $06, nE3
	dc.b	$06, nG3, $06, nRst, $06, nG3, $06, nRst, $06, nFs3, $06, nG3
	dc.b	$06, nRst, $06, nE3, $06, nRst, $0C, nD3, $06, nRst, $06, nCs3
	dc.b	$06, nRst, $06, nB2, $06, nRst, $06, nCs2, $12, nB1, $12, nE2
	dc.b	$06, nCs2, $18, nA1, $12, nB1, $0C, nC2, $1E, nD2, $06, nE2
	dc.b	$06, nD2, $1E, nG2, $18, nG2, $02, nAb2, $01, nA2, $1B, nG2
	dc.b	$06, nA2, $06, nBb2, $1E, nB2, $02, nCs3, $01, nD3, $15, nC3
	dc.b	$1E, nBb2, $06, nC3, $06, nD3, $36, nE3, $4E, nD3, $0C, nCs3
	dc.b	$06, nB2, $60
	smpsStop

; PSG2 Data
SegaJingle_PSG2:
	dc.b	nRst, $5E, $5E, $5E, $5E, $5E, $5E, $5E, $5E, $5E, $5E, $02
	dc.b	nE2, $06, nA2, $06, nB2, $06, nD3, $06, nRst, $06, nD3, $06
	dc.b	nRst, $06, nD3, $06, nCs3, $06, nB2, $06, nCs3, $09, nRst, $03
	dc.b	nAb2, $06, nRst, $06, nE2, $06, nRst, $06, nE2, $06, nAb2, $06
	dc.b	nA2, $06, nB2, $06, nRst, $06, nB2, $06, nRst, $06, nA2, $06
	dc.b	nAb2, $06, nFs2, $06, nAb2, $09, nRst, $03, nE2, $06, nRst, $06
	dc.b	nD2, $06, nRst, $06, nE2, $06, nAb2, $06, nB2, $06, nD3, $06
	dc.b	nRst, $06, nD3, $06, nRst, $06, nD3, $06, nCs3, $06, nB2, $06
	dc.b	nCs3, $09, nRst, $03, nAb2, $06, nRst, $06, nE2, $06, nRst, $06
	dc.b	nE2, $06, nAb2, $06, nB2, $06, nD3, $06, nRst, $06, nD3, $06
	dc.b	nRst, $06, nCs3, $06, nD3, $06, nRst, $06, nB2, $06, nRst, $0C
	dc.b	nA2, $06, nRst, $06, nAb2, $06, nRst, $06, nFs2, $06, nRst, $06
	smpsPSGAlterVol     $01
	dc.b	nA1, $06, nRst, $06
	smpsPSGAlterVol     $FF
	smpsPSGAlterVol     $01
	dc.b	nG1, $06, nRst, $06
	smpsPSGAlterVol     $FF
	smpsPSGAlterVol     $01
	dc.b	nFs1, $06, nRst, $06
	smpsPSGAlterVol     $FF
	smpsPSGAlterVol     $01
	dc.b	nE1, $06, nRst, $06
	smpsPSGAlterVol     $FF
	dc.b	nBb1, $01, nC2, $05, nB1, $06, nA1, $03, nRst, $03, nD1, $09
	dc.b	nRst, $03, nD1, $06, nFs1, $06, nA1, $06, nC2, $06, nRst, $06
	dc.b	nB1, $06, nRst, $06, nA1, $06, nRst, $06, nE1, $06, nRst, $06
	dc.b	nC1, $01, nCs1, $05, nA0, $0C, nRst, $0C, nD1, $03, nRst, $03
	dc.b	nFs1, $06, nA1, $06, nD2, $06, nRst, $06, nC2, $06, nRst, $06
	dc.b	nB1, $06, nRst, $06, nA1, $06, nRst, $06, nBb1, $01, nC2, $05
	dc.b	nB1, $06, nA1, $03, nRst, $03, nD1, $09, nRst, $03, nD1, $06
	dc.b	nFs1, $06, nA1, $06, nD2, $06, nRst, $06, nD2, $06, nRst, $06
	dc.b	nCs2, $06, nD2, $06, nRst, $06, nE2, $06, nRst, $1E, nE2, $06
	dc.b	nA2, $06, nB2, $06, nD3, $06, nRst, $06, nD3, $06, nRst, $06
	dc.b	nD3, $06, nCs3, $06, nB2, $06, nCs3, $09, nRst, $03, nAb2, $06
	dc.b	nRst, $06, nE2, $06, nRst, $06, nE2, $06, nAb2, $06, nA2, $06
	dc.b	nB2, $06, nRst, $06, nB2, $06, nRst, $06, nA2, $06, nAb2, $06
	dc.b	nFs2, $06, nAb2, $09, nRst, $03, nE2, $06, nRst, $06, nD2, $06
	dc.b	nRst, $06, nE2, $06, nAb2, $06, nB2, $06, nD3, $06, nRst, $06
	dc.b	nD3, $06, nRst, $06, nD3, $06, nCs3, $06, nB2, $06, nCs3, $09
	dc.b	nRst, $03, nAb2, $06, nRst, $06, nE2, $06, nRst, $06, nE2, $06
	dc.b	nAb2, $06, nB2, $06, nD3, $06, nRst, $06, nD3, $06, nRst, $06
	dc.b	nCs3, $06, nD3, $06, nRst, $06, nB2, $06, nRst, $0C, nA2, $06
	dc.b	nRst, $06, nAb2, $06, nRst, $06, nFs2, $06, nRst, $6F, $6F, $6F
	dc.b	$6F, $6F, $6F, $6F, $6F, $6F, $6F, $6F, $6F, nE2, $06, nA2
	dc.b	$06, nB2, $06, nD3, $06, nRst, $06, nD3, $06, nRst, $06, nD3
	dc.b	$06, nCs3, $06, nB2, $06, nCs3, $09, nRst, $03, nAb2, $06, nRst
	dc.b	$06, nE2, $06, nRst, $06, nE2, $06, nAb2, $06, nA2, $06, nB2
	dc.b	$06, nRst, $06, nB2, $06, nRst, $06, nA2, $06, nAb2, $06, nFs2
	dc.b	$06, nAb2, $09, nRst, $03, nE2, $06, nRst, $06, nD2, $06, nRst
	dc.b	$06, nE2, $06, nAb2, $06, nB2, $06, nD3, $06, nRst, $06, nD3
	dc.b	$06, nRst, $06, nD3, $06, nCs3, $06, nB2, $06, nCs3, $09, nRst
	dc.b	$03, nAb2, $06, nRst, $06, nE2, $06, nRst, $06, nE2, $06, nAb2
	dc.b	$06, nB2, $06, nD3, $06, nRst, $06, nD3, $06, nRst, $06, nCs3
	dc.b	$06, nD3, $06, nRst, $06, nB2, $06, nRst, $0C, nA2, $06, nRst
	dc.b	$06, nAb2, $06, nRst, $06, nFs2, $06, nRst, $06
	smpsPSGAlterVol     $01
	dc.b	nA1, $06, nRst, $06
	smpsPSGAlterVol     $FF
	smpsPSGAlterVol     $01
	dc.b	nG1, $06, nRst, $06
	smpsPSGAlterVol     $FF
	smpsPSGAlterVol     $01
	dc.b	nFs1, $06, nRst, $06
	smpsPSGAlterVol     $FF
	smpsPSGAlterVol     $01
	dc.b	nE1, $06, nRst, $06
	smpsPSGAlterVol     $FF
	dc.b	nBb1, $01, nC2, $05, nB1, $06, nA1, $03, nRst, $03, nD1, $09
	dc.b	nRst, $03, nD1, $06, nFs1, $06, nA1, $06, nC2, $06, nRst, $06
	dc.b	nB1, $06, nRst, $06, nA1, $06, nRst, $06, nE1, $06, nRst, $06
	dc.b	nC1, $01, nCs1, $05, nA0, $0C, nRst, $0C, nD1, $03, nRst, $03
	dc.b	nFs1, $06, nA1, $06, nD2, $06, nRst, $06, nC2, $06, nRst, $06
	dc.b	nB1, $06, nRst, $06, nA1, $06, nRst, $06, nBb1, $01, nC2, $05
	dc.b	nB1, $06, nA1, $03, nRst, $03, nD1, $09, nRst, $03, nD1, $06
	dc.b	nFs1, $06, nA1, $06, nD2, $06, nRst, $06, nD2, $06, nRst, $06
	dc.b	nCs2, $06, nD2, $06, nRst, $06, nE2, $06, nRst, $1E, nE2, $06
	dc.b	nA2, $06, nB2, $06, nD3, $06, nRst, $06, nD3, $06, nRst, $06
	dc.b	nD3, $06, nCs3, $06, nB2, $06, nCs3, $09, nRst, $03, nAb2, $06
	dc.b	nRst, $06, nE2, $06, nRst, $06, nE2, $06, nAb2, $06, nA2, $06
	dc.b	nB2, $06, nRst, $06, nB2, $06, nRst, $06, nA2, $06, nAb2, $06
	dc.b	nFs2, $06, nAb2, $09, nRst, $03, nE2, $06, nRst, $06, nD2, $06
	dc.b	nRst, $06, nE2, $06, nAb2, $06, nB2, $06, nD3, $06, nRst, $06
	dc.b	nD3, $06, nRst, $06, nD3, $06, nCs3, $06, nB2, $06, nCs3, $09
	dc.b	nRst, $03, nAb2, $06, nRst, $06, nE2, $06, nRst, $06, nE2, $06
	dc.b	nAb2, $06, nB2, $06, nD3, $06, nRst, $06, nD3, $06, nRst, $06
	dc.b	nCs3, $06, nD3, $06, nRst, $06, nB2, $06, nRst, $0C, nA2, $06
	dc.b	nRst, $06, nAb2, $06, nRst, $06, nFs2, $06, nRst, $6F, $6F, $6F
	dc.b	$6F, $6F, $6F, $6F, $6F, $6F, $6F, $6F, $6F, nE2, $06, nA2
	dc.b	$06, nB2, $06, nD3, $06, nRst, $06, nD3, $06, nRst, $06, nD3
	dc.b	$06, nCs3, $06, nB2, $06, nCs3, $09, nRst, $03, nAb2, $06, nRst
	dc.b	$06, nE2, $06, nRst, $06, nE2, $06, nAb2, $06, nA2, $06, nB2
	dc.b	$06, nRst, $06, nB2, $06, nRst, $06, nA2, $06, nAb2, $06, nFs2
	dc.b	$06, nAb2, $09, nRst, $03, nE2, $06, nRst, $06, nD2, $06, nRst
	dc.b	$06, nE2, $06, nAb2, $06, nB2, $06, nD3, $06, nRst, $06, nD3
	dc.b	$06, nRst, $06, nD3, $06, nCs3, $06, nB2, $06, nCs3, $09, nRst
	dc.b	$03, nAb2, $06, nRst, $06, nE2, $06, nRst, $06, nE2, $06, nAb2
	dc.b	$06, nB2, $06, nD3, $06, nRst, $06, nD3, $06, nRst, $06, nCs3
	dc.b	$06, nD3, $06, nRst, $06, nB2, $06, nRst, $0C, nA2, $06, nRst
	dc.b	$06, nAb2, $06, nRst, $06, nFs2, $06, nRst, $06
	smpsPSGAlterVol     $01
	dc.b	nA1, $06, nRst, $06
	smpsPSGAlterVol     $FF
	smpsPSGAlterVol     $01
	dc.b	nG1, $06, nRst, $06
	smpsPSGAlterVol     $FF
	smpsPSGAlterVol     $01
	dc.b	nFs1, $06, nRst, $06
	smpsPSGAlterVol     $FF
	smpsPSGAlterVol     $01
	dc.b	nE1, $06, nRst, $06
	smpsPSGAlterVol     $FF
	dc.b	nBb1, $01, nC2, $05, nB1, $06, nA1, $03, nRst, $03, nD1, $09
	dc.b	nRst, $03, nD1, $06, nFs1, $06, nA1, $06, nC2, $06, nRst, $06
	dc.b	nB1, $06, nRst, $06, nA1, $06, nRst, $06, nE1, $06, nRst, $06
	dc.b	nC1, $01, nCs1, $05, nA0, $0C, nRst, $0C, nD1, $03, nRst, $03
	dc.b	nFs1, $06, nA1, $06, nD2, $06, nRst, $06, nC2, $06, nRst, $06
	dc.b	nB1, $06, nRst, $06, nA1, $06, nRst, $06, nBb1, $01, nC2, $05
	dc.b	nB1, $06, nA1, $03, nRst, $03, nD1, $09, nRst, $03, nD1, $06
	dc.b	nFs1, $06, nA1, $06, nD2, $06, nRst, $06, nD2, $06, nRst, $06
	dc.b	nCs2, $06, nD2, $06, nRst, $06, nE2, $06, nRst, $1E, nE2, $06
	dc.b	nA2, $06, nB2, $06, nD3, $06, nRst, $06, nD3, $06, nRst, $06
	dc.b	nD3, $06, nCs3, $06, nB2, $06, nCs3, $09, nRst, $03, nAb2, $06
	dc.b	nRst, $06, nE2, $06, nRst, $06, nE2, $06, nAb2, $06, nA2, $06
	dc.b	nB2, $06, nRst, $06, nB2, $06, nRst, $06, nA2, $06, nAb2, $06
	dc.b	nFs2, $06, nAb2, $09, nRst, $03, nE2, $06, nRst, $06, nD2, $06
	dc.b	nRst, $06, nE2, $06, nAb2, $06, nB2, $06, nD3, $06, nRst, $06
	dc.b	nD3, $06, nRst, $06, nD3, $06, nCs3, $06, nB2, $06, nCs3, $09
	dc.b	nRst, $03, nAb2, $06, nRst, $06, nE2, $06, nRst, $06, nE2, $06
	dc.b	nAb2, $06, nB2, $06, nD3, $06, nRst, $06, nD3, $06, nRst, $06
	dc.b	nCs3, $06, nD3, $06, nRst, $06, nB2, $06, nRst, $0C, nA2, $06
	dc.b	nRst, $06, nAb2, $06, nRst, $06, nFs2, $06
	smpsStop

; PSG3 Data
SegaJingle_PSG3:
	smpsPSGform         $E7
	smpsPSGAlterVol     $04
	smpsPSGAlterVol     $FC
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $03
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $03
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $03
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $03
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $03
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $03
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $03
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $03
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $03
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $03
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $03
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $03
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03
	smpsPSGvoice        fTone_07
	dc.b	nMaxPSG, $02, nMaxPSG, $02, nMaxPSG, $02
	smpsPSGvoice        fTone_01
	smpsPSGvoice        fTone_07
	dc.b	nMaxPSG, $03
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_07
	dc.b	nMaxPSG, $03
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_07
	smpsPSGAlterVol     $02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	smpsPSGAlterVol     $FE
	smpsPSGvoice        fTone_07
	smpsPSGAlterVol     $05
	dc.b	nMaxPSG, $03
	smpsPSGvoice        fTone_02
	smpsPSGAlterVol     $FB
	smpsPSGvoice        fTone_07
	smpsPSGAlterVol     $05
	dc.b	nMaxPSG, $03
	smpsPSGvoice        fTone_02
	smpsPSGAlterVol     $FB
	smpsPSGvoice        fTone_07
	smpsPSGAlterVol     $07
	dc.b	nMaxPSG, $03
	smpsPSGvoice        fTone_01
	smpsPSGAlterVol     $F9
	smpsPSGvoice        fTone_07
	smpsPSGAlterVol     $07
	dc.b	nMaxPSG, $03
	smpsPSGvoice        fTone_02
	smpsPSGAlterVol     $F9
	dc.b	nRst, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $03
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nEb5, $03, nEb5, $03
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nEb5, $03, nEb5, $03
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	smpsPSGvoice        fTone_07
	dc.b	nA0, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nEb5, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_07
	dc.b	nAb1, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nEb5, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06, nEb5, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	smpsPSGvoice        fTone_07
	dc.b	nC1, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nEb5, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_07
	dc.b	nB1, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nEb5, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06, nEb5, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	smpsPSGvoice        fTone_07
	dc.b	nE1, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nEb5, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_07
	dc.b	nD2, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nEb5, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06, nEb5, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	smpsPSGvoice        fTone_07
	dc.b	nE2, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nEb5, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_07
	dc.b	nFs2, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nEb5, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06, nEb5, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	smpsPSGvoice        fTone_07
	dc.b	nB1, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nEb5, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06, nEb5, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nEb5, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06, nEb5, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	smpsPSGvoice        fTone_07
	dc.b	nB1, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nEb5, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06, nEb5, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nEb5, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06, nEb5, $06
	smpsPSGvoice        fTone_02
	dc.b	nRst, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nEb5, $03, nEb5, $03
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nEb5, $03, nEb5, $03
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	smpsPSGvoice        fTone_07
	dc.b	nA0, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nEb5, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_07
	dc.b	nAb1, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nEb5, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06, nEb5, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	smpsPSGvoice        fTone_07
	dc.b	nC1, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nEb5, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_07
	dc.b	nB1, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nEb5, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06, nEb5, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	smpsPSGvoice        fTone_07
	dc.b	nE1, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nEb5, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_07
	dc.b	nD2, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nEb5, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06, nEb5, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	smpsPSGvoice        fTone_07
	dc.b	nE2, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nEb5, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_07
	dc.b	nFs2, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nEb5, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06, nEb5, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	smpsPSGvoice        fTone_07
	dc.b	nB1, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nEb5, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06, nEb5, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nEb5, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06, nEb5, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	smpsPSGvoice        fTone_07
	dc.b	nB1, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nEb5, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06, nEb5, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nEb5, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06, nEb5, $06
	smpsPSGvoice        fTone_02
	dc.b	nRst, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_01
	dc.b	nEb5, $03, nEb5, $03
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nEb5, $03, nEb5, $03
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	smpsPSGvoice        fTone_07
	dc.b	nA0, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nEb5, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_07
	dc.b	nAb1, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nEb5, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06, nEb5, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	smpsPSGvoice        fTone_07
	dc.b	nC1, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nEb5, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_07
	dc.b	nB1, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nEb5, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06, nEb5, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	smpsPSGvoice        fTone_07
	dc.b	nE1, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nEb5, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_07
	dc.b	nD2, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nEb5, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06, nEb5, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	smpsPSGvoice        fTone_07
	dc.b	nE2, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nEb5, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_07
	dc.b	nFs2, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nEb5, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06, nEb5, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	smpsPSGvoice        fTone_07
	dc.b	nB1, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nEb5, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06, nEb5, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nEb5, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06, nEb5, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	smpsPSGvoice        fTone_07
	dc.b	nB1, $06
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nEb5, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06, nEb5, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nEb5, $06, nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06, nEb5, $06
	smpsStop

SegaJingle_Voices:
;	Voice $00
;	$28
;	$39, $35, $30, $31, 	$1F, $1F, $1F, $1F, 	$0C, $0A, $07, $0A
;	$07, $07, $07, $09, 	$26, $16, $16, $F6, 	$17, $32, $14, $00
	smpsVcAlgorithm     $00
	smpsVcFeedback      $05
	smpsVcUnusedBits    $00
	smpsVcDetune        $03, $03, $03, $03
	smpsVcCoarseFreq    $01, $00, $05, $09
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $1F, $1F, $1F, $1F
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $0A, $07, $0A, $0C
	smpsVcDecayRate2    $09, $07, $07, $07
	smpsVcDecayLevel    $0F, $01, $01, $02
	smpsVcReleaseRate   $06, $06, $06, $06
	smpsVcTotalLevel    $00, $14, $32, $17

;	Voice $01
;	$3D
;	$01, $01, $01, $01, 	$94, $19, $19, $19, 	$0F, $0D, $0D, $0D
;	$07, $04, $04, $04, 	$25, $1A, $1A, $1A, 	$15, $00, $00, $00
	smpsVcAlgorithm     $05
	smpsVcFeedback      $07
	smpsVcUnusedBits    $00
	smpsVcDetune        $00, $00, $00, $00
	smpsVcCoarseFreq    $01, $01, $01, $01
	smpsVcRateScale     $00, $00, $00, $02
	smpsVcAttackRate    $19, $19, $19, $14
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $0D, $0D, $0D, $0F
	smpsVcDecayRate2    $04, $04, $04, $07
	smpsVcDecayLevel    $01, $01, $01, $02
	smpsVcReleaseRate   $0A, $0A, $0A, $05
	smpsVcTotalLevel    $00, $00, $00, $15

;	Voice $02
;	$3B
;	$3E, $42, $41, $33, 	$DE, $14, $1E, $14, 	$14, $0F, $0F, $00
;	$01, $00, $00, $00, 	$36, $25, $26, $29, 	$1F, $1E, $19, $00
	smpsVcAlgorithm     $03
	smpsVcFeedback      $07
	smpsVcUnusedBits    $00
	smpsVcDetune        $03, $04, $04, $03
	smpsVcCoarseFreq    $03, $01, $02, $0E
	smpsVcRateScale     $00, $00, $00, $03
	smpsVcAttackRate    $14, $1E, $14, $1E
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $00, $0F, $0F, $14
	smpsVcDecayRate2    $00, $00, $00, $01
	smpsVcDecayLevel    $02, $02, $02, $03
	smpsVcReleaseRate   $09, $06, $05, $06
	smpsVcTotalLevel    $00, $19, $1E, $1F

;	Voice $03
;	$3B
;	$3E, $42, $41, $33, 	$DE, $14, $1E, $14, 	$14, $0F, $0F, $00
;	$01, $00, $00, $00, 	$36, $25, $26, $29, 	$14, $13, $0A, $00
	smpsVcAlgorithm     $03
	smpsVcFeedback      $07
	smpsVcUnusedBits    $00
	smpsVcDetune        $03, $04, $04, $03
	smpsVcCoarseFreq    $03, $01, $02, $0E
	smpsVcRateScale     $00, $00, $00, $03
	smpsVcAttackRate    $14, $1E, $14, $1E
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $00, $0F, $0F, $14
	smpsVcDecayRate2    $00, $00, $00, $01
	smpsVcDecayLevel    $02, $02, $02, $03
	smpsVcReleaseRate   $09, $06, $05, $06
	smpsVcTotalLevel    $00, $0A, $13, $14

;	Voice $04
;	$3C
;	$31, $72, $70, $30, 	$52, $53, $52, $53, 	$08, $00, $08, $00
;	$04, $00, $04, $00, 	$1F, $0F, $1F, $0F, 	$1A, $00, $16, $00
	smpsVcAlgorithm     $04
	smpsVcFeedback      $07
	smpsVcUnusedBits    $00
	smpsVcDetune        $03, $07, $07, $03
	smpsVcCoarseFreq    $00, $00, $02, $01
	smpsVcRateScale     $01, $01, $01, $01
	smpsVcAttackRate    $13, $12, $13, $12
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $00, $08, $00, $08
	smpsVcDecayRate2    $00, $04, $00, $04
	smpsVcDecayLevel    $00, $01, $00, $01
	smpsVcReleaseRate   $0F, $0F, $0F, $0F
	smpsVcTotalLevel    $00, $16, $00, $1A

