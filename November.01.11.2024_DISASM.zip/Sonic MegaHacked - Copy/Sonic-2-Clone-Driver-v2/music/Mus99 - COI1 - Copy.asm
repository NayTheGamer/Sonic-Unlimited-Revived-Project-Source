COI1_Header:
	smpsHeaderStartSong 1
	smpsHeaderVoice     COI1_Voices
	smpsHeaderChan      $07, $03
	smpsHeaderTempo     $01, $00

	smpsHeaderDAC       COI1_DAC,	$00, $F2
	smpsHeaderFM        COI1_FM1,	$00, $00
	smpsHeaderFM        COI1_FM2,	$00, $00
	smpsHeaderFM        COI1_FM3,	$00, $00
	smpsHeaderFM        COI1_FM4,	$00, $00
	smpsHeaderFM        COI1_FM5,	$00, $00
	smpsHeaderFM        COI1_FM6,	$00, $00
	smpsHeaderPSG       COI1_PSG1,	$00, $00, $00, $00
	smpsHeaderPSG       COI1_PSG2,	$00, $00, $00, $00
	smpsHeaderPSG       COI1_PSG3,	$00, $00, $00, $00

; DAC Data
COI1_DAC:
; FM3 Data
COI1_FM3:
; PSG3 Data
COI1_PSG3:
	smpsStop

; FM1 Data
COI1_FM1:
	smpsSetvoice        $00
	smpsAlterVol        $7F
	smpsPan             panCenter, $00
	smpsModSet          $00, $02, $03, $03
	dc.b	nRst, $7F, $09
	smpsSetvoice        $05
	smpsModOff
	dc.b	smpsNoAttack, nRst, $01
	smpsSetvoice        $06
	smpsAlterVol        $9D
	smpsPan             panLeft, $00
	dc.b	smpsNoAttack, nRst, $44

COI1_Jump04:
	smpsAlterVol        $F6
	dc.b	nG6, $2E, nC6, $7F, smpsNoAttack, $09, nRst, $18
	smpsAlterNote       $01
	dc.b	nA5, $2E, nA5, $7F, smpsNoAttack, $0B, nRst, $7F, $4F, nE6, $2E, nA5
	dc.b	nRst, $72
	smpsAlterNote       $00
	dc.b	nG5, $2E, nRst, $73, nB5, $16, nRst, $17, nD6, $2E, nF5, $45
	dc.b	nRst, $7F, $66
	smpsAlterVol        $0A
	smpsPan             panLeft, $00
	smpsModOff
	smpsJump            COI1_Jump04

; FM2 Data
COI1_FM2:
	smpsSetvoice        $01
	smpsAlterVol        $7F
	smpsPan             panRight, $00
	smpsModSet          $00, $02, $03, $03
	dc.b	nRst, $7F, $4E

COI1_Jump03:
	smpsSetvoice        $07
	smpsAlterVol        $99
	smpsPan             panCenter, $00
	smpsModOff
	dc.b	smpsNoAttack, nRst, $01, nG5, $12, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nG5, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nG5, $02
	smpsAlterNote       $00
	dc.b	nD5, $13, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nD5, $02
	smpsAlterNote       $00
	dc.b	nC5, $13, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nC5, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nC5, $02, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nC5, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nC5, $02, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nC5, $02, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nC5, $02, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nC5, $01, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	nC5, $02, smpsNoAttack
	smpsAlterNote       $FD
	dc.b	nC5, $02, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	nC5, $02, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nC5, $02, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nC5, $02, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nC5, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nC5, $02, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nC5, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nC5, $02, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nC5, $02, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nC5, $01, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nC5, $02, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	nC5, $02, smpsNoAttack
	smpsAlterNote       $FD
	dc.b	nC5, $02, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	nC5, $02, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nC5, $02, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nC5, $02, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nC5, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nC5, $02, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nC5, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nC5, $02, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nC5, $01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nC5, $02, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nC5, $02, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	nC5, $02, smpsNoAttack
	smpsAlterNote       $FD
	dc.b	nC5, $02, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	nC5, $02, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nC5, $02, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nC5, $02, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nC5, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nC5, $02, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nC5, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nC5, $02, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nC5, $01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nC5, $02, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nC5, $02, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	nC5, $02, smpsNoAttack
	smpsAlterNote       $FD
	dc.b	nC5, $02, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	nC5, $02, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nC5, $02, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nC5, $02, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nC5, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nC5, $02, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nC5, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nC5, $01, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nC5, $02, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nC5, $02, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nC5, $02, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	nC5, $02, smpsNoAttack
	smpsAlterNote       $FD
	dc.b	nC5, $02, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	nC5, $02, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nC5, $02, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nC5, $02, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nC5, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nC5, $01, nRst, $17
	smpsAlterNote       $01
	dc.b	nA4, $14, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nA4, $01, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nA4, $02
	smpsAlterNote       $00
	dc.b	nG4, $13, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nG4, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nG4, $02
	smpsAlterNote       $01
	dc.b	nA4, $13, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $04
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nA4, $01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $04
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	nA4, $01, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nA4, $02
	smpsAlterNote       $00
	dc.b	nD5, $13, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nD5, $01, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $FD
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nD5, $01, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $FD
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nD5, $01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $FD
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nD5, $01, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $FD
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nD5, $01, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $FD
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nD5, $01, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $FD
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nD5, $02, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nD5, $01, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nD5, $02, nRst, $73
	smpsAlterNote       $01
	dc.b	nE5, $13, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nE5, $02, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nE5, $02
	smpsAlterNote       $00
	dc.b	nB4, $13, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nB4, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nB4, $02
	smpsAlterNote       $01
	dc.b	nA4, $13, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $04
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nA4, $01, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $04
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nA4, $01, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $04
	dc.b	nA4, $01, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nA4, $01, smpsNoAttack
	smpsAlterNote       $04
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nA4, $01, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $04
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4, $01, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nA4, $02, nRst, $17
	smpsAlterNote       $00
	dc.b	nG4, $13, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nG4, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nG4, $02, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nG4, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nG4, $02, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nG4, $02, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nG4, $02, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nG4, $02, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	nG4, $02, smpsNoAttack
	smpsAlterNote       $FD
	dc.b	nG4, $01, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	nG4, $02, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nG4, $02, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nG4, $02, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nG4, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nG4, $02
	smpsAlterNote       $01
	dc.b	nA4, $13, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $04
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nA4, $01, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $04
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4, $01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $04
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nA4, $01, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $04
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nA4, $01, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nA4, $02
	smpsAlterNote       $00
	dc.b	nB4, $13, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nB4, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nB4, $02
	smpsAlterNote       $00
	dc.b	nC5, $13, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nC5, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nC5, $01
	smpsAlterNote       $00
	dc.b	nD5, $14, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nD5, $01, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nD5, $02
	smpsAlterNote       $01
	dc.b	nA4, $13, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nA4, $02, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nA4, $02
	smpsAlterNote       $00
	dc.b	nF4, $13, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nF4, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nF4, $02, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nF4, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nF4, $02, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nF4, $02, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nF4, $02, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nF4, $02, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	nF4, $02, smpsNoAttack
	smpsAlterNote       $FD
	dc.b	nF4, $02, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	nF4, $01, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nF4, $02, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nF4, $02, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nF4, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nF4, $02, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nF4, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nF4, $02, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nF4, $02, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nF4, $02, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nF4, $02, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	nF4, $02, smpsNoAttack
	smpsAlterNote       $FD
	dc.b	nF4, $01, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	nF4, $02, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nF4, $02, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nF4, $02, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nF4, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nF4, $02
	smpsAlterNote       $01
	dc.b	nE4, $13, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $04
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nE4, $01, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $04
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nE4, $01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $04
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nE4, $01, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $04
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nE4, $01, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $04
	dc.b	nE4, $01, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nE4, $01, smpsNoAttack
	smpsAlterNote       $04
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $02
	dc.b	nE4, $02, smpsNoAttack
	smpsAlterNote       $03
	dc.b	nE4, $01, nRst, $45
	smpsSetvoice        $01
	smpsAlterVol        $67
	smpsPan             panRight, $00
	smpsModSet          $00, $02, $03, $03
	smpsAlterNote       $00
	smpsJump            COI1_Jump03

; FM4 Data
COI1_FM4:
	smpsSetvoice        $03
	smpsAlterVol        $7F
	smpsPan             panCenter, $00
	smpsModSet          $00, $02, $03, $03
	dc.b	nRst, $7F, $0A
	smpsSetvoice        $06
	smpsAlterVol        $9D
	smpsPan             panRight, $00
	smpsModOff
	dc.b	smpsNoAttack, nRst, $44

COI1_Jump02:
	dc.b	nRst, $17
	smpsAlterVol        $F6
	dc.b	nD6, $45, nRst, $7F, $0A, nG5, $45, nRst, $17, nD6, $7F, smpsNoAttack
	dc.b	$21, nRst, $7F, $0B, nB5, $45, nRst, $7F, $21
	smpsAlterNote       $01
	dc.b	nA5, $7F, smpsNoAttack, $0B
	smpsAlterNote       $00
	dc.b	nC6, $2D
	smpsAlterNote       $01
	dc.b	nA5, $5C
	smpsAlterVol        $02
	dc.b	nE5, $7F, smpsNoAttack, $21, nRst, $45
	smpsAlterVol        $08
	smpsPan             panRight, $00
	smpsModOff
	smpsAlterNote       $00
	smpsJump            COI1_Jump02

; FM5 Data
COI1_FM5:
	smpsSetvoice        $04
	smpsAlterVol        $1B
	smpsPan             panCenter, $00
	smpsModSet          $00, $02, $03, $03
	smpsAlterNote       $01
	dc.b	nA4, $0A
	smpsAlterVol        $FE
	smpsAlterNote       $00
	dc.b	nBb4, $0C
	smpsAlterNote       $01
	dc.b	nA4, $0B
	smpsAlterVol        $FD
	smpsAlterNote       $00
	dc.b	nBb4, $0C, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4, $0B
	smpsAlterVol        $FE
	dc.b	smpsNoAttack
	smpsAlterNote       $00
	dc.b	nBb4, $0C, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4, $0B, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nBb4, $0C, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4, $0B, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nBb4, $0C, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4, $0B
	smpsAlterVol        $03
	dc.b	smpsNoAttack
	smpsAlterNote       $00
	dc.b	nBb4, $0C, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4, $0B, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nBb4, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4, $0C
	smpsAlterVol        $FD
	dc.b	smpsNoAttack
	smpsAlterNote       $00
	dc.b	nBb4, $0B, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4, $0C, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nBb4, $0B

COI1_Jump01:
	dc.b	smpsNoAttack, nBb4, $01, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4, $0B, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nBb4
	smpsAlterVol        $FD
	dc.b	smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4, $0C, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nBb4, $0B, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4, $0C, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nBb4, $0B, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4
	smpsAlterVol        $FD
	dc.b	smpsNoAttack
	smpsAlterNote       $00
	dc.b	nBb4, $0C, smpsNoAttack, nB4, $0B, smpsNoAttack, nC5, $0C, smpsNoAttack, nB4, $0B
	smpsAlterVol        $02
	dc.b	smpsNoAttack, nC5, $0C
	smpsAlterVol        $01
	dc.b	smpsNoAttack, nB4, $0B, smpsNoAttack, nC5, $0C, smpsNoAttack, nB4, $0B
	smpsAlterVol        $02
	dc.b	smpsNoAttack, nC5, $0C, smpsNoAttack, nB4, $0B, smpsNoAttack, nC5, $0C
	smpsAlterVol        $03
	dc.b	smpsNoAttack, nB4, $0B, smpsNoAttack, nC5, smpsNoAttack, nB4, $0C
	smpsAlterVol        $03
	dc.b	smpsNoAttack, nC5, $0B
	smpsAlterVol        $FD
	dc.b	smpsNoAttack, nD5, $17, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nE5, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nD5, smpsNoAttack, nC5, $2E, nRst, $17
	smpsAlterVol        $02
	dc.b	nB4
	smpsAlterVol        $FE
	dc.b	smpsNoAttack, nC5, smpsNoAttack, nB4
	smpsAlterVol        $02
	dc.b	smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4, $2D, nRst, $17, smpsNoAttack, nA4, $0C, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nB4, $0B, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4, $0C
	smpsAlterVol        $FE
	dc.b	smpsNoAttack
	smpsAlterNote       $00
	dc.b	nB4, $0B, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4, $0C, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nB4, $0B, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4
	smpsAlterVol        $FD
	dc.b	smpsNoAttack, nA4, $01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nB4, $0B, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nB4, $0C
	smpsAlterVol        $FF
	dc.b	smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4, $0B, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nB4, $0C
	smpsAlterVol        $FE
	dc.b	smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4, $0B, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nBb4, $0C
	smpsAlterVol        $FF
	dc.b	smpsNoAttack, nB4, $0B, smpsNoAttack, nC5, $0C, smpsNoAttack, nB4, $0B, smpsNoAttack, nC5, smpsNoAttack
	dc.b	nB4, $0C
	smpsAlterVol        $02
	dc.b	smpsNoAttack, nC5, $0B, smpsNoAttack, nB4, $0C, smpsNoAttack, nC5, $0B, smpsNoAttack, nB4, $0C
	smpsAlterVol        $02
	dc.b	smpsNoAttack, nC5, $0B, smpsNoAttack, nB4, $0C, smpsNoAttack, nC5, $0B
	smpsAlterVol        $02
	dc.b	smpsNoAttack, nB4, $0C, smpsNoAttack, nC5, $0B, smpsNoAttack, nD5, $17
	smpsAlterVol        $FE
	dc.b	smpsNoAttack
	smpsAlterNote       $01
	dc.b	nE5, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nD5, smpsNoAttack, nC5, smpsNoAttack, nD5
	smpsAlterVol        $02
	dc.b	smpsNoAttack, nB4, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nB4, $16
	smpsAlterVol        $FD
	dc.b	smpsNoAttack, nB4, $01, smpsNoAttack, nF4, $16
	smpsAlterVol        $01
	dc.b	smpsNoAttack, nF4, $17
	smpsAlterVol        $02
	dc.b	smpsNoAttack, nD4
	smpsAlterVol        $01
	dc.b	smpsNoAttack, nEb4, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nE4, $0C, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nF4, $0B, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nE4
	smpsAlterVol        $FE
	dc.b	smpsNoAttack
	smpsAlterNote       $00
	dc.b	nF4, $0C, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nE4, $0B
	smpsAlterVol        $FF
	dc.b	smpsNoAttack
	smpsAlterNote       $00
	dc.b	nF4, $0C, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nE4, $0B, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nF4, $0C, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nE4, $0B, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nF4, $0C, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nE4, $0B
	smpsAlterVol        $03
	dc.b	smpsNoAttack
	smpsAlterNote       $00
	dc.b	nF4, $0C, smpsNoAttack, nFs4, $0B, smpsNoAttack, nG4, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4, $0C, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nBb4, $0B, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4, $0C
	smpsAlterVol        $FE
	dc.b	smpsNoAttack
	smpsAlterNote       $00
	dc.b	nBb4, $0B, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4, $0C, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nBb4, $0B
	smpsPan             panCenter, $00
	smpsModOn
	smpsAlterNote       $00
	smpsJump            COI1_Jump01

; FM6 Data
COI1_FM6:
	smpsSetvoice        $04
	smpsAlterVol        $1B
	smpsPan             panCenter, $00
	smpsModSet          $00, $02, $03, $03
	dc.b	nF4, $0B
	smpsAlterVol        $FE
	dc.b	nG4, nF4
	smpsAlterVol        $FD
	dc.b	nG4, $0C, smpsNoAttack, nF4, $0B
	smpsAlterVol        $FE
	dc.b	smpsNoAttack, nG4, $0C, smpsNoAttack, nF4, $0B, smpsNoAttack, nG4, $0C, smpsNoAttack, nF4, $0B
	dc.b	smpsNoAttack, nG4, $0C, smpsNoAttack, nF4, $0B
	smpsAlterVol        $03
	dc.b	smpsNoAttack, nG4, $0C, smpsNoAttack, nF4, $0B, smpsNoAttack, nG4, smpsNoAttack, nF4, $0C
	smpsAlterVol        $FD
	dc.b	smpsNoAttack, nG4, $0B, smpsNoAttack, nF4, $0C, smpsNoAttack, nG4, $0B

COI1_Jump00:
	dc.b	smpsNoAttack, nG4, $01
	smpsAlterVol        $FF
	dc.b	smpsNoAttack, nF4, $0B, smpsNoAttack, nG4, smpsNoAttack, nF4, $0C, smpsNoAttack, nG4, $0B
	smpsAlterVol        $FD
	dc.b	smpsNoAttack, nF4, $0C, smpsNoAttack, nG4, $0B, smpsNoAttack, nF4, $0C, smpsNoAttack, nG4, $16
	dc.b	smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4, $0C, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nG4, $0B, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4, $0C, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nG4, $0B, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4, $0C
	smpsAlterVol        $03
	dc.b	smpsNoAttack
	smpsAlterNote       $00
	dc.b	nG4, $0B, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4, $0C
	smpsAlterVol        $01
	dc.b	smpsNoAttack
	smpsAlterNote       $00
	dc.b	nG4, $0B, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4, $0C, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nG4, $0B
	smpsAlterVol        $03
	dc.b	smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nG4, $0C
	smpsAlterVol        $02
	dc.b	smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4, $0B
	smpsAlterVol        $FD
	dc.b	smpsNoAttack, nA4, $0C, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nB4, $0B
	smpsAlterVol        $FD
	dc.b	smpsNoAttack, nC5, $0C
	smpsAlterVol        $FF
	dc.b	smpsNoAttack, nD5, $0B, smpsNoAttack, nC5, $0C
	smpsAlterVol        $03
	dc.b	smpsNoAttack, nB4, $0B, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4, $2E, nRst, $17
	smpsAlterVol        $03
	dc.b	nE4, $0B, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nFs4, $0C
	smpsAlterVol        $FD
	dc.b	smpsNoAttack, nG4, $0B, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4, $0C, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nG4, $0B, smpsNoAttack, nFs4, $0C
	smpsAlterVol        $03
	dc.b	smpsNoAttack
	smpsAlterNote       $01
	dc.b	nE4, $2D, nRst, $17
	smpsAlterNote       $00
	dc.b	nF4, $0C, smpsNoAttack, nG4, $0B, smpsNoAttack, nF4, $0C, smpsNoAttack, nG4, $0B
	smpsAlterVol        $FD
	dc.b	smpsNoAttack, nF4, $0C, smpsNoAttack, nG4, $0B, smpsNoAttack, nF4, $0C, smpsNoAttack, nG4, $0B
	smpsAlterVol        $FE
	dc.b	smpsNoAttack, nF4, smpsNoAttack, nG4, $0C, smpsNoAttack, nF4, $0B, smpsNoAttack, nG4, $0C
	smpsAlterVol        $FD
	dc.b	smpsNoAttack, nF4, $0B, smpsNoAttack, nG4, $17
	smpsAlterVol        $FE
	dc.b	smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4, $0C, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nG4, $0B, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4, $0C, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nG4, $0B
	smpsAlterVol        $03
	dc.b	smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nG4, $0C, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4, $0B, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nG4, $0C
	smpsAlterVol        $02
	dc.b	smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4, $0B, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nG4, $0C, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4, $0B
	smpsAlterVol        $02
	dc.b	smpsNoAttack
	smpsAlterNote       $00
	dc.b	nG4, $0C, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nA4, $39
	smpsAlterVol        $FE
	dc.b	smpsNoAttack, nA4, $2E, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nG4, $17
	smpsAlterVol        $02
	dc.b	smpsNoAttack, nF4, $2E, smpsNoAttack, nG4, $17, smpsNoAttack, nD4, $2D, smpsNoAttack, nBb3, $17
	smpsAlterVol        $01
	dc.b	smpsNoAttack, nG3, smpsNoAttack, nC4, $0C, smpsNoAttack, nD4, $0B, smpsNoAttack, nC4, smpsNoAttack, nC4
	dc.b	$01
	smpsAlterVol        $FE
	dc.b	smpsNoAttack, nD4, $0B, smpsNoAttack, nC4, smpsNoAttack, nD4, $0C
	smpsAlterVol        $FF
	dc.b	smpsNoAttack, nC4, $0B, smpsNoAttack, nD4, $0C, smpsNoAttack, nC4, $0B
	smpsAlterVol        $01
	dc.b	smpsNoAttack, nD4, $0C, smpsNoAttack, nC4, $0B
	smpsAlterVol        $02
	dc.b	smpsNoAttack, nD4, $0C, smpsNoAttack, nEb4, $0B, smpsNoAttack
	smpsAlterNote       $01
	dc.b	nE4, $0C, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nF4, $0B, smpsNoAttack, nG4, smpsNoAttack, nF4, $0C
	smpsAlterVol        $FE
	dc.b	smpsNoAttack, nG4, $0B, smpsNoAttack, nF4, $0C, smpsNoAttack, nG4, $0B
	smpsPan             panCenter, $00
	smpsModOn
	smpsJump            COI1_Jump00

; PSG1 Data
COI1_PSG1:
	dc.b	nRst, $7F, $20
	smpsPSGAlterVol     $04
	dc.b	nA3, $05
	smpsPSGAlterVol     $01
	dc.b	nA3, $06
	smpsPSGAlterVol     $01
	dc.b	nA3, $05
	smpsPSGAlterVol     $01
	dc.b	nA3, $04
	smpsPSGAlterVol     $01
	dc.b	nA3, $06
	smpsPSGAlterVol     $01
	dc.b	nA3, $05
	smpsPSGAlterVol     $01
	dc.b	nA3
	smpsPSGAlterVol     $01
	dc.b	nA3
	smpsPSGAlterVol     $01
	dc.b	nA3

COI1_Jump06:
	smpsPSGAlterVol     $01
	dc.b	nA3, $01
	smpsPSGAlterVol     $F7
	dc.b	nG3, $04
	smpsPSGAlterVol     $01
	dc.b	nG3, $06
	smpsPSGAlterVol     $01
	dc.b	nG3, $05
	smpsPSGAlterVol     $01
	dc.b	nG3, $04
	smpsPSGAlterVol     $01
	dc.b	nG3, $06
	smpsPSGAlterVol     $01
	dc.b	nG3, $05
	smpsPSGAlterVol     $01
	dc.b	nG3
	smpsPSGAlterVol     $01
	dc.b	nG3
	smpsPSGAlterVol     $01
	dc.b	nG3
	smpsPSGAlterVol     $01
	dc.b	nG3
	smpsPSGAlterVol     $01
	dc.b	nG3, $02, nRst, $3E
	smpsPSGAlterVol     $F6
	dc.b	nE3, $05
	smpsPSGAlterVol     $01
	dc.b	nE3
	smpsPSGAlterVol     $01
	dc.b	nE3
	smpsPSGAlterVol     $01
	dc.b	nE3
	smpsPSGAlterVol     $01
	dc.b	nE3
	smpsPSGAlterVol     $01
	dc.b	nE3
	smpsPSGAlterVol     $01
	dc.b	nE3
	smpsPSGAlterVol     $01
	dc.b	nE3
	smpsPSGAlterVol     $01
	dc.b	nE3
	smpsPSGAlterVol     $01
	dc.b	nE3, $01
	smpsPSGAlterVol     $F7
	dc.b	nD3, $04
	smpsPSGAlterVol     $01
	dc.b	nD3, $06
	smpsPSGAlterVol     $01
	dc.b	nD3, $05
	smpsPSGAlterVol     $01
	dc.b	nD3
	smpsPSGAlterVol     $01
	dc.b	nD3
	smpsPSGAlterVol     $01
	dc.b	nD3
	smpsPSGAlterVol     $01
	dc.b	nD3
	smpsPSGAlterVol     $01
	dc.b	nD3
	smpsPSGAlterVol     $01
	dc.b	nD3
	smpsPSGAlterVol     $01
	dc.b	nD3
	smpsPSGAlterVol     $01
	dc.b	nD3, $02, nRst, $6C
	smpsPSGAlterVol     $F6
	dc.b	nD2, $05
	smpsPSGAlterVol     $01
	dc.b	nD2, $03, nRst, $0F
	smpsPSGAlterVol     $FF
	dc.b	nA1, $05
	smpsPSGAlterVol     $01
	dc.b	nA1, $03, nRst, $0F
	smpsPSGAlterVol     $FF
	dc.b	nC2, $05
	smpsPSGAlterVol     $01
	dc.b	nC2, $03, nRst, $0F
	smpsPSGAlterVol     $FF
	dc.b	nB1, $05
	smpsPSGAlterVol     $01
	dc.b	nB1, $02, nRst, $3E
	smpsPSGAlterVol     $FF
	dc.b	nA1, $05
	smpsPSGAlterVol     $01
	dc.b	nA1, $02, nRst, $10
	smpsPSGAlterVol     $FF
	dc.b	nE2, $04
	smpsPSGAlterVol     $01
	dc.b	nE2, $03, nRst, $0F
	smpsPSGAlterVol     $FF
	dc.b	nA2, $05
	smpsPSGAlterVol     $01
	dc.b	nA2, $03, nRst, $0F
	smpsPSGAlterVol     $04
	dc.b	nA2, $02
	smpsPSGAlterVol     $01
	dc.b	nA2, $01
	smpsPSGAlterVol     $01
	dc.b	nA2
	smpsPSGAlterVol     $01
	dc.b	nA2, $02
	smpsPSGAlterVol     $01
	dc.b	nA2, $01
	smpsPSGAlterVol     $01
	dc.b	nA2, nRst, $0F
	smpsPSGAlterVol     $F6
	dc.b	nB3, $05
	smpsPSGAlterVol     $01
	dc.b	nB3
	smpsPSGAlterVol     $01
	dc.b	nB3
	smpsPSGAlterVol     $01
	dc.b	nB3
	smpsPSGAlterVol     $01
	dc.b	nB3
	smpsPSGAlterVol     $01
	dc.b	nB3
	smpsPSGAlterVol     $01
	dc.b	nB3, $06
	smpsPSGAlterVol     $01
	dc.b	nB3, $04
	smpsPSGAlterVol     $01
	dc.b	nB3, $06
	smpsPSGAlterVol     $F8
	dc.b	nG3, $05
	smpsPSGAlterVol     $01
	dc.b	nG3
	smpsPSGAlterVol     $01
	dc.b	nG3
	smpsPSGAlterVol     $01
	dc.b	nG3
	smpsPSGAlterVol     $01
	dc.b	nG3
	smpsPSGAlterVol     $01
	dc.b	nG3
	smpsPSGAlterVol     $01
	dc.b	nG3
	smpsPSGAlterVol     $01
	dc.b	nG3
	smpsPSGAlterVol     $01
	dc.b	nG3
	smpsPSGAlterVol     $01
	dc.b	nG3
	smpsPSGAlterVol     $01
	dc.b	nG3, $02, nRst, $3F
	smpsPSGAlterVol     $F6
	dc.b	nE3, $04
	smpsPSGAlterVol     $01
	dc.b	nE3, $05
	smpsPSGAlterVol     $01
	dc.b	nE3, $06
	smpsPSGAlterVol     $01
	dc.b	nE3, $05
	smpsPSGAlterVol     $01
	dc.b	nE3, $04
	smpsPSGAlterVol     $01
	dc.b	nE3, $06
	smpsPSGAlterVol     $01
	dc.b	nE3, $05
	smpsPSGAlterVol     $01
	dc.b	nE3
	smpsPSGAlterVol     $01
	dc.b	nE3
	smpsPSGAlterVol     $F8
	dc.b	nD3
	smpsPSGAlterVol     $01
	dc.b	nD3
	smpsPSGAlterVol     $01
	dc.b	nD3, $06
	smpsPSGAlterVol     $01
	dc.b	nD3, $04
	smpsPSGAlterVol     $01
	dc.b	nD3, $05
	smpsPSGAlterVol     $01
	dc.b	nD3, $06
	smpsPSGAlterVol     $01
	dc.b	nD3, $05
	smpsPSGAlterVol     $01
	dc.b	nD3
	smpsPSGAlterVol     $01
	dc.b	nD3
	smpsPSGAlterVol     $01
	dc.b	nD3
	smpsPSGAlterVol     $01
	dc.b	nD3, $02, nRst, $7F, $7F, $6A
	smpsPSGAlterVol     $F6
	dc.b	nC2, $05
	smpsPSGAlterVol     $01
	dc.b	nC2, $03
	smpsPSGAlterVol     $01
	dc.b	nC2, $01
	smpsPSGAlterVol     $01
	dc.b	nC2, $02
	smpsPSGAlterVol     $01
	dc.b	nC2, $01
	smpsPSGAlterVol     $01
	dc.b	nC2
	smpsPSGAlterVol     $01
	dc.b	nC2
	smpsPSGAlterVol     $01
	dc.b	nC2, $02
	smpsPSGAlterVol     $01
	dc.b	nC2, $01
	smpsPSGAlterVol     $01
	dc.b	nC2
	smpsPSGAlterVol     $01
	dc.b	nC2, nRst, $1B
	smpsPSGAlterVol     $F6
	dc.b	nG1, $05
	smpsPSGAlterVol     $01
	dc.b	nG1, $03
	smpsPSGAlterVol     $01
	dc.b	nG1, $01
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1, $02
	smpsPSGAlterVol     $01
	dc.b	nG1, $01
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1, $02
	smpsPSGAlterVol     $01
	dc.b	nG1, $01
	smpsPSGAlterVol     $01
	dc.b	nG1, nRst, $48
	smpsPSGAlterVol     $F6
	dc.b	nA3, $05
	smpsPSGAlterVol     $01
	dc.b	nA3
	smpsPSGAlterVol     $01
	dc.b	nA3
	smpsPSGAlterVol     $01
	dc.b	nA3
	smpsPSGAlterVol     $01
	dc.b	nA3
	smpsPSGAlterVol     $01
	dc.b	nA3
	smpsPSGAlterVol     $01
	dc.b	nA3, $06
	smpsPSGAlterVol     $01
	dc.b	nA3, $04
	smpsPSGAlterVol     $01
	dc.b	nA3, $05
	smpsPSGAlterVol     $01
	dc.b	nA3, $01
	smpsPSGAlterVol     $FE
	smpsJump            COI1_Jump06

; PSG2 Data
COI1_PSG2:
	dc.b	nRst, $7F, $30
	smpsPSGAlterVol     $06
	dc.b	nA4, $05
	smpsPSGAlterVol     $01
	dc.b	nA4
	smpsPSGAlterVol     $01
	dc.b	nA4
	smpsPSGAlterVol     $01
	dc.b	nA4
	smpsPSGAlterVol     $01
	dc.b	nA4
	smpsPSGAlterVol     $01
	dc.b	nA4

COI1_Jump05:
	smpsPSGAlterVol     $01
	dc.b	nA4
	smpsPSGAlterVol     $01
	dc.b	nA4
	smpsPSGAlterVol     $01
	dc.b	nA4, nRst, $01
	smpsPSGAlterVol     $F8
	dc.b	nG4, $04
	smpsPSGAlterVol     $01
	dc.b	nG4, $06
	smpsPSGAlterVol     $01
	dc.b	nG4, $05
	smpsPSGAlterVol     $01
	dc.b	nG4
	smpsPSGAlterVol     $01
	dc.b	nG4
	smpsPSGAlterVol     $01
	dc.b	nG4
	smpsPSGAlterVol     $01
	dc.b	nG4
	smpsPSGAlterVol     $01
	dc.b	nG4
	smpsPSGAlterVol     $01
	dc.b	nG4, nRst, $45
	smpsPSGAlterVol     $F8
	dc.b	nE4, $05
	smpsPSGAlterVol     $01
	dc.b	nE4
	smpsPSGAlterVol     $01
	dc.b	nE4
	smpsPSGAlterVol     $01
	dc.b	nE4
	smpsPSGAlterVol     $01
	dc.b	nE4
	smpsPSGAlterVol     $01
	dc.b	nE4
	smpsPSGAlterVol     $01
	dc.b	nE4
	smpsPSGAlterVol     $01
	dc.b	nE4
	smpsPSGAlterVol     $01
	dc.b	nE4, nRst, $01
	smpsPSGAlterVol     $F8
	dc.b	nD4, $05
	smpsPSGAlterVol     $01
	dc.b	nD4
	smpsPSGAlterVol     $01
	dc.b	nD4
	smpsPSGAlterVol     $01
	dc.b	nD4
	smpsPSGAlterVol     $01
	dc.b	nD4
	smpsPSGAlterVol     $01
	dc.b	nD4
	smpsPSGAlterVol     $01
	dc.b	nD4
	smpsPSGAlterVol     $01
	dc.b	nD4
	smpsPSGAlterVol     $01
	dc.b	nD4, nRst, $66
	smpsPSGAlterVol     $F6
	dc.b	nD3, $05
	smpsPSGAlterVol     $01
	dc.b	nD3, $03, nRst, $0F
	smpsPSGAlterVol     $FF
	dc.b	nA2, $05
	smpsPSGAlterVol     $01
	dc.b	nA2, $03, nRst, $0F
	smpsPSGAlterVol     $FF
	dc.b	nC3, $05
	smpsPSGAlterVol     $01
	dc.b	nC3, $02, nRst, $10
	smpsPSGAlterVol     $FF
	dc.b	nB2, $05
	smpsPSGAlterVol     $01
	dc.b	nB2, $02, nRst, $3E
	smpsPSGAlterVol     $FF
	dc.b	nA2, $04
	smpsPSGAlterVol     $01
	dc.b	nA2, $03, nRst, $0F
	smpsPSGAlterVol     $FF
	dc.b	nE3, $05
	smpsPSGAlterVol     $01
	dc.b	nE3, $03, nRst, $0F
	smpsPSGAlterVol     $FF
	dc.b	nA3, $05
	smpsPSGAlterVol     $01
	dc.b	nA3, $03, nRst, $0F
	smpsPSGAlterVol     $04
	dc.b	nA3, $02
	smpsPSGAlterVol     $01
	dc.b	nA3, $01
	smpsPSGAlterVol     $01
	dc.b	nA3
	smpsPSGAlterVol     $01
	dc.b	nA3
	smpsPSGAlterVol     $01
	dc.b	nA3, $02
	smpsPSGAlterVol     $01
	dc.b	nA3, $01, nRst, $1C
	smpsPSGAlterVol     $F8
	dc.b	nB4, $05
	smpsPSGAlterVol     $01
	dc.b	nB4
	smpsPSGAlterVol     $01
	dc.b	nB4
	smpsPSGAlterVol     $01
	dc.b	nB4, $06
	smpsPSGAlterVol     $01
	dc.b	nB4, $04
	smpsPSGAlterVol     $01
	dc.b	nB4, $06
	smpsPSGAlterVol     $01
	dc.b	nB4, $05
	smpsPSGAlterVol     $01
	dc.b	nB4
	smpsPSGAlterVol     $01
	dc.b	nB4
	smpsPSGAlterVol     $F8
	dc.b	nG4
	smpsPSGAlterVol     $01
	dc.b	nG4
	smpsPSGAlterVol     $01
	dc.b	nG4, $06
	smpsPSGAlterVol     $01
	dc.b	nG4, $04
	smpsPSGAlterVol     $01
	dc.b	nG4, $05
	smpsPSGAlterVol     $01
	dc.b	nG4, $06
	smpsPSGAlterVol     $01
	dc.b	nG4, $05
	smpsPSGAlterVol     $01
	dc.b	nG4, $04
	smpsPSGAlterVol     $01
	dc.b	nG4, $06, nRst, $45
	smpsPSGAlterVol     $F8
	dc.b	nE4, $05
	smpsPSGAlterVol     $01
	dc.b	nE4
	smpsPSGAlterVol     $01
	dc.b	nE4
	smpsPSGAlterVol     $01
	dc.b	nE4
	smpsPSGAlterVol     $01
	dc.b	nE4
	smpsPSGAlterVol     $01
	dc.b	nE4
	smpsPSGAlterVol     $01
	dc.b	nE4
	smpsPSGAlterVol     $01
	dc.b	nE4
	smpsPSGAlterVol     $01
	dc.b	nE4, nRst, $01
	smpsPSGAlterVol     $F8
	dc.b	nD4, $05
	smpsPSGAlterVol     $01
	dc.b	nD4
	smpsPSGAlterVol     $01
	dc.b	nD4
	smpsPSGAlterVol     $01
	dc.b	nD4
	smpsPSGAlterVol     $01
	dc.b	nD4
	smpsPSGAlterVol     $01
	dc.b	nD4
	smpsPSGAlterVol     $01
	dc.b	nD4
	smpsPSGAlterVol     $01
	dc.b	nD4
	smpsPSGAlterVol     $01
	dc.b	nD4, nRst, $7F, $7F, $64
	smpsPSGAlterVol     $F6
	dc.b	nC3, $05
	smpsPSGAlterVol     $01
	dc.b	nC3, $03
	smpsPSGAlterVol     $01
	dc.b	nC3, $01
	smpsPSGAlterVol     $01
	dc.b	nC3
	smpsPSGAlterVol     $01
	dc.b	nC3, $02
	smpsPSGAlterVol     $01
	dc.b	nC3, $01
	smpsPSGAlterVol     $01
	dc.b	nC3
	smpsPSGAlterVol     $01
	dc.b	nC3, $02
	smpsPSGAlterVol     $01
	dc.b	nC3, $01
	smpsPSGAlterVol     $01
	dc.b	nC3
	smpsPSGAlterVol     $01
	dc.b	nC3, nRst, $1B
	smpsPSGAlterVol     $F6
	dc.b	nG2, $04
	smpsPSGAlterVol     $01
	dc.b	nG2
	smpsPSGAlterVol     $01
	dc.b	nG2, $01
	smpsPSGAlterVol     $01
	dc.b	nG2
	smpsPSGAlterVol     $01
	dc.b	nG2
	smpsPSGAlterVol     $01
	dc.b	nG2, $02
	smpsPSGAlterVol     $01
	dc.b	nG2, $01
	smpsPSGAlterVol     $01
	dc.b	nG2
	smpsPSGAlterVol     $01
	dc.b	nG2, $02
	smpsPSGAlterVol     $01
	dc.b	nG2, $01
	smpsPSGAlterVol     $01
	dc.b	nG2, nRst, $56
	smpsPSGAlterVol     $F8
	dc.b	nA4, $05
	smpsPSGAlterVol     $01
	dc.b	nA4
	smpsPSGAlterVol     $01
	dc.b	nA4
	smpsPSGAlterVol     $01
	dc.b	nA4
	smpsPSGAlterVol     $01
	dc.b	nA4
	smpsPSGAlterVol     $01
	dc.b	nA4
	smpsPSGAlterVol     $FF
	smpsJump            COI1_Jump05

COI1_Voices:
;	Voice $00
;	$3B
;	$45, $42, $02, $41, 	$10, $12, $11, $13, 	$11, $1F, $1F, $10
;	$10, $00, $00, $00, 	$FF, $FF, $FF, $FF, 	$7F, $7F, $7F, $00
	smpsVcAlgorithm     $03
	smpsVcFeedback      $07
	smpsVcUnusedBits    $00
	smpsVcDetune        $04, $00, $04, $04
	smpsVcCoarseFreq    $01, $02, $02, $05
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $13, $11, $12, $10
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $10, $1F, $1F, $11
	smpsVcDecayRate2    $00, $00, $00, $10
	smpsVcDecayLevel    $0F, $0F, $0F, $0F
	smpsVcReleaseRate   $0F, $0F, $0F, $0F
	smpsVcTotalLevel    $00, $7F, $7F, $7F

;	Voice $01
;	$3A
;	$72, $35, $72, $31, 	$50, $10, $1F, $50, 	$04, $14, $14, $1F
;	$00, $00, $00, $00, 	$FF, $FF, $FF, $FF, 	$7F, $7F, $7F, $00
	smpsVcAlgorithm     $02
	smpsVcFeedback      $07
	smpsVcUnusedBits    $00
	smpsVcDetune        $03, $07, $03, $07
	smpsVcCoarseFreq    $01, $02, $05, $02
	smpsVcRateScale     $01, $00, $00, $01
	smpsVcAttackRate    $10, $1F, $10, $10
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $1F, $14, $14, $04
	smpsVcDecayRate2    $00, $00, $00, $00
	smpsVcDecayLevel    $0F, $0F, $0F, $0F
	smpsVcReleaseRate   $0F, $0F, $0F, $0F
	smpsVcTotalLevel    $00, $7F, $7F, $7F

;	Voice $02
;	$39
;	$02, $00, $71, $30, 	$5F, $98, $5F, $9F, 	$0C, $05, $07, $0C
;	$10, $03, $03, $06, 	$FF, $FF, $FF, $FF, 	$7F, $7F, $7F, $00
	smpsVcAlgorithm     $01
	smpsVcFeedback      $07
	smpsVcUnusedBits    $00
	smpsVcDetune        $03, $07, $00, $00
	smpsVcCoarseFreq    $00, $01, $00, $02
	smpsVcRateScale     $02, $01, $02, $01
	smpsVcAttackRate    $1F, $1F, $18, $1F
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $0C, $07, $05, $0C
	smpsVcDecayRate2    $06, $03, $03, $10
	smpsVcDecayLevel    $0F, $0F, $0F, $0F
	smpsVcReleaseRate   $0F, $0F, $0F, $0F
	smpsVcTotalLevel    $00, $7F, $7F, $7F

;	Voice $03
;	$3C
;	$01, $02, $01, $01, 	$1F, $10, $1F, $10, 	$00, $08, $00, $08
;	$00, $00, $00, $00, 	$FF, $FF, $FF, $FF, 	$7F, $00, $7F, $00
	smpsVcAlgorithm     $04
	smpsVcFeedback      $07
	smpsVcUnusedBits    $00
	smpsVcDetune        $00, $00, $00, $00
	smpsVcCoarseFreq    $01, $01, $02, $01
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $10, $1F, $10, $1F
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $08, $00, $08, $00
	smpsVcDecayRate2    $00, $00, $00, $00
	smpsVcDecayLevel    $0F, $0F, $0F, $0F
	smpsVcReleaseRate   $0F, $0F, $0F, $0F
	smpsVcTotalLevel    $00, $7F, $00, $7F

;	Voice $04
;	$3A
;	$72, $35, $72, $31, 	$50, $10, $1F, $50, 	$04, $14, $14, $1F
;	$00, $00, $00, $00, 	$1B, $8A, $2A, $0A, 	$2B, $28, $35, $00
	smpsVcAlgorithm     $02
	smpsVcFeedback      $07
	smpsVcUnusedBits    $00
	smpsVcDetune        $03, $07, $03, $07
	smpsVcCoarseFreq    $01, $02, $05, $02
	smpsVcRateScale     $01, $00, $00, $01
	smpsVcAttackRate    $10, $1F, $10, $10
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $1F, $14, $14, $04
	smpsVcDecayRate2    $00, $00, $00, $00
	smpsVcDecayLevel    $00, $02, $08, $01
	smpsVcReleaseRate   $0A, $0A, $0A, $0B
	smpsVcTotalLevel    $00, $35, $28, $2B

;	Voice $05
;	$02
;	$4D, $47, $47, $41, 	$1F, $1F, $1F, $1F, 	$1B, $0D, $11, $10
;	$10, $00, $00, $00, 	$FF, $FF, $FF, $FF, 	$7F, $7F, $7F, $00
	smpsVcAlgorithm     $02
	smpsVcFeedback      $00
	smpsVcUnusedBits    $00
	smpsVcDetune        $04, $04, $04, $04
	smpsVcCoarseFreq    $01, $07, $07, $0D
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $1F, $1F, $1F, $1F
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $10, $11, $0D, $1B
	smpsVcDecayRate2    $00, $00, $00, $10
	smpsVcDecayLevel    $0F, $0F, $0F, $0F
	smpsVcReleaseRate   $0F, $0F, $0F, $0F
	smpsVcTotalLevel    $00, $7F, $7F, $7F

;	Voice $06
;	$02
;	$4D, $47, $47, $41, 	$1F, $1F, $1F, $1F, 	$1B, $0D, $11, $0D
;	$00, $00, $00, $00, 	$FA, $F9, $F9, $F9, 	$17, $2A, $22, $00
	smpsVcAlgorithm     $02
	smpsVcFeedback      $00
	smpsVcUnusedBits    $00
	smpsVcDetune        $04, $04, $04, $04
	smpsVcCoarseFreq    $01, $07, $07, $0D
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $1F, $1F, $1F, $1F
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $0D, $11, $0D, $1B
	smpsVcDecayRate2    $00, $00, $00, $00
	smpsVcDecayLevel    $0F, $0F, $0F, $0F
	smpsVcReleaseRate   $09, $09, $09, $0A
	smpsVcTotalLevel    $00, $22, $2A, $17

;	Voice $07
;	$3C
;	$1A, $03, $19, $45, 	$04, $04, $07, $06, 	$08, $06, $07, $08
;	$00, $00, $00, $00, 	$06, $F6, $08, $A8, 	$17, $04, $10, $00
	smpsVcAlgorithm     $04
	smpsVcFeedback      $07
	smpsVcUnusedBits    $00
	smpsVcDetune        $04, $01, $00, $01
	smpsVcCoarseFreq    $05, $09, $03, $0A
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $06, $07, $04, $04
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $08, $07, $06, $08
	smpsVcDecayRate2    $00, $00, $00, $00
	smpsVcDecayLevel    $0A, $00, $0F, $00
	smpsVcReleaseRate   $08, $08, $06, $06
	smpsVcTotalLevel    $00, $10, $04, $17

