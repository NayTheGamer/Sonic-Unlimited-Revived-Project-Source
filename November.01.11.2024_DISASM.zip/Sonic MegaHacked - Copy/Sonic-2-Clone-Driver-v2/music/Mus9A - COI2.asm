COI2_Header:
	smpsHeaderStartSong 1
	smpsHeaderVoice     COI2_Voices
	smpsHeaderChan      $07, $03
	smpsHeaderTempo     $01, $00

	smpsHeaderDAC       COI2_DAC,	$00, $F2
	smpsHeaderFM        COI2_FM1,	$00, $00
	smpsHeaderFM        COI2_FM2,	$00, $00
	smpsHeaderFM        COI2_FM3,	$00, $00
	smpsHeaderFM        COI2_FM4,	$00, $00
	smpsHeaderFM        COI2_FM5,	$00, $00
	smpsHeaderFM        COI2_FM6,	$00, $00
	smpsHeaderPSG       COI2_PSG1,	$00, $00, $00, $00
	smpsHeaderPSG       COI2_PSG2,	$00, $00, $00, $00
	smpsHeaderPSG       COI2_PSG3,	$00, $00, $00, $00

; DAC Data
COI2_DAC:
; FM3 Data
COI2_FM3:
; FM4 Data
COI2_FM4:
; PSG3 Data
COI2_PSG3:
	smpsStop

; FM1 Data
COI2_FM1:
	smpsSetvoice        $00
	smpsAlterVol        $7F
	smpsPan             panRight, $00
	smpsModSet          $00, $02, $03, $03
	dc.b	nRst, $58
	smpsPan             panCenter, $00
	smpsModOff
	dc.b	smpsNoAttack, nRst, $01
	smpsSetvoice        $06
	smpsAlterVol        $91
	smpsPan             panRight, $00
	smpsModSet          $00, $02, $03, $03
	dc.b	nC5, $0E, nAb4, $0F, nBb4, $49, nRst, $10, nC5, $0F, nAb4, nBb4
	dc.b	$1D, nEb5, $1E, nCs5, $17, nRst, $06, nC5, $0F, nAb4, nE4, $2D
	dc.b	nFs4, $0E, nAb4, $1F, nRst, $1D, nE4, $2C, nFs4, $0F, nAb4, $19
	dc.b	nRst, $03
	smpsSetvoice        $07
	smpsPan             panCenter, $00
	dc.b	smpsNoAttack, nRst, $02
	smpsAlterVol        $FD
	smpsPan             panLeft, $00
	dc.b	nC5, $0E, nAb4, $0F, nBb4, $4A, nRst, $0F, nC5, nAb4, nBb4, $1D
	dc.b	nEb5, $1E, nCs5, $17, nRst, $07, nC5, $0E, nCs5, $0F, nC5, $50
	dc.b	nRst, $09, nFs4, $0F, nAb4, nFs4, $1D, nC4, $53, nRst, $7F, $7F
	dc.b	$4E
	smpsSetvoice        $06
	smpsAlterVol        $03
	smpsPan             panRight, $00
	dc.b	nC5, $0F, nAb4, nBb4, $49, nRst, $10, nC5, $0F, nAb4, $0E, nBb4
	dc.b	$1E, nEb5, nCs5, $16, nRst, $07, nC5, $0F, nAb4, nE4, $2C, nFs4
	dc.b	$0F, nAb4, $1E, nRst, $1D, nE4, $2D, nFs4, $0F, nAb4, $19, nRst
	dc.b	$03
	smpsSetvoice        $07
	smpsPan             panCenter, $00
	dc.b	smpsNoAttack, nRst, $01
	smpsAlterVol        $FD
	smpsPan             panLeft, $00
	dc.b	nC5, $0F, nAb4, nBb4, $49, nRst, $10, nC5, $0F, nAb4, $0E, nRst
	dc.b	$01, nBb4, $1D, nEb5, $1E, nCs5, $17, nRst, $06, nC5, $0F, nCs5
	dc.b	nC5, $50, nRst, $09, nFs4, $0F, nAb4, nFs4, $1D, nC4, $52, nRst
	dc.b	$7F, $7F, $32
	smpsSetvoice        $00
	smpsAlterVol        $F3
	smpsPan             panCenter, $00
	smpsModOff
	smpsJump            COI2_FM1

; FM2 Data
COI2_FM2:
	smpsSetvoice        $01
	smpsAlterVol        $13
	smpsPan             panCenter, $00
	smpsModSet          $00, $02, $01, $03
	dc.b	nE2, $07, nF2, nFs2, $08, nG2, $07, nAb2, $08, nA2, $07, nBb2
	dc.b	nB2, $08, nC3, $07, nB2, $08, nBb2, $07, nA2, $08, nAb2, $07
	dc.b	nG2, nFs2, $08, nF2, $07, nE2, nF2, $08, nFs2, $07, nG2, $08
	dc.b	nAb2, $07, nA2, $08, nBb2, $07, nB2, nC3, $08, nB2, $07, nBb2
	dc.b	$08, nA2, $07, nAb2, nG2, $08, nFs2, $07, nF2, $08, nE2, $07
	dc.b	nF2, nFs2, $08, nG2, $07, nAb2, $08, nA2, $07, nBb2, nB2, $08
	dc.b	nC3, $07, nB2, $08, nBb2, $07, nA2, $08, nAb2, $07, nG2, nFs2
	dc.b	$08, nF2, $07, nE2, $08, nF2, $07, nFs2, nG2, $08, nAb2, $07
	dc.b	nA2, $08, nBb2, $07, nB2, nC3, $08, nB2, $07, nBb2, $08, nA2
	dc.b	$07, nAb2, nG2, $08, nFs2, $07, nF2, $08, nE2, $07, nF2, nFs2
	dc.b	$08, nG2, $07, nAb2, $08, nA2, $07, nBb2, nRst, $01, nB2, $07
	dc.b	nC3, nB2, $08, nBb2, $07, nA2, $08, nAb2, $07, nG2, nFs2, $08
	dc.b	nF2, $07, nE2, $08, nF2, $07, nFs2, nG2, $08, nAb2, $07, nA2
	dc.b	$08, nBb2, $07, nB2, nC3, $08, nB2, $07, nBb2, $08, nA2, $07
	dc.b	nAb2, nRst, $01, nG2, $07, nFs2, nF2, $08, nE2, $07, nF2, $08
	dc.b	nFs2, $07, nG2, nAb2, $08, nA2, $07, nBb2, $08, nB2, $07, nC3
	dc.b	nB2, $08, nBb2, $07, nA2, $08, nAb2, $07, nG2, nRst, $01, nFs2
	dc.b	$07, nF2, nRst, $01, nE2, $07, nF2, nFs2, nG2, $08, nAb2, $07
	dc.b	nA2, $08, nBb2, $07, nB2, nRst, $01, nC3, $07, nB2, nBb2, $08
	dc.b	nA2, $07, nAb2, $08, nG2, $07, nFs2, nF2, $08, nE2, $07, nF2
	dc.b	$08, nFs2, $07, nG2, nAb2, $08, nA2, $07, nBb2, $08, nB2, $07
	dc.b	nC3, nB2, $08, nBb2, $07, nA2, $08, nAb2, $07, nG2, nFs2, $08
	dc.b	nF2, $07, smpsNoAttack, nF2, $01, nE2, $07, nF2, nFs2, nRst, $01, nG2
	dc.b	$07, nAb2, nA2, $08, nBb2, $07, nB2, $08, nC3, $07, nB2, nBb2
	dc.b	$08, nA2, $07, nAb2, $08, nG2, $07, nFs2, nF2, $08, nE2, $07
	dc.b	nF2, $08, nFs2, $07, nG2, nAb2, $08, nA2, $07, nBb2, $08, nB2
	dc.b	$07, nC3, nB2, $08, nBb2, $07, nA2, $08, nAb2, $07, nG2, $08
	dc.b	nFs2, $07, nF2, smpsNoAttack, nF2, $01, nE2, $07, nF2, nFs2, $08, nG2
	dc.b	$07, nAb2, nA2, $08, nBb2, $07, nB2, $08, nC3, $07, nB2, nBb2
	dc.b	$08, nA2, $07, nRst, $01, nAb2, $07, nG2, nFs2, nF2, $08, nE2
	dc.b	$07, nF2, $08, nFs2, $07, nG2, nRst, $01, nAb2, $07, nA2, nBb2
	dc.b	$08, nB2, $07, nC3, $08, nB2, $07, nBb2, nA2, $08, nAb2, $07
	dc.b	nG2, $08, nFs2, $07, nF2
	smpsSetvoice        $08
	dc.b	smpsNoAttack, nF2, $01
	smpsSetvoice        $01
	dc.b	nE2, $07, nF2, nFs2, $08, nG2, $07, nAb2, nA2, $08, nBb2, $07
	dc.b	nB2, $08, nC3, $07, nB2, nRst, $01, nBb2, $07, nA2, nAb2, $08
	dc.b	nG2, $07, nFs2, $08, nF2, $07, nE2, nF2, $08, nFs2, $07, nG2
	dc.b	$08, nAb2, $07, nA2, nBb2, $08, nB2, $07, nC3, $08, nB2, $07
	dc.b	nBb2, nA2, $08, nAb2, $07, nG2, $08, nFs2, $07, nF2
	smpsSetvoice        $08
	dc.b	smpsNoAttack, nF2, $01
	smpsSetvoice        $01
	dc.b	nE2, $07, nF2, nFs2, $08, nG2, $07, nAb2, nRst, $01, nA2, $07
	dc.b	nBb2, nB2, $08, nC3, $07, nB2, $08, nBb2, $07, nA2, nAb2, $08
	dc.b	nG2, $07, nFs2, $08, nF2, $07, nE2, nF2, $08, nFs2, $07, nG2
	dc.b	$08, nAb2, $07, nA2, nBb2, $08, nB2, $07, nC3, $08, nB2, $07
	dc.b	nBb2, nA2, $08, nAb2, $07, nG2, $08, nFs2, $07, nF2, $08, nE2
	dc.b	$07, nF2, nFs2, $08, nG2, $07, nAb2, $08, nA2, $07, nBb2, nB2
	dc.b	$08, nC3, $07, nB2, $08, nBb2, $07, nA2, nAb2, $08, nG2, $07
	dc.b	nFs2, $08, nF2, $07, nE2, nF2, $08, nFs2, $07, nG2, $08, nAb2
	dc.b	$07, nA2, nRst, $01, nBb2, $07, nB2, nC3, $08, nB2, $07, nBb2
	dc.b	$08, nA2, $07, nAb2, nG2, $08, nFs2, $07, nF2, $08, nE2, $07
	dc.b	nF2, nFs2, $08, nG2, $07, nAb2, $08, nA2, $07, nBb2, nB2, $08
	dc.b	nC3, $07, nB2, $08, nBb2, $07, nA2, nRst, $01, nAb2, $07, nG2
	dc.b	nFs2, $08, nF2, $07, nE2, nRst, $01, nF2, $07, nFs2, nG2, $08
	dc.b	nAb2, $07, nA2, $08, nBb2, $07, nB2, nC3, $08, nB2, $07, nBb2
	dc.b	$08, nA2, $07, nAb2, nG2, $08, nFs2, $07, nF2, $08, nE2, $07
	dc.b	nF2, nFs2, $08, nG2, $07, nAb2, $08, nA2, $07, nBb2, nB2, $08
	dc.b	nC3, $07, nB2, $08, nBb2, $07, nA2, nRst, $01, nAb2, $07, nG2
	dc.b	nFs2, $08, nF2, nRst, $3A
	smpsSetvoice        $08
	dc.b	smpsNoAttack, nRst, $01
	smpsSetvoice        $00
	smpsAlterVol        $ED
	smpsPan             panCenter, $00
	smpsModOff
	smpsJump            COI2_FM2

; FM5 Data
COI2_FM5:
	smpsSetvoice        $04
	smpsAlterVol        $14
	smpsPan             panCenter, $00
	smpsModSet          $00, $02, $02, $03
	dc.b	nAb2, $0E
	smpsAlterVol        $FD
	dc.b	nC4, $0F, nRst, nC4, $0E, nRst, $01
	smpsAlterVol        $F7
	dc.b	nE2, $0E, nRst, $01
	smpsAlterVol        $09
	dc.b	nBb3, $0E, nRst, $0F, nBb3, $0E, nRst, $01, nAb2, $0E, nRst, $01
	dc.b	nC4, $0E, nRst, $10, nC4, $0E
	smpsAlterVol        $F7
	dc.b	nE2, $0F
	smpsAlterVol        $09
	dc.b	nBb3, $0E, nRst, $10, nBb3, $0E, nRst, $01, nAb2, $0E, nRst, $01
	dc.b	nC4, $0E, nRst, $0F, nC4, $0E, nRst, $01
	smpsAlterVol        $F7
	dc.b	nE2, $0E, nRst, $01
	smpsAlterVol        $09
	dc.b	nBb3, $0E, nRst, $0F, nBb3, nAb2, $0E, nRst, $01, nC4, $0E, nRst
	dc.b	$10, nC4, $0E
	smpsAlterVol        $F7
	dc.b	nRst, $01, nE2, $0E
	smpsAlterVol        $09
	dc.b	nBb3, nRst, $10, nBb3, $0E, nRst, $01, nAb2, $0E, nRst, $01, nC4
	dc.b	$0E, nRst, $0F, nC4, $0E, nRst, $01
	smpsAlterVol        $F7
	dc.b	nE2, $0E, nRst, $01
	smpsAlterVol        $09
	dc.b	nBb3, $0E, nRst, $0F, nBb3, nRst, $01, nAb2, $0D, nRst, $01, nC4
	dc.b	$0E, nRst, $10, nC4, $0E, nRst, $01
	smpsAlterVol        $F7
	dc.b	nE2, $0E
	smpsAlterVol        $09
	dc.b	nBb3, nRst, $10, nBb3, $0E, nRst, $01, nAb2, $0E, nRst, $01, nC4
	dc.b	$0E, nRst, $0F, nC4, $0E, nRst, $01
	smpsAlterVol        $F7
	dc.b	nE2, $0E, nRst, $01
	smpsAlterVol        $09
	dc.b	nBb3, $0E, nRst, $10, nBb3, $0E, nRst, $01, nAb2, $0D, nRst, $01
	dc.b	nC4, $0E, nRst, $10, nC4, $0E, nRst, $01
	smpsAlterVol        $F7
	dc.b	nE2, $0E
	smpsAlterVol        $09
	dc.b	nBb3, $0F, nRst, nBb3, $0E, nRst, $01, nAb2, $0E, nRst, $01, nC4
	dc.b	$0E, nRst, $0F, nC4, $0E, nRst, $01
	smpsAlterVol        $F7
	dc.b	nE2, $0E, nRst, $01
	smpsAlterVol        $09
	dc.b	nBb3, $0E, nRst, $10, nBb3, $0E, nRst, $01
	smpsAlterVol        $F8
	dc.b	nB3, $0D, nRst, $10, nA3, $0E, nRst, $2D, nG3, $0E, nRst, $10
	dc.b	nF3, $0E, nRst, $10, nE3, $0E, nRst, $0F, nD3, $0E, nRst, $10
	dc.b	nBb2, $0E, nRst, $10, nAb2, $0E
	smpsAlterVol        $08
	dc.b	nC4, nRst, $10, nC4, $0E, nRst, $01
	smpsAlterVol        $F7
	dc.b	nE2, $0E
	smpsAlterVol        $09
	dc.b	nRst, $01, nBb3, $0E, nRst, $0F, nBb3, $0E, nRst, $01, nAb2, $0E
	dc.b	nRst, $01, nC4, $0E, nRst, $0F, nC4
	smpsAlterVol        $F7
	dc.b	nE2, $0E, nRst, $01
	smpsAlterVol        $09
	dc.b	nBb3, $0E, nRst, $10, nBb3, $0E, nRst, $01, nAb2, $0E, nC4, nRst
	dc.b	$10, nC4, $0E, nRst, $01
	smpsAlterVol        $F7
	dc.b	nE2, $0E, nRst, $01
	smpsAlterVol        $09
	dc.b	nBb3, $0E, nRst, $0F, nBb3, $0E, nRst, $01, nAb2, $0E, nRst, $01
	dc.b	nC4, $0E, nRst, $0F, nC4
	smpsAlterVol        $F7
	dc.b	nE2, $0E, nRst, $01
	smpsAlterVol        $09
	dc.b	nBb3, $0E, nRst, $10, nBb3, $0E, nRst, $01, nAb2, $0E, nC4, $0F
	dc.b	nRst, nC4, $0E, nRst, $01
	smpsAlterVol        $F7
	dc.b	nE2, $0E, nRst, $01
	smpsAlterVol        $09
	dc.b	nBb3, $0E, nRst, $0F, nBb3, $0E, nRst, $01, nAb2, $0E, nRst, $01
	dc.b	nC4, $0E, nRst, $10, nC4, $0E
	smpsAlterVol        $F7
	dc.b	nE2, nRst, $01
	smpsAlterVol        $09
	dc.b	nBb3, $0E, nRst, $10, nBb3, $0E, nRst, $01, nAb2, $0E, nC4, $0F
	dc.b	nRst, nC4, $0E, nRst, $01
	smpsAlterVol        $F7
	dc.b	nE2, $0E, nRst, $01
	smpsAlterVol        $09
	dc.b	nBb3, $0E, nRst, $0F, nBb3, $0E, nRst, $01, nAb2, $0E, nRst, $01
	dc.b	nC4, $0E, nRst, $10, nC4, $0E
	smpsAlterVol        $F7
	dc.b	nE2, $0F
	smpsAlterVol        $09
	dc.b	nBb3, $0E, nRst, $10, nBb3, $0E, nRst, $01, nAb2, $0E, nC4, $0F
	dc.b	nRst, nC4, $0E, nRst, $01
	smpsAlterVol        $F7
	dc.b	nE2, $0E, nRst, $01
	smpsAlterVol        $09
	dc.b	nBb3, $0E, nRst, $0F, nBb3, $0E, nRst, $01
	smpsAlterVol        $F8
	dc.b	nB3, $0E, nRst, $10, nA3, $0E, nRst, $2D, nG3, $0E, nRst, $10
	dc.b	nF3, $0E, nRst, $0F, nE3, $0E, nRst, $10, nD3, $0E, nRst, $10
	dc.b	nBb2, $0E, nRst, $0F, nG2, $0E, nRst, $2E
	smpsSetvoice        $00
	smpsAlterVol        $F7
	smpsPan             panCenter, $00
	smpsModOff
	smpsJump            COI2_FM5

; FM6 Data
COI2_FM6:
	smpsSetvoice        $05
	smpsAlterVol        $12
	smpsPan             panCenter, $00
	dc.b	nD1, $07, nD1, nD1, $08, nD1, $07, nFs1, $06, nRst, $09, nFs1
	dc.b	$06, nRst, $09, nFs1, $0F, nF1, $05, nRst, $0A, nE1, $05, nRst
	dc.b	$09, nEb1, $06, nRst, $09, nD1, $08, nD1, $07, nD1, nD1, $08
	dc.b	nFs1, $05, nRst, $0A, nFs1, $05, nRst, $0A, nFs1, $0E, nF1, $06
	dc.b	nRst, $09, nE1, $06, nRst, $09, nEb1, $05, nRst, $0A, nD1, $07
	dc.b	nD1, $08, nD1, $07, nD1, nFs1, $06, nRst, $09, nFs1, $06, nRst
	dc.b	$09, nFs1, $0F, nF1, $05, nRst, $0A, nE1, $05, nRst, $09, nEb1
	dc.b	$06, nRst, $09, smpsNoAttack, nRst, $01, nD1, $07, nD1, nD1, nD1, $08
	dc.b	nFs1, $05, nRst, $0A, nFs1, $05, nRst, $0A, nFs1, $0E, nF1, $06
	dc.b	nRst, $09, nE1, $06, nRst, $09, nEb1, $05, nRst, $0A, nD1, $07
	dc.b	nD1, $08, nD1, $07, nD1, nFs1, $06, nRst, $09, nFs1, $06, nRst
	dc.b	$09, nFs1, $0F, nF1, $05, nRst, $0A, nE1, $05, nRst, $0A, nEb1
	dc.b	$05, nRst, $0A, nD1, $07, nD1, nD1, nD1, $08, nFs1, $05, nRst
	dc.b	$0A, nFs1, $05, nRst, $0A, nFs1, $0E, nF1, $06, nRst, $09, nE1
	dc.b	$06, nRst, $09, nEb1, $05, nRst, $0A, nD1, $07, nD1, $08, nD1
	dc.b	$07, nD1, nFs1, $06, nRst, $09, nFs1, $06, nRst, $09, nFs1, $0F
	dc.b	nF1, $05, nRst, $0A, nE1, $05, nRst, $0A, nEb1, $05, nRst, $0A
	dc.b	nD1, $07, nD1, nD1, $08, nD1, $07, nFs1, $05, nRst, $0A, nFs1
	dc.b	$05, nRst, $0A, nFs1, $0E, nF1, $06, nRst, $09, nE1, $06, nRst
	dc.b	$09, nEb1, $06, nRst, $09, nD1, $07, nD1, $08, nD1, $07, nD1
	dc.b	nRst, $01, nFs1, $05, nRst, $09, nFs1, $06, nRst, $09, nFs1, $0F
	dc.b	nF1, $05, nRst, $0A, nE1, $05, nRst, $0A, nEb1, $05, nRst, $0A
	dc.b	nD1, $07, nD1, nD1, $08, nD1, $07, nFs1, $0C, nRst, $2F, nE1
	dc.b	$06, nRst, $09, nEb1, $06, nRst, $09, nD1, $07, nD1, $08, nD1
	dc.b	$07, nD1, $08, nFs1, $0C, nRst, $4D, nD1, $07, nD1, nD1, $08
	dc.b	nD1, $07, nFs1, $06, nRst, $09, nFs1, $05, nRst, $0A, nFs1, $0F
	dc.b	nF1, $05, nRst, $0A, nE1, $05, nRst, $09, nEb1, $06, nRst, $09
	dc.b	nD1, $07, nD1, $08, nD1, $07, nD1, $08, nFs1, $05, nRst, $09
	dc.b	nFs1, $06, nRst, $09, nFs1, $0F, nF1, $06, nRst, $09, nE1, $05
	dc.b	nRst, $0A, nEb1, $05, nRst, $0A, nD1, $07, nD1, nD1, $08, nD1
	dc.b	$07, nFs1, $06, nRst, $09, nFs1, $05, nRst, $0A, nFs1, $0F, nF1
	dc.b	$05, nRst, $09, nE1, $06, nRst, $09, nEb1, $06, nRst, $09, nD1
	dc.b	$07, nD1, $08, nD1, $07, nD1, $08, nFs1, $05, nRst, $0A, nFs1
	dc.b	$05, nRst, $09, nFs1, $0F, nF1, $06, nRst, $09, nE1, $05, nRst
	dc.b	$0A, nEb1, $05, nRst, $0A, nD1, $07, nD1, nD1, $08, nD1, $07
	dc.b	nFs1, $06, nRst, $09, nFs1, $05, nRst, $0A, nFs1, $0F, nF1, $05
	dc.b	nRst, $0A, nE1, $05, nRst, $09, nEb1, $06, nRst, $09, nD1, $07
	dc.b	nD1, $08, nD1, $07, nD1, $08, nFs1, $05, nRst, $0A, nFs1, $05
	dc.b	nRst, $09, nFs1, $0F, nF1, $06, nRst, $09, nE1, $05, nRst, $0A
	dc.b	nEb1, $05, nRst, $0A, nD1, $07, nD1, nD1, $08, nD1, $07, nFs1
	dc.b	$06, nRst, $09, nFs1, $06, nRst, $09, nFs1, $0F, nF1, $05, nRst
	dc.b	$0A, nE1, $05, nRst, $09, nEb1, $06, nRst, $09, nD1, $08, nD1
	dc.b	$07, nD1, nD1, $08, nFs1, $05, nRst, $0A, nFs1, $05, nRst, $09
	dc.b	nFs1, $0F, nF1, $06, nRst, $09, nE1, $06, nRst, $09, nEb1, $05
	dc.b	nRst, $0A, nD1, $07, nD1, $08, nD1, $07, nD1, nFs1, $06, nRst
	dc.b	$09, nFs1, $06, nRst, $09, nFs1, $0F, nF1, $05, nRst, $0A, nE1
	dc.b	$05, nRst, $09, nEb1, $06, nRst, $0A, nD1, $07, nD1, nD1, nD1
	dc.b	$08, nFs1, $0C, nRst, $2F, nE1, $06, nRst, $09, nEb1, $05, nRst
	dc.b	$0A, nD1, $07, nD1, nRst, $01, nD1, $07, nD1, nFs1, $0D, nRst
	dc.b	$7F, $09
	smpsSetvoice        $00
	smpsAlterVol        $EE
	smpsPan             panCenter, $00
	smpsJump            COI2_FM6

; PSG1 Data
COI2_PSG1:
	dc.b	nRst, $0F
	smpsPSGAlterVol     $05
	dc.b	nBb1, $04
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, $03
	smpsPSGAlterVol     $01
	dc.b	nBb1, $01
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nBb1, $04
	smpsPSGAlterVol     $01
	dc.b	nBb1, $05
	smpsPSGAlterVol     $01
	dc.b	nBb1, $04
	smpsPSGAlterVol     $01
	dc.b	nBb1, $02
	smpsPSGAlterVol     $01
	dc.b	nBb1, $01
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, $02
	smpsPSGAlterVol     $01
	dc.b	nBb1, $01
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nAb1, $04
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, $05
	smpsPSGAlterVol     $01
	dc.b	nAb1, $02
	smpsPSGAlterVol     $01
	dc.b	nAb1, $01
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nAb1, $05
	smpsPSGAlterVol     $01
	dc.b	nAb1, $04
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, $03
	smpsPSGAlterVol     $01
	dc.b	nAb1, $01
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nBb1, $04
	smpsPSGAlterVol     $01
	dc.b	nBb1, $05
	smpsPSGAlterVol     $01
	dc.b	nBb1, $04
	smpsPSGAlterVol     $01
	dc.b	nBb1, $02
	smpsPSGAlterVol     $01
	dc.b	nBb1, $01
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, $02, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nBb1, $04
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, $03
	smpsPSGAlterVol     $01
	dc.b	nBb1, $01
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nAb1, $05
	smpsPSGAlterVol     $01
	dc.b	nAb1, $04
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, $03
	smpsPSGAlterVol     $01
	dc.b	nAb1, $01
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nAb1, $04
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, $05
	smpsPSGAlterVol     $01
	dc.b	nAb1, $02
	smpsPSGAlterVol     $01
	dc.b	nAb1, $01
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, $02
	smpsPSGAlterVol     $01
	dc.b	nAb1, $01, nRst, $09
	smpsPSGAlterVol     $F8
	dc.b	nBb1, $04
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, $03
	smpsPSGAlterVol     $01
	dc.b	nBb1, $01
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nBb1, $04
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, $05
	smpsPSGAlterVol     $01
	dc.b	nBb1, $03
	smpsPSGAlterVol     $02
	dc.b	nBb1, $01
	smpsPSGAlterVol     $01
	dc.b	nBb1, $02
	smpsPSGAlterVol     $01
	dc.b	nBb1, $01
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nAb1, $04
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, $05
	smpsPSGAlterVol     $01
	dc.b	nAb1, $02
	smpsPSGAlterVol     $01
	dc.b	nAb1, $01
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nAb1, $05
	smpsPSGAlterVol     $01
	dc.b	nAb1, $04
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, $03
	smpsPSGAlterVol     $01
	dc.b	nAb1, $01
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nBb1, $04
	smpsPSGAlterVol     $01
	dc.b	nBb1, $05
	smpsPSGAlterVol     $01
	dc.b	nBb1, $04
	smpsPSGAlterVol     $01
	dc.b	nBb1, $02
	smpsPSGAlterVol     $01
	dc.b	nBb1, $01
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, $02
	smpsPSGAlterVol     $02
	dc.b	nBb1, $01
	smpsPSGAlterVol     $01
	dc.b	nBb1, $02, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nBb1, $04
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, $05
	smpsPSGAlterVol     $01
	dc.b	nBb1, $02
	smpsPSGAlterVol     $01
	dc.b	nBb1, $01
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nAb1, $05
	smpsPSGAlterVol     $01
	dc.b	nAb1, $04
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, $03
	smpsPSGAlterVol     $01
	dc.b	nAb1, $01
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nAb1, $04
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, $05
	smpsPSGAlterVol     $01
	dc.b	nAb1, $02
	smpsPSGAlterVol     $01
	dc.b	nAb1, $01
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, $02
	smpsPSGAlterVol     $01
	dc.b	nAb1, $01
	smpsPSGAlterVol     $01
	dc.b	nAb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nBb1, $04
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, $03
	smpsPSGAlterVol     $01
	dc.b	nBb1, $01
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nBb1, $04
	smpsPSGAlterVol     $01
	dc.b	nBb1, $05
	smpsPSGAlterVol     $01
	dc.b	nBb1, $04
	smpsPSGAlterVol     $01
	dc.b	nBb1, $03
	smpsPSGAlterVol     $01
	dc.b	nBb1, $01
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nAb1, $04
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, $03
	smpsPSGAlterVol     $01
	dc.b	nAb1, $01
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, nRst, $09
	smpsPSGAlterVol     $F7
	dc.b	nAb1, $04
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, $03
	smpsPSGAlterVol     $01
	dc.b	nAb1, $01
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nBb1, $04
	smpsPSGAlterVol     $01
	dc.b	nBb1, $05
	smpsPSGAlterVol     $01
	dc.b	nBb1, $04
	smpsPSGAlterVol     $01
	dc.b	nBb1, $02
	smpsPSGAlterVol     $01
	dc.b	nBb1, $01
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, $02
	smpsPSGAlterVol     $01
	dc.b	nBb1, $01
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nBb1, $04
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, $05
	smpsPSGAlterVol     $01
	dc.b	nBb1, $02
	smpsPSGAlterVol     $01
	dc.b	nBb1, $01
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nAb1, $05
	smpsPSGAlterVol     $01
	dc.b	nAb1, $04
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, $03
	smpsPSGAlterVol     $02
	dc.b	nAb1, $02
	smpsPSGAlterVol     $01
	dc.b	nAb1, $01
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nAb1, $04
	smpsPSGAlterVol     $01
	dc.b	nAb1, $05
	smpsPSGAlterVol     $01
	dc.b	nAb1, $04
	smpsPSGAlterVol     $01
	dc.b	nAb1, $02
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $02
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, $01
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nBb1, $04
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, $03
	smpsPSGAlterVol     $01
	dc.b	nBb1, $01
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nBb1, $05
	smpsPSGAlterVol     $01
	dc.b	nBb1, $04
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, $03
	smpsPSGAlterVol     $01
	dc.b	nBb1, $01
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nAb1, $04
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, $03
	smpsPSGAlterVol     $01
	dc.b	nAb1, $01
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, $02
	smpsPSGAlterVol     $02
	dc.b	nAb1, $01, nRst, $09
	smpsPSGAlterVol     $F7
	dc.b	nAb1, $04
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, $03
	smpsPSGAlterVol     $01
	dc.b	nAb1, $01
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nBb1, $04
	smpsPSGAlterVol     $01
	dc.b	nBb1, $05
	smpsPSGAlterVol     $01
	dc.b	nBb1, $04
	smpsPSGAlterVol     $01
	dc.b	nBb1, $03
	smpsPSGAlterVol     $02
	dc.b	nBb1, $01
	smpsPSGAlterVol     $01
	dc.b	nBb1, $02
	smpsPSGAlterVol     $01
	dc.b	nBb1, $01
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nBb1, $04
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, $05
	smpsPSGAlterVol     $01
	dc.b	nBb1, $02
	smpsPSGAlterVol     $01
	dc.b	nBb1, $01
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, nRst, $09
	smpsPSGAlterVol     $F7
	dc.b	nAb1, $04
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, $03
	smpsPSGAlterVol     $01
	dc.b	nAb1, $01
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nAb1, $04
	smpsPSGAlterVol     $01
	dc.b	nAb1, $05
	smpsPSGAlterVol     $01
	dc.b	nAb1, $04
	smpsPSGAlterVol     $01
	dc.b	nAb1, $02
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, $01
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nBb1, $04
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, $03
	smpsPSGAlterVol     $01
	dc.b	nBb1, $01
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nBb1, $05
	smpsPSGAlterVol     $01
	dc.b	nBb1, $04
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, $03
	smpsPSGAlterVol     $01
	dc.b	nBb1, $01
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nAb1, $04
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, $05
	smpsPSGAlterVol     $01
	dc.b	nAb1, $02
	smpsPSGAlterVol     $01
	dc.b	nAb1, $01
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, $02
	smpsPSGAlterVol     $01
	dc.b	nAb1, $01
	smpsPSGAlterVol     $01
	dc.b	nAb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nAb1, $04
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, $03
	smpsPSGAlterVol     $01
	dc.b	nAb1, $01
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nFs1, $04
	smpsPSGAlterVol     $01
	dc.b	nFs1, $05
	smpsPSGAlterVol     $01
	dc.b	nFs1, $04
	smpsPSGAlterVol     $01
	dc.b	nFs1, $03
	smpsPSGAlterVol     $02
	dc.b	nFs1, $01
	smpsPSGAlterVol     $01
	dc.b	nFs1, $02
	smpsPSGAlterVol     $01
	dc.b	nFs1, $01
	smpsPSGAlterVol     $01
	dc.b	nFs1
	smpsPSGAlterVol     $01
	dc.b	nFs1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nFs1, $04
	smpsPSGAlterVol     $01
	dc.b	nFs1
	smpsPSGAlterVol     $01
	dc.b	nFs1, $05
	smpsPSGAlterVol     $01
	dc.b	nFs1, $04
	smpsPSGAlterVol     $01
	dc.b	nFs1
	smpsPSGAlterVol     $01
	dc.b	nFs1
	smpsPSGAlterVol     $01
	dc.b	nFs1
	smpsPSGAlterVol     $FA
	dc.b	nFs1, $05
	smpsPSGAlterVol     $01
	dc.b	nFs1, $04
	smpsPSGAlterVol     $01
	dc.b	nFs1
	smpsPSGAlterVol     $01
	dc.b	nFs1, $02
	smpsPSGAlterVol     $FD
	dc.b	nG1, $04
	smpsPSGAlterVol     $01
	dc.b	nG1, $05
	smpsPSGAlterVol     $01
	dc.b	nG1, $04
	smpsPSGAlterVol     $01
	dc.b	nG1, $02
	smpsPSGAlterVol     $FD
	dc.b	nFs1, $04
	smpsPSGAlterVol     $01
	dc.b	nFs1, $05
	smpsPSGAlterVol     $01
	dc.b	nFs1, $04
	smpsPSGAlterVol     $01
	dc.b	nFs1, $02
	smpsPSGAlterVol     $FD
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1, $05
	smpsPSGAlterVol     $01
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, $05
	smpsPSGAlterVol     $01
	dc.b	nE1, $04
	smpsPSGAlterVol     $FA
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, $05
	smpsPSGAlterVol     $01
	dc.b	nD1, $04
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $FA
	dc.b	nC1
	smpsPSGAlterVol     $01
	dc.b	nC1, $05
	smpsPSGAlterVol     $01
	dc.b	nC1, $04
	smpsPSGAlterVol     $01
	dc.b	nC1
	smpsPSGAlterVol     $01
	dc.b	nC1, $05
	smpsPSGAlterVol     $01
	dc.b	nC1, $04
	smpsPSGAlterVol     $01
	dc.b	nC1
	smpsPSGAlterVol     $FA
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, $05
	smpsPSGAlterVol     $01
	dc.b	nAb1, $04
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, $05, nRst, $0E
	smpsPSGAlterVol     $FA
	dc.b	nBb1, $04
	smpsPSGAlterVol     $01
	dc.b	nBb1, $05
	smpsPSGAlterVol     $01
	dc.b	nBb1, $04
	smpsPSGAlterVol     $01
	dc.b	nBb1, $03
	smpsPSGAlterVol     $01
	dc.b	nBb1, $01
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nBb1, $04
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, $05
	smpsPSGAlterVol     $01
	dc.b	nBb1, $02
	smpsPSGAlterVol     $01
	dc.b	nBb1, $01
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, nRst, $09
	smpsPSGAlterVol     $F7
	dc.b	nAb1, $04
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, $03
	smpsPSGAlterVol     $01
	dc.b	nAb1, $01
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nAb1, $04
	smpsPSGAlterVol     $01
	dc.b	nAb1, $05
	smpsPSGAlterVol     $01
	dc.b	nAb1, $04
	smpsPSGAlterVol     $01
	dc.b	nAb1, $03
	smpsPSGAlterVol     $01
	dc.b	nAb1, $01
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nBb1, $04
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, $05
	smpsPSGAlterVol     $01
	dc.b	nBb1, $02
	smpsPSGAlterVol     $01
	dc.b	nBb1, $01
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nBb1, $05
	smpsPSGAlterVol     $01
	dc.b	nBb1, $04
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, $03
	smpsPSGAlterVol     $01
	dc.b	nBb1, $01
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nAb1, $04
	smpsPSGAlterVol     $01
	dc.b	nAb1, $05
	smpsPSGAlterVol     $01
	dc.b	nAb1, $04
	smpsPSGAlterVol     $01
	dc.b	nAb1, $02
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $02
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, $01
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nAb1, $04
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, $03
	smpsPSGAlterVol     $01
	dc.b	nAb1, $01
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nBb1, $04
	smpsPSGAlterVol     $01
	dc.b	nBb1, $05
	smpsPSGAlterVol     $01
	dc.b	nBb1, $04
	smpsPSGAlterVol     $01
	dc.b	nBb1, $03
	smpsPSGAlterVol     $01
	dc.b	nBb1, $01
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nBb1, $04
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, $03
	smpsPSGAlterVol     $01
	dc.b	nBb1, $01
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, $02
	smpsPSGAlterVol     $02
	dc.b	nBb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nAb1, $04
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, $03
	smpsPSGAlterVol     $01
	dc.b	nAb1, $01
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nAb1, $05
	smpsPSGAlterVol     $01
	dc.b	nAb1, $04
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, $03
	smpsPSGAlterVol     $01
	dc.b	nAb1, $01
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nBb1, $04
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, $05
	smpsPSGAlterVol     $01
	dc.b	nBb1, $02
	smpsPSGAlterVol     $01
	dc.b	nBb1, $01
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, nRst, $09
	smpsPSGAlterVol     $F7
	dc.b	nBb1, $04
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, $03
	smpsPSGAlterVol     $01
	dc.b	nBb1, $01
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nAb1, $04
	smpsPSGAlterVol     $01
	dc.b	nAb1, $05
	smpsPSGAlterVol     $01
	dc.b	nAb1, $04
	smpsPSGAlterVol     $01
	dc.b	nAb1, $02
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, $01
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nAb1, $04
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, $03
	smpsPSGAlterVol     $01
	dc.b	nAb1, $01
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nBb1, $05
	smpsPSGAlterVol     $01
	dc.b	nBb1, $04
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, $03
	smpsPSGAlterVol     $01
	dc.b	nBb1, $01
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nBb1, $04
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, $05
	smpsPSGAlterVol     $01
	dc.b	nBb1, $02
	smpsPSGAlterVol     $01
	dc.b	nBb1, $01
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, $02
	smpsPSGAlterVol     $01
	dc.b	nBb1, $01
	smpsPSGAlterVol     $01
	dc.b	nBb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nAb1, $04
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, $05
	smpsPSGAlterVol     $01
	dc.b	nAb1, $02
	smpsPSGAlterVol     $01
	dc.b	nAb1, $01
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nAb1, $05
	smpsPSGAlterVol     $01
	dc.b	nAb1, $04
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, $03
	smpsPSGAlterVol     $02
	dc.b	nAb1, $02
	smpsPSGAlterVol     $01
	dc.b	nAb1, $01
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nBb1, $04
	smpsPSGAlterVol     $01
	dc.b	nBb1, $05
	smpsPSGAlterVol     $01
	dc.b	nBb1, $04
	smpsPSGAlterVol     $01
	dc.b	nBb1, $02
	smpsPSGAlterVol     $01
	dc.b	nBb1, $01
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, nRst, $09
	smpsPSGAlterVol     $F7
	dc.b	nBb1, $04
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, $03
	smpsPSGAlterVol     $01
	dc.b	nBb1, $01
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nAb1, $04
	smpsPSGAlterVol     $01
	dc.b	nAb1, $05
	smpsPSGAlterVol     $01
	dc.b	nAb1, $04
	smpsPSGAlterVol     $01
	dc.b	nAb1, $03
	smpsPSGAlterVol     $01
	dc.b	nAb1, $01
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nAb1, $04
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, $05
	smpsPSGAlterVol     $01
	dc.b	nAb1, $02
	smpsPSGAlterVol     $01
	dc.b	nAb1, $01
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, $02
	smpsPSGAlterVol     $02
	dc.b	nAb1, $01, nRst, $09
	smpsPSGAlterVol     $F7
	dc.b	nBb1, $04
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, $03
	smpsPSGAlterVol     $01
	dc.b	nBb1, $01
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nBb1, $04
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, $05
	smpsPSGAlterVol     $01
	dc.b	nBb1, $02
	smpsPSGAlterVol     $01
	dc.b	nBb1, $01
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, $02
	smpsPSGAlterVol     $01
	dc.b	nBb1, $01
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nAb1, $04
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, $03
	smpsPSGAlterVol     $01
	dc.b	nAb1, $01
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nAb1, $05
	smpsPSGAlterVol     $01
	dc.b	nAb1, $04
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, $03
	smpsPSGAlterVol     $01
	dc.b	nAb1, $01
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nBb1, $04
	smpsPSGAlterVol     $01
	dc.b	nBb1, $05
	smpsPSGAlterVol     $01
	dc.b	nBb1, $04
	smpsPSGAlterVol     $01
	dc.b	nBb1, $02
	smpsPSGAlterVol     $01
	dc.b	nBb1, $01
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, nRst, $09
	smpsPSGAlterVol     $F7
	dc.b	nBb1, $04
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, $05
	smpsPSGAlterVol     $01
	dc.b	nBb1, $02
	smpsPSGAlterVol     $01
	dc.b	nBb1, $01
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nAb1, $05
	smpsPSGAlterVol     $01
	dc.b	nAb1, $04
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, $02
	smpsPSGAlterVol     $01
	dc.b	nAb1, $01
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, $02
	smpsPSGAlterVol     $01
	dc.b	nAb1, $01
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nAb1, $04
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, $05
	smpsPSGAlterVol     $01
	dc.b	nAb1, $02
	smpsPSGAlterVol     $01
	dc.b	nAb1, $01
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, $02
	smpsPSGAlterVol     $01
	dc.b	nAb1, $01
	smpsPSGAlterVol     $01
	dc.b	nAb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nBb1, $04
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, $03
	smpsPSGAlterVol     $01
	dc.b	nBb1, $01
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nBb1, $04
	smpsPSGAlterVol     $01
	dc.b	nBb1, $05
	smpsPSGAlterVol     $01
	dc.b	nBb1, $04
	smpsPSGAlterVol     $01
	dc.b	nBb1, $03
	smpsPSGAlterVol     $01
	dc.b	nBb1, $01
	smpsPSGAlterVol     $02
	dc.b	nBb1, $02
	smpsPSGAlterVol     $01
	dc.b	nBb1, $01
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nAb1, $04
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, $03
	smpsPSGAlterVol     $01
	dc.b	nAb1, $01
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nAb1, $04
	smpsPSGAlterVol     $01
	dc.b	nAb1, $05
	smpsPSGAlterVol     $01
	dc.b	nAb1, $04
	smpsPSGAlterVol     $01
	dc.b	nAb1, $03
	smpsPSGAlterVol     $01
	dc.b	nAb1, $01
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nFs1, $04
	smpsPSGAlterVol     $01
	dc.b	nFs1, $05
	smpsPSGAlterVol     $01
	dc.b	nFs1, $04
	smpsPSGAlterVol     $01
	dc.b	nFs1, $02
	smpsPSGAlterVol     $01
	dc.b	nFs1, $01
	smpsPSGAlterVol     $01
	dc.b	nFs1
	smpsPSGAlterVol     $01
	dc.b	nFs1
	smpsPSGAlterVol     $01
	dc.b	nFs1, $02
	smpsPSGAlterVol     $02
	dc.b	nFs1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nFs1, $04
	smpsPSGAlterVol     $01
	dc.b	nFs1
	smpsPSGAlterVol     $01
	dc.b	nFs1, $05
	smpsPSGAlterVol     $01
	dc.b	nFs1, $04
	smpsPSGAlterVol     $01
	dc.b	nFs1
	smpsPSGAlterVol     $01
	dc.b	nFs1
	smpsPSGAlterVol     $01
	dc.b	nFs1
	smpsPSGAlterVol     $FA
	dc.b	nFs1, $05
	smpsPSGAlterVol     $01
	dc.b	nFs1, $04
	smpsPSGAlterVol     $01
	dc.b	nFs1
	smpsPSGAlterVol     $01
	dc.b	nFs1, $02
	smpsPSGAlterVol     $FD
	dc.b	nG1, $04
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1, $05
	smpsPSGAlterVol     $01
	dc.b	nG1, $02
	smpsPSGAlterVol     $FD
	dc.b	nFs1, $04
	smpsPSGAlterVol     $01
	dc.b	nFs1
	smpsPSGAlterVol     $01
	dc.b	nFs1, $05
	smpsPSGAlterVol     $01
	dc.b	nFs1, $02
	smpsPSGAlterVol     $FD
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, $05
	smpsPSGAlterVol     $01
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $FA
	dc.b	nD1, $05
	smpsPSGAlterVol     $01
	dc.b	nD1, $04
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, $05
	smpsPSGAlterVol     $01
	dc.b	nD1, $04
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $FA
	dc.b	nC1
	smpsPSGAlterVol     $01
	dc.b	nC1, $05
	smpsPSGAlterVol     $01
	dc.b	nC1, $04
	smpsPSGAlterVol     $01
	dc.b	nC1
	smpsPSGAlterVol     $01
	dc.b	nC1
	smpsPSGAlterVol     $01
	dc.b	nC1, $05
	smpsPSGAlterVol     $01
	dc.b	nC1, $04
	smpsPSGAlterVol     $FA
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, $05
	smpsPSGAlterVol     $01
	dc.b	nAb1, $04
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1
	smpsPSGAlterVol     $FA
	dc.b	nE2
	smpsPSGAlterVol     $01
	dc.b	nE2, $05
	smpsPSGAlterVol     $01
	dc.b	nE2, $04
	smpsPSGAlterVol     $01
	dc.b	nE2
	smpsPSGAlterVol     $01
	dc.b	nE2
	smpsPSGAlterVol     $01
	dc.b	nE2, $05
	smpsPSGAlterVol     $01
	dc.b	nE2, $04
	smpsPSGAlterVol     $01
	dc.b	nE2
	smpsPSGAlterVol     $01
	dc.b	nE2
	smpsPSGAlterVol     $01
	dc.b	nE2, $05, nRst, $11
	smpsPSGAlterVol     $F2
	smpsJump            COI2_PSG1

; PSG2 Data
COI2_PSG2:
	dc.b	nRst, $0F
	smpsPSGAlterVol     $05
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, $03
	smpsPSGAlterVol     $01
	dc.b	nE1, $01
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1, $05
	smpsPSGAlterVol     $01
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1, $02
	smpsPSGAlterVol     $01
	dc.b	nE1, $01
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, $02
	smpsPSGAlterVol     $01
	dc.b	nE1, $01
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nD1, $04
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, $05
	smpsPSGAlterVol     $01
	dc.b	nD1, $02
	smpsPSGAlterVol     $01
	dc.b	nD1, $01
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nD1, $05
	smpsPSGAlterVol     $01
	dc.b	nD1, $04
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, $03
	smpsPSGAlterVol     $01
	dc.b	nD1, $01
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1, $05
	smpsPSGAlterVol     $01
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1, $02
	smpsPSGAlterVol     $01
	dc.b	nE1, $01
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, $02, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, $03
	smpsPSGAlterVol     $01
	dc.b	nE1, $01
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nD1, $05
	smpsPSGAlterVol     $01
	dc.b	nD1, $04
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, $03
	smpsPSGAlterVol     $01
	dc.b	nD1, $01
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nD1, $04
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, $05
	smpsPSGAlterVol     $01
	dc.b	nD1, $02
	smpsPSGAlterVol     $01
	dc.b	nD1, $01
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, $02
	smpsPSGAlterVol     $01
	dc.b	nD1, $01
	smpsPSGAlterVol     $01
	dc.b	nD1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, $03
	smpsPSGAlterVol     $01
	dc.b	nE1, $01
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1, $05
	smpsPSGAlterVol     $01
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1, $03
	smpsPSGAlterVol     $02
	dc.b	nE1, $01
	smpsPSGAlterVol     $01
	dc.b	nE1, $02
	smpsPSGAlterVol     $01
	dc.b	nE1, $01
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nD1, $04
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, $05
	smpsPSGAlterVol     $01
	dc.b	nD1, $02
	smpsPSGAlterVol     $01
	dc.b	nD1, $01
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, nRst, $09
	smpsPSGAlterVol     $F7
	dc.b	nD1, $04
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, $03
	smpsPSGAlterVol     $01
	dc.b	nD1, $01
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1, $05
	smpsPSGAlterVol     $01
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1, $02
	smpsPSGAlterVol     $01
	dc.b	nE1, $01
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, $02
	smpsPSGAlterVol     $01
	dc.b	nE1, $01
	smpsPSGAlterVol     $02
	dc.b	nE1, $02, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, $05
	smpsPSGAlterVol     $01
	dc.b	nE1, $02
	smpsPSGAlterVol     $01
	dc.b	nE1, $01
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nD1, $05
	smpsPSGAlterVol     $01
	dc.b	nD1, $04
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, $03
	smpsPSGAlterVol     $01
	dc.b	nD1, $01
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nD1, $04
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, $05
	smpsPSGAlterVol     $01
	dc.b	nD1, $02
	smpsPSGAlterVol     $01
	dc.b	nD1, $01
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, $02
	smpsPSGAlterVol     $01
	dc.b	nD1, $01
	smpsPSGAlterVol     $01
	dc.b	nD1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, $03
	smpsPSGAlterVol     $01
	dc.b	nE1, $01
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1, $05
	smpsPSGAlterVol     $01
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1, $03
	smpsPSGAlterVol     $01
	dc.b	nE1, $01
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nD1, $04
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, $03
	smpsPSGAlterVol     $01
	dc.b	nD1, $01
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, nRst, $09
	smpsPSGAlterVol     $F7
	dc.b	nD1, $04
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, $03
	smpsPSGAlterVol     $01
	dc.b	nD1, $01
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1, $05
	smpsPSGAlterVol     $01
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1, $02
	smpsPSGAlterVol     $01
	dc.b	nE1, $01
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, $02
	smpsPSGAlterVol     $01
	dc.b	nE1, $01
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, $05
	smpsPSGAlterVol     $01
	dc.b	nE1, $02
	smpsPSGAlterVol     $01
	dc.b	nE1, $01
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nD1, $05
	smpsPSGAlterVol     $01
	dc.b	nD1, $04
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, $03
	smpsPSGAlterVol     $02
	dc.b	nD1, $02
	smpsPSGAlterVol     $01
	dc.b	nD1, $01
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nD1, $04
	smpsPSGAlterVol     $01
	dc.b	nD1, $05
	smpsPSGAlterVol     $01
	dc.b	nD1, $04
	smpsPSGAlterVol     $01
	dc.b	nD1, $02
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $02
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, $01
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, $03
	smpsPSGAlterVol     $01
	dc.b	nE1, $01
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nE1, $05
	smpsPSGAlterVol     $01
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, $03
	smpsPSGAlterVol     $01
	dc.b	nE1, $01
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nD1, $04
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, $03
	smpsPSGAlterVol     $01
	dc.b	nD1, $01
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, $02
	smpsPSGAlterVol     $02
	dc.b	nD1, $01, nRst, $09
	smpsPSGAlterVol     $F7
	dc.b	nD1, $04
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, $03
	smpsPSGAlterVol     $01
	dc.b	nD1, $01
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1, $05
	smpsPSGAlterVol     $01
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1, $03
	smpsPSGAlterVol     $02
	dc.b	nE1, $01
	smpsPSGAlterVol     $01
	dc.b	nE1, $02
	smpsPSGAlterVol     $01
	dc.b	nE1, $01
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, $05
	smpsPSGAlterVol     $01
	dc.b	nE1, $02
	smpsPSGAlterVol     $01
	dc.b	nE1, $01
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, nRst, $09
	smpsPSGAlterVol     $F7
	dc.b	nD1, $04
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, $03
	smpsPSGAlterVol     $01
	dc.b	nD1, $01
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nD1, $04
	smpsPSGAlterVol     $01
	dc.b	nD1, $05
	smpsPSGAlterVol     $01
	dc.b	nD1, $04
	smpsPSGAlterVol     $01
	dc.b	nD1, $03
	smpsPSGAlterVol     $01
	dc.b	nD1, $01
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, $03
	smpsPSGAlterVol     $01
	dc.b	nE1, $01
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nE1, $05
	smpsPSGAlterVol     $01
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, $03
	smpsPSGAlterVol     $01
	dc.b	nE1, $01
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nD1, $04
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, $05
	smpsPSGAlterVol     $01
	dc.b	nD1, $02
	smpsPSGAlterVol     $01
	dc.b	nD1, $01
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, $02
	smpsPSGAlterVol     $01
	dc.b	nD1, $01
	smpsPSGAlterVol     $01
	dc.b	nD1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nD1, $04
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, $03
	smpsPSGAlterVol     $01
	dc.b	nD1, $01
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nC1, $04
	smpsPSGAlterVol     $01
	dc.b	nC1, $05
	smpsPSGAlterVol     $01
	dc.b	nC1, $04
	smpsPSGAlterVol     $01
	dc.b	nC1, $03
	smpsPSGAlterVol     $02
	dc.b	nC1, $01
	smpsPSGAlterVol     $01
	dc.b	nC1, $02
	smpsPSGAlterVol     $01
	dc.b	nC1, $01
	smpsPSGAlterVol     $01
	dc.b	nC1
	smpsPSGAlterVol     $01
	dc.b	nC1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nC1, $04
	smpsPSGAlterVol     $01
	dc.b	nC1
	smpsPSGAlterVol     $01
	dc.b	nC1, $05
	smpsPSGAlterVol     $01
	dc.b	nC1, $04
	smpsPSGAlterVol     $01
	dc.b	nC1
	smpsPSGAlterVol     $01
	dc.b	nC1
	smpsPSGAlterVol     $01
	dc.b	nC1
	smpsPSGAlterVol     $FA
	dc.b	nC1, $05
	smpsPSGAlterVol     $01
	dc.b	nC1, $04
	smpsPSGAlterVol     $01
	dc.b	nC1
	smpsPSGAlterVol     $01
	dc.b	nC1, $02
	smpsPSGAlterVol     $FD
	dc.b	nC1, $04
	smpsPSGAlterVol     $01
	dc.b	nC1, $05
	smpsPSGAlterVol     $01
	dc.b	nC1, $04
	smpsPSGAlterVol     $01
	dc.b	nC1
	smpsPSGAlterVol     $01
	dc.b	nC1
	smpsPSGAlterVol     $01
	dc.b	nC1, $05
	smpsPSGAlterVol     $01
	dc.b	nC1, $04
	smpsPSGAlterVol     $FA
	dc.b	nBb0
	smpsPSGAlterVol     $01
	dc.b	nBb0, $05
	smpsPSGAlterVol     $01
	dc.b	nBb0, $04
	smpsPSGAlterVol     $01
	dc.b	nBb0
	smpsPSGAlterVol     $01
	dc.b	nBb0
	smpsPSGAlterVol     $01
	dc.b	nBb0, $05
	smpsPSGAlterVol     $01
	dc.b	nBb0, $04
	smpsPSGAlterVol     $01
	dc.b	nBb0
	smpsPSGAlterVol     $01
	dc.b	nBb0
	smpsPSGAlterVol     $01
	dc.b	nBb0, $05, nRst, $10
	smpsPSGAlterVol     $F7
	dc.b	nAb0, $04
	smpsPSGAlterVol     $01
	dc.b	nAb0, $05
	smpsPSGAlterVol     $01
	dc.b	nAb0, $04
	smpsPSGAlterVol     $01
	dc.b	nAb0
	smpsPSGAlterVol     $01
	dc.b	nAb0, $05
	smpsPSGAlterVol     $01
	dc.b	nAb0, $04
	smpsPSGAlterVol     $01
	dc.b	nAb0
	smpsPSGAlterVol     $FA
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, $05
	smpsPSGAlterVol     $01
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, $05
	smpsPSGAlterVol     $01
	dc.b	nE1, $01
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, nRst, $0B
	smpsPSGAlterVol     $F7
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1, $05
	smpsPSGAlterVol     $01
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1, $03
	smpsPSGAlterVol     $01
	dc.b	nE1, $01
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, $05
	smpsPSGAlterVol     $01
	dc.b	nE1, $02
	smpsPSGAlterVol     $01
	dc.b	nE1, $01
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, nRst, $09
	smpsPSGAlterVol     $F7
	dc.b	nD1, $04
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, $03
	smpsPSGAlterVol     $01
	dc.b	nD1, $01
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nD1, $04
	smpsPSGAlterVol     $01
	dc.b	nD1, $05
	smpsPSGAlterVol     $01
	dc.b	nD1, $04
	smpsPSGAlterVol     $01
	dc.b	nD1, $03
	smpsPSGAlterVol     $01
	dc.b	nD1, $01
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, $05
	smpsPSGAlterVol     $01
	dc.b	nE1, $02
	smpsPSGAlterVol     $01
	dc.b	nE1, $01
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, nRst, $09
	smpsPSGAlterVol     $F7
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, $03
	smpsPSGAlterVol     $01
	dc.b	nE1, $01
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nD1, $04
	smpsPSGAlterVol     $01
	dc.b	nD1, $05
	smpsPSGAlterVol     $01
	dc.b	nD1, $04
	smpsPSGAlterVol     $01
	dc.b	nD1, $02
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $02
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, $01
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nD1, $04
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, $03
	smpsPSGAlterVol     $01
	dc.b	nD1, $01
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1, $05
	smpsPSGAlterVol     $01
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1, $03
	smpsPSGAlterVol     $01
	dc.b	nE1, $01
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, $03
	smpsPSGAlterVol     $01
	dc.b	nE1, $01
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, $02
	smpsPSGAlterVol     $02
	dc.b	nE1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nD1, $04
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, $03
	smpsPSGAlterVol     $01
	dc.b	nD1, $01
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nD1, $05
	smpsPSGAlterVol     $01
	dc.b	nD1, $04
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, $03
	smpsPSGAlterVol     $01
	dc.b	nD1, $01
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, $05
	smpsPSGAlterVol     $01
	dc.b	nE1, $02
	smpsPSGAlterVol     $01
	dc.b	nE1, $01
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, nRst, $09
	smpsPSGAlterVol     $F7
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, $03
	smpsPSGAlterVol     $01
	dc.b	nE1, $01
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nD1, $04
	smpsPSGAlterVol     $01
	dc.b	nD1, $05
	smpsPSGAlterVol     $01
	dc.b	nD1, $04
	smpsPSGAlterVol     $01
	dc.b	nD1, $03
	smpsPSGAlterVol     $01
	dc.b	nD1, $01
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nD1, $04
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, $03
	smpsPSGAlterVol     $01
	dc.b	nD1, $01
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, nRst, $09
	smpsPSGAlterVol     $F7
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, $03
	smpsPSGAlterVol     $01
	dc.b	nE1, $01
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, $05
	smpsPSGAlterVol     $01
	dc.b	nE1, $02
	smpsPSGAlterVol     $01
	dc.b	nE1, $01
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, $02
	smpsPSGAlterVol     $01
	dc.b	nE1, $01
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nD1, $04
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, $05
	smpsPSGAlterVol     $01
	dc.b	nD1, $02
	smpsPSGAlterVol     $01
	dc.b	nD1, $01
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nD1, $05
	smpsPSGAlterVol     $01
	dc.b	nD1, $04
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, $03
	smpsPSGAlterVol     $02
	dc.b	nD1, $02
	smpsPSGAlterVol     $01
	dc.b	nD1, $01
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1, $05
	smpsPSGAlterVol     $01
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1, $02
	smpsPSGAlterVol     $01
	dc.b	nE1, $01
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, nRst, $09
	smpsPSGAlterVol     $F7
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, $03
	smpsPSGAlterVol     $01
	dc.b	nE1, $01
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nD1, $04
	smpsPSGAlterVol     $01
	dc.b	nD1, $05
	smpsPSGAlterVol     $01
	dc.b	nD1, $04
	smpsPSGAlterVol     $01
	dc.b	nD1, $03
	smpsPSGAlterVol     $01
	dc.b	nD1, $01
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nD1, $04
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, $05
	smpsPSGAlterVol     $01
	dc.b	nD1, $02
	smpsPSGAlterVol     $01
	dc.b	nD1, $01
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, $02
	smpsPSGAlterVol     $01
	dc.b	nD1, $01, nRst, $09
	smpsPSGAlterVol     $F8
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, $03
	smpsPSGAlterVol     $01
	dc.b	nE1, $01
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, $05
	smpsPSGAlterVol     $01
	dc.b	nE1, $02
	smpsPSGAlterVol     $01
	dc.b	nE1, $01
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, $02
	smpsPSGAlterVol     $01
	dc.b	nE1, $01
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nD1, $04
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, $03
	smpsPSGAlterVol     $01
	dc.b	nD1, $01
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nD1, $05
	smpsPSGAlterVol     $01
	dc.b	nD1, $04
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, $03
	smpsPSGAlterVol     $01
	dc.b	nD1, $01
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1, $05
	smpsPSGAlterVol     $01
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1, $02
	smpsPSGAlterVol     $01
	dc.b	nE1, $01
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, $02, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, $05
	smpsPSGAlterVol     $01
	dc.b	nE1, $02
	smpsPSGAlterVol     $01
	dc.b	nE1, $01
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nD1, $05
	smpsPSGAlterVol     $01
	dc.b	nD1, $04
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, $02
	smpsPSGAlterVol     $01
	dc.b	nD1, $01
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, $02
	smpsPSGAlterVol     $01
	dc.b	nD1, $01
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nD1, $04
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, $05
	smpsPSGAlterVol     $01
	dc.b	nD1, $02
	smpsPSGAlterVol     $01
	dc.b	nD1, $01
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, $02
	smpsPSGAlterVol     $01
	dc.b	nD1, $01
	smpsPSGAlterVol     $01
	dc.b	nD1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, $03
	smpsPSGAlterVol     $01
	dc.b	nE1, $01
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1, $05
	smpsPSGAlterVol     $01
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1, $03
	smpsPSGAlterVol     $01
	dc.b	nE1, $01
	smpsPSGAlterVol     $02
	dc.b	nE1, $02
	smpsPSGAlterVol     $01
	dc.b	nE1, $01
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nD1, $04
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, $03
	smpsPSGAlterVol     $01
	dc.b	nD1, $01
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nD1, $04
	smpsPSGAlterVol     $01
	dc.b	nD1, $05
	smpsPSGAlterVol     $01
	dc.b	nD1, $04
	smpsPSGAlterVol     $01
	dc.b	nD1, $03
	smpsPSGAlterVol     $01
	dc.b	nD1, $01
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nC1, $04
	smpsPSGAlterVol     $01
	dc.b	nC1, $05
	smpsPSGAlterVol     $01
	dc.b	nC1, $04
	smpsPSGAlterVol     $01
	dc.b	nC1, $02
	smpsPSGAlterVol     $01
	dc.b	nC1, $01
	smpsPSGAlterVol     $01
	dc.b	nC1
	smpsPSGAlterVol     $01
	dc.b	nC1, $02
	smpsPSGAlterVol     $01
	dc.b	nC1, $01
	smpsPSGAlterVol     $02
	dc.b	nC1, $02, nRst, $08
	smpsPSGAlterVol     $F7
	dc.b	nC1, $04
	smpsPSGAlterVol     $01
	dc.b	nC1
	smpsPSGAlterVol     $01
	dc.b	nC1, $05
	smpsPSGAlterVol     $01
	dc.b	nC1, $04
	smpsPSGAlterVol     $01
	dc.b	nC1
	smpsPSGAlterVol     $01
	dc.b	nC1
	smpsPSGAlterVol     $01
	dc.b	nC1
	smpsPSGAlterVol     $FA
	dc.b	nC1, $05
	smpsPSGAlterVol     $01
	dc.b	nC1, $04
	smpsPSGAlterVol     $01
	dc.b	nC1
	smpsPSGAlterVol     $01
	dc.b	nC1, $02
	smpsPSGAlterVol     $FD
	dc.b	nC1, $04
	smpsPSGAlterVol     $01
	dc.b	nC1
	smpsPSGAlterVol     $01
	dc.b	nC1, $05
	smpsPSGAlterVol     $01
	dc.b	nC1, $04
	smpsPSGAlterVol     $01
	dc.b	nC1
	smpsPSGAlterVol     $01
	dc.b	nC1
	smpsPSGAlterVol     $01
	dc.b	nC1, $05
	smpsPSGAlterVol     $FA
	dc.b	nBb0, $04
	smpsPSGAlterVol     $01
	dc.b	nBb0
	smpsPSGAlterVol     $01
	dc.b	nBb0, $05
	smpsPSGAlterVol     $01
	dc.b	nBb0, $04
	smpsPSGAlterVol     $01
	dc.b	nBb0
	smpsPSGAlterVol     $01
	dc.b	nBb0
	smpsPSGAlterVol     $01
	dc.b	nBb0, $05
	smpsPSGAlterVol     $01
	dc.b	nBb0, $04
	smpsPSGAlterVol     $01
	dc.b	nBb0
	smpsPSGAlterVol     $01
	dc.b	nBb0, nRst, $11
	smpsPSGAlterVol     $F7
	dc.b	nAb0, $04
	smpsPSGAlterVol     $01
	dc.b	nAb0, $05
	smpsPSGAlterVol     $01
	dc.b	nAb0, $04
	smpsPSGAlterVol     $01
	dc.b	nAb0
	smpsPSGAlterVol     $01
	dc.b	nAb0
	smpsPSGAlterVol     $01
	dc.b	nAb0, $05
	smpsPSGAlterVol     $01
	dc.b	nAb0, $04
	smpsPSGAlterVol     $FA
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, $05
	smpsPSGAlterVol     $01
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $FA
	dc.b	nBb1, $05
	smpsPSGAlterVol     $01
	dc.b	nBb1, $04
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, $05
	smpsPSGAlterVol     $01
	dc.b	nBb1, $04
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, $05, nRst, $11
	smpsPSGAlterVol     $F2
	smpsJump            COI2_PSG2

COI2_Voices:
;	Voice $00
;	$3C
;	$01, $02, $01, $01, 	$1F, $10, $1F, $10, 	$00, $08, $00, $08
;	$00, $00, $00, $00, 	$FF, $FF, $FF, $FF, 	$7F, $00, $7F, $00
	smpsVcAlgorithm     $04
	smpsVcFeedback      $07
	smpsVcUnusedBits    $00
	smpsVcDetune        $00, $00, $00, $00
	smpsVcCoarseFreq    $01, $01, $02, $01
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $10, $1F, $10, $1F
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $08, $00, $08, $00
	smpsVcDecayRate2    $00, $00, $00, $00
	smpsVcDecayLevel    $0F, $0F, $0F, $0F
	smpsVcReleaseRate   $0F, $0F, $0F, $0F
	smpsVcTotalLevel    $00, $7F, $00, $7F

;	Voice $01
;	$3E
;	$02, $03, $02, $01, 	$03, $09, $13, $16, 	$03, $02, $02, $02
;	$05, $07, $09, $0B, 	$CA, $3A, $3A, $3A, 	$16, $05, $02, $00
	smpsVcAlgorithm     $06
	smpsVcFeedback      $07
	smpsVcUnusedBits    $00
	smpsVcDetune        $00, $00, $00, $00
	smpsVcCoarseFreq    $01, $02, $03, $02
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $16, $13, $09, $03
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $02, $02, $02, $03
	smpsVcDecayRate2    $0B, $09, $07, $05
	smpsVcDecayLevel    $03, $03, $03, $0C
	smpsVcReleaseRate   $0A, $0A, $0A, $0A
	smpsVcTotalLevel    $00, $02, $05, $16

;	Voice $02
;	$39
;	$02, $00, $71, $30, 	$5F, $98, $5F, $9F, 	$0C, $05, $07, $0C
;	$10, $03, $03, $06, 	$FF, $FF, $FF, $FF, 	$7F, $7F, $7F, $00
	smpsVcAlgorithm     $01
	smpsVcFeedback      $07
	smpsVcUnusedBits    $00
	smpsVcDetune        $03, $07, $00, $00
	smpsVcCoarseFreq    $00, $01, $00, $02
	smpsVcRateScale     $02, $01, $02, $01
	smpsVcAttackRate    $1F, $1F, $18, $1F
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $0C, $07, $05, $0C
	smpsVcDecayRate2    $06, $03, $03, $10
	smpsVcDecayLevel    $0F, $0F, $0F, $0F
	smpsVcReleaseRate   $0F, $0F, $0F, $0F
	smpsVcTotalLevel    $00, $7F, $7F, $7F

;	Voice $03
;	$3A
;	$51, $25, $51, $11, 	$5F, $56, $5D, $9F, 	$09, $00, $00, $0A
;	$0B, $08, $08, $07, 	$FF, $FF, $FF, $FF, 	$7F, $7F, $7F, $00
	smpsVcAlgorithm     $02
	smpsVcFeedback      $07
	smpsVcUnusedBits    $00
	smpsVcDetune        $01, $05, $02, $05
	smpsVcCoarseFreq    $01, $01, $05, $01
	smpsVcRateScale     $02, $01, $01, $01
	smpsVcAttackRate    $1F, $1D, $16, $1F
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $0A, $00, $00, $09
	smpsVcDecayRate2    $07, $08, $08, $0B
	smpsVcDecayLevel    $0F, $0F, $0F, $0F
	smpsVcReleaseRate   $0F, $0F, $0F, $0F
	smpsVcTotalLevel    $00, $7F, $7F, $7F

;	Voice $04
;	$3C
;	$01, $51, $02, $01, 	$90, $96, $DE, $D9, 	$1F, $0B, $0D, $12
;	$06, $05, $0C, $06, 	$09, $78, $49, $28, 	$1F, $00, $1D, $0A
	smpsVcAlgorithm     $04
	smpsVcFeedback      $07
	smpsVcUnusedBits    $00
	smpsVcDetune        $00, $00, $05, $00
	smpsVcCoarseFreq    $01, $02, $01, $01
	smpsVcRateScale     $03, $03, $02, $02
	smpsVcAttackRate    $19, $1E, $16, $10
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $12, $0D, $0B, $1F
	smpsVcDecayRate2    $06, $0C, $05, $06
	smpsVcDecayLevel    $02, $04, $07, $00
	smpsVcReleaseRate   $08, $09, $08, $09
	smpsVcTotalLevel    $0A, $1D, $00, $1F

;	Voice $05
;	$33
;	$01, $02, $01, $00, 	$16, $13, $1F, $16, 	$11, $0B, $0C, $0C
;	$0E, $00, $0F, $10, 	$99, $06, $56, $96, 	$1F, $0F, $2A, $00
	smpsVcAlgorithm     $03
	smpsVcFeedback      $06
	smpsVcUnusedBits    $00
	smpsVcDetune        $00, $00, $00, $00
	smpsVcCoarseFreq    $00, $01, $02, $01
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $16, $1F, $13, $16
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $0C, $0C, $0B, $11
	smpsVcDecayRate2    $10, $0F, $00, $0E
	smpsVcDecayLevel    $09, $05, $00, $09
	smpsVcReleaseRate   $06, $06, $06, $09
	smpsVcTotalLevel    $00, $2A, $0F, $1F

;	Voice $06
;	$3C
;	$01, $02, $01, $01, 	$1F, $10, $1F, $10, 	$00, $08, $00, $08
;	$00, $00, $00, $00, 	$09, $29, $09, $19, 	$1D, $00, $1E, $00
	smpsVcAlgorithm     $04
	smpsVcFeedback      $07
	smpsVcUnusedBits    $00
	smpsVcDetune        $00, $00, $00, $00
	smpsVcCoarseFreq    $01, $01, $02, $01
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $10, $1F, $10, $1F
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $08, $00, $08, $00
	smpsVcDecayRate2    $00, $00, $00, $00
	smpsVcDecayLevel    $01, $00, $02, $00
	smpsVcReleaseRate   $09, $09, $09, $09
	smpsVcTotalLevel    $00, $1E, $00, $1D

;	Voice $07
;	$3A
;	$42, $45, $41, $41, 	$53, $1F, $1F, $50, 	$12, $11, $14, $1F
;	$00, $00, $00, $00, 	$2C, $3C, $1C, $0B, 	$29, $14, $35, $00
	smpsVcAlgorithm     $02
	smpsVcFeedback      $07
	smpsVcUnusedBits    $00
	smpsVcDetune        $04, $04, $04, $04
	smpsVcCoarseFreq    $01, $01, $05, $02
	smpsVcRateScale     $01, $00, $00, $01
	smpsVcAttackRate    $10, $1F, $1F, $13
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $1F, $14, $11, $12
	smpsVcDecayRate2    $00, $00, $00, $00
	smpsVcDecayLevel    $00, $01, $03, $02
	smpsVcReleaseRate   $0B, $0C, $0C, $0C
	smpsVcTotalLevel    $00, $35, $14, $29

;	Voice $08
;	$3E
;	$02, $03, $02, $01, 	$03, $09, $13, $16, 	$03, $02, $02, $02
;	$05, $07, $09, $0B, 	$FF, $FF, $FF, $FF, 	$16, $05, $02, $00
	smpsVcAlgorithm     $06
	smpsVcFeedback      $07
	smpsVcUnusedBits    $00
	smpsVcDetune        $00, $00, $00, $00
	smpsVcCoarseFreq    $01, $02, $03, $02
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $16, $13, $09, $03
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $02, $02, $02, $03
	smpsVcDecayRate2    $0B, $09, $07, $05
	smpsVcDecayLevel    $0F, $0F, $0F, $0F
	smpsVcReleaseRate   $0F, $0F, $0F, $0F
	smpsVcTotalLevel    $00, $02, $05, $16

