Ristar_Header:
	smpsHeaderStartSong 1
	smpsHeaderVoice     Ristar_Voices
	smpsHeaderChan      $07, $03
	smpsHeaderTempo     $01, $00

	smpsHeaderDAC       Ristar_DAC,	$00, $F2

; DAC Data
Ristar_DAC:
    dc.b  dSnare, $30, dKick, $30, dSnareDrum, $30, dHiTimpani, $30, dMidTimpani, $30, dLowTimpani
	smpsJump            Ristar_DAC

Ristar_Voices:
;	Voice $00
;	$00
;	$00, $00, $00, $00, 	$00, $00, $00, $00, 	$00, $00, $00, $00
;	$00, $00, $00, $00, 	$00, $00, $00, $00, 	$7F, $7F, $7F, $00
	smpsVcAlgorithm     $00
	smpsVcFeedback      $00
	smpsVcUnusedBits    $00
	smpsVcDetune        $00, $00, $00, $00
	smpsVcCoarseFreq    $00, $00, $00, $00
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $00, $00, $00, $00
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $00, $00, $00, $00
	smpsVcDecayRate2    $00, $00, $00, $00
	smpsVcDecayLevel    $00, $00, $00, $00
	smpsVcReleaseRate   $00, $00, $00, $00
	smpsVcTotalLevel    $00, $7F, $7F, $7F

;	Voice $01
;	$3B
;	$72, $31, $71, $32, 	$1F, $19, $51, $4F, 	$06, $07, $08, $01
;	$01, $00, $01, $00, 	$25, $96, $1A, $17, 	$26, $1B, $1B, $00
	smpsVcAlgorithm     $03
	smpsVcFeedback      $07
	smpsVcUnusedBits    $00
	smpsVcDetune        $03, $07, $03, $07
	smpsVcCoarseFreq    $02, $01, $01, $02
	smpsVcRateScale     $01, $01, $00, $00
	smpsVcAttackRate    $0F, $11, $19, $1F
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $01, $08, $07, $06
	smpsVcDecayRate2    $00, $01, $00, $01
	smpsVcDecayLevel    $01, $01, $09, $02
	smpsVcReleaseRate   $07, $0A, $06, $05
	smpsVcTotalLevel    $00, $1B, $1B, $26

;	Voice $02
;	$19
;	$51, $12, $42, $00, 	$5F, $5F, $9B, $53, 	$01, $02, $01, $01
;	$01, $02, $04, $06, 	$57, $57, $37, $37, 	$2C, $24, $30, $00
	smpsVcAlgorithm     $01
	smpsVcFeedback      $03
	smpsVcUnusedBits    $00
	smpsVcDetune        $00, $04, $01, $05
	smpsVcCoarseFreq    $00, $02, $02, $01
	smpsVcRateScale     $01, $02, $01, $01
	smpsVcAttackRate    $13, $1B, $1F, $1F
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $01, $01, $02, $01
	smpsVcDecayRate2    $06, $04, $02, $01
	smpsVcDecayLevel    $03, $03, $05, $05
	smpsVcReleaseRate   $07, $07, $07, $07
	smpsVcTotalLevel    $00, $30, $24, $2C

