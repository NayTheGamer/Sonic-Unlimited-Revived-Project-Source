SongA_Header:
	smpsHeaderStartSong 1
	smpsHeaderVoice     SongA_Voices
	smpsHeaderChan      $04, $03
	smpsHeaderTempo     $02, $00

	smpsHeaderDAC       SongA_DAC
	smpsHeaderFM        SongA_FM1,	$00, $0C
	smpsHeaderFM        SongA_FM2,	$00, $10
	smpsHeaderFM        SongA_FM3,	$00, $0C
	smpsHeaderPSG       SongA_PSG1,	$00, $00, $00, $00
	smpsHeaderPSG       SongA_PSG2,	$00, $00, $00, $00
	smpsHeaderPSG       SongA_PSG3,	$00, $02, $00, fTone_02

; DAC Data
SongA_DAC:
	smpsPan             panCenter, $00
	dc.b	dKick, $06, $84, $06, dSnareDrum, $06, $84, $03, $84, $03, dKick, $03
	dc.b	$84, $03, $84, $06, dSnareDrum, $06, $84, $06, dKick, $06, $84, $06
	dc.b	dSnareDrum, $06, $84, $03, $84, $03, dKick, $03, $84, $03, $84, $06
	dc.b	dSnareDrum, $06, $84, $06, dKick, $06, $84, $06, dSnareDrum, $06, $84, $03
	dc.b	$84, $03, dKick, $03, $84, $03, $84, $06, dSnareDrum, $06, $84, $06
	dc.b	dKick, $06, $84, $06, dSnareDrum, $06, $84, $03, $84, $03, dKick, $03
	dc.b	$84, $03, $84, $06, dSnareDrum, $06, $84, $06, dKick, $06, $84, $06
	dc.b	dSnareDrum, $06, $84, $03, $84, $03, dKick, $03, $84, $03, $84, $06
	dc.b	dSnareDrum, $06, $84, $06, dKick, $06, $84, $06, dSnareDrum, $06, $84, $03
	dc.b	$84, $03, dKick, $03, $84, $03, $84, $06, dSnareDrum, $06, $84, $06
	dc.b	dKick, $06, $84, $06, dSnareDrum, $06, $84, $03, $84, $03, dKick, $03
	dc.b	$84, $03, $84, $06, dSnareDrum, $06, $84, $06, dKick, $06, $84, $06
	dc.b	dSnareDrum, $06, $84, $03, $84, $03, dKick, $03, $84, $03, $84, $06
	dc.b	dSnareDrum, $06, $84, $06, $85, $06, $84, $06, dKick, $06, $84, $03
	dc.b	$84, $03, dSnareDrum, $03, $84, $03, $84, $06, dKick, $06, $84, $06
	dc.b	dSnareDrum, $06, $84, $06, dKick, $06, $84, $03, $84, $03, dSnareDrum, $03
	dc.b	$84, $03, $84, $06, dKick, $06, $84, $06, dSnareDrum, $06, $84, $06
	dc.b	dKick, $06, $84, $03, $84, $03, dSnareDrum, $03, $84, $03, $84, $06
	dc.b	dKick, $06, $84, $06, dSnareDrum, $06, $84, $06, dKick, $06, $84, $03
	dc.b	$84, $03, dSnareDrum, $03, $84, $03, $84, $06, dKick, $06, $84, $06
	dc.b	dSnareDrum, $06, $84, $06, dKick, $06, $84, $03, $84, $03, dSnareDrum, $03
	dc.b	$84, $03, $84, $06, dKick, $06, $84, $06, dSnareDrum, $06, $84, $06
	dc.b	dKick, $06, $84, $03, $84, $03, dSnareDrum, $03, $84, $03, $84, $06
	dc.b	dKick, $06, $84, $06, dSnareDrum, $06, $84, $06, dKick, $06, $84, $03
	dc.b	$84, $03, dSnareDrum, $03, $84, $03, $84, $06, dKick, $06, $84, $06
	dc.b	dSnareDrum, $06, $84, $06, dKick, $06, $84, $03, $84, $03, dSnare, $03
	dc.b	$84, $03, $84, $06, dSnare, $03, dSnare, $03, $84, $03, dSnare, $03
	smpsPan             panCenter, $00
	smpsStop

; FM1 Data
SongA_FM1:
	smpsPan             panCenter, $00
	smpsSetvoice        $00
	dc.b	nE5, $03, nRst, $03, nE5, $03, nRst, $03, nF5, $06, nE5, $06
	dc.b	nC5, $09, nG4, $09, nE5, $09, nRst, $03, nE5, $03, nRst, $03
	dc.b	nF5, $06, nE5, $06, nC5, $15, nRst, $03, nE5, $03, nRst, $03
	dc.b	nE5, $03, nRst, $03, nF5, $06, nE5, $06, nC5, $09, nG4, $09
	dc.b	nE5, $0C, nF5, $06, nFs5, $06, nG5, $06, nC5, $15, nRst, $03
	dc.b	nG5, $03, nRst, $03, nG5, $03, nRst, $03, nF5, $09, nC5, $09
	dc.b	nA4, $09, nRst, $03, nG5, $09, nRst, $03, nG5, $06, nF5, $09
	dc.b	nC5, $09, nA4, $06, nC5, $06, nD5, $06, nEb5, $1E, nD5, $0C
	dc.b	nEb5, $06, nF5, $09, nEb5, $09, nF5, $06, nG5, $12, nRst, $06
	dc.b	nE5, $03, nRst, $03, nE5, $03, nRst, $03, nF5, $06, nE5, $06
	dc.b	nC5, $09, nG4, $09, nE5, $09, nRst, $03, nE5, $03, nRst, $03
	dc.b	nF5, $06, nE5, $06, nC5, $15, nRst, $03, nE5, $03, nRst, $03
	dc.b	nE5, $03, nRst, $03, nF5, $06, nE5, $06, nC5, $09, nG4, $09
	dc.b	nE5, $0C, nF5, $06, nFs5, $06, nG5, $06, nC5, $15, nRst, $03
	dc.b	nG5, $03, nRst, $03, nG5, $03, nRst, $03, nF5, $09, nC5, $09
	dc.b	nA4, $09, nRst, $03, nG5, $09, nRst, $03, nG5, $06, nF5, $09
	dc.b	nC5, $09, nA4, $06, nC5, $06, nD5, $06, nEb5, $1E, nD5, $0C
	dc.b	nEb5, $06, nF5, $09, nEb5, $09, nF5, $06, nG5, $12, nRst, $06
	smpsPan             panCenter, $00	
	smpsSetvoice        $00
	smpsStop	

; FM2 Data
SongA_FM2:
	smpsPan             panCenter, $00
	smpsSetvoice        $00
	dc.b	nC5, $03, nF5, $03, nG5, $03, nC6, $03, nC5, $03, nF5, $03
	dc.b	nG5, $03, nC6, $03, nC5, $03, nF5, $03, nG5, $03, nC6, $03
	dc.b	nC5, $03, nF5, $03, nG5, $03, nC6, $03, nC5, $03, nF5, $03
	dc.b	nG5, $03, nC6, $03, nC5, $03, nF5, $03, nG5, $03, nC6, $03
	dc.b	nC5, $03, nF5, $03, nG5, $03, nC6, $03, nG6, $03, nF6, $03
	dc.b	nE6, $03, nC6, $03, nC5, $03, nF5, $03, nG5, $03, nC6, $03
	dc.b	nC5, $03, nF5, $03, nG5, $03, nC6, $03, nC5, $03, nF5, $03
	dc.b	nG5, $03, nC6, $03, nC5, $03, nF5, $03, nG5, $03, nC6, $03
	dc.b	nC5, $03, nF5, $03, nG5, $03, nC6, $03, nC5, $03, nF5, $03
	dc.b	nG5, $03, nC6, $03, nC5, $03, nF5, $03, nG5, $03, nC6, $03
	dc.b	nG6, $03, nF6, $03, nE6, $03, nC6, $03, nC5, $03, nF5, $03
	dc.b	nG5, $03, nC6, $03, nC5, $03, nF5, $03, nG5, $03, nC6, $03
	dc.b	nC5, $03, nF5, $03, nG5, $03, nC6, $03, nC5, $03, nF5, $03
	dc.b	nG5, $03, nC6, $03, nC5, $03, nF5, $03, nG5, $03, nC6, $03
	dc.b	nC5, $03, nF5, $03, nG5, $03, nC6, $03, nC5, $03, nF5, $03
	dc.b	nG5, $03, nC6, $03, nG6, $03, nF6, $03, nE6, $03, nC6, $03
	dc.b	nC5, $03, nF5, $03, nG5, $03, nC6, $03, nC5, $03, nF5, $03
	dc.b	nG5, $03, nC6, $03, nC5, $03, nF5, $03, nG5, $03, nC6, $03
	dc.b	nC5, $03, nF5, $03, nG5, $03, nC6, $03, nC5, $03, nF5, $03
	dc.b	nG5, $03, nC6, $03, nC5, $03, nF5, $03, nG5, $03, nC6, $03
	dc.b	nC5, $03, nF5, $03, nG5, $03, nC6, $03, nG6, $03, nF6, $03
	dc.b	nE6, $03, nC6, $03, nC5, $03, nF5, $03, nG5, $03, nC6, $03
	dc.b	nC5, $03, nF5, $03, nG5, $03, nC6, $03, nC5, $03, nF5, $03
	dc.b	nG5, $03, nC6, $03, nC5, $03, nF5, $03, nG5, $03, nC6, $03
	dc.b	nC5, $03, nF5, $03, nG5, $03, nC6, $03, nC5, $03, nF5, $03
	dc.b	nG5, $03, nC6, $03, nC5, $03, nF5, $03, nG5, $03, nC6, $03
	dc.b	nG6, $03, nF6, $03, nE6, $03, nC6, $03, nC5, $03, nF5, $03
	dc.b	nG5, $03, nC6, $03, nC5, $03, nF5, $03, nG5, $03, nC6, $03
	dc.b	nC5, $03, nF5, $03, nG5, $03, nC6, $03, nC5, $03, nF5, $03
	dc.b	nG5, $03, nC6, $03, nC5, $03, nF5, $03, nG5, $03, nC6, $03
	dc.b	nC5, $03, nF5, $03, nG5, $03, nC6, $03, nC5, $03, nF5, $03
	dc.b	nG5, $03, nC6, $03, nG6, $03, nF6, $03, nE6, $03, nC6, $03
	dc.b	nC5, $03, nF5, $03, nG5, $03, nC6, $03, nC5, $03, nF5, $03
	dc.b	nG5, $03, nC6, $03, nC5, $03, nF5, $03, nG5, $03, nC6, $03
	dc.b	nC5, $03, nF5, $03, nG5, $03, nC6, $03, nC5, $03, nF5, $03
	dc.b	nG5, $03, nC6, $03, nC5, $03, nF5, $03, nG5, $03, nC6, $03
	dc.b	nC5, $03, nF5, $03, nG5, $03, nC6, $03, nG6, $03, nF6, $03
	dc.b	nE6, $03, nC6, $03, nC5, $03, nF5, $03, nG5, $03, nC6, $03
	dc.b	nC5, $03, nF5, $03, nG5, $03, nC6, $03, nC5, $03, nF5, $03
	dc.b	nG5, $03, nC6, $03, nC5, $03, nF5, $03, nG5, $03, nC6, $03
	dc.b	nC5, $03, nF5, $03, nG5, $03, nC6, $03, nC5, $03, nF5, $03
	dc.b	nG5, $03, nC6, $03, nC5, $03, nF5, $03, nG5, $03, nC6, $03
	dc.b	nG6, $03, nF6, $03, nE6, $03, nC6, $03
	smpsPan             panCenter, $00
	smpsSetvoice        $00
	smpsStop	

; FM3 Data
SongA_FM3:
	smpsPan             panCenter, $00
	smpsSetvoice        $01
	dc.b	nC3, $03, nRst, $03, nC3, $03, nRst, $03, nC3, $03, nRst, $03
	dc.b	nC3, $03, nRst, $03, nC3, $03, nRst, $03, nC3, $03, nRst, $03
	dc.b	nC3, $03, nRst, $03, nC3, $03, nRst, $03, nC3, $03, nRst, $03
	dc.b	nC3, $03, nRst, $03, nC3, $03, nRst, $03, nC3, $03, nRst, $03
	dc.b	nC3, $03, nRst, $03, nC3, $03, nRst, $03, nC3, $03, nRst, $03
	dc.b	nC3, $03, nRst, $03, nBb2, $03, nRst, $03, nBb2, $03, nRst, $03
	dc.b	nBb2, $03, nRst, $03, nBb2, $03, nRst, $03, nBb2, $03, nRst, $03
	dc.b	nBb2, $03, nRst, $03, nBb2, $03, nRst, $03, nBb2, $03, nRst, $03
	dc.b	nBb2, $03, nRst, $03, nBb2, $03, nRst, $03, nBb2, $03, nRst, $03
	dc.b	nBb2, $03, nRst, $03, nBb2, $03, nRst, $03, nBb2, $03, nRst, $03
	dc.b	nBb2, $03, nRst, $03, nBb2, $03, nRst, $03, nA2, $03, nRst, $03
	dc.b	nA2, $03, nRst, $03, nA2, $03, nRst, $03, nA2, $03, nRst, $03
	dc.b	nA2, $03, nRst, $03, nA2, $03, nRst, $03, nA2, $03, nRst, $03
	dc.b	nA2, $03, nRst, $03, nA2, $03, nRst, $03, nA2, $03, nRst, $03
	dc.b	nA2, $03, nRst, $03, nA2, $03, nRst, $03, nA2, $03, nRst, $03
	dc.b	nA2, $03, nRst, $03, nA2, $03, nRst, $03, nA2, $03, nRst, $03
	dc.b	nAb2, $03, nRst, $03, nAb2, $03, nRst, $03, nAb2, $03, nRst, $03
	dc.b	nAb2, $03, nRst, $03, nAb2, $03, nRst, $03, nAb2, $03, nRst, $03
	dc.b	nAb2, $03, nRst, $03, nAb2, $03, nRst, $03, nAb2, $03, nRst, $03
	dc.b	nAb2, $03, nRst, $03, nAb2, $03, nRst, $03, nAb2, $03, nRst, $03
	dc.b	nBb2, $03, nRst, $03, nBb2, $03, nRst, $03, nBb2, $03, nRst, $03
	dc.b	nBb2, $03, nRst, $03, nC3, $03, nRst, $03, nC3, $03, nRst, $03
	dc.b	nC3, $03, nRst, $03, nC3, $03, nRst, $03, nC3, $03, nRst, $03
	dc.b	nC3, $03, nRst, $03, nC3, $03, nRst, $03, nC3, $03, nRst, $03
	dc.b	nC3, $03, nRst, $03, nC3, $03, nRst, $03, nC3, $03, nRst, $03
	dc.b	nC3, $03, nRst, $03, nC3, $03, nRst, $03, nC3, $03, nRst, $03
	dc.b	nC3, $03, nRst, $03, nC3, $03, nRst, $03, nBb2, $03, nRst, $03
	dc.b	nBb2, $03, nRst, $03, nBb2, $03, nRst, $03, nBb2, $03, nRst, $03
	dc.b	nBb2, $03, nRst, $03, nBb2, $03, nRst, $03, nBb2, $03, nRst, $03
	dc.b	nBb2, $03, nRst, $03, nBb2, $03, nRst, $03, nBb2, $03, nRst, $03
	dc.b	nBb2, $03, nRst, $03, nBb2, $03, nRst, $03, nBb2, $03, nRst, $03
	dc.b	nBb2, $03, nRst, $03, nBb2, $03, nRst, $03, nBb2, $03, nRst, $03
	dc.b	nA2, $03, nRst, $03, nA2, $03, nRst, $03, nA2, $03, nRst, $03
	dc.b	nA2, $03, nRst, $03, nA2, $03, nRst, $03, nA2, $03, nRst, $03
	dc.b	nA2, $03, nRst, $03, nA2, $03, nRst, $03, nA2, $03, nRst, $03
	dc.b	nA2, $03, nRst, $03, nA2, $03, nRst, $03, nA2, $03, nRst, $03
	dc.b	nA2, $03, nRst, $03, nA2, $03, nRst, $03, nA2, $03, nRst, $03
	dc.b	nA2, $03, nRst, $03, nAb2, $03, nRst, $03, nAb2, $03, nRst, $03
	dc.b	nAb2, $03, nRst, $03, nAb2, $03, nRst, $03, nAb2, $03, nRst, $03
	dc.b	nAb2, $03, nRst, $03, nAb2, $03, nRst, $03, nAb2, $03, nRst, $03
	dc.b	nAb2, $03, nRst, $03, nAb2, $03, nRst, $03, nAb2, $03, nRst, $03
	dc.b	nAb2, $03, nRst, $03, nBb2, $03, nRst, $03, nBb2, $03, nRst, $03
	dc.b	nBb2, $03, nRst, $03, nBb2, $03, nRst, $03
	smpsPan             panCenter, $00
	smpsSetvoice        $01
	smpsStop	

; PSG3 Data
SongA_PSG3:
	smpsPSGform         $E7
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $03, nMaxPSG, $03, nMaxPSG, $03
	dc.b	nMaxPSG, $03, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	dc.b	nMaxPSG, $06, nMaxPSG, $03, nMaxPSG, $03, nMaxPSG, $03, nMaxPSG, $03, nMaxPSG, $06
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $03
	dc.b	nMaxPSG, $03, nMaxPSG, $03, nMaxPSG, $03, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $03, nMaxPSG, $03, nMaxPSG, $03
	dc.b	nMaxPSG, $03, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	dc.b	nMaxPSG, $06, nMaxPSG, $03, nMaxPSG, $03, nMaxPSG, $03, nMaxPSG, $03, nMaxPSG, $06
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $03
	dc.b	nMaxPSG, $03, nMaxPSG, $03, nMaxPSG, $03, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $03, nMaxPSG, $03, nMaxPSG, $03
	dc.b	nMaxPSG, $03, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	dc.b	nMaxPSG, $06, nMaxPSG, $03, nMaxPSG, $03, nMaxPSG, $03, nMaxPSG, $03, nMaxPSG, $06
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $03
	dc.b	nMaxPSG, $03, nMaxPSG, $03, nMaxPSG, $03, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $03, nMaxPSG, $03, nMaxPSG, $03
	dc.b	nMaxPSG, $03, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	dc.b	nMaxPSG, $06, nMaxPSG, $03, nMaxPSG, $03, nMaxPSG, $03, nMaxPSG, $03, nMaxPSG, $06
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $03
	dc.b	nMaxPSG, $03, nMaxPSG, $03, nMaxPSG, $03, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $03, nMaxPSG, $03, nMaxPSG, $03
	dc.b	nMaxPSG, $03, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	dc.b	nMaxPSG, $06, nMaxPSG, $03, nMaxPSG, $03, nMaxPSG, $03, nMaxPSG, $03, nMaxPSG, $06
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $03
	dc.b	nMaxPSG, $03, nMaxPSG, $03, nMaxPSG, $03, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	dc.b	nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $03, nMaxPSG, $03, nMaxPSG, $03
	dc.b	nMaxPSG, $03, nMaxPSG, $06, nMaxPSG, $06, nMaxPSG, $06
	smpsFade	
	smpsStop	

; PSG1 Data
SongA_PSG1:
; PSG2 Data
SongA_PSG2:
	smpsStop

SongA_Voices:
;	Voice $00
;	$04
;	$71, $41, $31, $31, 	$12, $12, $12, $12, 	$00, $00, $00, $00
;	$00, $00, $00, $00, 	$0F, $0F, $0F, $0F, 	$23, $00, $23, $00
	smpsVcAlgorithm     $04
	smpsVcFeedback      $00
	smpsVcUnusedBits    $00
	smpsVcDetune        $03, $03, $04, $07
	smpsVcCoarseFreq    $01, $01, $01, $01
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $12, $12, $12, $12
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $00, $00, $00, $00
	smpsVcDecayRate2    $00, $00, $00, $00
	smpsVcDecayLevel    $00, $00, $00, $00
	smpsVcReleaseRate   $0F, $0F, $0F, $0F
	smpsVcTotalLevel    $00, $23, $00, $23

;	Voice $01
;	$20
;	$36, $35, $30, $31, 	$DF, $DF, $9F, $9F, 	$07, $06, $09, $06
;	$07, $06, $06, $08, 	$20, $10, $10, $F8, 	$19, $37, $13, $00
	smpsVcAlgorithm     $00
	smpsVcFeedback      $04
	smpsVcUnusedBits    $00
	smpsVcDetune        $03, $03, $03, $03
	smpsVcCoarseFreq    $01, $00, $05, $06
	smpsVcRateScale     $02, $02, $03, $03
	smpsVcAttackRate    $1F, $1F, $1F, $1F
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $06, $09, $06, $07
	smpsVcDecayRate2    $08, $06, $06, $07
	smpsVcDecayLevel    $0F, $01, $01, $02
	smpsVcReleaseRate   $08, $00, $00, $00
	smpsVcTotalLevel    $00, $13, $37, $19

