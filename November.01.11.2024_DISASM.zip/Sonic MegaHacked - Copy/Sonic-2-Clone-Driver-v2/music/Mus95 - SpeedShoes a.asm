SpeedOfSoundUnused_Header:
	smpsHeaderStartSong 1
	smpsHeaderVoice     SpeedOfSoundUnused_Voices
	smpsHeaderChan      $07, $03
	smpsHeaderTempo     $02, $1E

	smpsHeaderDAC       SpeedOfSoundUnused_DAC
	smpsHeaderFM        SpeedOfSoundUnused_FM1,	$00, $29
	smpsHeaderFM        SpeedOfSoundUnused_FM2,	$00, $00
	smpsHeaderFM        SpeedOfSoundUnused_FM3,	$00, $00
	smpsHeaderFM        SpeedOfSoundUnused_FM4,	$00, $37
	smpsHeaderFM        SpeedOfSoundUnused_FM5,	$00, $00
	smpsHeaderFM        SpeedOfSoundUnused_FM6,	$00, $00
	smpsHeaderPSG       SpeedOfSoundUnused_PSG1,	$00, $00, $00, $00
	smpsHeaderPSG       SpeedOfSoundUnused_PSG2,	$00, $00, $00, $00
	smpsHeaderPSG       SpeedOfSoundUnused_PSG3,	$00, $0F, $00, fTone_01

; DAC Data
SpeedOfSoundUnused_DAC:
	smpsPan             panCenter, $00
	dc.b	nRst, $18, $85, $06, dKick, $06, dSnare, $06, dKick, $03, dKick, $06
	dc.b	dKick, $03, dKick, $06, dSnare, $03, dKick, $06, dSnare, $03, dKick, $06
	dc.b	dKick, $06, dSnare, $06, dKick, $03, dKick, $06, dKick, $03, dKick, $06
	dc.b	dSnare, $03, dKick, $09, dKick, $06, dKick, $06, dSnare, $06, dKick, $03
	dc.b	dKick, $06, dKick, $03, dKick, $06, dSnare, $03, dKick, $09, dKick, $06
	dc.b	dKick, $06, dSnare, $06, dKick, $03, dKick, $06, dKick, $03, dKick, $06
	dc.b	dSnare, $03, dKick, $03, dSnare, $03, dSnare, $03, dKick, $06, dKick, $06
	dc.b	dSnare, $06, dKick, $03, dKick, $06, dKick, $03, dKick, $06, dSnare, $03
	dc.b	dKick, $06, dSnare, $03, dKick, $06, dKick, $06, dSnare, $06, dKick, $03
	dc.b	dKick, $06, dKick, $03, dKick, $06, dSnare, $03, dKick, $09, dKick, $06
	dc.b	dKick, $06, dSnare, $06, dKick, $03, dKick, $06, dKick, $03, dKick, $06
	dc.b	dSnare, $03, dKick, $09, dKick, $06, dKick, $06, dSnare, $03, dSnare, $03
	dc.b	dSnare, $03, dSnare, $06, dSnare, $03, dSnare, $06, dSnare, $03, dKick, $03
	dc.b	dSnare, $03, dSnare, $03, $85, $06, dKick, $06, dSnare, $06, dKick, $03
	dc.b	dKick, $06, dKick, $03, dKick, $06, dSnare, $03, dKick, $06, dSnare, $03
	dc.b	dKick, $06, dKick, $06, dSnare, $06, dKick, $03, dKick, $06, dKick, $03
	dc.b	dKick, $06, dSnare, $03, dKick, $09, dKick, $06, dKick, $06, dSnare, $06
	dc.b	dKick, $03, dKick, $06, dKick, $03, dKick, $06, dSnare, $03, dKick, $09
	dc.b	dKick, $06, dKick, $06, dSnare, $06, dKick, $03, dKick, $06, dKick, $03
	dc.b	dKick, $06, dSnare, $03, dKick, $03, dSnare, $03, dSnare, $03, dKick, $06
	dc.b	dKick, $06, dSnare, $06, dKick, $03, dKick, $06, dKick, $03, dKick, $06
	dc.b	dSnare, $03, dKick, $06, dSnare, $03, dKick, $06, dKick, $06, dSnare, $06
	dc.b	dKick, $03, dKick, $06, dKick, $03, dKick, $06, dSnare, $03, dKick, $09
	dc.b	dKick, $06, dKick, $06, dSnare, $06, dKick, $03, dKick, $06, dKick, $03
	dc.b	dKick, $06, dSnare, $03, dKick, $09, dKick, $06, dKick, $06, dSnare, $03
	dc.b	dSnare, $03, dSnare, $03, dSnare, $06, dSnare, $03, dSnare, $06, dSnare, $03
	dc.b	dKick, $03, dSnare, $03, dSnare, $03, $85, $06
	smpsStop

; FM1 Data
SpeedOfSoundUnused_FM1:
	smpsPan             panCenter, $00
	smpsSetvoice        $00
	dc.b	nRst, $18, nE3, $03, nRst, $03, nE3, $03, nRst, $03, nE3, $03
	dc.b	nRst, $03, nE3, $03, nE3, $03, nRst, $03, nE3, $03, nE3, $03
	dc.b	nRst, $03, nE3, $03, nRst, $03, nE3, $03, nRst, $03, nB2, $03
	dc.b	nRst, $03, nB2, $03, nRst, $03, nB2, $03, nRst, $03, nB2, $03
	dc.b	nB2, $03, nRst, $03, nB2, $03, nB2, $03, nRst, $03, nB2, $03
	dc.b	nRst, $03, nB2, $03, nRst, $03, nD3, $03, nRst, $03, nD3, $03
	dc.b	nRst, $03, nD3, $03, nRst, $03, nD3, $03, nD3, $03, nRst, $03
	dc.b	nD3, $03, nD3, $03, nRst, $03, nD3, $03, nRst, $03, nD3, $03
	dc.b	nRst, $03, nA2, $03, nRst, $03, nA2, $03, nRst, $03, nA2, $03
	dc.b	nRst, $03, nA2, $03, nA2, $03, nRst, $03, nA2, $03, nA2, $03
	dc.b	nRst, $03, nA2, $03, nRst, $03, nA2, $03, nRst, $03, nE3, $03
	dc.b	nRst, $03, nE3, $03, nRst, $03, nE3, $03, nRst, $03, nE3, $03
	dc.b	nE3, $03, nRst, $03, nE3, $03, nE3, $03, nRst, $03, nE3, $03
	dc.b	nRst, $03, nE3, $03, nRst, $03, nB2, $03, nRst, $03, nB2, $03
	dc.b	nRst, $03, nB2, $03, nRst, $03, nB2, $03, nB2, $03, nRst, $03
	dc.b	nB2, $03, nB2, $03, nRst, $03, nB2, $03, nRst, $03, nB2, $03
	dc.b	nRst, $03, nD3, $03, nRst, $03, nD3, $03, nRst, $03, nD3, $03
	dc.b	nRst, $03, nD3, $03, nD3, $03, nRst, $03, nD3, $03, nD3, $03
	dc.b	nRst, $03, nD3, $03, nRst, $03, nD3, $03, nRst, $03, nA2, $03
	dc.b	nRst, $03, nA2, $03, nRst, $03, nA2, $03, nRst, $03, nA2, $03
	dc.b	nA2, $03, nRst, $03, nA2, $03, nA2, $03, nRst, $03, nA2, $03
	dc.b	nRst, $03, nA2, $03, nRst, $03, nE3, $03, nRst, $03, nE3, $03
	dc.b	nRst, $03, nE3, $03, nRst, $03, nE3, $03, nE3, $03, nRst, $03
	dc.b	nE3, $03, nE3, $03, nRst, $03, nE3, $03, nRst, $03, nE3, $03
	dc.b	nRst, $03, nB2, $03, nRst, $03, nB2, $03, nRst, $03, nB2, $03
	dc.b	nRst, $03, nB2, $03, nB2, $03, nRst, $03, nB2, $03, nB2, $03
	dc.b	nRst, $03, nB2, $03, nRst, $03, nB2, $03, nRst, $03, nD3, $03
	dc.b	nRst, $03, nD3, $03, nRst, $03, nD3, $03, nRst, $03, nD3, $03
	dc.b	nD3, $03, nRst, $03, nD3, $03, nD3, $03, nRst, $03, nD3, $03
	dc.b	nRst, $03, nD3, $03, nRst, $03, nA2, $03, nRst, $03, nA2, $03
	dc.b	nRst, $03, nA2, $03, nRst, $03, nA2, $03, nA2, $03, nRst, $03
	dc.b	nA2, $03, nA2, $03, nRst, $03, nA2, $03, nRst, $03, nA2, $03
	dc.b	nRst, $03, nE3, $03, nRst, $03, nE3, $03, nRst, $03, nE3, $03
	dc.b	nRst, $03, nE3, $03, nE3, $03, nRst, $03, nE3, $03, nE3, $03
	dc.b	nRst, $03, nE3, $03, nRst, $03, nE3, $03, nRst, $03, nB2, $03
	dc.b	nRst, $03, nB2, $03, nRst, $03, nB2, $03, nRst, $03, nB2, $03
	dc.b	nB2, $03, nRst, $03, nB2, $03, nB2, $03, nRst, $03, nB2, $03
	dc.b	nRst, $03, nB2, $03, nRst, $03, nD3, $03, nRst, $03, nD3, $03
	dc.b	nRst, $03, nD3, $03, nRst, $03, nD3, $03, nD3, $03, nRst, $03
	dc.b	nD3, $03, nD3, $03, nRst, $03, nD3, $03, nRst, $03, nD3, $03
	dc.b	nRst, $03, nA2, $03, nRst, $03, nA2, $03, nRst, $03, nA2, $03
	dc.b	nRst, $03, nA2, $03, nA2, $03, nRst, $03, nA2, $03, nA2, $03
	dc.b	nRst, $03, nA2, $03, nRst, $03, nA2, $03
	smpsFade

; FM2 Data
SpeedOfSoundUnused_FM2:
	smpsPan             panCenter, $00
	smpsSetvoice        $01
	dc.b	nRst, $18, nAb4, $03, nRst, $03, nAb4, $03, nRst, $03, nA4, $06
	dc.b	nAb4, $03, nRst, $03, nE4, $06, nRst, $03, nB3, $06, nRst, $03
	dc.b	nB3, $36, nAb4, $03, nRst, $03, nAb4, $03, nRst, $03, nA4, $06
	dc.b	nAb4, $03, nRst, $03, nE4, $06, nRst, $03, nB3, $06, nRst, $03
	dc.b	nB4, $1E, nA4, $18, nAb4, $03, nRst, $03, nAb4, $03, nRst, $03
	dc.b	nA4, $06, nAb4, $03, nRst, $03, nE4, $06, nRst, $03, nB3, $06
	dc.b	nRst, $03, nB3, $36, nAb4, $03, nRst, $03, nAb4, $03, nRst, $03
	dc.b	nA4, $06, nAb4, $03, nRst, $03, nE4, $06, nRst, $03, nB3, $06
	dc.b	nRst, $03, nB4, $36, nAb4, $03, nRst, $03, nAb4, $03, nRst, $03
	dc.b	nA4, $06, nAb4, $03, nRst, $03, nE4, $06, nRst, $03, nB3, $06
	dc.b	nRst, $03, nB3, $36, nAb4, $03, nRst, $03, nAb4, $03, nRst, $03
	dc.b	nA4, $06, nAb4, $03, nRst, $03, nE4, $06, nRst, $03, nB3, $06
	dc.b	nRst, $03, nB4, $1E, nA4, $18, nAb4, $03, nRst, $03, nAb4, $03
	dc.b	nRst, $03, nA4, $06, nAb4, $03, nRst, $03, nE4, $06, nRst, $03
	dc.b	nB3, $06, nRst, $03, nB3, $36, nAb4, $03, nRst, $03, nAb4, $03
	dc.b	nRst, $03, nA4, $06, nAb4, $03, nRst, $03, nE4, $06, nRst, $03
	dc.b	nB3, $06, nRst, $03, nB4, $36
	smpsStop

; FM3 Data
SpeedOfSoundUnused_FM3:
	smpsPan             panCenter, $00
	smpsSetvoice        $01
	dc.b	nRst, $48, nAb4, $03, nRst, $03, nAb4, $03, nRst, $03, nA4, $06
	dc.b	nAb4, $03, nRst, $03, nE4, $06, nRst, $03, nB3, $06, nRst, $03
	dc.b	nB3, $36, nAb4, $03, nRst, $03, nAb4, $03, nRst, $03, nA4, $06
	dc.b	nAb4, $03, nRst, $03, nE4, $06, nRst, $03, nB3, $06, nRst, $03
	dc.b	nB4, $36, nAb4, $03, nRst, $03, nAb4, $03, nRst, $03, nA4, $06
	dc.b	nAb4, $03, nRst, $03, nE4, $06, nRst, $03, nB3, $06, nRst, $03
	dc.b	nB3, $36, nAb4, $03, nRst, $03, nAb4, $03, nRst, $03, nA4, $06
	dc.b	nAb4, $03, nRst, $03, nE4, $06, nRst, $03, nB3, $06, nRst, $03
	dc.b	nB4, $06, nRst, $30, nAb4, $03, nRst, $03, nAb4, $03, nRst, $03
	dc.b	nA4, $06, nAb4, $03, nRst, $03, nE4, $06, nRst, $03, nB3, $06
	dc.b	nRst, $03, nB3, $36, nAb4, $03, nRst, $03, nAb4, $03, nRst, $03
	dc.b	nA4, $06, nAb4, $03, nRst, $03, nE4, $06, nRst, $03, nB3, $06
	dc.b	nRst, $03, nB4, $36, nAb4, $03, nRst, $03, nAb4, $03, nRst, $03
	dc.b	nA4, $06, nAb4, $03, nRst, $03, nE4, $06, nRst, $03, nB3, $06
	dc.b	nRst, $03, nB3, $36, nAb4, $03, nRst, $03, nAb4, $03, nRst, $03
	dc.b	nA4, $06, nAb4, $03, nRst, $03, nE4, $06, nRst, $03, nB3, $06
	dc.b	nRst, $03, nB4, $06
	smpsStop

; FM4 Data
SpeedOfSoundUnused_FM4:
	smpsPan             panCenter, $00
	smpsSetvoice        $02
	dc.b	nRst, $18, nE6, $30, nB5, $30, nD6, $30, nB6, $18, nA6, $18
	dc.b	nE6, $30, nB5, $30, nD6, $30, nAb6, $0C, nB6, $0C, nE6, $0C
	dc.b	nB5, $0C, nE6, $30, nB5, $30, nD6, $30, nB6, $18, nA6, $18
	dc.b	nE6, $30, nB5, $30, nD6, $30, nAb6, $0C, nB6, $0C, nE6, $0C
	dc.b	nB5, $0C
	smpsStop

; FM5 Data
SpeedOfSoundUnused_FM5:
	smpsPan             panCenter, $00
	smpsSetvoice        $03
	dc.b	nRst, $18, nE4, $30, nB3, $30, nD4, $30, nB4, $18, nA4, $18
	dc.b	nE4, $30, nB3, $30, nD4, $30, nAb4, $0C, nB4, $0C, nE4, $0C
	dc.b	nB3, $0C, nE4, $30, nB3, $30, nD4, $30, nB4, $18, nA4, $18
	dc.b	nE4, $30, nB3, $30, nD4, $30, nAb4, $0C, nB4, $0C, nE4, $0C
	dc.b	nB3, $0C
	smpsStop

; FM6 Data
SpeedOfSoundUnused_FM6:
	smpsPan             panCenter, $00
	smpsSetvoice        $03
	dc.b	nRst, $18, nE4, $06, nRst, $7F, $7F, $7C, nE4, $06, nRst, $7F
	dc.b	$7F, $7C, nE4, $06
	smpsStop

; PSG3 Data
SpeedOfSoundUnused_PSG3:
	smpsPSGform         $E7
	dc.b	nMaxPSG, $0C, nEb5, $0C
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $06
	smpsPSGvoice        fTone_02
	dc.b	nMaxPSG, $03, nMaxPSG, $03
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C
	smpsStop

; PSG1 Data
SpeedOfSoundUnused_PSG1:
; PSG2 Data
SpeedOfSoundUnused_PSG2:
	smpsStop

SpeedOfSoundUnused_Voices:
;	Voice $00
;	$28
;	$39, $35, $30, $31, 	$1F, $1F, $1F, $1F, 	$0C, $0A, $07, $0A
;	$07, $07, $07, $09, 	$26, $16, $16, $F6, 	$17, $32, $14, $00
	smpsVcAlgorithm     $00
	smpsVcFeedback      $05
	smpsVcUnusedBits    $00
	smpsVcDetune        $03, $03, $03, $03
	smpsVcCoarseFreq    $01, $00, $05, $09
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $1F, $1F, $1F, $1F
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $0A, $07, $0A, $0C
	smpsVcDecayRate2    $09, $07, $07, $07
	smpsVcDecayLevel    $0F, $01, $01, $02
	smpsVcReleaseRate   $06, $06, $06, $06
	smpsVcTotalLevel    $00, $14, $32, $17

;	Voice $01
;	$3A
;	$01, $07, $31, $71, 	$8E, $8E, $8D, $53, 	$0E, $0E, $0E, $06
;	$00, $00, $00, $00, 	$1F, $FF, $1F, $2F, 	$18, $28, $27, $00
	smpsVcAlgorithm     $02
	smpsVcFeedback      $07
	smpsVcUnusedBits    $00
	smpsVcDetune        $07, $03, $00, $00
	smpsVcCoarseFreq    $01, $01, $07, $01
	smpsVcRateScale     $01, $02, $02, $02
	smpsVcAttackRate    $13, $0D, $0E, $0E
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $06, $0E, $0E, $0E
	smpsVcDecayRate2    $00, $00, $00, $00
	smpsVcDecayLevel    $02, $01, $0F, $01
	smpsVcReleaseRate   $0F, $0F, $0F, $0F
	smpsVcTotalLevel    $00, $27, $28, $18

;	Voice $02
;	$3E
;	$38, $01, $7A, $34, 	$59, $D9, $5F, $9C, 	$0F, $04, $0F, $0A
;	$02, $02, $05, $05, 	$AF, $AF, $66, $66, 	$28, $00, $23, $00
	smpsVcAlgorithm     $06
	smpsVcFeedback      $07
	smpsVcUnusedBits    $00
	smpsVcDetune        $03, $07, $00, $03
	smpsVcCoarseFreq    $04, $0A, $01, $08
	smpsVcRateScale     $02, $01, $03, $01
	smpsVcAttackRate    $1C, $1F, $19, $19
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $0A, $0F, $04, $0F
	smpsVcDecayRate2    $05, $05, $02, $02
	smpsVcDecayLevel    $06, $06, $0A, $0A
	smpsVcReleaseRate   $06, $06, $0F, $0F
	smpsVcTotalLevel    $00, $23, $00, $28

;	Voice $03
;	$3B
;	$51, $71, $61, $41, 	$51, $16, $18, $1A, 	$05, $01, $01, $00
;	$09, $01, $01, $01, 	$17, $97, $27, $47, 	$1C, $22, $15, $00
	smpsVcAlgorithm     $03
	smpsVcFeedback      $07
	smpsVcUnusedBits    $00
	smpsVcDetune        $04, $06, $07, $05
	smpsVcCoarseFreq    $01, $01, $01, $01
	smpsVcRateScale     $00, $00, $00, $01
	smpsVcAttackRate    $1A, $18, $16, $11
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $00, $01, $01, $05
	smpsVcDecayRate2    $01, $01, $01, $09
	smpsVcDecayLevel    $04, $02, $09, $01
	smpsVcReleaseRate   $07, $07, $07, $07
	smpsVcTotalLevel    $00, $15, $22, $1C

