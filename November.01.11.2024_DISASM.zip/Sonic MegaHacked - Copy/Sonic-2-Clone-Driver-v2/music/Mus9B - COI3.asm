COI3_Header:
	smpsHeaderStartSong 1
	smpsHeaderVoice     COI3_Voices
	smpsHeaderChan      $07, $03
	smpsHeaderTempo     $01, $00

	smpsHeaderDAC       COI3_DAC,	$00, $F2
	smpsHeaderFM        COI3_FM1,	$00, $00
	smpsHeaderFM        COI3_FM2,	$00, $00
	smpsHeaderFM        COI3_FM3,	$00, $00
	smpsHeaderFM        COI3_FM4,	$00, $00
	smpsHeaderFM        COI3_FM5,	$00, $00
	smpsHeaderFM        COI3_FM6,	$00, $00
	smpsHeaderPSG       COI3_PSG1,	$00, $00, $00, $00
	smpsHeaderPSG       COI3_PSG2,	$00, $00, $00, $00
	smpsHeaderPSG       COI3_PSG3,	$00, $00, $00, $00

; DAC Data
COI3_DAC:
; FM3 Data
COI3_FM3:
; PSG3 Data
COI3_PSG3:
	smpsStop

; FM1 Data
COI3_FM1:
	smpsSetvoice        $00
	smpsAlterVol        $15
	smpsPan             panLeft, $00
	smpsModSet          $00, $02, $03, $03
	dc.b	nRst, $39, nC4, $0C, nRst, $2C
	smpsSetvoice        $06
	dc.b	smpsNoAttack, nRst, $01
	smpsSetvoice        $05
	smpsPan             panCenter, $00
	dc.b	smpsNoAttack, nRst
	smpsAlterVol        $FC
	smpsPan             panLeft, $00
	dc.b	nG4, $04, nRst, $0F
	smpsAlterVol        $02
	dc.b	nG4, $05, nRst, $04
	smpsAlterVol        $FE
	dc.b	nG4, $1D
	smpsAlterVol        $01
	dc.b	nG4, $01

COI3_Jump04:
	dc.b	smpsNoAttack, nG4, $0E, nRst, nG4, $0F, nRst, $0E, nF4, $1D, nE4, $09
	dc.b	nRst, $14, nG4, $0E, nRst, nG4, $0F, nRst, $0E, nG4, nRst, $0F
	dc.b	nG4, $0E, nRst, nBb4, $0F, nRst, $0E, nBb4, nRst, $0F, nA4, $0E
	dc.b	nRst, $0F, nG4, $1C, nA4, $0D, nRst, $10, nA4, $0D, nRst, $10
	dc.b	nG4, $0E, nRst, nG4, $0F, nRst, $0E, nG4, nRst, $0F, nG4, $0E
	dc.b	nRst, $0F, nF4, $1C, nE4, $0A, nRst, $13, nG4, $0E, nRst, $0F
	dc.b	nG4, $0E, nRst, nG4, $0F, nRst, $0E, nG4, nRst, $0F, nBb4, $0E
	dc.b	nRst, nBb4, $0F, nRst, $0E, nA4, $0F, nRst, $0E, nG4, $1D, nF4
	dc.b	$1C, nEb4, $1D, nD4, nCs4, $1B
	smpsSetvoice        $09
	smpsAlterVol        $01
	smpsPan             panCenter, $00
	smpsModOff
	dc.b	smpsNoAttack, nCs4, $01
	smpsPan             panLeft, $00
	dc.b	nA5, $05, nRst, $0F, nA5, $04, nRst, $05, nB5, nRst, nA5, nRst
	dc.b	$04, nB5, $0A, nC6, $05, nRst, $0E, nC6, $05, nRst, nD6, $04
	dc.b	nRst, $05, nC6, nRst, nD6, $09, nE6, $05, nRst, $0E, nE6, $05
	dc.b	nRst, nE6, nRst, nF6, $04, nRst, $05, nE6, nRst, nD6, $04, nRst
	dc.b	$05, nE6, nRst, nD6, nRst, $04, nC6, $05, nRst, nB5, nRst, nBb5
	dc.b	$04, nRst, $05, nA5, nRst, $0E, nA5, $05, nRst, nB5, nRst, $04
	dc.b	nA5, $05, nRst, nB5, $0A, nC6, $04, nRst, $0F, nC6, $04, nRst
	dc.b	$05, nD6, nRst, nC6, nRst, $04, nD6, $0A, nE6, $05, nRst, $0E
	dc.b	nE6, $05, nRst, nE6, $04, nRst, $05, nF6, nRst, nE6, nRst, $04
	dc.b	nD6, $05, nRst, nE6, nRst, nD6, $04, nRst, $05, nC6, nRst, nB5
	dc.b	$04, nRst, $05, nBb5, nRst
	smpsAlterVol        $02
	dc.b	nA5, $0D, nRst, $10, nA5, $0D, nRst, $0F, nA5, $0D, nRst, $10
	dc.b	nA5, $0D, nRst, $10, nA5, $09, nA6, $0D, nRst, $07, nA6, $0D
	dc.b	nRst, $05, nA5, $0D, nRst, $06, nA6, $0D, nRst, $07, nA6, $0E
	dc.b	nRst, $0F, nA5, $0D, nRst, $0F, nA5, $0D, nRst, $10, nA5, $0D
	dc.b	nRst, $10, nA5, $0D, nRst, $0F, nA5, $09, nA6, $0D, nRst, $08
	dc.b	nA6, $0D, nRst, $05, nA5, $0D, nRst, $06, nA6, $0D, nRst, $07
	dc.b	nA6, $0D, nRst, $0F
	smpsAlterVol        $FF
	dc.b	nB5, $05, nRst, $0E, nB5, $05, nRst, nCs6, nRst, nB5, $04, nRst
	dc.b	$05, nCs6, $0A, nD6, $04, nRst, $0F, nD6, $05, nRst, $04, nE6
	dc.b	$05, nRst, nD6, nRst, nE6, $09, nFs6, $05, nRst, $0E, nFs6, $05
	dc.b	nRst, nFs6, nRst, $04, nG6, $05, nRst, nFs6, nRst, nE6, $04, nRst
	dc.b	$05, nFs6, nRst, nE6, $04, nRst, $05, nD6, nRst, nCs6, nRst, $04
	dc.b	nC6, $05, nRst, nB5, nRst, $0E, nB5, $05, nRst, nCs6, $04, nRst
	dc.b	$05, nB5, nRst, nCs6, $09, nD6, $05, nRst, $0E, nD6, $05, nRst
	dc.b	nE6, nRst, nD6, $04, nRst, $05, nE6, $0A, nFs6, $05, nRst, $0E
	dc.b	nFs6, $05, nRst, $04, nFs6, $05, nRst, nG6, nRst, nFs6, $04, nRst
	dc.b	$05, nE6, nRst, nFs6, nRst, $04, nE6, $05, nRst, nD6, nRst, $04
	dc.b	nCs6, $05, nRst, nC6, nRst
	smpsAlterVol        $01
	dc.b	nB5, $0D, nRst, $0F, nB5, $0D, nRst, $10, nB5, $0D, nRst, $10
	dc.b	nB5, $0D, nRst, $0F, nB5, $09, nB6, $0E, nRst, $07, nB6, $0D
	dc.b	nRst, $05, nB5, $0D, nRst, $06, nB6, $0D, nRst, $07, nB6, $0D
	dc.b	nRst, $0F, nB5, $0D, nRst, $10, nB5, $0D, nRst, $10, nB5, $0D
	dc.b	nRst, $0F, nB5, $0E, nRst, $0F, nB5, $09, nB6, $0D, nRst, $07
	dc.b	nB6, $0E, nRst, $04, nB5, $0E, nRst, $06, nB6, $0D, nRst, $07
	dc.b	nB6, $0D, nRst, $0F
	smpsAlterVol        $FF
	dc.b	nD5, $05, nRst, $0E, nD5, $05, nRst, nE5, $04, nRst, $05, nD5
	dc.b	nRst, nE5, $09, nF5, $05, nRst, $0F, nF5, $04, nRst, $05, nG5
	dc.b	nRst, nF5, $04, nRst, $05, nG5, $0A, nA5, $05, nRst, $0E, nA5
	dc.b	$05, nRst, nA5, $04, nRst, $05, nBb5, nRst, nA5, $04, nRst, $05
	dc.b	nG5, nRst, nA5, nRst, $04, nG5, $05, nRst, nF5, nRst, nE5, $04
	dc.b	nRst, $05, nEb5, $0A, nD5, $04, nRst, $0F, nD5, $05, nRst, $04
	dc.b	nE5, $05, nRst, nD5, nRst, nE5, $09, nF5, $05, nRst, $0E, nF5
	dc.b	$05, nRst, nG5, nRst, $04, nF5, $05, nRst, nG5, $09, nRst, $01
	dc.b	nA5, $04, nRst, $0F, nA5, $04, nRst, $05, nA5, nRst, nBb5, nRst
	dc.b	$04, nB5, $05, nRst, nC6, nRst, $18, nCs6, $04, nRst, $18, nD6
	dc.b	$05, nRst, $6E
	smpsSetvoice        $05
	smpsAlterVol        $FE
	smpsModSet          $00, $02, $03, $03
	dc.b	nG4, $01
	smpsPan             panLeft, $00
	smpsModOn
	smpsJump            COI3_Jump04

; FM2 Data
COI3_FM2:
	smpsSetvoice        $01
	smpsAlterVol        $10
	smpsPan             panLeft, $00
	smpsModSet          $00, $02, $01, $03
	dc.b	nC3, $39
	smpsAlterVol        $01
	dc.b	nBb2, $0F, nRst, $45
	smpsSetvoice        $07
	smpsAlterVol        $FB
	smpsPan             panCenter, $00
	smpsModOff
	dc.b	smpsNoAttack, nRst, $02
	smpsAlterVol        $FC
	dc.b	smpsNoAttack, nRst, $01, nG1, $07, nRst, $15
	smpsSetvoice        $08
	dc.b	smpsNoAttack, nRst, $01

COI3_Jump03:
	smpsSetvoice        $07
	dc.b	nA2, $07, nRst, $15, nG2, $08, nRst, $15, nG1, $07, nRst, $16
	dc.b	nG2, $07, nRst, $16, nA2, $07, nRst, $15, nG2, $07, nRst, $16
	dc.b	nG1, $07, nRst, $16, nC3, $07, nRst, $15, nA2, $08, nRst, $15
	dc.b	nG2, $07, nRst, $16, nG1, $07, nRst, $16, nG2, $07, nRst, $15
	dc.b	nA2, $07, nRst, $16, nF2, $07, nRst, $16, nG1, $07, nRst, $15
	dc.b	nG2, $08, nRst, $15, nA2, $07, nRst, $16, nG2, $07, nRst, $16
	dc.b	nG1, $07, nRst, $15, nG2, $07, nRst, $16, nA2, $07, nRst, $16
	dc.b	nG2, $07, nRst, $15, nG1, $08, nRst, $15, nC3, $07, nRst, $16
	dc.b	nA2, $07, nRst, $16, nG2, $07, nRst, $15, nG1, $07, nRst, $16
	dc.b	nG2, $07, nRst, $16, nA2, $07, nRst, $15, nG2, $08, nRst, $15
	dc.b	nF2, $07, nRst, $16, nE2, $07, nRst, $13
	smpsSetvoice        $01
	smpsAlterVol        $05
	smpsModSet          $00, $02, $01, $03
	dc.b	smpsNoAttack, nRst, $03
	smpsAlterVol        $03
	dc.b	nG2, $0D, nRst, $0F, nG2, $0D, nRst, $10, nG2, $0D, nRst, $10
	dc.b	nG2, $0D, nRst, $0F, nG2, $0D, nRst, $10, nG2, $0D, nRst, $10
	dc.b	nG2, $0D, nRst, $10, nG2, $0D, nRst, $0F, nG2, $0D, nRst, $10
	dc.b	nG2, $0D, nRst, $10, nG2, $0D, nRst, $0F, nG2, $0D, nRst, $10
	dc.b	nG2, $0D, nRst, $10, nG2, $0D, nRst, $0F, nG2, $0E, nRst, $0F
	dc.b	nG2, $0D, nRst, $10
	smpsAlterVol        $FD
	dc.b	nB1, $05, nRst, $0E, nB1, $05, nRst, nCs2, $04, nRst, $05, nB1
	dc.b	nRst, nCs2, $09, nD2, $05, nRst, $0E, nD2, $05, nRst, nE2, nRst
	dc.b	nD2, $04, nRst, $05, nE2, $0A, nFs2, $04, nRst, $0F, nFs2, $05
	dc.b	nRst, $04, nFs2, $05, nRst, nG2, nRst, nFs2, $04, nRst, $05, nE2
	dc.b	$0A, nFs2, $04, nRst, $05, nE2, nRst, nD2, nRst, $04, nCs2, $05
	dc.b	nRst, nC2, nRst, nB1, $04, nRst, $0F, nB1, $04, nRst, $05, nCs2
	dc.b	nRst, nB1, nRst, $04, nCs2, $0A, nD2, $05, nRst, $0E, nD2, $05
	dc.b	nRst, nE2, $04, nRst, $05, nD2, nRst, nE2, $09, nFs2, $05, nRst
	dc.b	$0F, nFs2, $04, nRst, $05, nFs2, nRst, nG2, $04, nRst, $05, nFs2
	dc.b	nRst, nE2, $09, nFs2, $05, nRst, nE2, nRst, nD2, $04, nRst, $05
	dc.b	nCs2, nRst, nC2, $04, nRst, $05
	smpsAlterVol        $03
	dc.b	nA2, $0F, nRst, $0E, nA2, nRst, $0F, nA2, $0E, nRst, nA2, $0F
	dc.b	nRst, $0E, nA2, nRst, $0F, nA2, $0E, nRst, $0F, nA2, $0E, nRst
	dc.b	nA2, $0F, nRst, $0E, nA2, nRst, $0F, nA2, $0E, nRst, nA2, $0F
	dc.b	nRst, $0E, nA2, nRst, $0F, nA2, $0E, nRst, $0F, nA2, $0E, nRst
	dc.b	nA2, $0F, nRst, $0E, nA2, nRst, $0F
	smpsAlterVol        $FD
	dc.b	nCs2, $04, nRst, $0F, nCs2, $05, nRst, $04, nEb2, $05, nRst, nCs2
	dc.b	nRst, $04, nEb2, $0A, nE2, $05, nRst, $0E, nE2, $05, nRst, nFs2
	dc.b	nRst, $04, nE2, $05, nRst, nFs2, $09, nRst, $01, nAb2, $04, nRst
	dc.b	$0F, nAb2, $04, nRst, $05, nAb2, nRst, nA2, $04, nRst, $05, nAb2
	dc.b	nRst, nFs2, $09, nAb2, $05, nRst, nFs2, nRst, nE2, $04, nRst, $05
	dc.b	nEb2, nRst, nD2, $04, nRst, $05, nCs2, nRst, $0E, nCs2, $05, nRst
	dc.b	nEb2, nRst, nCs2, $04, nRst, $05, nEb2, $0A, nE2, $04, nRst, $0F
	dc.b	nE2, $05, nRst, $04, nFs2, $05, nRst, nE2, nRst, nFs2, $09, nAb2
	dc.b	$05, nRst, $0E, nAb2, $05, nRst, nAb2, nRst, $04, nA2, $05, nRst
	dc.b	nAb2, nRst, nFs2, $09, nAb2, $05, nRst, nFs2, $04, nRst, $05, nE2
	dc.b	nRst, nEb2, nRst, $04, nD2, $05, nRst
	smpsAlterVol        $03
	dc.b	nC3, $0E, nRst, $0F, nC3, $0E, nRst, nC3, $0F, nRst, $0E, nC3
	dc.b	nRst, $0F, nC3, $0E, nRst, $0F, nC3, $0E, nRst, nC3, $0F, nRst
	dc.b	$0E, nC3, nRst, $0F, nC3, $0E, nRst, nC3, $0F, nRst, $0E, nC3
	dc.b	nRst, $0F, nC3, $0E, nRst, $0F, nC3, $0E, nRst, nC3, $0F, nRst
	dc.b	$0E, nC3, nRst, $0F, nA2, $1C, nD3, $0F, nRst, $0E, nCs3, nRst
	dc.b	$0F, nB2, $0E, nRst, nA2, $0F, nRst, $0E
	smpsSetvoice        $0C
	dc.b	smpsNoAttack, nRst, $01
	smpsSetvoice        $08
	smpsAlterVol        $F8
	smpsPan             panCenter, $00
	smpsModOff
	smpsJump            COI3_Jump03

; FM4 Data
COI3_FM4:
	smpsSetvoice        $00
	smpsAlterVol        $10
	smpsPan             panCenter, $00
	smpsModSet          $00, $02, $03, $03
	dc.b	nRst, $39, nG3, $0C, nRst, $2A
	smpsSetvoice        $05
	dc.b	smpsNoAttack, nRst, $04
	smpsAlterVol        $01
	smpsPan             panRight, $00
	dc.b	nB4, nRst, $0F
	smpsAlterVol        $02
	dc.b	nB4, $05, nRst
	smpsAlterVol        $FE
	dc.b	nB4, $1D

COI3_Jump02:
	smpsAlterVol        $01
	dc.b	nBb4, $0D, nRst, $10, nBb4, $0D, nRst, $0F, nA4, $1D, nG4, $09
	dc.b	nRst, $14, nBb4, $0D, nRst, $0F, nBb4, $0D, nRst, $10, nC5, $0D
	dc.b	nRst, $10, nC5, $0D, nRst, $10, nD5, $0D, nRst, $0F, nD5, $0D
	dc.b	nRst, $10, nC5, $0D, nRst, $10, nB4, $1C, nC5, $0D, nRst, $10
	dc.b	nC5, $0D, nRst, $10, nB4, $0E, nRst, nB4, $0F, nRst, $0E, nBb4
	dc.b	$0D, nRst, $10, nBb4, $0D, nRst, $10, nA4, $1C, nG4, $0A, nRst
	dc.b	$13, nBb4, $0D, nRst, $10, nBb4, $0D, nRst, $0F, nC5, $0E, nRst
	dc.b	$0F, nC5, $0D, nRst, $10, nD5, $0D, nRst, $10, nD5, $0D, nRst
	dc.b	$0F, nC5, $0D, nRst, $10, nB4, $1D, smpsNoAttack
	smpsAlterNote       $07
	dc.b	nB4, $01, smpsNoAttack
	smpsAlterNote       $23
	dc.b	nB4, $01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nC5, $1A, nB4, $1D, nBb4, nA4, $19, nRst, $7F, $7F, $7F, $7F
	dc.b	$7F, $7F, $7F, $7F, $7F, $7F, $7F, $7F, $7F, $7F, $3B
	smpsSetvoice        $0A
	dc.b	smpsNoAttack, nRst, $01
	smpsSetvoice        $0B
	smpsAlterVol        $FA
	smpsPan             panCenter, $00
	smpsModSet          $00, $02, $02, $03
	dc.b	smpsNoAttack, nRst, $03, nC4, $7F, smpsNoAttack, $62, nRst, $05, nC4, $73
	smpsAlterVol        $FF
	dc.b	nF4, $1C
	smpsAlterVol        $03
	dc.b	nEb4, $10, nRst, $17
	smpsAlterVol        $FF
	dc.b	nE4, $04, nRst, $05
	smpsAlterVol        $FE
	dc.b	nE4, nRst
	smpsAlterVol        $FF
	dc.b	nE4, $1C
	smpsAlterVol        $02
	dc.b	nRst, $01, nD4, $3E, nRst, $35
	smpsSetvoice        $05
	smpsAlterVol        $05
	smpsPan             panRight, $00
	smpsModSet          $00, $02, $03, $03
	smpsJump            COI3_Jump02

; FM5 Data
COI3_FM5:
	smpsSetvoice        $03
	smpsAlterVol        $0F
	smpsPan             panLeft, $00
	smpsModSet          $00, $02, $03, $03
	dc.b	nC6, $11, nD6, $04, nC6, $05, nD6, $04, nC6, nD6, nC6, nD6
	dc.b	$05, nC6, $04, nD6, $06, nC6, $0A, nBb5, $09, nA5, $0A, nG5
	dc.b	nF5, $09, nE5, $0A, nD5, $13, nRst, $12
	smpsAlterVol        $FF
	dc.b	nD5, $0C, nE5, $09

COI3_Jump01:
	smpsAlterVol        $01
	dc.b	nE5, $01, nF5, $05, nRst, $0D, nF5, $05, nRst, nF5, $09, nE5
	dc.b	$05, nRst, nD5, $08, nEb5, $01, nE5, $05, nRst, $0E, nD5, $05
	dc.b	nRst, nC5, $17, nRst, $06, nE5, $01, nF5, $05, nRst, $0D, nF5
	dc.b	$04, nRst, $05, nF5, $0A, nE5, $05, nRst, $04, nD5, $05, nRst
	dc.b	nE5, $16, nRst, $07, nE5, $09, nF5, $0A, nG5, nAb5, $01, nA5
	dc.b	$04, nRst, $0E, nA5, $04, nRst, $05, nA5, $0A, nG5, $04, nRst
	dc.b	$05, nF5, $09, nFs5, $01, nG5, $05, nRst, $0E, nE5, $05, nRst
	dc.b	nE5, $09, nF5, $0A, nG5, $09, nAb5, $01, nRst, nA5, $04, nRst
	dc.b	$0D, nA5, $05, nRst, nA5, $0A, nB5, $04, nRst, $05, nA5, nRst
	dc.b	nG5, $2E, nRst, $0B, nE5, $01, nF5, $05, nRst, $0D, nF5, $05
	dc.b	nRst, nF5, $09, nE5, $05, nRst, nD5, $08, nEb5, $02, nE5, $04
	dc.b	nRst, $0F, nD5, $04, nRst, $05, nC5, $17, nRst, $06, nE5, $01
	dc.b	nF5, $05, nRst, $0D, nF5, $05, nRst, nF5, $09, nE5, $05, nRst
	dc.b	nD5, nRst, nE5, $15, nRst, $07, nE5, $0A, nF5, $09, nG5, $0A
	dc.b	nAb5, $01, nA5, $05, nRst, $0D, nA5, $05, nRst, nA5, $09, nG5
	dc.b	$05, nRst, nF5, $08, nFs5, $01, nG5, $05, nRst, $0E, nE5, $05
	dc.b	nRst, nE5, $0A, nF5, $09, nG5, $0A, nAb5, $01, nA5, $05, nRst
	dc.b	$0D, nA5, $05, nRst, $04, nA5, $0A, nB5, $05, nRst, nA5, $04
	dc.b	nRst, $05, nG5, $2F, nRst, $0B
	smpsPan             panRight, $00
	dc.b	nA4, $04, nRst, $0F, nA4, $04, nRst, $05, nB4, nRst, nA4, nRst
	dc.b	$04, nB4, $0A, nC5, $05, nRst, $0E, nC5, $05, nRst, nD5, $04
	dc.b	nRst, $05, nC5, nRst, nD5, $09, nE5, $05, nRst, $0F, nE5, $04
	dc.b	nRst, $05, nE5, $0A, nF5, $04, nRst, $05, nE5, nRst, nD5, $09
	dc.b	nE5, $05, nRst, nD5, nRst, nC5, $04, nRst, $05, nB4, nRst, nBb4
	dc.b	$04, nRst, $05, nA4, nRst, $0E, nA4, $05, nRst, nB4, nRst, nA4
	dc.b	$04, nRst, $05, nB4, $0A, nC5, $04, nRst, $0F, nC5, $05, nRst
	dc.b	$04, nD5, $05, nRst, nC5, nRst, nD5, $09, nE5, $05, nRst, $0E
	dc.b	nE5, $05, nRst, nE5, $09, nF5, $05, nRst, nE5, nRst, nD5, $09
	dc.b	nE5, $05, nRst, nD5, $04, nRst, $05, nC5, nRst, nB4, $04, nRst
	dc.b	$05, nBb4, nRst, nA4, $0D, nRst, $10, nA4, $0D, nRst, $0F, nA4
	dc.b	$0D, nRst, $10, nA4, $0D, nRst, $10, nA4, $0D, nRst, $0F, nA4
	dc.b	$0E, nRst, $0F, nA4, $0D, nRst, $10, nA4, $0D, nRst, $10, nA4
	dc.b	$0D, nRst, $0F, nA4, $0D, nRst, $10, nA4, $0D, nRst, $10, nA4
	dc.b	$0D, nRst, $10, nA4, $0D, nRst, $0F, nA4, $0D, nRst, $10, nA4
	dc.b	$0D, nRst, $10, nA4, $0D, nRst, $0F
	smpsAlterVol        $FF
	dc.b	nB4, $05, nRst, $0E, nB4, $05, nRst, nCs5, nRst, nB4, $04, nRst
	dc.b	$05, nCs5, $0A, nD5, $04, nRst, $0F, nD5, $05, nRst, $04, nE5
	dc.b	$05, nRst, nD5, nRst, nE5, $09, nFs5, $05, nRst, $0E, nFs5, $05
	dc.b	nRst, nFs5, $09, nG5, $05, nRst, nFs5, nRst, nE5, $09, nFs5, $05
	dc.b	nRst, nE5, $04, nRst, $05, nD5, nRst, nCs5, nRst, $04, nC5, $05
	dc.b	nRst, nB4, nRst, $0E, nB4, $05, nRst, nCs5, $04, nRst, $05, nB4
	dc.b	nRst, nCs5, $09, nD5, $05, nRst, $0F, nD5, $04, nRst, $05, nE5
	dc.b	nRst, nD5, $04, nRst, $05, nE5, $0A, nFs5, $05, nRst, $0E, nFs5
	dc.b	$05, nRst, nFs5, $09, nG5, $05, nRst, nFs5, $04, nRst, $05, nE5
	dc.b	$0A, nFs5, $05, nRst, $04, nE5, $05, nRst, nD5, nRst, nCs5, $04
	dc.b	nRst, $05, nC5, nRst
	smpsAlterVol        $01
	dc.b	nB4, $0D, nRst, $0F, nB4, $0D, nRst, $10, nB4, $0D, nRst, $10
	dc.b	nB4, $0D, nRst, $10, nB4, $0D, nRst, $0F, nB4, $0D, nRst, $10
	dc.b	nB4, $0D, nRst, $10, nB4, $0D, nRst, $0F, nB4, $0D, nRst, $10
	dc.b	nB4, $0D, nRst, $10, nB4, $0D, nRst, $10, nB4, $0D, nRst, $0F
	dc.b	nB4, $0D, nRst, $10, nB4, $0D, nRst, $10, nB4, $0D, nRst, $0F
	dc.b	nB4, $0D, nRst, $10
	smpsAlterVol        $FF
	dc.b	nD5, $05, nRst, $0E, nD5, $05, nRst, nE5, nRst, $04, nD5, $05
	dc.b	nRst, nE5, $09, nRst, $01, nF5, $04, nRst, $0F, nF5, $04, nRst
	dc.b	$05, nG5, nRst, nF5, nRst, $04, nG5, $0A, nA5, $05, nRst, $0E
	dc.b	nA5, $05, nRst, nA5, $09, nBb5, $05, nRst, nA5, $04, nRst, $05
	dc.b	nG5, $0A, nA5, $05, nRst, $04, nG5, $05, nRst, nF5, nRst, nE5
	dc.b	$04, nRst, $05, nEb5, $0A, nD5, $04, nRst, $0F, nD5, $05, nRst
	dc.b	nE5, $04, nRst, $05, nD5, nRst, nE5, $09, nF5, $05, nRst, $0E
	dc.b	nF5, $05, nRst, nG5, nRst, $04, nF5, $05, nRst, nG5, $0A, nA5
	dc.b	$04, nRst, $0F, nA5, $04, nRst, $05, nA5, nRst, nBb5, nRst, $04
	dc.b	nB5, $05, nRst, nC6, $15, nRst, $01, nB5, $03, nC6, $04, nCs6
	dc.b	$15, nC6, $04, nCs6, nD6, $3E, nRst, $35
	smpsPan             panLeft, $00
	smpsModOn
	smpsJump            COI3_Jump01

; FM6 Data
COI3_FM6:
	smpsSetvoice        $04
	smpsAlterVol        $0A
	smpsPan             panCenter, $00
	dc.b	nC2, $02, nRst, $11
	smpsAlterVol        $02
	dc.b	nC2, $02, nRst, $08
	smpsAlterVol        $FE
	dc.b	nC2, $02, nRst, $11
	smpsAlterVol        $02
	dc.b	nC2, $02, nRst, $07, smpsNoAttack, nRst, $01
	smpsAlterVol        $FE
	dc.b	nC2, $02, nRst, $10
	smpsAlterVol        $02
	dc.b	smpsNoAttack, nRst, $01, smpsNoAttack, nC2, $02, nRst, $02, smpsNoAttack, nC2, $01
	smpsAlterVol        $02
	dc.b	nC2, $03
	smpsAlterVol        $FD
	dc.b	nC2, $02
	smpsAlterVol        $FF
	dc.b	nC2, $03, nRst, $06, nC2, $02, nRst, $07, nC2, $03, nRst, $07
	dc.b	nC2, $02, nRst, $11
	smpsAlterVol        $02
	dc.b	nC2, $02, nRst, $08
	smpsAlterVol        $FE
	dc.b	nC2, $02, nRst, $11
	smpsAlterVol        $02
	dc.b	nC2, $02, nRst, $08

COI3_Jump00:
	smpsAlterVol        $FE
	dc.b	smpsNoAttack, nRst, $01, smpsNoAttack, nC2, $01, nRst, $11
	smpsAlterVol        $02
	dc.b	nC2, $02, nRst, $03, nC2, $01
	smpsAlterVol        $02
	dc.b	nC2, $02
	smpsAlterVol        $FD
	dc.b	nC2, $03
	smpsAlterVol        $FF
	dc.b	nC2, $02, nRst, $06, nC2, $02, nRst, $08, nC2, $02, nRst, $07
	dc.b	nC2, $03, nRst, $10
	smpsAlterVol        $02
	dc.b	nC2, $03, nRst, $07
	smpsAlterVol        $FE
	dc.b	nC2, $02, nRst, $11
	smpsAlterVol        $02
	dc.b	nC2, $02, nRst, $08
	smpsAlterVol        $FE
	dc.b	nC2, $02, nRst, $11
	smpsAlterVol        $02
	dc.b	nC2, $02, nRst, $03, nC2, $01
	smpsAlterVol        $02
	dc.b	nC2, $02
	smpsAlterVol        $FD
	dc.b	nC2, $03
	smpsAlterVol        $FF
	dc.b	nC2, $02, nRst, $06, nC2, $02, nRst, $07, nC2, $03, nRst, $07
	dc.b	nC2, $02, nRst, $11
	smpsAlterVol        $02
	dc.b	nC2, $03, nRst, $07
	smpsAlterVol        $FE
	dc.b	nC2, $02, nRst, $11
	smpsAlterVol        $02
	dc.b	nC2, $02, nRst, $08
	smpsAlterVol        $FE
	dc.b	nC2, $02, nRst, $11
	smpsAlterVol        $02
	dc.b	nC2, $02, nRst, nC2
	smpsAlterVol        $02
	dc.b	nC2
	smpsAlterVol        $FD
	dc.b	nC2
	smpsAlterVol        $FF
	dc.b	nC2, $03, nRst, $06, nC2, $02, nRst, $07, nC2, $03, nRst, $07
	dc.b	nC2, $02, nRst, $11
	smpsAlterVol        $02
	dc.b	nC2, $02, nRst, $08
	smpsAlterVol        $FE
	dc.b	nC2, $02, nRst, $11
	smpsAlterVol        $02
	dc.b	nC2, $02, nRst, $07
	smpsAlterVol        $FE
	dc.b	smpsNoAttack, nRst, $01, smpsNoAttack, nC2, $02, nRst, $10
	smpsAlterVol        $02
	dc.b	nC2, $03, nRst, $02, nC2, $01
	smpsAlterVol        $02
	dc.b	nC2, $03
	smpsAlterVol        $FD
	dc.b	nC2, $02
	smpsAlterVol        $FF
	dc.b	nC2, $03, nRst, $06, nC2, $02, nRst, $07, nC2, $03, nRst, $06
	dc.b	nC2, $01
	smpsAlterVol        $FF
	dc.b	nC2, $02, nRst, $07
	smpsAlterVol        $01
	dc.b	nC2, $03, nRst, $07, nC2, $02, nRst, $08, nC2, $01, nC2, $02
	dc.b	nRst, $10
	smpsAlterVol        $07
	dc.b	nC2, $02, nC2
	smpsAlterVol        $FB
	dc.b	nC2, $03
	smpsAlterVol        $FF
	dc.b	nC2, $02
	smpsAlterVol        $FF
	dc.b	nC2, $03, nRst, $10
	smpsAlterVol        $02
	dc.b	nC2, $03, nRst, $07
	smpsAlterVol        $FE
	dc.b	nC2, $02, nRst, $11
	smpsAlterVol        $02
	dc.b	nC2, $02, nRst, $08
	smpsAlterVol        $FE
	dc.b	nC2, $02, nRst, $11
	smpsAlterVol        $02
	dc.b	nC2, $02, nRst, $03, nC2, $01
	smpsAlterVol        $02
	dc.b	nC2, $02
	smpsAlterVol        $FD
	dc.b	nC2
	smpsAlterVol        $FF
	dc.b	smpsNoAttack, nC2, $01, smpsNoAttack, nC2, $02, nRst, $06, smpsNoAttack, nC2, $02, nRst
	dc.b	$07, smpsNoAttack, nC2, $03, nRst, $07, nC2, $02, nRst, $11
	smpsAlterVol        $02
	dc.b	nC2, $02, nRst, $08
	smpsAlterVol        $FE
	dc.b	nC2, $02, nRst, $11
	smpsAlterVol        $02
	dc.b	nC2, $02, nRst, $08
	smpsAlterVol        $FE
	dc.b	nC2, $02, nRst, $11
	smpsAlterVol        $02
	dc.b	nC2, $02, nRst, nC2, $01, smpsNoAttack, nC2, $01
	smpsAlterVol        $02
	dc.b	nC2, $02
	smpsAlterVol        $FD
	dc.b	nC2
	smpsAlterVol        $FF
	dc.b	nC2, $03, nRst, $06, nC2, $02, nRst, $07, nC2, $03, nRst, $07
	dc.b	nC2, $02, nRst, $11
	smpsAlterVol        $02
	dc.b	nC2, $02, nRst, $08
	smpsAlterVol        $FE
	dc.b	nC2, $02, nRst, $11
	smpsAlterVol        $02
	dc.b	nC2, $02, nRst, $07
	smpsAlterVol        $FE
	dc.b	nC2, $03, nRst, $10
	smpsAlterVol        $02
	dc.b	nC2, $03, nRst, $02, nC2, $01
	smpsAlterVol        $02
	dc.b	nC2, $03
	smpsAlterVol        $FD
	dc.b	nC2, $02
	smpsAlterVol        $FF
	dc.b	nC2, $03, nRst, $06, nC2, $02, nRst, $07, nC2, $03, nRst, $07
	dc.b	nC2, $02, nRst, $11
	smpsAlterVol        $02
	dc.b	nC2, $02, nRst, $03, nC2, $01
	smpsAlterVol        $02
	dc.b	nC2, $02
	smpsAlterVol        $FD
	dc.b	nC2, $03
	smpsAlterVol        $FF
	dc.b	nC2, $02, nRst, $06, nC2, $02, nRst, $08, nC2, $02, nRst, $06
	dc.b	nC2, $01
	smpsAlterVol        $FF
	dc.b	nC2, $02, nRst, $08
	smpsAlterVol        $01
	dc.b	nC2, $02, nRst, $07, nC2, $03, nRst, $07, nC2, $01, nC2, $02
	dc.b	nRst, $10
	smpsAlterVol        $07
	dc.b	nC2, $02, nC2, $03
	smpsAlterVol        $FB
	dc.b	nC2, $02
	smpsAlterVol        $FF
	dc.b	nC2, $03
	smpsAlterVol        $FF
	dc.b	nC2, $02, nRst, $11
	smpsAlterVol        $02
	dc.b	nC2, $02, nRst, $07
	smpsAlterVol        $FE
	dc.b	nC2, $03, nRst, $10
	smpsAlterVol        $02
	dc.b	nC2, $03, nRst, $07
	smpsAlterVol        $FE
	dc.b	nC2, $02, nRst, $11
	smpsAlterVol        $02
	dc.b	nC2, $02, nRst, $03, nC2, $01
	smpsAlterVol        $02
	dc.b	nC2, $02
	smpsAlterVol        $FD
	dc.b	nC2, $03
	smpsAlterVol        $FF
	dc.b	nC2, $02, nRst, $06, nC2, $03, nRst, $07, nC2, $02, nRst, $07
	smpsAlterVol        $02
	dc.b	smpsNoAttack, nRst, $01, smpsNoAttack, nC2, $01
	smpsAlterVol        $FE
	dc.b	nC2, $02, nRst, $06, nC2, $02, nRst, $08
	smpsAlterVol        $02
	dc.b	nC2, $02, nRst, $07
	smpsAlterVol        $FE
	dc.b	nC2, $02, nRst, $11
	smpsAlterVol        $02
	dc.b	nC2, $03, nRst, $07
	smpsAlterVol        $FE
	dc.b	nC2, $02, nRst, $11
	smpsAlterVol        $02
	dc.b	nC2, $02, nRst, $03, nC2, $01
	smpsAlterVol        $02
	dc.b	nC2, $02
	smpsAlterVol        $FD
	dc.b	nC2, $03
	smpsAlterVol        $FF
	dc.b	nC2, $02, nRst, $06, nC2, $02, nRst, $08, nC2, $02, nRst, $07
	dc.b	nC2, $03, nRst, $10
	smpsAlterVol        $02
	dc.b	nC2, $03, nRst, $07
	smpsAlterVol        $FE
	dc.b	nC2, $02, nRst, $11
	smpsAlterVol        $02
	dc.b	nC2, $02, nRst, $08
	smpsAlterVol        $FE
	dc.b	nC2, $02, nRst, $11
	smpsAlterVol        $02
	dc.b	nC2, $02, nRst, $03, nC2, $01
	smpsAlterVol        $02
	dc.b	nC2, $02
	smpsAlterVol        $FD
	dc.b	nC2, $03
	smpsAlterVol        $FF
	dc.b	nC2, $02, nRst, $06, nC2, $02, nRst, $08, nC2, $02, nRst, $07
	smpsAlterVol        $02
	dc.b	nC2, $01
	smpsAlterVol        $FE
	dc.b	nC2, $03, nRst, $06, nC2, $02, nRst, $07
	smpsAlterVol        $02
	dc.b	nC2, $03, nRst, $07
	smpsAlterVol        $FE
	dc.b	nC2, $02, nRst, $11
	smpsAlterVol        $02
	dc.b	nC2, $02, nRst, $08
	smpsAlterVol        $FE
	dc.b	nC2, $02, nRst, $11
	smpsAlterVol        $02
	dc.b	nC2, $02, nRst, nC2
	smpsAlterVol        $02
	dc.b	nC2
	smpsAlterVol        $FD
	dc.b	nC2
	smpsAlterVol        $FF
	dc.b	nC2, $03, nRst, $06, nC2, $02, nRst, $07, nC2, $03, nRst, $07
	dc.b	nC2, $02, nRst, $11
	smpsAlterVol        $02
	dc.b	nC2, $02, nRst, $08
	smpsAlterVol        $FE
	dc.b	nC2, $02, nRst, $11
	smpsAlterVol        $02
	dc.b	nC2, $02, nRst, $07
	smpsAlterVol        $FE
	dc.b	nC2, $03, nRst, $10
	smpsAlterVol        $02
	dc.b	smpsNoAttack, nRst, $01, smpsNoAttack, nC2, $02, nRst, $02, smpsNoAttack, nC2, $01
	smpsAlterVol        $02
	dc.b	nC2, $03
	smpsAlterVol        $FD
	dc.b	nC2, $02
	smpsAlterVol        $FF
	dc.b	nC2, $03, nRst, $06, nC2, $02, nRst, $07, nC2, $03, nRst, $06
	smpsAlterVol        $02
	dc.b	nC2, $01, nC2, $02, nRst, $07, nC2, $03, nRst, $07, nC2, $02
	dc.b	nRst, $07, smpsNoAttack, nRst, $01
	smpsAlterVol        $FE
	dc.b	nC2, $02, nRst, $11
	smpsAlterVol        $02
	dc.b	nC2, $02, nRst, $07
	smpsAlterVol        $FE
	dc.b	nC2, $03, nRst, $10
	smpsAlterVol        $02
	dc.b	nC2, $03, nRst, $02, nC2, $01
	smpsAlterVol        $02
	dc.b	nC2, $03
	smpsAlterVol        $FD
	dc.b	nC2, $02
	smpsAlterVol        $FF
	dc.b	nC2, nRst, $06, nC2, $03, nRst, $07, nC2, $02, nRst, $08, nC2
	dc.b	$02, nRst, $11
	smpsAlterVol        $02
	dc.b	nC2, $02, nRst, $07
	smpsAlterVol        $FE
	dc.b	nC2, $03, nRst, $10
	smpsAlterVol        $02
	dc.b	nC2, $03, nRst, $07
	smpsAlterVol        $FE
	dc.b	nC2, $02, nRst, $11
	smpsAlterVol        $02
	dc.b	nC2, $03, nRst, $02, nC2, $01
	smpsAlterVol        $02
	dc.b	nC2, $02
	smpsAlterVol        $FD
	dc.b	smpsNoAttack, nC2, $01, smpsNoAttack, nC2, $02
	smpsAlterVol        $FF
	dc.b	nC2, nRst, $06, nC2, $03, nRst, $07, nC2, $02, nRst, $06
	smpsAlterVol        $02
	dc.b	nC2, $02, nC2, nRst, $07, nC2, $02, nRst, $08, nC2, $02, nRst
	dc.b	$07
	smpsAlterVol        $FE
	dc.b	nC2, $03, nRst, $10
	smpsAlterVol        $02
	dc.b	nC2, $03, nRst, $07
	smpsAlterVol        $FE
	dc.b	nC2, $02, nRst, $11
	smpsAlterVol        $02
	dc.b	nC2, $02, nRst, $03, nC2, $01
	smpsAlterVol        $02
	dc.b	nC2, $02
	smpsAlterVol        $FD
	dc.b	nC2, $03
	smpsAlterVol        $FF
	dc.b	nC2, $02, nRst, $06, nC2, $03, nRst, $07, nC2, $02, nRst, $08
	dc.b	nC2, $02, nRst, $10
	smpsAlterVol        $02
	dc.b	smpsNoAttack, nRst, $01, smpsNoAttack, nC2, $02, nRst, $07
	smpsAlterVol        $FE
	dc.b	nC2, $02, nRst, $11
	smpsAlterVol        $02
	dc.b	nC2, $02, nRst, $08
	smpsAlterVol        $FE
	dc.b	nC2, $02, nRst, $11
	smpsAlterVol        $02
	dc.b	nC2, $02, nRst, $03, nC2, $01
	smpsAlterVol        $02
	dc.b	nC2, $02
	smpsAlterVol        $FD
	dc.b	nC2, $03
	smpsAlterVol        $FF
	dc.b	nC2, $02, nRst, $06, nC2, $02, nRst, $08, nC2, $02, nRst, $06
	smpsAlterVol        $02
	dc.b	nC2, $01, nC2, $03, nRst, $07, nC2, $02, nRst, $07, nC2, $03
	dc.b	nRst, $07
	smpsAlterVol        $FE
	dc.b	nC2, $02, nRst, $11
	smpsAlterVol        $02
	dc.b	nC2, $02, nRst, $08
	smpsAlterVol        $FE
	dc.b	nC2, $02, nRst, $11
	smpsAlterVol        $02
	dc.b	nC2, $02, nRst, nC2
	smpsAlterVol        $02
	dc.b	nC2
	smpsAlterVol        $FD
	dc.b	nC2
	smpsAlterVol        $FF
	dc.b	nRst, $01, smpsNoAttack, nC2, $02, nRst, $06, smpsNoAttack, nC2, $02, nRst, $07
	dc.b	smpsNoAttack, nC2, $03, nRst, $07, nC2, $02, nRst, $11
	smpsAlterVol        $02
	dc.b	nC2, $02, nRst, $08
	smpsAlterVol        $FE
	dc.b	nC2, $02, nRst, $11
	smpsAlterVol        $02
	dc.b	nC2, $02, nRst, $08
	smpsAlterVol        $FE
	dc.b	nC2, $02, nRst, $11
	smpsAlterVol        $02
	dc.b	nC2, $02, nRst, nC2, $01
	smpsAlterVol        $02
	dc.b	nRst, $01, smpsNoAttack, nC2, $02
	smpsAlterVol        $FD
	dc.b	nC2
	smpsAlterVol        $FF
	dc.b	nC2, $03, nRst, $06, nC2, $02, nRst, $07, nC2, $03, nRst, $06
	smpsAlterVol        $02
	dc.b	nC2, $01, nC2, $02, nRst, $07, nC2, $03, nRst, $07, nC2, $02
	dc.b	nRst, $08
	smpsAlterVol        $FE
	dc.b	nC2, $02, nRst, $11
	smpsAlterVol        $02
	dc.b	nC2, $02, nRst, $07
	smpsAlterVol        $FE
	dc.b	nC2, $03, nRst, $10
	smpsAlterVol        $02
	dc.b	nC2, $03, nRst, $02, nC2, $01
	smpsAlterVol        $02
	dc.b	nC2, $03
	smpsAlterVol        $FD
	dc.b	nC2, $02
	smpsAlterVol        $FF
	dc.b	nC2, $03, nRst, $06, nC2, $02, nRst, $07, nC2, $02, nRst, $08
	dc.b	nC2, $02, nRst, $11
	smpsAlterVol        $02
	dc.b	nC2, $02, nRst, $07
	smpsAlterVol        $FE
	dc.b	smpsNoAttack, nRst, $01, smpsNoAttack, nC2, $02, nRst, $11
	smpsAlterVol        $02
	dc.b	nC2, $02, nRst, $07
	smpsAlterVol        $FE
	dc.b	nC2, $02, nRst, $11
	smpsAlterVol        $02
	dc.b	nC2, $03, nRst, $02, nC2, $01
	smpsAlterVol        $02
	dc.b	nC2, $03
	smpsAlterVol        $FD
	dc.b	nC2, $02
	smpsAlterVol        $FF
	dc.b	nC2, nRst, $06, nC2, $03, nRst, $07, nC2, $02, nRst, $06
	smpsAlterVol        $02
	dc.b	nC2, $02, nC2, nRst, $07, nC2, $02, nRst, $08, nC2, $02, nRst
	dc.b	$07
	smpsAlterVol        $FE
	dc.b	nC2, $03, nRst, $10
	smpsAlterVol        $02
	dc.b	nC2, $03, nRst, $07
	smpsAlterVol        $FE
	dc.b	nC2, $02, nRst, $11
	smpsAlterVol        $02
	dc.b	nC2, $02, nRst, $03, nC2, $01
	smpsAlterVol        $02
	dc.b	nC2, $02
	smpsAlterVol        $FD
	dc.b	nC2, $03
	smpsAlterVol        $FF
	dc.b	nC2, $02, nRst, $06, nC2, $03, nRst, $07, nC2, $02, nRst, $07
	dc.b	smpsNoAttack, nRst, $01, smpsNoAttack, nC2, $02, nRst, $10
	smpsAlterVol        $02
	dc.b	smpsNoAttack, nRst, $01, smpsNoAttack, nC2, $02, nRst, $07
	smpsAlterVol        $FE
	dc.b	nC2, $02, nRst, $11
	smpsAlterVol        $02
	dc.b	nC2, $03, nRst, $07
	smpsAlterVol        $FE
	dc.b	nC2, $02, nRst, $11
	smpsAlterVol        $02
	dc.b	nC2, $02, nRst, $03, nC2, $01
	smpsAlterVol        $02
	dc.b	nC2, $02
	smpsAlterVol        $FD
	dc.b	nC2, $03
	smpsAlterVol        $FF
	dc.b	nC2, $02, nRst, $06, nC2, $02, nRst, $08, nC2, $02, nRst, $06
	smpsAlterVol        $02
	dc.b	nC2, $01, nC2, $03, nRst, $07, nC2, $02, nRst, $07, nC2, $03
	dc.b	nRst, $07
	smpsAlterVol        $FE
	dc.b	nC2, $02, nRst, $11
	smpsAlterVol        $02
	dc.b	nC2, $02, nRst, $08
	smpsAlterVol        $FE
	dc.b	nC2, $02, nRst, $11
	smpsAlterVol        $02
	dc.b	nC2, $02, nRst, $03, nC2, $01
	smpsAlterVol        $02
	dc.b	nC2, $02
	smpsAlterVol        $FD
	dc.b	nC2, $03
	smpsAlterVol        $FF
	dc.b	nC2, $02, nRst, $06, nC2, $02, nRst, $07, nC2, $03, nRst, $07
	dc.b	nC2, $02, nRst, $11
	smpsAlterVol        $02
	dc.b	nC2, $03, nRst, $02, nC2, $01
	smpsAlterVol        $02
	dc.b	nC2, $03
	smpsAlterVol        $FD
	dc.b	nC2, $02
	smpsAlterVol        $FF
	dc.b	nC2, nRst, $06, nC2, $03, nRst, $07, nC2, $02, nRst, $08, nC2
	dc.b	$02, nRst, $11
	smpsAlterVol        $02
	dc.b	nC2, $02, nRst, $07
	smpsAlterVol        $FE
	dc.b	nC2, $03, nRst, $10
	smpsAlterVol        $02
	dc.b	nC2, $03, nRst, $07
	smpsAlterVol        $FE
	dc.b	nC2, $02, nRst, $11
	smpsAlterVol        $02
	dc.b	nC2, $02, nRst, $03, nC2, $01
	smpsAlterVol        $02
	dc.b	nC2, $02
	smpsAlterVol        $FD
	dc.b	nC2, $03
	smpsAlterVol        $FF
	dc.b	nC2, $02, nRst, $06, nC2, $03, nRst, $07, nC2, $02, nRst, $07
	dc.b	nC2, $03, nRst, $10, smpsNoAttack, nRst, $01
	smpsAlterVol        $02
	dc.b	nC2, $02, nRst, $07
	smpsAlterVol        $FE
	dc.b	nC2, $02, nRst, $11
	smpsAlterVol        $02
	dc.b	nC2, $03, nRst, $07
	smpsAlterVol        $FE
	dc.b	nC2, $02, nRst, $11
	smpsAlterVol        $02
	dc.b	nC2, $02, nRst, $03, nC2, $01
	smpsAlterVol        $02
	dc.b	nC2, $02
	smpsAlterVol        $FD
	dc.b	nC2, $03
	smpsAlterVol        $FF
	dc.b	nC2, $02, nRst, $06, nC2, $02, nRst, $08, nC2, $02, nRst, $07
	dc.b	nC2, $03, nRst, $10, nC2, $03, nRst, $02, nC2, nC2, $03, nC2
	dc.b	$02, nRst, $08, nC2, $02, nRst, $07, nC2, $02, nRst, $08
	smpsAlterVol        $FF
	dc.b	nC2, $02, nRst, $07, nC2, $02, nRst, $08, nC2, $02, nRst, $03
	dc.b	nC2, $01, nC2, $02, nC2, nRst, $01, nC2, $02, nRst, $06, nC2
	dc.b	$02, nRst, $07, nC2, $03, nRst, $06, nC2, $01, nC2, $02, nRst
	dc.b	$08, nC2, $02, nRst, $07, nC2, $03, nRst, $07, nC2, $01, nC2
	dc.b	$02, nRst, nC2, nC2, nC2, $03, nC2, $02, nC2, nC2, $03, nC2
	dc.b	$02, nC2, $03, nC2, $02, nC2, $03, nC2, $02, nRst, $11, nC2
	dc.b	$02, nRst, nC2, $03, nC2, $02, nC2, nRst, $08, nC2, $02, nRst
	dc.b	$07, nC2, $03, nRst, $07, nC2, $02, nRst, $07, nC2, $03, nRst
	dc.b	$07, nC2, $02, nRst, $03, nC2, $02, nC2, $03, nC2, $02, nRst
	dc.b	$1B
	smpsAlterVol        $03
	smpsPan             panCenter, $00
	smpsJump            COI3_Jump00

; PSG1 Data
COI3_PSG1:
	dc.b	nRst, $7F, $7F, $7F, $7F, $7F, $7F, $7F, $7F, $4C

COI3_Jump06:
	dc.b	nRst, $7F, $7F, $7F, $7F, $7F, $7F, $7F, $1E
	smpsPSGAlterVol     $03
	dc.b	nF1, $04
	smpsPSGAlterVol     $01
	dc.b	nF1
	smpsPSGAlterVol     $01
	dc.b	nF1
	smpsPSGAlterVol     $01
	dc.b	nF1
	smpsPSGAlterVol     $01
	dc.b	nF1
	smpsPSGAlterVol     $01
	dc.b	nF1, $05
	smpsPSGAlterVol     $01
	dc.b	nF1, $03
	smpsPSGAlterVol     $FA
	dc.b	nG1, $04
	smpsPSGAlterVol     $01
	dc.b	nG1, $05
	smpsPSGAlterVol     $01
	dc.b	nG1, $04
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $FA
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1, $05
	smpsPSGAlterVol     $01
	dc.b	nA1, $04
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $FA
	dc.b	nB1
	smpsPSGAlterVol     $01
	dc.b	nB1
	smpsPSGAlterVol     $01
	dc.b	nB1
	smpsPSGAlterVol     $01
	dc.b	nB1
	smpsPSGAlterVol     $01
	dc.b	nB1, $05
	smpsPSGAlterVol     $01
	dc.b	nB1, $04
	smpsPSGAlterVol     $01
	dc.b	nB1
	smpsPSGAlterVol     $FA
	dc.b	nC2
	smpsPSGAlterVol     $01
	dc.b	nC2
	smpsPSGAlterVol     $01
	dc.b	nC2
	smpsPSGAlterVol     $01
	dc.b	nC2
	smpsPSGAlterVol     $01
	dc.b	nC2
	smpsPSGAlterVol     $01
	dc.b	nC2, $05
	smpsPSGAlterVol     $01
	dc.b	nC2, $03
	smpsPSGAlterVol     $FA
	dc.b	nBb1, $04
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, $05
	smpsPSGAlterVol     $01
	dc.b	nBb1, $04
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $FA
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1, $05
	smpsPSGAlterVol     $01
	dc.b	nA1, $04
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $FA
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1, $05
	smpsPSGAlterVol     $01
	dc.b	nG1, $03
	smpsPSGAlterVol     $FA
	dc.b	nF1, $04
	smpsPSGAlterVol     $01
	dc.b	nF1, $05
	smpsPSGAlterVol     $01
	dc.b	nF1, $04
	smpsPSGAlterVol     $01
	dc.b	nF1
	smpsPSGAlterVol     $01
	dc.b	nF1
	smpsPSGAlterVol     $01
	dc.b	nF1
	smpsPSGAlterVol     $01
	dc.b	nF1
	smpsPSGAlterVol     $FA
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1, $05
	smpsPSGAlterVol     $01
	dc.b	nG1, $04
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $FA
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1, $05
	smpsPSGAlterVol     $01
	dc.b	nA1, $04
	smpsPSGAlterVol     $01
	dc.b	nA1, $03
	smpsPSGAlterVol     $FA
	dc.b	nB1, $05
	smpsPSGAlterVol     $01
	dc.b	nB1, $04
	smpsPSGAlterVol     $01
	dc.b	nB1
	smpsPSGAlterVol     $01
	dc.b	nB1
	smpsPSGAlterVol     $01
	dc.b	nB1
	smpsPSGAlterVol     $01
	dc.b	nB1
	smpsPSGAlterVol     $01
	dc.b	nB1
	smpsPSGAlterVol     $FA
	dc.b	nC2
	smpsPSGAlterVol     $01
	dc.b	nC2
	smpsPSGAlterVol     $01
	dc.b	nC2, $05
	smpsPSGAlterVol     $01
	dc.b	nC2, $04
	smpsPSGAlterVol     $01
	dc.b	nC2
	smpsPSGAlterVol     $01
	dc.b	nC2
	smpsPSGAlterVol     $01
	dc.b	nC2
	smpsPSGAlterVol     $FA
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, $05
	smpsPSGAlterVol     $01
	dc.b	nBb1, $04
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $FA
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1, $05
	smpsPSGAlterVol     $01
	dc.b	nA1, $03
	smpsPSGAlterVol     $FA
	dc.b	nG1, $04
	smpsPSGAlterVol     $01
	dc.b	nG1, $05
	smpsPSGAlterVol     $01
	dc.b	nG1, $04
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $FA
	dc.b	nG0
	smpsPSGAlterVol     $01
	dc.b	nG0
	smpsPSGAlterVol     $01
	dc.b	nG0, $05
	smpsPSGAlterVol     $01
	dc.b	nG0, $04
	smpsPSGAlterVol     $01
	dc.b	nG0
	smpsPSGAlterVol     $01
	dc.b	nG0
	smpsPSGAlterVol     $01
	dc.b	nG0
	smpsPSGAlterVol     $FA
	dc.b	nA0
	smpsPSGAlterVol     $01
	dc.b	nA0
	smpsPSGAlterVol     $01
	dc.b	nA0
	smpsPSGAlterVol     $01
	dc.b	nA0
	smpsPSGAlterVol     $01
	dc.b	nA0, $05
	smpsPSGAlterVol     $01
	dc.b	nA0, $04
	smpsPSGAlterVol     $01
	dc.b	nA0
	smpsPSGAlterVol     $FA
	dc.b	nB0
	smpsPSGAlterVol     $01
	dc.b	nB0
	smpsPSGAlterVol     $01
	dc.b	nB0
	smpsPSGAlterVol     $01
	dc.b	nB0
	smpsPSGAlterVol     $01
	dc.b	nB0
	smpsPSGAlterVol     $01
	dc.b	nB0, $05
	smpsPSGAlterVol     $01
	dc.b	nB0, $03
	smpsPSGAlterVol     $FA
	dc.b	nCs1, $04
	smpsPSGAlterVol     $01
	dc.b	nCs1
	smpsPSGAlterVol     $01
	dc.b	nCs1, $05
	smpsPSGAlterVol     $01
	dc.b	nCs1, $04
	smpsPSGAlterVol     $01
	dc.b	nCs1
	smpsPSGAlterVol     $01
	dc.b	nCs1
	smpsPSGAlterVol     $01
	dc.b	nCs1
	smpsPSGAlterVol     $FA
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, $05
	smpsPSGAlterVol     $01
	dc.b	nD1, $04
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $FA
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, $05
	smpsPSGAlterVol     $01
	dc.b	nD1, $03
	smpsPSGAlterVol     $FA
	dc.b	nD1, $04
	smpsPSGAlterVol     $01
	dc.b	nD1, $05
	smpsPSGAlterVol     $01
	dc.b	nD1, $04
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $FA
	dc.b	nA0
	smpsPSGAlterVol     $01
	dc.b	nA0
	smpsPSGAlterVol     $01
	dc.b	nA0
	smpsPSGAlterVol     $01
	dc.b	nA0, $05
	smpsPSGAlterVol     $01
	dc.b	nA0, $04
	smpsPSGAlterVol     $01
	dc.b	nA0
	smpsPSGAlterVol     $01
	dc.b	nA0
	smpsPSGAlterVol     $FA
	dc.b	nG0
	smpsPSGAlterVol     $01
	dc.b	nG0
	smpsPSGAlterVol     $01
	dc.b	nG0
	smpsPSGAlterVol     $01
	dc.b	nG0
	smpsPSGAlterVol     $01
	dc.b	nG0, $05
	smpsPSGAlterVol     $01
	dc.b	nG0, $04
	smpsPSGAlterVol     $01
	dc.b	nG0, $03
	smpsPSGAlterVol     $FA
	dc.b	nA0, $05
	smpsPSGAlterVol     $01
	dc.b	nA0, $04
	smpsPSGAlterVol     $01
	dc.b	nA0
	smpsPSGAlterVol     $01
	dc.b	nA0
	smpsPSGAlterVol     $01
	dc.b	nA0
	smpsPSGAlterVol     $01
	dc.b	nA0
	smpsPSGAlterVol     $01
	dc.b	nA0
	smpsPSGAlterVol     $FA
	dc.b	nB0
	smpsPSGAlterVol     $01
	dc.b	nB0
	smpsPSGAlterVol     $01
	dc.b	nB0, $05
	smpsPSGAlterVol     $01
	dc.b	nB0, $04
	smpsPSGAlterVol     $01
	dc.b	nB0
	smpsPSGAlterVol     $01
	dc.b	nB0
	smpsPSGAlterVol     $01
	dc.b	nB0
	smpsPSGAlterVol     $FA
	dc.b	nCs1
	smpsPSGAlterVol     $01
	dc.b	nCs1
	smpsPSGAlterVol     $01
	dc.b	nCs1
	smpsPSGAlterVol     $01
	dc.b	nCs1
	smpsPSGAlterVol     $01
	dc.b	nCs1, $05
	smpsPSGAlterVol     $01
	dc.b	nCs1, $04
	smpsPSGAlterVol     $01
	dc.b	nCs1
	smpsPSGAlterVol     $FA
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, $05
	smpsPSGAlterVol     $01
	dc.b	nD1, $03
	smpsPSGAlterVol     $FA
	dc.b	nD1, $04
	smpsPSGAlterVol     $01
	dc.b	nD1, $05
	smpsPSGAlterVol     $01
	dc.b	nD1, $04
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $FA
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, $05
	smpsPSGAlterVol     $01
	dc.b	nD1, $04
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $FA
	dc.b	nA0
	smpsPSGAlterVol     $01
	dc.b	nA0
	smpsPSGAlterVol     $01
	dc.b	nA0
	smpsPSGAlterVol     $01
	dc.b	nA0
	smpsPSGAlterVol     $01
	dc.b	nA0
	smpsPSGAlterVol     $01
	dc.b	nA0, $05
	smpsPSGAlterVol     $01
	dc.b	nA0, $04
	smpsPSGAlterVol     $FA
	dc.b	nG1, $03
	smpsPSGAlterVol     $01
	dc.b	nG1, $05
	smpsPSGAlterVol     $01
	dc.b	nG1, $04
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $FA
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1, $05
	smpsPSGAlterVol     $01
	dc.b	nA1, $04
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $FA
	dc.b	nB1
	smpsPSGAlterVol     $01
	dc.b	nB1
	smpsPSGAlterVol     $01
	dc.b	nB1
	smpsPSGAlterVol     $01
	dc.b	nB1
	smpsPSGAlterVol     $01
	dc.b	nB1, $05
	smpsPSGAlterVol     $01
	dc.b	nB1, $04
	smpsPSGAlterVol     $01
	dc.b	nB1
	smpsPSGAlterVol     $FA
	dc.b	nCs2
	smpsPSGAlterVol     $01
	dc.b	nCs2
	smpsPSGAlterVol     $01
	dc.b	nCs2
	smpsPSGAlterVol     $01
	dc.b	nCs2
	smpsPSGAlterVol     $01
	dc.b	nCs2
	smpsPSGAlterVol     $01
	dc.b	nCs2, $05
	smpsPSGAlterVol     $01
	dc.b	nCs2, $03
	smpsPSGAlterVol     $FA
	dc.b	nD2, $04
	smpsPSGAlterVol     $01
	dc.b	nD2
	smpsPSGAlterVol     $01
	dc.b	nD2, $05
	smpsPSGAlterVol     $01
	dc.b	nD2, $04
	smpsPSGAlterVol     $01
	dc.b	nD2
	smpsPSGAlterVol     $01
	dc.b	nD2
	smpsPSGAlterVol     $01
	dc.b	nD2
	smpsPSGAlterVol     $FA
	dc.b	nC2
	smpsPSGAlterVol     $01
	dc.b	nC2
	smpsPSGAlterVol     $01
	dc.b	nC2
	smpsPSGAlterVol     $01
	dc.b	nC2, $05
	smpsPSGAlterVol     $01
	dc.b	nC2, $04
	smpsPSGAlterVol     $01
	dc.b	nC2
	smpsPSGAlterVol     $01
	dc.b	nC2
	smpsPSGAlterVol     $FA
	dc.b	nB1
	smpsPSGAlterVol     $01
	dc.b	nB1
	smpsPSGAlterVol     $01
	dc.b	nB1
	smpsPSGAlterVol     $01
	dc.b	nB1
	smpsPSGAlterVol     $01
	dc.b	nB1
	smpsPSGAlterVol     $01
	dc.b	nB1, $05
	smpsPSGAlterVol     $01
	dc.b	nB1, $03
	smpsPSGAlterVol     $FA
	dc.b	nA1, $04
	smpsPSGAlterVol     $01
	dc.b	nA1, $05
	smpsPSGAlterVol     $01
	dc.b	nA1, $04
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $FA
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1, $05
	smpsPSGAlterVol     $01
	dc.b	nG1, $04
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $FA
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1, $05
	smpsPSGAlterVol     $01
	dc.b	nA1, $04
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $FA
	dc.b	nB1
	smpsPSGAlterVol     $01
	dc.b	nB1
	smpsPSGAlterVol     $01
	dc.b	nB1
	smpsPSGAlterVol     $01
	dc.b	nB1
	smpsPSGAlterVol     $01
	dc.b	nB1
	smpsPSGAlterVol     $01
	dc.b	nB1, $05
	smpsPSGAlterVol     $01
	dc.b	nB1, $03
	smpsPSGAlterVol     $FA
	dc.b	nCs2, $04
	smpsPSGAlterVol     $01
	dc.b	nCs2
	smpsPSGAlterVol     $01
	dc.b	nCs2, $05
	smpsPSGAlterVol     $01
	dc.b	nCs2, $04
	smpsPSGAlterVol     $01
	dc.b	nCs2
	smpsPSGAlterVol     $01
	dc.b	nCs2
	smpsPSGAlterVol     $01
	dc.b	nCs2
	smpsPSGAlterVol     $FA
	dc.b	nD2
	smpsPSGAlterVol     $01
	dc.b	nD2
	smpsPSGAlterVol     $01
	dc.b	nD2
	smpsPSGAlterVol     $01
	dc.b	nD2, $05
	smpsPSGAlterVol     $01
	dc.b	nD2, $04
	smpsPSGAlterVol     $01
	dc.b	nD2
	smpsPSGAlterVol     $01
	dc.b	nD2
	smpsPSGAlterVol     $FA
	dc.b	nC2
	smpsPSGAlterVol     $01
	dc.b	nC2
	smpsPSGAlterVol     $01
	dc.b	nC2
	smpsPSGAlterVol     $01
	dc.b	nC2
	smpsPSGAlterVol     $01
	dc.b	nC2
	smpsPSGAlterVol     $01
	dc.b	nC2, $05
	smpsPSGAlterVol     $01
	dc.b	nC2, $03
	smpsPSGAlterVol     $FA
	dc.b	nB1, $04
	smpsPSGAlterVol     $01
	dc.b	nB1, $05
	smpsPSGAlterVol     $01
	dc.b	nB1, $04
	smpsPSGAlterVol     $01
	dc.b	nB1
	smpsPSGAlterVol     $01
	dc.b	nB1
	smpsPSGAlterVol     $01
	dc.b	nB1
	smpsPSGAlterVol     $01
	dc.b	nB1
	smpsPSGAlterVol     $FA
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1, $05
	smpsPSGAlterVol     $01
	dc.b	nA1, $04
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $FA
	dc.b	nA0
	smpsPSGAlterVol     $01
	dc.b	nA0
	smpsPSGAlterVol     $01
	dc.b	nA0
	smpsPSGAlterVol     $01
	dc.b	nA0
	smpsPSGAlterVol     $01
	dc.b	nA0, $05
	smpsPSGAlterVol     $01
	dc.b	nA0, $04
	smpsPSGAlterVol     $01
	dc.b	nA0
	smpsPSGAlterVol     $FA
	dc.b	nB0
	smpsPSGAlterVol     $01
	dc.b	nB0
	smpsPSGAlterVol     $01
	dc.b	nB0
	smpsPSGAlterVol     $01
	dc.b	nB0
	smpsPSGAlterVol     $01
	dc.b	nB0
	smpsPSGAlterVol     $01
	dc.b	nB0, $05
	smpsPSGAlterVol     $01
	dc.b	nB0, $03
	smpsPSGAlterVol     $FA
	dc.b	nCs1, $04
	smpsPSGAlterVol     $01
	dc.b	nCs1
	smpsPSGAlterVol     $01
	dc.b	nCs1, $05
	smpsPSGAlterVol     $01
	dc.b	nCs1, $04
	smpsPSGAlterVol     $01
	dc.b	nCs1
	smpsPSGAlterVol     $01
	dc.b	nCs1
	smpsPSGAlterVol     $01
	dc.b	nCs1
	smpsPSGAlterVol     $FA
	dc.b	nEb1
	smpsPSGAlterVol     $01
	dc.b	nEb1
	smpsPSGAlterVol     $01
	dc.b	nEb1
	smpsPSGAlterVol     $01
	dc.b	nEb1, $05
	smpsPSGAlterVol     $01
	dc.b	nEb1, $04
	smpsPSGAlterVol     $01
	dc.b	nEb1
	smpsPSGAlterVol     $01
	dc.b	nEb1
	smpsPSGAlterVol     $FA
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, $05
	smpsPSGAlterVol     $01
	dc.b	nE1, $03
	smpsPSGAlterVol     $FA
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1, $05
	smpsPSGAlterVol     $01
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $FA
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, $05
	smpsPSGAlterVol     $01
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $FA
	dc.b	nB0
	smpsPSGAlterVol     $01
	dc.b	nB0
	smpsPSGAlterVol     $01
	dc.b	nB0
	smpsPSGAlterVol     $01
	dc.b	nB0
	smpsPSGAlterVol     $01
	dc.b	nB0, $05
	smpsPSGAlterVol     $01
	dc.b	nB0, $04
	smpsPSGAlterVol     $01
	dc.b	nB0
	smpsPSGAlterVol     $FA
	dc.b	nA0
	smpsPSGAlterVol     $01
	dc.b	nA0
	smpsPSGAlterVol     $01
	dc.b	nA0
	smpsPSGAlterVol     $01
	dc.b	nA0
	smpsPSGAlterVol     $01
	dc.b	nA0
	smpsPSGAlterVol     $01
	dc.b	nA0
	smpsPSGAlterVol     $01
	dc.b	nA0
	smpsPSGAlterVol     $FA
	dc.b	nB0
	smpsPSGAlterVol     $01
	dc.b	nB0
	smpsPSGAlterVol     $01
	dc.b	nB0, $05
	smpsPSGAlterVol     $01
	dc.b	nB0, $04
	smpsPSGAlterVol     $01
	dc.b	nB0
	smpsPSGAlterVol     $01
	dc.b	nB0
	smpsPSGAlterVol     $01
	dc.b	nB0
	smpsPSGAlterVol     $FA
	dc.b	nCs1
	smpsPSGAlterVol     $01
	dc.b	nCs1
	smpsPSGAlterVol     $01
	dc.b	nCs1
	smpsPSGAlterVol     $01
	dc.b	nCs1
	smpsPSGAlterVol     $01
	dc.b	nCs1, $05
	smpsPSGAlterVol     $01
	dc.b	nCs1, $04
	smpsPSGAlterVol     $01
	dc.b	nCs1
	smpsPSGAlterVol     $FA
	dc.b	nEb1
	smpsPSGAlterVol     $01
	dc.b	nEb1
	smpsPSGAlterVol     $01
	dc.b	nEb1
	smpsPSGAlterVol     $01
	dc.b	nEb1
	smpsPSGAlterVol     $01
	dc.b	nEb1
	smpsPSGAlterVol     $01
	dc.b	nEb1, $05
	smpsPSGAlterVol     $01
	dc.b	nEb1, $03
	smpsPSGAlterVol     $FA
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1, $05
	smpsPSGAlterVol     $01
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $FA
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, $05
	smpsPSGAlterVol     $01
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $FA
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, $05
	smpsPSGAlterVol     $01
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1, $03
	smpsPSGAlterVol     $FA
	dc.b	nB0, $05
	smpsPSGAlterVol     $01
	dc.b	nB0, $04
	smpsPSGAlterVol     $01
	dc.b	nB0
	smpsPSGAlterVol     $01
	dc.b	nB0
	smpsPSGAlterVol     $01
	dc.b	nB0
	smpsPSGAlterVol     $01
	dc.b	nB0, $05
	smpsPSGAlterVol     $01
	dc.b	nB0, $03
	smpsPSGAlterVol     $FA
	dc.b	nBb1, $04
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, $05
	smpsPSGAlterVol     $01
	dc.b	nBb1, $04
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $FA
	dc.b	nC2
	smpsPSGAlterVol     $01
	dc.b	nC2
	smpsPSGAlterVol     $01
	dc.b	nC2
	smpsPSGAlterVol     $01
	dc.b	nC2
	smpsPSGAlterVol     $01
	dc.b	nC2, $05
	smpsPSGAlterVol     $01
	dc.b	nC2, $04
	smpsPSGAlterVol     $01
	dc.b	nC2
	smpsPSGAlterVol     $FA
	dc.b	nD2
	smpsPSGAlterVol     $01
	dc.b	nD2
	smpsPSGAlterVol     $01
	dc.b	nD2
	smpsPSGAlterVol     $01
	dc.b	nD2
	smpsPSGAlterVol     $01
	dc.b	nD2
	smpsPSGAlterVol     $01
	dc.b	nD2, $05
	smpsPSGAlterVol     $01
	dc.b	nD2, $03
	smpsPSGAlterVol     $FA
	dc.b	nE2, $04
	smpsPSGAlterVol     $01
	dc.b	nE2, $05
	smpsPSGAlterVol     $01
	dc.b	nE2, $04
	smpsPSGAlterVol     $01
	dc.b	nE2
	smpsPSGAlterVol     $01
	dc.b	nE2
	smpsPSGAlterVol     $01
	dc.b	nE2
	smpsPSGAlterVol     $01
	dc.b	nE2
	smpsPSGAlterVol     $FA
	dc.b	nF2
	smpsPSGAlterVol     $01
	dc.b	nF2
	smpsPSGAlterVol     $01
	dc.b	nF2
	smpsPSGAlterVol     $01
	dc.b	nF2, $05
	smpsPSGAlterVol     $01
	dc.b	nF2, $04
	smpsPSGAlterVol     $01
	dc.b	nF2
	smpsPSGAlterVol     $01
	dc.b	nF2
	smpsPSGAlterVol     $FA
	dc.b	nEb2
	smpsPSGAlterVol     $01
	dc.b	nEb2
	smpsPSGAlterVol     $01
	dc.b	nEb2
	smpsPSGAlterVol     $01
	dc.b	nEb2
	smpsPSGAlterVol     $01
	dc.b	nEb2, $05
	smpsPSGAlterVol     $01
	dc.b	nEb2, $04
	smpsPSGAlterVol     $01
	dc.b	nEb2
	smpsPSGAlterVol     $FA
	dc.b	nD2
	smpsPSGAlterVol     $01
	dc.b	nD2
	smpsPSGAlterVol     $01
	dc.b	nD2
	smpsPSGAlterVol     $01
	dc.b	nD2
	smpsPSGAlterVol     $01
	dc.b	nD2
	smpsPSGAlterVol     $01
	dc.b	nD2
	smpsPSGAlterVol     $01
	dc.b	nD2
	smpsPSGAlterVol     $FA
	dc.b	nC2
	smpsPSGAlterVol     $01
	dc.b	nC2
	smpsPSGAlterVol     $01
	dc.b	nC2, $05
	smpsPSGAlterVol     $01
	dc.b	nC2, $04
	smpsPSGAlterVol     $01
	dc.b	nC2
	smpsPSGAlterVol     $01
	dc.b	nC2
	smpsPSGAlterVol     $01
	dc.b	nC2
	smpsPSGAlterVol     $FA
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, $05
	smpsPSGAlterVol     $01
	dc.b	nBb1, $04
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $FA
	dc.b	nC2
	smpsPSGAlterVol     $01
	dc.b	nC2
	smpsPSGAlterVol     $01
	dc.b	nC2
	smpsPSGAlterVol     $01
	dc.b	nC2
	smpsPSGAlterVol     $01
	dc.b	nC2
	smpsPSGAlterVol     $01
	dc.b	nC2, $05
	smpsPSGAlterVol     $01
	dc.b	nC2, $03
	smpsPSGAlterVol     $FA
	dc.b	nD2, $04
	smpsPSGAlterVol     $01
	dc.b	nD2, $05
	smpsPSGAlterVol     $01
	dc.b	nD2, $04
	smpsPSGAlterVol     $01
	dc.b	nD2
	smpsPSGAlterVol     $01
	dc.b	nD2
	smpsPSGAlterVol     $01
	dc.b	nD2
	smpsPSGAlterVol     $01
	dc.b	nD2
	smpsPSGAlterVol     $FA
	dc.b	nE2
	smpsPSGAlterVol     $01
	dc.b	nE2
	smpsPSGAlterVol     $01
	dc.b	nE2
	smpsPSGAlterVol     $01
	dc.b	nE2, $05
	smpsPSGAlterVol     $01
	dc.b	nE2, $04
	smpsPSGAlterVol     $01
	dc.b	nE2
	smpsPSGAlterVol     $01
	dc.b	nE2
	smpsPSGAlterVol     $FA
	dc.b	nF2
	smpsPSGAlterVol     $01
	dc.b	nF2
	smpsPSGAlterVol     $01
	dc.b	nF2
	smpsPSGAlterVol     $01
	dc.b	nF2
	smpsPSGAlterVol     $01
	dc.b	nF2, $05
	smpsPSGAlterVol     $01
	dc.b	nF2, $04
	smpsPSGAlterVol     $01
	dc.b	nF2, $03, nA1, $01
	smpsPSGAlterVol     $FB
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1, $1B
	smpsPSGAlterVol     $08
	dc.b	nE1, $01
	smpsPSGAlterVol     $F7
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, $1B
	smpsPSGAlterVol     $02
	dc.b	nCs1, $01
	smpsPSGAlterVol     $FD
	dc.b	nCs1
	smpsPSGAlterVol     $01
	dc.b	nCs1, $1B
	smpsPSGAlterVol     $02
	dc.b	nD1, $01
	smpsPSGAlterVol     $FE
	dc.b	nD1, $3D
	smpsPSGAlterVol     $02
	dc.b	nD1, $01
	smpsPSGAlterVol     $02
	dc.b	nD1
	smpsPSGAlterVol     $02
	dc.b	nD1
	smpsPSGAlterVol     $02
	dc.b	nD1, nRst, $31
	smpsPSGAlterVol     $F3
	smpsJump            COI3_Jump06

; PSG2 Data
COI3_PSG2:
	dc.b	nRst, $7F, $7F, $7F, $7F, $7F, $7F, $7F, $7F, $4C

COI3_Jump05:
	dc.b	nRst, $7F, $7F, $7F, $7F, $7F, $7F, $7F, $1E
	smpsPSGAlterVol     $03
	dc.b	nD1, $04
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1, $05
	smpsPSGAlterVol     $01
	dc.b	nD1, $03
	smpsPSGAlterVol     $FA
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1, $05
	smpsPSGAlterVol     $01
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $FA
	dc.b	nF1
	smpsPSGAlterVol     $01
	dc.b	nF1
	smpsPSGAlterVol     $01
	dc.b	nF1, $05
	smpsPSGAlterVol     $01
	dc.b	nF1, $04
	smpsPSGAlterVol     $01
	dc.b	nF1
	smpsPSGAlterVol     $01
	dc.b	nF1
	smpsPSGAlterVol     $01
	dc.b	nF1
	smpsPSGAlterVol     $FA
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1, $05
	smpsPSGAlterVol     $01
	dc.b	nG1, $04
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $FA
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1, $05
	smpsPSGAlterVol     $01
	dc.b	nG1, $03
	smpsPSGAlterVol     $FA
	dc.b	nG1, $04
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1, $05
	smpsPSGAlterVol     $01
	dc.b	nG1, $04
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $FA
	dc.b	nF1
	smpsPSGAlterVol     $01
	dc.b	nF1
	smpsPSGAlterVol     $01
	dc.b	nF1
	smpsPSGAlterVol     $01
	dc.b	nF1, $05
	smpsPSGAlterVol     $01
	dc.b	nF1, $04
	smpsPSGAlterVol     $01
	dc.b	nF1
	smpsPSGAlterVol     $01
	dc.b	nF1
	smpsPSGAlterVol     $FA
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, $05
	smpsPSGAlterVol     $01
	dc.b	nE1, $03
	smpsPSGAlterVol     $FA
	dc.b	nD1, $04
	smpsPSGAlterVol     $01
	dc.b	nD1, $05
	smpsPSGAlterVol     $01
	dc.b	nD1, $04
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $01
	dc.b	nD1
	smpsPSGAlterVol     $FA
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, $05
	smpsPSGAlterVol     $01
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $FA
	dc.b	nF1
	smpsPSGAlterVol     $01
	dc.b	nF1
	smpsPSGAlterVol     $01
	dc.b	nF1
	smpsPSGAlterVol     $01
	dc.b	nF1
	smpsPSGAlterVol     $01
	dc.b	nF1, $05
	smpsPSGAlterVol     $01
	dc.b	nF1, $04
	smpsPSGAlterVol     $01
	dc.b	nF1, $03, nG1, $01
	smpsPSGAlterVol     $FA
	dc.b	nG1, $04
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1, $05
	smpsPSGAlterVol     $01
	dc.b	nG1, $03
	smpsPSGAlterVol     $FA
	dc.b	nG1, $04
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1, $05
	smpsPSGAlterVol     $01
	dc.b	nG1, $04
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $FA
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1, $05
	smpsPSGAlterVol     $01
	dc.b	nG1, $04
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $FA
	dc.b	nF1
	smpsPSGAlterVol     $01
	dc.b	nF1
	smpsPSGAlterVol     $01
	dc.b	nF1
	smpsPSGAlterVol     $01
	dc.b	nF1
	smpsPSGAlterVol     $01
	dc.b	nF1
	smpsPSGAlterVol     $01
	dc.b	nF1, $05
	smpsPSGAlterVol     $01
	dc.b	nF1, $03
	smpsPSGAlterVol     $FA
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1, $05
	smpsPSGAlterVol     $01
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $FA
	dc.b	nE0
	smpsPSGAlterVol     $01
	dc.b	nE0
	smpsPSGAlterVol     $01
	dc.b	nE0, $05
	smpsPSGAlterVol     $01
	dc.b	nE0, $04
	smpsPSGAlterVol     $01
	dc.b	nE0
	smpsPSGAlterVol     $01
	dc.b	nE0
	smpsPSGAlterVol     $01
	dc.b	nE0
	smpsPSGAlterVol     $FA
	dc.b	nFs0
	smpsPSGAlterVol     $01
	dc.b	nFs0
	smpsPSGAlterVol     $01
	dc.b	nFs0
	smpsPSGAlterVol     $01
	dc.b	nFs0
	smpsPSGAlterVol     $01
	dc.b	nFs0, $05
	smpsPSGAlterVol     $01
	dc.b	nFs0, $04
	smpsPSGAlterVol     $01
	dc.b	nFs0
	smpsPSGAlterVol     $FA
	dc.b	nG0
	smpsPSGAlterVol     $01
	dc.b	nG0
	smpsPSGAlterVol     $01
	dc.b	nG0
	smpsPSGAlterVol     $01
	dc.b	nG0
	smpsPSGAlterVol     $01
	dc.b	nG0
	smpsPSGAlterVol     $01
	dc.b	nG0, $05
	smpsPSGAlterVol     $01
	dc.b	nG0, $03
	smpsPSGAlterVol     $FA
	dc.b	nA0, $04
	smpsPSGAlterVol     $01
	dc.b	nA0
	smpsPSGAlterVol     $01
	dc.b	nA0, $05
	smpsPSGAlterVol     $01
	dc.b	nA0, $04
	smpsPSGAlterVol     $01
	dc.b	nA0
	smpsPSGAlterVol     $01
	dc.b	nA0
	smpsPSGAlterVol     $01
	dc.b	nA0
	smpsPSGAlterVol     $FA
	dc.b	nB0
	smpsPSGAlterVol     $01
	dc.b	nB0
	smpsPSGAlterVol     $01
	dc.b	nB0
	smpsPSGAlterVol     $01
	dc.b	nB0, $05
	smpsPSGAlterVol     $01
	dc.b	nB0, $04
	smpsPSGAlterVol     $01
	dc.b	nB0
	smpsPSGAlterVol     $01
	dc.b	nB0
	smpsPSGAlterVol     $FA
	dc.b	nCs1
	smpsPSGAlterVol     $01
	dc.b	nCs1
	smpsPSGAlterVol     $01
	dc.b	nCs1
	smpsPSGAlterVol     $01
	dc.b	nCs1
	smpsPSGAlterVol     $01
	dc.b	nCs1
	smpsPSGAlterVol     $01
	dc.b	nCs1, $05
	smpsPSGAlterVol     $01
	dc.b	nCs1, $03
	smpsPSGAlterVol     $FA
	dc.b	nB0, $04
	smpsPSGAlterVol     $01
	dc.b	nB0, $05
	smpsPSGAlterVol     $01
	dc.b	nB0, $04
	smpsPSGAlterVol     $01
	dc.b	nB0
	smpsPSGAlterVol     $01
	dc.b	nB0
	smpsPSGAlterVol     $01
	dc.b	nB0
	smpsPSGAlterVol     $01
	dc.b	nB0
	smpsPSGAlterVol     $FA
	dc.b	nFs0
	smpsPSGAlterVol     $01
	dc.b	nFs0
	smpsPSGAlterVol     $01
	dc.b	nFs0, $05
	smpsPSGAlterVol     $01
	dc.b	nFs0, $04
	smpsPSGAlterVol     $01
	dc.b	nFs0
	smpsPSGAlterVol     $01
	dc.b	nFs0
	smpsPSGAlterVol     $01
	dc.b	nFs0
	smpsPSGAlterVol     $FA
	dc.b	nE0
	smpsPSGAlterVol     $01
	dc.b	nE0
	smpsPSGAlterVol     $01
	dc.b	nE0
	smpsPSGAlterVol     $01
	dc.b	nE0
	smpsPSGAlterVol     $01
	dc.b	nE0, $05
	smpsPSGAlterVol     $01
	dc.b	nE0, $04
	smpsPSGAlterVol     $01
	dc.b	nE0
	smpsPSGAlterVol     $FA
	dc.b	nFs0
	smpsPSGAlterVol     $01
	dc.b	nFs0
	smpsPSGAlterVol     $01
	dc.b	nFs0
	smpsPSGAlterVol     $01
	dc.b	nFs0
	smpsPSGAlterVol     $01
	dc.b	nFs0
	smpsPSGAlterVol     $01
	dc.b	nFs0
	smpsPSGAlterVol     $01
	dc.b	nFs0
	smpsPSGAlterVol     $FA
	dc.b	nG0
	smpsPSGAlterVol     $01
	dc.b	nG0
	smpsPSGAlterVol     $01
	dc.b	nG0, $05
	smpsPSGAlterVol     $01
	dc.b	nG0, $04
	smpsPSGAlterVol     $01
	dc.b	nG0
	smpsPSGAlterVol     $01
	dc.b	nG0
	smpsPSGAlterVol     $01
	dc.b	nG0
	smpsPSGAlterVol     $FA
	dc.b	nA0
	smpsPSGAlterVol     $01
	dc.b	nA0
	smpsPSGAlterVol     $01
	dc.b	nA0
	smpsPSGAlterVol     $01
	dc.b	nA0
	smpsPSGAlterVol     $01
	dc.b	nA0, $05
	smpsPSGAlterVol     $01
	dc.b	nA0, $04
	smpsPSGAlterVol     $01
	dc.b	nA0
	smpsPSGAlterVol     $FA
	dc.b	nB0
	smpsPSGAlterVol     $01
	dc.b	nB0
	smpsPSGAlterVol     $01
	dc.b	nB0
	smpsPSGAlterVol     $01
	dc.b	nB0
	smpsPSGAlterVol     $01
	dc.b	nB0
	smpsPSGAlterVol     $01
	dc.b	nB0, $05
	smpsPSGAlterVol     $01
	dc.b	nB0, $03
	smpsPSGAlterVol     $FA
	dc.b	nCs1, $04
	smpsPSGAlterVol     $01
	dc.b	nCs1, $05
	smpsPSGAlterVol     $01
	dc.b	nCs1, $04
	smpsPSGAlterVol     $01
	dc.b	nCs1
	smpsPSGAlterVol     $01
	dc.b	nCs1
	smpsPSGAlterVol     $01
	dc.b	nCs1
	smpsPSGAlterVol     $01
	dc.b	nCs1
	smpsPSGAlterVol     $FA
	dc.b	nB0
	smpsPSGAlterVol     $01
	dc.b	nB0
	smpsPSGAlterVol     $01
	dc.b	nB0
	smpsPSGAlterVol     $01
	dc.b	nB0, $05
	smpsPSGAlterVol     $01
	dc.b	nB0, $04
	smpsPSGAlterVol     $01
	dc.b	nB0
	smpsPSGAlterVol     $01
	dc.b	nB0
	smpsPSGAlterVol     $FA
	dc.b	nFs0
	smpsPSGAlterVol     $01
	dc.b	nFs0
	smpsPSGAlterVol     $01
	dc.b	nFs0
	smpsPSGAlterVol     $01
	dc.b	nFs0
	smpsPSGAlterVol     $01
	dc.b	nFs0, $05
	smpsPSGAlterVol     $01
	dc.b	nFs0, $04
	smpsPSGAlterVol     $01
	dc.b	nFs0
	smpsPSGAlterVol     $FA
	dc.b	nE1, $03
	smpsPSGAlterVol     $01
	dc.b	nE1, $05
	smpsPSGAlterVol     $01
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $FA
	dc.b	nFs1
	smpsPSGAlterVol     $01
	dc.b	nFs1
	smpsPSGAlterVol     $01
	dc.b	nFs1, $05
	smpsPSGAlterVol     $01
	dc.b	nFs1, $04
	smpsPSGAlterVol     $01
	dc.b	nFs1
	smpsPSGAlterVol     $01
	dc.b	nFs1
	smpsPSGAlterVol     $01
	dc.b	nFs1
	smpsPSGAlterVol     $FA
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1, $05
	smpsPSGAlterVol     $01
	dc.b	nG1, $04
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $FA
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1, $05
	smpsPSGAlterVol     $01
	dc.b	nA1, $03
	smpsPSGAlterVol     $FA
	dc.b	nA1, $04
	smpsPSGAlterVol     $01
	dc.b	nA1, $05
	smpsPSGAlterVol     $01
	dc.b	nA1, $04
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $FA
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1, $05
	smpsPSGAlterVol     $01
	dc.b	nA1, $04
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $FA
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1, $05
	smpsPSGAlterVol     $01
	dc.b	nG1, $04
	smpsPSGAlterVol     $01
	dc.b	nG1, $03
	smpsPSGAlterVol     $FA
	dc.b	nFs1, $04
	smpsPSGAlterVol     $01
	dc.b	nFs1, $05
	smpsPSGAlterVol     $01
	dc.b	nFs1, $04
	smpsPSGAlterVol     $01
	dc.b	nFs1
	smpsPSGAlterVol     $01
	dc.b	nFs1
	smpsPSGAlterVol     $01
	dc.b	nFs1
	smpsPSGAlterVol     $01
	dc.b	nFs1
	smpsPSGAlterVol     $FA
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1, $05
	smpsPSGAlterVol     $01
	dc.b	nE1, $04
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $01
	dc.b	nE1
	smpsPSGAlterVol     $FA
	dc.b	nFs1
	smpsPSGAlterVol     $01
	dc.b	nFs1
	smpsPSGAlterVol     $01
	dc.b	nFs1
	smpsPSGAlterVol     $01
	dc.b	nFs1
	smpsPSGAlterVol     $01
	dc.b	nFs1, $05
	smpsPSGAlterVol     $01
	dc.b	nFs1, $04
	smpsPSGAlterVol     $01
	dc.b	nFs1
	smpsPSGAlterVol     $FA
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1, $05
	smpsPSGAlterVol     $01
	dc.b	nG1, $03
	smpsPSGAlterVol     $FA
	dc.b	nA1, $04
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1, $05
	smpsPSGAlterVol     $01
	dc.b	nA1, $04
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $FA
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1, $05
	smpsPSGAlterVol     $01
	dc.b	nA1, $04
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $FA
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1, $05
	smpsPSGAlterVol     $01
	dc.b	nA1, $03
	smpsPSGAlterVol     $FA
	dc.b	nG1, $04
	smpsPSGAlterVol     $01
	dc.b	nG1, $05
	smpsPSGAlterVol     $01
	dc.b	nG1, $04
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $FA
	dc.b	nFs1
	smpsPSGAlterVol     $01
	dc.b	nFs1
	smpsPSGAlterVol     $01
	dc.b	nFs1, $05
	smpsPSGAlterVol     $01
	dc.b	nFs1, $04
	smpsPSGAlterVol     $01
	dc.b	nFs1
	smpsPSGAlterVol     $01
	dc.b	nFs1
	smpsPSGAlterVol     $01
	dc.b	nFs1
	smpsPSGAlterVol     $FA
	dc.b	nFs0
	smpsPSGAlterVol     $01
	dc.b	nFs0
	smpsPSGAlterVol     $01
	dc.b	nFs0
	smpsPSGAlterVol     $01
	dc.b	nFs0
	smpsPSGAlterVol     $01
	dc.b	nFs0, $05
	smpsPSGAlterVol     $01
	dc.b	nFs0, $04
	smpsPSGAlterVol     $01
	dc.b	nFs0
	smpsPSGAlterVol     $FA
	dc.b	nAb0
	smpsPSGAlterVol     $01
	dc.b	nAb0
	smpsPSGAlterVol     $01
	dc.b	nAb0
	smpsPSGAlterVol     $01
	dc.b	nAb0
	smpsPSGAlterVol     $01
	dc.b	nAb0
	smpsPSGAlterVol     $01
	dc.b	nAb0, $05
	smpsPSGAlterVol     $01
	dc.b	nAb0, $03
	smpsPSGAlterVol     $FA
	dc.b	nA0, $04
	smpsPSGAlterVol     $01
	dc.b	nA0
	smpsPSGAlterVol     $01
	dc.b	nA0, $05
	smpsPSGAlterVol     $01
	dc.b	nA0, $04
	smpsPSGAlterVol     $01
	dc.b	nA0
	smpsPSGAlterVol     $01
	dc.b	nA0
	smpsPSGAlterVol     $01
	dc.b	nA0
	smpsPSGAlterVol     $FA
	dc.b	nB0
	smpsPSGAlterVol     $01
	dc.b	nB0
	smpsPSGAlterVol     $01
	dc.b	nB0
	smpsPSGAlterVol     $01
	dc.b	nB0, $05
	smpsPSGAlterVol     $01
	dc.b	nB0, $04
	smpsPSGAlterVol     $01
	dc.b	nB0
	smpsPSGAlterVol     $01
	dc.b	nB0
	smpsPSGAlterVol     $FA
	dc.b	nCs1
	smpsPSGAlterVol     $01
	dc.b	nCs1
	smpsPSGAlterVol     $01
	dc.b	nCs1
	smpsPSGAlterVol     $01
	dc.b	nCs1
	smpsPSGAlterVol     $01
	dc.b	nCs1
	smpsPSGAlterVol     $01
	dc.b	nCs1, $05
	smpsPSGAlterVol     $01
	dc.b	nCs1, $03
	smpsPSGAlterVol     $FA
	dc.b	nEb1, $04
	smpsPSGAlterVol     $01
	dc.b	nEb1, $05
	smpsPSGAlterVol     $01
	dc.b	nEb1, $04
	smpsPSGAlterVol     $01
	dc.b	nEb1
	smpsPSGAlterVol     $01
	dc.b	nEb1
	smpsPSGAlterVol     $01
	dc.b	nEb1
	smpsPSGAlterVol     $01
	dc.b	nEb1
	smpsPSGAlterVol     $FA
	dc.b	nCs1
	smpsPSGAlterVol     $01
	dc.b	nCs1
	smpsPSGAlterVol     $01
	dc.b	nCs1, $05
	smpsPSGAlterVol     $01
	dc.b	nCs1, $04
	smpsPSGAlterVol     $01
	dc.b	nCs1
	smpsPSGAlterVol     $01
	dc.b	nCs1
	smpsPSGAlterVol     $01
	dc.b	nCs1
	smpsPSGAlterVol     $FA
	dc.b	nAb0
	smpsPSGAlterVol     $01
	dc.b	nAb0
	smpsPSGAlterVol     $01
	dc.b	nAb0
	smpsPSGAlterVol     $01
	dc.b	nAb0
	smpsPSGAlterVol     $01
	dc.b	nAb0, $05
	smpsPSGAlterVol     $01
	dc.b	nAb0, $04
	smpsPSGAlterVol     $01
	dc.b	nAb0
	smpsPSGAlterVol     $FA
	dc.b	nFs0
	smpsPSGAlterVol     $01
	dc.b	nFs0
	smpsPSGAlterVol     $01
	dc.b	nFs0
	smpsPSGAlterVol     $01
	dc.b	nFs0
	smpsPSGAlterVol     $01
	dc.b	nFs0
	smpsPSGAlterVol     $01
	dc.b	nFs0
	smpsPSGAlterVol     $01
	dc.b	nFs0
	smpsPSGAlterVol     $FA
	dc.b	nAb0
	smpsPSGAlterVol     $01
	dc.b	nAb0
	smpsPSGAlterVol     $01
	dc.b	nAb0, $05
	smpsPSGAlterVol     $01
	dc.b	nAb0, $04
	smpsPSGAlterVol     $01
	dc.b	nAb0
	smpsPSGAlterVol     $01
	dc.b	nAb0
	smpsPSGAlterVol     $01
	dc.b	nAb0
	smpsPSGAlterVol     $FA
	dc.b	nA0
	smpsPSGAlterVol     $01
	dc.b	nA0
	smpsPSGAlterVol     $01
	dc.b	nA0
	smpsPSGAlterVol     $01
	dc.b	nA0, $05
	smpsPSGAlterVol     $01
	dc.b	nA0, $04
	smpsPSGAlterVol     $01
	dc.b	nA0
	smpsPSGAlterVol     $01
	dc.b	nA0
	smpsPSGAlterVol     $FA
	dc.b	nB0
	smpsPSGAlterVol     $01
	dc.b	nB0
	smpsPSGAlterVol     $01
	dc.b	nB0
	smpsPSGAlterVol     $01
	dc.b	nB0
	smpsPSGAlterVol     $01
	dc.b	nB0
	smpsPSGAlterVol     $01
	dc.b	nB0, $05
	smpsPSGAlterVol     $01
	dc.b	nB0, $03
	smpsPSGAlterVol     $FA
	dc.b	nCs1, $04
	smpsPSGAlterVol     $01
	dc.b	nCs1, $05
	smpsPSGAlterVol     $01
	dc.b	nCs1, $04
	smpsPSGAlterVol     $01
	dc.b	nCs1
	smpsPSGAlterVol     $01
	dc.b	nCs1
	smpsPSGAlterVol     $01
	dc.b	nCs1
	smpsPSGAlterVol     $01
	dc.b	nCs1
	smpsPSGAlterVol     $FA
	dc.b	nEb1
	smpsPSGAlterVol     $01
	dc.b	nEb1
	smpsPSGAlterVol     $01
	dc.b	nEb1, $05
	smpsPSGAlterVol     $01
	dc.b	nEb1, $04
	smpsPSGAlterVol     $01
	dc.b	nEb1
	smpsPSGAlterVol     $01
	dc.b	nEb1
	smpsPSGAlterVol     $01
	dc.b	nEb1
	smpsPSGAlterVol     $FA
	dc.b	nCs1
	smpsPSGAlterVol     $01
	dc.b	nCs1
	smpsPSGAlterVol     $01
	dc.b	nCs1
	smpsPSGAlterVol     $01
	dc.b	nCs1
	smpsPSGAlterVol     $01
	dc.b	nCs1, $05
	smpsPSGAlterVol     $01
	dc.b	nCs1, $04
	smpsPSGAlterVol     $01
	dc.b	nCs1, $03
	smpsPSGAlterVol     $FA
	dc.b	nAb0, $05
	smpsPSGAlterVol     $01
	dc.b	nAb0, $04
	smpsPSGAlterVol     $01
	dc.b	nAb0
	smpsPSGAlterVol     $01
	dc.b	nAb0
	smpsPSGAlterVol     $01
	dc.b	nAb0
	smpsPSGAlterVol     $01
	dc.b	nAb0, $05
	smpsPSGAlterVol     $01
	dc.b	nAb0, $03
	smpsPSGAlterVol     $FA
	dc.b	nG1, $04
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1, $05
	smpsPSGAlterVol     $01
	dc.b	nG1, $04
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $FA
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1, $05
	smpsPSGAlterVol     $01
	dc.b	nA1, $04
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $FA
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1, $05
	smpsPSGAlterVol     $01
	dc.b	nBb1, $03
	smpsPSGAlterVol     $FA
	dc.b	nC2, $04
	smpsPSGAlterVol     $01
	dc.b	nC2, $05
	smpsPSGAlterVol     $01
	dc.b	nC2, $04
	smpsPSGAlterVol     $01
	dc.b	nC2
	smpsPSGAlterVol     $01
	dc.b	nC2
	smpsPSGAlterVol     $01
	dc.b	nC2
	smpsPSGAlterVol     $01
	dc.b	nC2
	smpsPSGAlterVol     $FA
	dc.b	nC2
	smpsPSGAlterVol     $01
	dc.b	nC2
	smpsPSGAlterVol     $01
	dc.b	nC2
	smpsPSGAlterVol     $01
	dc.b	nC2, $05
	smpsPSGAlterVol     $01
	dc.b	nC2, $04
	smpsPSGAlterVol     $01
	dc.b	nC2
	smpsPSGAlterVol     $01
	dc.b	nC2
	smpsPSGAlterVol     $FA
	dc.b	nC2
	smpsPSGAlterVol     $01
	dc.b	nC2
	smpsPSGAlterVol     $01
	dc.b	nC2
	smpsPSGAlterVol     $01
	dc.b	nC2
	smpsPSGAlterVol     $01
	dc.b	nC2, $05
	smpsPSGAlterVol     $01
	dc.b	nC2, $04
	smpsPSGAlterVol     $01
	dc.b	nC2
	smpsPSGAlterVol     $FA
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $FA
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1, $05
	smpsPSGAlterVol     $01
	dc.b	nA1, $04
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $FA
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1, $05
	smpsPSGAlterVol     $01
	dc.b	nG1, $04
	smpsPSGAlterVol     $01
	dc.b	nG1
	smpsPSGAlterVol     $FA
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1
	smpsPSGAlterVol     $01
	dc.b	nA1, $05
	smpsPSGAlterVol     $01
	dc.b	nA1, $03
	smpsPSGAlterVol     $FA
	dc.b	nBb1, $04
	smpsPSGAlterVol     $01
	dc.b	nBb1, $05
	smpsPSGAlterVol     $01
	dc.b	nBb1, $04
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $01
	dc.b	nBb1
	smpsPSGAlterVol     $FA
	dc.b	nC2
	smpsPSGAlterVol     $01
	dc.b	nC2
	smpsPSGAlterVol     $01
	dc.b	nC2, $05
	smpsPSGAlterVol     $01
	dc.b	nC2, $04
	smpsPSGAlterVol     $01
	dc.b	nC2
	smpsPSGAlterVol     $01
	dc.b	nC2
	smpsPSGAlterVol     $01
	dc.b	nC2
	smpsPSGAlterVol     $FA
	dc.b	nC2
	smpsPSGAlterVol     $01
	dc.b	nC2
	smpsPSGAlterVol     $01
	dc.b	nC2
	smpsPSGAlterVol     $01
	dc.b	nC2
	smpsPSGAlterVol     $01
	dc.b	nC2, $05
	smpsPSGAlterVol     $01
	dc.b	nC2, $04
	smpsPSGAlterVol     $01
	dc.b	nC2
	smpsPSGAlterVol     $FB
	dc.b	nC2, $01
	smpsPSGAlterVol     $01
	dc.b	nC2, $1B
	smpsPSGAlterVol     $08
	dc.b	nAb1, $01
	smpsPSGAlterVol     $F7
	dc.b	nAb1
	smpsPSGAlterVol     $01
	dc.b	nAb1, $1B
	smpsPSGAlterVol     $02
	dc.b	nG1, $01
	smpsPSGAlterVol     $FD
	dc.b	nG1
	smpsPSGAlterVol     $01
	dc.b	nG1, $1B
	smpsPSGAlterVol     $02
	dc.b	nFs1, $01
	smpsPSGAlterVol     $FE
	dc.b	nFs1, $3D
	smpsPSGAlterVol     $02
	dc.b	nFs1, $01
	smpsPSGAlterVol     $02
	dc.b	nFs1
	smpsPSGAlterVol     $02
	dc.b	nFs1
	smpsPSGAlterVol     $02
	dc.b	nFs1, nRst, $31
	smpsPSGAlterVol     $F3
	smpsJump            COI3_Jump05

COI3_Voices:
;	Voice $00
;	$3C
;	$01, $02, $01, $01, 	$1F, $10, $1F, $10, 	$00, $08, $00, $08
;	$00, $00, $00, $00, 	$09, $29, $09, $19, 	$1D, $00, $1E, $00
	smpsVcAlgorithm     $04
	smpsVcFeedback      $07
	smpsVcUnusedBits    $00
	smpsVcDetune        $00, $00, $00, $00
	smpsVcCoarseFreq    $01, $01, $02, $01
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $10, $1F, $10, $1F
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $08, $00, $08, $00
	smpsVcDecayRate2    $00, $00, $00, $00
	smpsVcDecayLevel    $01, $00, $02, $00
	smpsVcReleaseRate   $09, $09, $09, $09
	smpsVcTotalLevel    $00, $1E, $00, $1D

;	Voice $01
;	$3C
;	$02, $52, $41, $11, 	$8E, $91, $8F, $95, 	$0C, $08, $09, $07
;	$00, $00, $00, $00, 	$28, $39, $28, $39, 	$18, $00, $13, $00
	smpsVcAlgorithm     $04
	smpsVcFeedback      $07
	smpsVcUnusedBits    $00
	smpsVcDetune        $01, $04, $05, $00
	smpsVcCoarseFreq    $01, $01, $02, $02
	smpsVcRateScale     $02, $02, $02, $02
	smpsVcAttackRate    $15, $0F, $11, $0E
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $07, $09, $08, $0C
	smpsVcDecayRate2    $00, $00, $00, $00
	smpsVcDecayLevel    $03, $02, $03, $02
	smpsVcReleaseRate   $09, $08, $09, $08
	smpsVcTotalLevel    $00, $13, $00, $18

;	Voice $02
;	$39
;	$02, $00, $71, $30, 	$5F, $98, $5F, $9F, 	$0C, $05, $07, $0C
;	$10, $03, $03, $06, 	$FF, $FF, $FF, $FF, 	$7F, $7F, $7F, $00
	smpsVcAlgorithm     $01
	smpsVcFeedback      $07
	smpsVcUnusedBits    $00
	smpsVcDetune        $03, $07, $00, $00
	smpsVcCoarseFreq    $00, $01, $00, $02
	smpsVcRateScale     $02, $01, $02, $01
	smpsVcAttackRate    $1F, $1F, $18, $1F
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $0C, $07, $05, $0C
	smpsVcDecayRate2    $06, $03, $03, $10
	smpsVcDecayLevel    $0F, $0F, $0F, $0F
	smpsVcReleaseRate   $0F, $0F, $0F, $0F
	smpsVcTotalLevel    $00, $7F, $7F, $7F

;	Voice $03
;	$3A
;	$72, $35, $72, $31, 	$50, $10, $1F, $50, 	$04, $14, $14, $1F
;	$00, $00, $00, $00, 	$1B, $8A, $2A, $0A, 	$2B, $28, $35, $00
	smpsVcAlgorithm     $02
	smpsVcFeedback      $07
	smpsVcUnusedBits    $00
	smpsVcDetune        $03, $07, $03, $07
	smpsVcCoarseFreq    $01, $02, $05, $02
	smpsVcRateScale     $01, $00, $00, $01
	smpsVcAttackRate    $10, $1F, $10, $10
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $1F, $14, $14, $04
	smpsVcDecayRate2    $00, $00, $00, $00
	smpsVcDecayLevel    $00, $02, $08, $01
	smpsVcReleaseRate   $0A, $0A, $0A, $0B
	smpsVcTotalLevel    $00, $35, $28, $2B

;	Voice $04
;	$3C
;	$08, $00, $30, $00, 	$1F, $17, $1F, $1C, 	$0E, $10, $17, $0E
;	$00, $16, $14, $10, 	$0A, $EA, $5A, $2A, 	$00, $00, $00, $00
	smpsVcAlgorithm     $04
	smpsVcFeedback      $07
	smpsVcUnusedBits    $00
	smpsVcDetune        $00, $03, $00, $00
	smpsVcCoarseFreq    $00, $00, $00, $08
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $1C, $1F, $17, $1F
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $0E, $17, $10, $0E
	smpsVcDecayRate2    $10, $14, $16, $00
	smpsVcDecayLevel    $02, $05, $0E, $00
	smpsVcReleaseRate   $0A, $0A, $0A, $0A
	smpsVcTotalLevel    $00, $00, $00, $00

;	Voice $05
;	$3B
;	$45, $42, $02, $41, 	$10, $12, $11, $13, 	$11, $1F, $1F, $10
;	$10, $00, $00, $00, 	$3A, $0A, $0A, $1A, 	$1F, $30, $20, $00
	smpsVcAlgorithm     $03
	smpsVcFeedback      $07
	smpsVcUnusedBits    $00
	smpsVcDetune        $04, $00, $04, $04
	smpsVcCoarseFreq    $01, $02, $02, $05
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $13, $11, $12, $10
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $10, $1F, $1F, $11
	smpsVcDecayRate2    $00, $00, $00, $10
	smpsVcDecayLevel    $01, $00, $00, $03
	smpsVcReleaseRate   $0A, $0A, $0A, $0A
	smpsVcTotalLevel    $00, $20, $30, $1F

;	Voice $06
;	$3C
;	$01, $02, $01, $01, 	$1F, $10, $1F, $10, 	$00, $08, $00, $08
;	$00, $00, $00, $00, 	$FF, $FF, $FF, $FF, 	$1D, $00, $1E, $00
	smpsVcAlgorithm     $04
	smpsVcFeedback      $07
	smpsVcUnusedBits    $00
	smpsVcDetune        $00, $00, $00, $00
	smpsVcCoarseFreq    $01, $01, $02, $01
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $10, $1F, $10, $1F
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $08, $00, $08, $00
	smpsVcDecayRate2    $00, $00, $00, $00
	smpsVcDecayLevel    $0F, $0F, $0F, $0F
	smpsVcReleaseRate   $0F, $0F, $0F, $0F
	smpsVcTotalLevel    $00, $1E, $00, $1D

;	Voice $07
;	$2C
;	$01, $01, $02, $02, 	$1F, $1E, $1F, $1F, 	$0F, $0E, $0F, $0E
;	$0E, $03, $0E, $03, 	$DB, $FA, $DB, $FA, 	$21, $00, $21, $00
	smpsVcAlgorithm     $04
	smpsVcFeedback      $05
	smpsVcUnusedBits    $00
	smpsVcDetune        $00, $00, $00, $00
	smpsVcCoarseFreq    $02, $02, $01, $01
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $1F, $1F, $1E, $1F
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $0E, $0F, $0E, $0F
	smpsVcDecayRate2    $03, $0E, $03, $0E
	smpsVcDecayLevel    $0F, $0D, $0F, $0D
	smpsVcReleaseRate   $0A, $0B, $0A, $0B
	smpsVcTotalLevel    $00, $21, $00, $21

;	Voice $08
;	$2C
;	$01, $01, $02, $02, 	$1F, $1E, $1F, $1F, 	$0F, $0E, $0F, $0E
;	$0E, $03, $0E, $03, 	$FF, $FF, $FF, $FF, 	$21, $00, $21, $00
	smpsVcAlgorithm     $04
	smpsVcFeedback      $05
	smpsVcUnusedBits    $00
	smpsVcDetune        $00, $00, $00, $00
	smpsVcCoarseFreq    $02, $02, $01, $01
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $1F, $1F, $1E, $1F
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $0E, $0F, $0E, $0F
	smpsVcDecayRate2    $03, $0E, $03, $0E
	smpsVcDecayLevel    $0F, $0F, $0F, $0F
	smpsVcReleaseRate   $0F, $0F, $0F, $0F
	smpsVcTotalLevel    $00, $21, $00, $21

;	Voice $09
;	$02
;	$4D, $47, $47, $41, 	$1F, $1F, $1F, $1F, 	$1B, $0D, $11, $0D
;	$00, $00, $00, $00, 	$FA, $F9, $F9, $F9, 	$17, $2A, $22, $00
	smpsVcAlgorithm     $02
	smpsVcFeedback      $00
	smpsVcUnusedBits    $00
	smpsVcDetune        $04, $04, $04, $04
	smpsVcCoarseFreq    $01, $07, $07, $0D
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $1F, $1F, $1F, $1F
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $0D, $11, $0D, $1B
	smpsVcDecayRate2    $00, $00, $00, $00
	smpsVcDecayLevel    $0F, $0F, $0F, $0F
	smpsVcReleaseRate   $09, $09, $09, $0A
	smpsVcTotalLevel    $00, $22, $2A, $17

;	Voice $0A
;	$3A
;	$41, $46, $41, $41, 	$90, $96, $90, $90, 	$06, $11, $0B, $0D
;	$00, $00, $00, $00, 	$3A, $7A, $2A, $FF, 	$1F, $30, $20, $00
	smpsVcAlgorithm     $02
	smpsVcFeedback      $07
	smpsVcUnusedBits    $00
	smpsVcDetune        $04, $04, $04, $04
	smpsVcCoarseFreq    $01, $01, $06, $01
	smpsVcRateScale     $02, $02, $02, $02
	smpsVcAttackRate    $10, $10, $16, $10
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $0D, $0B, $11, $06
	smpsVcDecayRate2    $00, $00, $00, $00
	smpsVcDecayLevel    $0F, $02, $07, $03
	smpsVcReleaseRate   $0F, $0A, $0A, $0A
	smpsVcTotalLevel    $00, $20, $30, $1F

;	Voice $0B
;	$3A
;	$41, $46, $41, $41, 	$90, $96, $90, $90, 	$06, $11, $0B, $0D
;	$00, $00, $00, $00, 	$3A, $7A, $2A, $1A, 	$1D, $22, $20, $00
	smpsVcAlgorithm     $02
	smpsVcFeedback      $07
	smpsVcUnusedBits    $00
	smpsVcDetune        $04, $04, $04, $04
	smpsVcCoarseFreq    $01, $01, $06, $01
	smpsVcRateScale     $02, $02, $02, $02
	smpsVcAttackRate    $10, $10, $16, $10
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $0D, $0B, $11, $06
	smpsVcDecayRate2    $00, $00, $00, $00
	smpsVcDecayLevel    $01, $02, $07, $03
	smpsVcReleaseRate   $0A, $0A, $0A, $0A
	smpsVcTotalLevel    $00, $20, $22, $1D

;	Voice $0C
;	$3C
;	$02, $52, $41, $11, 	$8E, $91, $8F, $95, 	$0C, $08, $09, $07
;	$00, $00, $00, $00, 	$FF, $FF, $FF, $FF, 	$18, $00, $13, $00
	smpsVcAlgorithm     $04
	smpsVcFeedback      $07
	smpsVcUnusedBits    $00
	smpsVcDetune        $01, $04, $05, $00
	smpsVcCoarseFreq    $01, $01, $02, $02
	smpsVcRateScale     $02, $02, $02, $02
	smpsVcAttackRate    $15, $0F, $11, $0E
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $07, $09, $08, $0C
	smpsVcDecayRate2    $00, $00, $00, $00
	smpsVcDecayLevel    $0F, $0F, $0F, $0F
	smpsVcReleaseRate   $0F, $0F, $0F, $0F
	smpsVcTotalLevel    $00, $13, $00, $18

