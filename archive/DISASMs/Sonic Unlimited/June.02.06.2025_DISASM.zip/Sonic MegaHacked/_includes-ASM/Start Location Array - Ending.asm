; ---------------------------------------------------------------------------
; Ending start location array
; ---------------------------------------------------------------------------

		binclude	"_level-data/start-position/ghz1 (Credits demo 1).bin"
		binclude	"_level-data/start-position/mz2 (Credits demo).bin"
		binclude	"_level-data/start-position/syz3 (Credits demo).bin"
		binclude	"_level-data/start-position/lz3 (Credits demo).bin"
		binclude	"_level-data/start-position/slz3 (Credits demo).bin"
		binclude	"_level-data/start-position/sbz1 (Credits demo).bin"
		binclude	"_level-data/start-position/sbz2 (Credits demo).bin"
		binclude	"_level-data/start-position/ghz1 (Credits demo 2).bin"
		even
