; ---------------------------------------------------------------------------
; Special stage start locations
; ---------------------------------------------------------------------------

		binclude	"_level-data/start-position/ss1.bin"
		binclude	"_level-data/start-position/ss2.bin"
		binclude	"_level-data/start-position/ss3.bin"
		binclude	"_level-data/start-position/ss4.bin"
		binclude	"_level-data/start-position/ss5.bin"
		binclude	"_level-data/start-position/ss6.bin"
		even
