; ---------------------------------------------------------------------------
; Sonic start location array
; ---------------------------------------------------------------------------

		binclude	"_level-data/start-position/ghz1.bin"
		binclude	"_level-data/start-position/ghz2.bin"
		binclude	"_level-data/start-position/ghz3.bin"
		dc.w	$80,$A8

		binclude	"_level-data/start-position/lz1.bin"
		binclude	"_level-data/start-position/lz2.bin"
		binclude	"_level-data/start-position/lz3.bin"
		binclude	"_level-data/start-position/sbz3.bin"

		binclude	"_level-data/start-position/mz1.bin"
		binclude	"_level-data/start-position/mz2.bin"
		binclude	"_level-data/start-position/mz3.bin"
		dc.w	$80,$A8

		binclude	"_level-data/start-position/slz1.bin"
		binclude	"_level-data/start-position/slz2.bin"
		binclude	"_level-data/start-position/slz3.bin"
		dc.w	$80,$A8

		binclude	"_level-data/start-position/syz1.bin"
		binclude	"_level-data/start-position/syz2.bin"
		binclude	"_level-data/start-position/syz3.bin"
		dc.w	$80,$A8

		binclude	"_level-data/start-position/sbz1.bin"
		binclude	"_level-data/start-position/sbz2.bin"
		binclude	"_level-data/start-position/fz.bin"
		dc.w	$80,$A8
		
;		binclude	"_level-data/start-position/hpz.bin"
;		binclude	"_level-data/start-position/hpz.bin"
;		binclude	"_level-data/start-position/hpz.bin"		
;		dc.w	$80,$A8		

		zonewarning StartLocArray,$10

		binclude	"_level-data/start-position/end1.bin"
		binclude	"_level-data/start-position/end2.bin"
		dc.w	$80,$A8
		dc.w	$80,$A8

		even
