--[[
              ADVANCED INDICATOR FOR COBALT+
              Beta release v1.2
              Script made by Kadecz
              Does not support arrow with or without arrow scroll
              Added character scrolling
--]]

-------------------------- Variables ---------------------------
lngth = 0 -- Variable to calculate length
sp = script.Parent
lift = script.Tree.Value
customlbl = require(script.Custom_Floor_Label)
chars = require(script.CHAR)
charsARW = require(script.CHARARW)
space = 1 -- Spacing between characters
spaceSmall = 0 -- Spacing between characters (Small)
matrixresolution = {24, 16} -- Resolution of matrix, change if needed
customtextbig = chars["FONT_SIZE_BIG"]
customtxt = require(lift.CustomLabel)["CUSTOMFLOORLABEL"]
maxlen = 17 -- Maximum big font length span
alignX = "R" -- Alignment type, can be L (left), M (middle) or R (right)
alignY = "M" -- Alignment type, can be U (up), M (middle) or D (down)

--- Offset options --

xof = 0 -- X offset
yof = -1 -- Y offset
syof = 0 -- Small font Y offset
sxof = 0 -- Small font X offset

--- Color options ---

typeswitch = 1 -- Set to 1 to use transparency
enabledtransp = 0 -- Lit transparency
disabledtransp = 1 -- Unlit transparency
enabledclr = Color3.fromRGB(85, 255, 0) -- Lit color
disabledclr = Color3.fromRGB(88, 88, 88) -- Unlit color

-- Arrow --
TextOffset = UDim2.new(0, -4 * 6, 0, 0) -- How far the text moves when the arrow is visible
ScrollTime = 0.05

--- Scroll options --

scrollEnable = false -- Enable/disable scrolling
scrollSpd = 0.01 -- Scrolling Time
scrollSpc = 2 -- Spacing of scrolling
scrollType = 1 -- 1: Scrolling / 2: Jumping
scrollDir = "D" -- Scroll direction

-- (For Scrolling, don't touch.)
scrPos = 0

-- (Space Changing, don't touch.)
spaceVar = 0

---------------------

local kep = 0
local t = script.Parent.RUN
function onfloorchange(SF,clear,scrollIgnore)
	t.Value = true
	for an=1,matrixresolution[2] do
		for bn=1,matrixresolution[1] do
			if clear then if typeswitch == 0 then
					sp.Text["Row"..an]["D"..bn].ImageColor3 = disabledclr -- clear display
				else
					sp.Text["Row"..an]["D"..bn].ImageTransparency = disabledtransp
				end 
			end
		end
	end
	if string.len(SF) == 0 then return nil
	else
		if customtxt[tonumber(SF)] then SF = customtxt[tonumber(SF)] end
		calculatefont(SF)
		local diff = (customtextbig == chars["FONT_SIZE_SMALL"] and getvalue((getvalue((chars["FONT_SIZE_BIG"]),1)["CD"]),2) - getvalue((getvalue((chars["FONT_SIZE_SMALL"]),1)["CD"]),2) or 0)
		local fs = (customtextbig == chars["FONT_SIZE_SMALL"] and 1 or 0)
		local startPos = 0
		for n=1,string.len(SF) do
			if n == 1 then startPos = calculatestartpos(SF) + (fs == 1 and sxof or xof)
			else startPos = calculatestartpos(SF) + calculatelen(string.sub(SF,1,(n-1)),false) + spaceVar + (fs == 1 and sxof or xof) end
			local startPosY = calculatestartpos(SF,true)
			local scrollStart = startPosY + (fs == 1 and syof or yof)
			local scrollEnd = scrollStart + customtextbig[string.sub(SF,n,n)]["CD"][2]
			local POINT = 0
			local PMARK = false
			repeat POINT = POINT + 1 pcall(function()
					local ap = startPosY + (fs == 1 and syof or yof) + scrPos + POINT
					for p=startPos + 1,startPos + (getvalue(customtextbig[string.sub(SF,n,n)]["CD"],1)) do
						local cp = p - startPos
						local dp = POINT
						if typeswitch == 0 then
							sp.Text["Row"..ap]["D"..p].ImageColor3 = (string.sub(getvalue(customtextbig[string.sub(SF,n,n)]["DAT"][dp],1),cp,cp) == "1" and (not scrollIgnore or (ap >= scrollStart and ap <= scrollEnd))) and enabledclr or disabledclr
						else
							sp.Text["Row"..ap]["D"..p].ImageTransparency = (string.sub(getvalue(customtextbig[string.sub(SF,n,n)]["DAT"][dp],1),cp,cp) == "1" and (not scrollIgnore or (ap >= scrollStart and ap <= scrollEnd))) and enabledtransp or disabledtransp
						end
					end
				end)
				if POINT == customtextbig[string.sub(SF,n,n)]["CD"][2] then PMARK = true end
			until PMARK
		end
	end
	t.Value = false
end

function calculatelen(char,onlybig,vertical)
	local lngth = 0
	if string.len(char) == 0 then return 0 end
	for a=1,string.len(char) do
		if onlybig == true then
			if vertical then
				lngth = chars["FONT_SIZE_BIG"][string.sub(char,a,a)]["CD"][2]
			else
				lngth = lngth + chars["FONT_SIZE_BIG"][string.sub(char,a,a)]["CD"][1]
			end
		else
			if vertical then
				lngth = customtextbig[string.sub(char,a,a)]["CD"][2]
			else
				lngth = lngth + customtextbig[string.sub(char,a,a)]["CD"][1]
			end
		end
	end
	if not vertical then
		lngth = lngth + spaceVar * (string.len(char) - 1)
	end
	return lngth
end

function calculatestartpos(chb,vertical)
	if vertical then
		if alignY == "M" then local d = ((matrixresolution[2] - calculatelen(chb,false,true)) / 2) return math.ceil(d)
		elseif alignY == "U" then return 1
		elseif alignY == "D" then return (matrixresolution[2] - calculatelen(chb,false,true)) end
	else
		if alignX == "M" then local d = ((matrixresolution[1] - calculatelen(chb,false)) / 2) return math.ceil(d)
		elseif alignX == "L" then return 1
		elseif alignX == "R" then return (matrixresolution[1] - calculatelen(chb,false)) end
	end
end

function getvalue(a,b)
	local k,v
	if b == 1 then k,v = next(a,nil)
	else k,v = next(a,b-1)
	end
	return v
end

function calculatefont(chd)
	spaceVar = space
	if calculatelen(chd,true) > maxlen then 
		spaceVar = spaceSmall
		customtextbig = chars["FONT_SIZE_SMALL"]
	else 
		spaceVar = space
		customtextbig = chars["FONT_SIZE_BIG"]
	end
end

function scroll(val,scspd,scspc,scdir)
	local dd = kep
	local sav = scrPos
	local aa = lift.Direction.Value == 1 and 1 or -1
	local space1 = scspc+customtextbig[string.sub(dd,1,1)]["CD"][2]
	for n=1,space1+1 do
		newWait(scrollSpd)
		if scrollType == 1 then
			onfloorchange(dd,true,true)
		else
			onfloorchange(" ",true)
		end
		scrPos = scrPos + space1 * aa
		onfloorchange(val,false,true)
		scrPos = scrPos - (space1+1) * aa
	end
	kep = val
	scrPos = sav
end

function floor(val)
	-- Custom indicator code.
	if not scrollEnable then
		onfloorchange(tostring(val),true)
	else
		if t.Value then t.Changed:Wait() end
		scroll(tostring(val),scrollSpd,scrollSpc,scrollDir)
	end
end

lift:WaitForChild("Floor").Changed:Connect(function(VAL)
		floor(VAL)
end)

function SetARWDisplay(CHAR)
	if sp.Arrow and charsARW[CHAR] ~= nil then
		for i,l in pairs(charsARW[CHAR]) do 
			for r=1,7 do
				if typeswitch == 0 then
					sp.Arrow["Row"..i]["D"..r].ImageColor3 = (l:sub(r,r) == "1" and enabledclr or disabledclr)
				else
					sp.Arrow["Row"..i]["D"..r].ImageTransparency = (l:sub(r,r) == "1" and enabledtransp or disabledtransp)
				end
			end
		end
	end
end

function newWait(TimeToTake)
	local Accumulated = 0
	while TimeToTake > Accumulated do
		Accumulated += game:GetService("RunService").Heartbeat:Wait() 
	end
end

-- -- -- -- -- -- --
--DIRECTION SCROLL--
-- -- -- -- -- -- --
while wait() do
	if lift:WaitForChild("Direction").Value == 1 then
		sp.Text.Position = TextOffset
		for S=1,5 do
			newWait(ScrollTime)
			SetARWDisplay("U"..S)
		end
	elseif lift:WaitForChild("Direction").Value == -1 then
		sp.Text.Position = TextOffset
		for S=1,5 do
			newWait(ScrollTime)
			SetARWDisplay("D"..S)
		end
	else
		sp.Text.Position = UDim2.new(0,0,0,0)
		SetARWDisplay("NIL")
	end
end
