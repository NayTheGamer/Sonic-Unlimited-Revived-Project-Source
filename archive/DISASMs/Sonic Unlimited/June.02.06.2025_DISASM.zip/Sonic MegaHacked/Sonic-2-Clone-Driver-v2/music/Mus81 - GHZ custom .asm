GreenHillCustom_Header:
	smpsHeaderStartSong 1
	smpsHeaderVoice     GreenHillCustom_Voices
	smpsHeaderChan      $05, $03
	smpsHeaderTempo     $01, $00

	smpsHeaderDAC       GreenHillCustom_DAC
	smpsHeaderFM        GreenHillCustom_FM1,	$F3, $15
	smpsHeaderFM        GreenHillCustom_FM2,	$FF, $17
	smpsHeaderFM        GreenHillCustom_FM3,	$FF, $15
	smpsHeaderFM        GreenHillCustom_FM4,	$FF, $15
	smpsHeaderPSG       GreenHillCustom_PSG1,	$E7, $09, $00, fTone_05
	smpsHeaderPSG       GreenHillCustom_PSG2,	$F3, $09, $00, $00
	smpsHeaderPSG       GreenHillCustom_PSG3,	$00, $02, $00, fTone_04

; FM1 Data
GreenHillCustom_FM1:
	smpsSetvoice        $00
	smpsPan             panCenter, $00
	dc.b	nRst, $30

GreenHillCustom_Jump04:
	smpsCall            GreenHillCustom_Call0A
	smpsCall            GreenHillCustom_Call0B
	smpsCall            GreenHillCustom_Call0C
	smpsCall            GreenHillCustom_Call0D
	smpsCall            GreenHillCustom_Call0A
	smpsCall            GreenHillCustom_Call0B
	smpsCall            GreenHillCustom_Call0C
	smpsCall            GreenHillCustom_Call0E
	smpsCall            GreenHillCustom_Call0F
	smpsCall            GreenHillCustom_Call10
	smpsCall            GreenHillCustom_Call11
	smpsCall            GreenHillCustom_Call12
	smpsCall            GreenHillCustom_Call13
	smpsCall            GreenHillCustom_Call14
	dc.b	nA3, $60, smpsNoAttack, $48, nRst, $18
	smpsJump            GreenHillCustom_Jump04

GreenHillCustom_Call0A:
	dc.b	nA3, $0C, nA4, nA3, $0C, $06, $0C, $06, nA4, $0C, nA3, nB3
	smpsReturn

GreenHillCustom_Call0B:
	dc.b	nC4, $0C, nC5, nC4, $0C, $06, $0C, $06, nC5, $0C, nC4, nCs4
	smpsReturn

GreenHillCustom_Call0C:
	dc.b	nD4, $0C, nD5, nD4, $0C, $06, $0C, $06, nD5, $0C, nD4, nEb4
	smpsReturn

GreenHillCustom_Call0D:
	dc.b	nE3, $0C, nE4, nE3, $0C, $06, $06, nG3, $12, $12, nAb4, $0C
	smpsReturn

GreenHillCustom_Call0E:
	dc.b	nE3, $0C, nE4, nE3, $0C, $06, $06, nE4, $12, nD4, $12, nC4
	dc.b	$0C
	smpsReturn

GreenHillCustom_Call0F:
	dc.b	nD4, $12, $12, $18, nA3, $0C, nC4, nD4
	smpsReturn

GreenHillCustom_Call10:
	dc.b	nE4, $12, $12, $18, nB3, $0C, nE4, nD4
	smpsReturn

GreenHillCustom_Call11:
	dc.b	nC4, $12, $12, $18, nG3, $0C, nB3, nC4
	smpsReturn

GreenHillCustom_Call12:
	dc.b	nD4, $12, $12, $18, nC4, $0C, nB3, nG3
	smpsReturn

GreenHillCustom_Call13:
	dc.b	nF3, $12, $12, $18, nA3, $0C, nF3, nFs3
	smpsReturn

GreenHillCustom_Call14:
	dc.b	nG3, $12, $12, $18, nB3, $0C, nG3, nAb3
	smpsReturn

; FM2 Data
GreenHillCustom_FM2:
	smpsSetvoice        $01
	dc.b	nRst, $30

GreenHillCustom_Jump03:
	smpsPan             panCenter, $00
	smpsModSet          $07, $01, $03, $05
	dc.b	nRst, $0C, nA3, $24, $12, nG3, $12, nE3, $0C, nG3, $12, nE3
	dc.b	$12, nD3, $0C, $06, nE3, $2A, nRst, $0C, nG3, $24, $12, nFs3
	dc.b	$12, nD3, $0C, nE3, $30, nG3, $12, $12, nAb3, $0C, nRst, $0C
	dc.b	nA3, $24, $12, nG3, $12, nE3, $0C, nG3, $12, nE3, $12, nD3
	dc.b	$0C, $06, nE3, $2A, nRst, $0C, nG3, $24, $12, nFs3, $12, nD3
	dc.b	$0C, nE3, $30
	smpsPan             panLeft, $00
	dc.b	nE4, $12, nD4, $12, nC4, $0C, nA3, $12, $12, $24, nRst, $0C
	dc.b	nB3, $06, nC4, $06, nB3, $12, $12, $24, nRst, $0C, nC4, $06
	dc.b	nD4, $06, nC4, $12, $12, $24, nRst, $0C, nD4, $06, nE4, $06
	dc.b	nD4, $24, nC4, $0C, nB3, $12, nA3, $12, nAb3, $0C, nA3, $12
	dc.b	$12, $24, nRst, $0C, nB3, $06, nC4, $06, nB3, $12, $12, $24
	dc.b	nRst, $0C, nCs4, $06, nD4, $06, nCs4, $48
	smpsModSet          $02, $01, $20, $FF
	dc.b	smpsNoAttack, nCs4, $18
	smpsModSet          $07, $01, $03, $05
	dc.b	smpsNoAttack, nCs5, $48, nRst, $18
	smpsJump            GreenHillCustom_Jump03

; FM3 Data
GreenHillCustom_FM3:
	smpsPan             panRight, $00
	smpsModSet          $07, $01, $03, $05
	dc.b	nRst, $30
	smpsAlterNote       $01

GreenHillCustom_Jump02:
	smpsSetvoice        $02
	smpsAlterPitch      $F4
	smpsAlterVol        $05
	dc.b	nA2, $0C, nA3, $0C
	smpsNoteFill        $04
	dc.b	nA2, $06, $06, $06, $06
	smpsNoteFill        $00
	dc.b	nA3, $0C
	smpsNoteFill        $04
	dc.b	nA2, $06, $06, $06, $06
	smpsNoteFill        $00
	dc.b	nA3, $0C, nC3, $0C, nC4, $0C
	smpsNoteFill        $04
	dc.b	nC3, $06, $06, $06, $06
	smpsNoteFill        $00
	dc.b	nC4, $0C
	smpsNoteFill        $04
	dc.b	nC3, $06, $06, $06, $06
	smpsNoteFill        $00
	dc.b	nC4, $0C, nD3, $0C, nD4, $0C
	smpsNoteFill        $04
	dc.b	nD3, $06, $06, $06, $06
	smpsNoteFill        $00
	dc.b	nD4, $0C
	smpsNoteFill        $04
	dc.b	nD3, $06, $06, $06, $06
	smpsNoteFill        $00
	dc.b	nD4, $0C, nE3, $30, nG3, $12, $12, $0C, nA2, $0C, nA3, $0C
	smpsNoteFill        $04
	dc.b	nA2, $06, $06, $06, $06
	smpsNoteFill        $00
	dc.b	nA3, $0C
	smpsNoteFill        $04
	dc.b	nA2, $06, $06, $06, $06
	smpsNoteFill        $00
	dc.b	nA3, $0C, nC3, $0C, nC4, $0C
	smpsNoteFill        $04
	dc.b	nC3, $06, $06, $06, $06
	smpsNoteFill        $00
	dc.b	nC4, $0C
	smpsNoteFill        $04
	dc.b	nC3, $06, $06, $06, $06
	smpsNoteFill        $00
	dc.b	nC4, $0C, nD3, $0C, nD4, $0C
	smpsNoteFill        $04
	dc.b	nD3, $06, $06, $06, $06
	smpsNoteFill        $00
	dc.b	nD4, $0C
	smpsNoteFill        $04
	dc.b	nD3, $06, $06, $06, $06
	smpsNoteFill        $00
	dc.b	nD4, $0C, nE3, $30
	smpsSetvoice        $01
	smpsAlterPitch      $0C
	smpsAlterVol        $FB
	dc.b	nC4, $12, nB3, $12, nAb4, $0C, nD4, $12, $12, $24, nRst, $0C
	dc.b	nAb3, $06, nA3, $06, nAb3, $12, $12, $24, nRst, $0C, nE4, $06
	dc.b	nF4, $06, nE4, $12, $12, $24, nRst, $0C, nB3, $06, nC4, $06
	dc.b	nB3, $24, nA3, $0C, nAb3, $12, nFs3, $12, nE3, $0C, nF4, $12
	dc.b	$12, $24, nRst, $0C, nG4, $06, nA4, $06, nG4, $12, $12, $24
	dc.b	nRst, $0C, nA4, $06, nB4, $06, nA4, $48
	smpsModSet          $02, $01, $20, $FF
	dc.b	smpsNoAttack, nA4, $18
	smpsModSet          $07, $01, $03, $05
	dc.b	smpsNoAttack, nA5, $48, nRst, $18
	smpsJump            GreenHillCustom_Jump02

; FM4 Data
GreenHillCustom_FM4:
	smpsSetvoice        $01
	smpsModSet          $07, $01, $03, $05
	dc.b	nRst, $30
	smpsAlterNote       $FF

GreenHillCustom_Jump01:
	smpsPan             panLeft, $00
	smpsSetvoice        $02
	smpsAlterVol        $05
	dc.b	nA2, $0C, nE3, $0C
	smpsNoteFill        $04
	dc.b	nA2, $06, $06, $06, $06
	smpsNoteFill        $00
	dc.b	nE3, $0C
	smpsNoteFill        $04
	dc.b	nA2, $06, $06, $06, $06
	smpsNoteFill        $00
	dc.b	nE3, $0C, nC3, $0C, nG3, $0C
	smpsNoteFill        $04
	dc.b	nC3, $06, $06, $06, $06
	smpsNoteFill        $00
	dc.b	nG3, $0C
	smpsNoteFill        $04
	dc.b	nC3, $06, $06, $06, $06
	smpsNoteFill        $00
	dc.b	nG3, $0C, nD3, $0C, nA3, $0C
	smpsNoteFill        $04
	dc.b	nD3, $06, $06, $06, $06
	smpsNoteFill        $00
	dc.b	nA3, $0C
	smpsNoteFill        $04
	dc.b	nD3, $06, $06, $06, $06
	smpsNoteFill        $00
	dc.b	nA3, $0C, nB2, $30, nD3, $12, $12, nEb3, $0C, nA2, $0C, nE3
	dc.b	$0C
	smpsNoteFill        $04
	dc.b	nA2, $06, $06, $06, $06
	smpsNoteFill        $00
	dc.b	nE3, $0C
	smpsNoteFill        $04
	dc.b	nA2, $06, $06, $06, $06
	smpsNoteFill        $00
	dc.b	nE3, $0C, nC3, $0C, nG3, $0C
	smpsNoteFill        $04
	dc.b	nC3, $06, $06, $06, $06
	smpsNoteFill        $00
	dc.b	nG3, $0C
	smpsNoteFill        $04
	dc.b	nC3, $06, $06, $06, $06
	smpsNoteFill        $00
	dc.b	nG3, $0C, nD3, $0C, nA3, $0C
	smpsNoteFill        $04
	dc.b	nD3, $06, $06, $06, $06
	smpsNoteFill        $00
	dc.b	nA3, $0C
	smpsNoteFill        $04
	dc.b	nD3, $06, $06, $06, $06
	smpsNoteFill        $00
	dc.b	nA3, $0C, nB3, $30
	smpsSetvoice        $01
	smpsAlterVol        $FB
	smpsPan             panCenter, $00
	dc.b	nC4, $12, nB3, $12, nE3, $0C, nD3, $12, $12, $3C, nE3, $12
	dc.b	$12, $3C, nC3, $12, $12, $3C, nD3, $12, $12, $3C, nF3, $12
	dc.b	$12, $18, nE3, $0C, nF3, $0C, nFs3, $0C, nG3, $12, $12, $18
	dc.b	nF3, $0C, nG3, $0C, nAb3, $0C, nA3, $48
	smpsModSet          $02, $01, $20, $FF
	dc.b	smpsNoAttack, nA3, $18
	smpsModSet          $07, $01, $03, $05
	dc.b	smpsNoAttack, nA4, $48, nRst, $18
	smpsJump            GreenHillCustom_Jump01

; PSG1 Data
GreenHillCustom_PSG1:
	smpsPSGvoice        fTone_05
	dc.b	nRst, $32
	smpsJump            GreenHillCustom_Jump03

; PSG2 Data
GreenHillCustom_PSG2:
	smpsPSGvoice        fTone_01
	dc.b	nRst, $34
	smpsJump            GreenHillCustom_Jump03

; PSG3 Data
GreenHillCustom_PSG3:
	smpsPSGform         $E7
	smpsCall            GreenHillCustom_Call15

GreenHillCustom_Jump05:
	smpsCall            GreenHillCustom_Call16
	smpsCall            GreenHillCustom_Call17
	smpsCall            GreenHillCustom_Call18
	smpsCall            GreenHillCustom_Call19
	smpsCall            GreenHillCustom_Call16
	smpsCall            GreenHillCustom_Call17
	smpsCall            GreenHillCustom_Call18
	smpsCall            GreenHillCustom_Call1A

GreenHillCustom_Loop00:
	smpsCall            GreenHillCustom_Call1B
	smpsLoop            $00, $03, GreenHillCustom_Loop00
	smpsCall            GreenHillCustom_Call1C
	smpsCall            GreenHillCustom_Call1B
	smpsCall            GreenHillCustom_Call1B
	smpsCall            GreenHillCustom_Call1D
	smpsCall            GreenHillCustom_Call1E
	smpsJump            GreenHillCustom_Jump05

GreenHillCustom_Call15:
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $18, $18
	smpsReturn

GreenHillCustom_Call16:
	smpsPSGvoice        fTone_01
	smpsPSGAlterVol     $FE
	dc.b	nMaxPSG, $18
	smpsPSGvoice        fTone_04
	smpsPSGAlterVol     $02

GreenHillCustom_Loop01:
	smpsPSGAlterVol     $01
	dc.b	nMaxPSG, $0C
	smpsPSGAlterVol     $FF
	dc.b	nMaxPSG, $0C
	smpsLoop            $00, $03, GreenHillCustom_Loop01
	smpsReturn

GreenHillCustom_Call17:
	smpsPSGAlterVol     $01
	dc.b	nMaxPSG, $0C
	smpsPSGAlterVol     $FF
	dc.b	nMaxPSG, $0C
	smpsLoop            $00, $03, GreenHillCustom_Call17
	smpsPSGAlterVol     $01
	dc.b	nMaxPSG, $0C
	smpsPSGAlterVol     $FF
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $0C
	smpsReturn

GreenHillCustom_Call18:
	smpsPSGvoice        fTone_04
	smpsPSGAlterVol     $01
	dc.b	nMaxPSG, $0C
	smpsPSGAlterVol     $FF
	dc.b	nMaxPSG, $0C
	smpsLoop            $00, $04, GreenHillCustom_Call18
	smpsReturn

GreenHillCustom_Call19:
	smpsPSGvoice        fTone_04
	smpsPSGAlterVol     $01
	dc.b	nMaxPSG, $0C
	smpsPSGvoice        fTone_01
	smpsPSGAlterVol     $FF
	dc.b	nMaxPSG, $0C
	smpsLoop            $00, $02, GreenHillCustom_Call19
	smpsPSGvoice        fTone_04
	smpsPSGAlterVol     $01
	dc.b	nMaxPSG, $0C
	smpsPSGAlterVol     $FF
	dc.b	nMaxPSG, $0C
	smpsPSGAlterVol     $01
	dc.b	nMaxPSG, $0C
	smpsPSGvoice        fTone_01
	smpsPSGAlterVol     $FF
	dc.b	nMaxPSG, $0C
	smpsReturn

GreenHillCustom_Call1A:
	smpsPSGvoice        fTone_01
	dc.b	nMaxPSG, $18, $18
	smpsPSGAlterVol     $01
	dc.b	$0C, $0C
	smpsPSGAlterVol     $FF
	dc.b	$0C, $0C
	smpsReturn

GreenHillCustom_Call1B:
	smpsPSGvoice        fTone_01
	smpsPSGAlterVol     $FE
	dc.b	nMaxPSG, $12, $12, $18
	smpsPSGvoice        fTone_02
	smpsPSGAlterVol     $03
	dc.b	$06, $06
	smpsPSGAlterVol     $FF
	dc.b	$06, $06
	smpsPSGvoice        fTone_01
	dc.b	$0C
	smpsReturn

GreenHillCustom_Call1C:
	smpsPSGvoice        fTone_01
	smpsPSGAlterVol     $FE
	dc.b	nMaxPSG, $12, $12, $0C
	smpsPSGAlterVol     $02
	dc.b	$18, $18
	smpsReturn

GreenHillCustom_Call1D:
	smpsPSGvoice        fTone_01
	smpsPSGAlterVol     $FE
	dc.b	nMaxPSG, $18
	smpsPSGAlterVol     $02
	dc.b	$18
	smpsPSGAlterVol     $01
	dc.b	$18
	smpsPSGAlterVol     $FF
	dc.b	$18
	smpsReturn

GreenHillCustom_Call1E:
	smpsPSGAlterVol     $01
	dc.b	nMaxPSG, $18
	smpsPSGAlterVol     $FF
	dc.b	$18
	smpsPSGAlterVol     $01
	dc.b	$18
	smpsPSGAlterVol     $FE
	dc.b	$18
	smpsPSGAlterVol     $01
	smpsReturn

; DAC Data
GreenHillCustom_DAC:
	smpsCall            GreenHillCustom_Call00

GreenHillCustom_Jump00:
	smpsCall            GreenHillCustom_Call01
	smpsCall            GreenHillCustom_Call02
	smpsCall            GreenHillCustom_Call01
	smpsCall            GreenHillCustom_Call03
	smpsCall            GreenHillCustom_Call01
	smpsCall            GreenHillCustom_Call02
	smpsCall            GreenHillCustom_Call01
	smpsCall            GreenHillCustom_Call04
	smpsCall            GreenHillCustom_Call05
	smpsCall            GreenHillCustom_Call06
	smpsCall            GreenHillCustom_Call05
	smpsCall            GreenHillCustom_Call07
	smpsCall            GreenHillCustom_Call05
	smpsCall            GreenHillCustom_Call06
	smpsCall            GreenHillCustom_Call08
	smpsCall            GreenHillCustom_Call09
	smpsJump            GreenHillCustom_Jump00

GreenHillCustom_Call00:
	dc.b	dSnare, $06, dKick, dKick, dSnare, dKick, dKick, dSnare, $0C
	smpsReturn

GreenHillCustom_Call01:
	dc.b	dKick, $0C, dSnare, $12, dKick, $06, dSnare, $0C, dKick, $0C, dSnare, $06
	dc.b	dKick, $0C, $06, dSnare, $0C
	smpsReturn

GreenHillCustom_Call02:
	dc.b	dKick, $0C, dSnare, $12, dKick, $06, dSnare, $0C, dKick, $06, dKick, dSnare
	dc.b	dKick, $0C, $06, dSnare, $0C
	smpsReturn

GreenHillCustom_Call03:
	dc.b	dKick, $0C, dSnare, $12, dKick, $06, dSnare, $0C, $84, $04, $04, $04
	dc.b	$85, $06, $06, $86, $06, $06, $87, $06, $06
	smpsReturn

GreenHillCustom_Call04:
	dc.b	dSnare, $0C, $0C, $0C, $06, $06, $84, $04, $04, $04, $85, $06
	dc.b	$06, $86, $06, $06, $87, $06, $06
	smpsReturn

GreenHillCustom_Call05:
	dc.b	dKick, $0C, dSnare, $06, dKick, $0C, $06, dSnare, $0C, dKick, $06, $06
	dc.b	dSnare, $0C, dKick, $06, $06, dSnare, $0C
	smpsReturn

GreenHillCustom_Call06:
	dc.b	dKick, $0C, dSnare, $06, dKick, $0C, $06, dSnare, $12, dKick, $06, dSnare
	dc.b	$0C, dKick, $06, $06, dSnare, $0C
	smpsReturn

GreenHillCustom_Call07:
	dc.b	dKick, $0C, dSnare, $06, dKick, $0C, $06, dSnare, $0C, $84, $04, $04
	dc.b	$04, $85, $06, $06, $86, $06, $06, $87, $06, $06
	smpsReturn

GreenHillCustom_Call08:
	dc.b	dKick, $0C, $06, dSnare, $0C, dSnare, $06, dKick, dSnare, dKick, $06, dSnare
	dc.b	dKick, dKick, dSnare, dKick, dSnare, dSnare
	smpsReturn

GreenHillCustom_Call09:
	dc.b	$84, $04, $04, $04, $85, $06, $06, $86, $06, $06, $87, $06
	dc.b	$06, dSnare, $06, dKick, dKick, dKick, dSnare, $18
	smpsReturn

GreenHillCustom_Voices:
;	Voice $00
;	$1B
;	$1A, $51, $30, $01, 	$1F, $1F, $94, $1F, 	$0B, $03, $0A, $05
;	$05, $04, $02, $05, 	$5F, $5F, $5F, $2F, 	$26, $28, $15, $80
	smpsVcAlgorithm     $03
	smpsVcFeedback      $03
	smpsVcUnusedBits    $00
	smpsVcDetune        $00, $03, $05, $01
	smpsVcCoarseFreq    $01, $00, $01, $0A
	smpsVcRateScale     $00, $02, $00, $00
	smpsVcAttackRate    $1F, $14, $1F, $1F
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $05, $0A, $03, $0B
	smpsVcDecayRate2    $05, $02, $04, $05
	smpsVcDecayLevel    $02, $05, $05, $05
	smpsVcReleaseRate   $0F, $0F, $0F, $0F
	smpsVcTotalLevel    $00, $15, $28, $26

;	Voice $01
;	$20
;	$42, $43, $14, $71, 	$1F, $12, $1F, $1F, 	$04, $02, $04, $0A
;	$01, $01, $02, $02, 	$1F, $1F, $1F, $1F, 	$13, $24, $13, $80
	smpsVcAlgorithm     $00
	smpsVcFeedback      $04
	smpsVcUnusedBits    $00
	smpsVcDetune        $07, $01, $04, $04
	smpsVcCoarseFreq    $01, $04, $03, $02
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $1F, $1F, $12, $1F
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $0A, $04, $02, $04
	smpsVcDecayRate2    $02, $02, $01, $01
	smpsVcDecayLevel    $01, $01, $01, $01
	smpsVcReleaseRate   $0F, $0F, $0F, $0F
	smpsVcTotalLevel    $00, $13, $24, $13

;	Voice $02
;	$3A
;	$42, $43, $14, $71, 	$1F, $12, $1F, $1F, 	$04, $02, $04, $0A
;	$01, $01, $02, $02, 	$1F, $1F, $1F, $1F, 	$1A, $14, $16, $80
	smpsVcAlgorithm     $02
	smpsVcFeedback      $07
	smpsVcUnusedBits    $00
	smpsVcDetune        $07, $01, $04, $04
	smpsVcCoarseFreq    $01, $04, $03, $02
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $1F, $1F, $12, $1F
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $0A, $04, $02, $04
	smpsVcDecayRate2    $02, $02, $01, $01
	smpsVcDecayLevel    $01, $01, $01, $01
	smpsVcReleaseRate   $0F, $0F, $0F, $0F
	smpsVcTotalLevel    $00, $16, $14, $1A

