AnotherPartOfMe_Header:
	smpsHeaderStartSong 1
	smpsHeaderVoice     AnotherPartOfMe_Voices
	smpsHeaderChan      $06, $03
	smpsHeaderTempo     $01, $00

	smpsHeaderDAC       AnotherPartOfMe_DAC
	smpsHeaderFM        AnotherPartOfMe_FM1,	$00, $00
	smpsHeaderFM        AnotherPartOfMe_FM2,	$00, $00
	smpsHeaderFM        AnotherPartOfMe_FM3,	$00, $00
	smpsHeaderFM        AnotherPartOfMe_FM4,	$00, $00
	smpsHeaderFM        AnotherPartOfMe_FM5,	$00, $00
	smpsHeaderPSG       AnotherPartOfMe_PSG1,	$00, $00, $00, $00
	smpsHeaderPSG       AnotherPartOfMe_PSG2,	$00, $00, $00, $00
	smpsHeaderPSG       AnotherPartOfMe_PSG3,	$00, $00, $00, $00

; DAC Data
AnotherPartOfMe_DAC:
	smpsStop

; FM1 Data
AnotherPartOfMe_FM1:
	smpsSetvoice        $00
	smpsAlterVol        $7F
	smpsPan             panCenter, $00
	dc.b	nRst, $03
	smpsSetvoice        $01
	smpsAlterVol        $95
	dc.b	nA4, $70
	smpsSetvoice        $03
	smpsAlterVol        $FA
	dc.b	nF6, $10
	smpsAlterVol        $02
	dc.b	nRst, $7F, $7F, $02

AnotherPartOfMe_Jump04:
	dc.b	nRst, $7F, $7F, $02
	smpsSetvoice        $06
	smpsAlterVol        $04
	smpsPan             panLeft, $00
	dc.b	smpsNoAttack, $10

AnotherPartOfMe_Loop18:
	dc.b	nA1, $08, nRst, nB1, $20, nRst, $08, nA1, nRst, nB1, nRst, $30
	smpsLoop            $00, $02, AnotherPartOfMe_Loop18
	dc.b	nG1, $08, nRst, nA1, $20, nRst, $08, nG1, nRst, nA1, nRst, $30
	smpsAlterNote       $01
	dc.b	nBb1, $08, nRst, nBb1, $12, nRst, $06
	smpsAlterNote       $00
	dc.b	nCs2, $08
	smpsSetvoice        $04
	smpsAlterVol        $FC
	smpsPan             panCenter, $00
	dc.b	nRst, nAb4, $01, smpsNoAttack
	smpsAlterNote       $0C
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $18
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E7
	dc.b	nA4, smpsNoAttack
	smpsAlterNote       $F3
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$08, nRst, $03

AnotherPartOfMe_Loop1A:
	dc.b	nG4, $08, nRst, nF4, nAb4, $02, smpsNoAttack
	smpsAlterNote       $04
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $08
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0C
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $10
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $14
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $18
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1C
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E3
	dc.b	nA4, smpsNoAttack
	smpsAlterNote       $E7
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $EB
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $EF
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F3
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F7
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FB
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$1B

AnotherPartOfMe_Loop19:
	dc.b	smpsNoAttack
	smpsAlterNote       $08
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $10
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $08
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F8
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F0
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $F8
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01
	smpsLoop            $00, $02, AnotherPartOfMe_Loop19
	dc.b	smpsNoAttack
	smpsAlterNote       $08
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $10
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $08
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F8
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F0
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $F8
	dc.b	$01, nRst, $10
	smpsAlterNote       $00
	dc.b	nAb4, $01, smpsNoAttack
	smpsAlterNote       $0C
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $18
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E7
	dc.b	nA4, smpsNoAttack
	smpsAlterNote       $F3
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$05, nRst, $06
	smpsLoop            $01, $02, AnotherPartOfMe_Loop1A
	dc.b	nG4, $08, nRst, nF4, nFs4, $02, smpsNoAttack
	smpsAlterNote       $04
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $08
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0C
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $10
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $14
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $18
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E6
	dc.b	nG4, smpsNoAttack
	smpsAlterNote       $EA
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $EE
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F2
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F6
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $02
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$1B

AnotherPartOfMe_Loop1B:
	dc.b	smpsNoAttack
	smpsAlterNote       $08
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $10
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $08
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F8
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F0
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $F8
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01
	smpsLoop            $00, $02, AnotherPartOfMe_Loop1B
	dc.b	smpsNoAttack
	smpsAlterNote       $08
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $10
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $08
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F8
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F0
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $F8
	dc.b	$01, nRst, $10
	smpsAlterNote       $00
	dc.b	nE4, $01, smpsNoAttack
	smpsAlterNote       $0C
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E9
	dc.b	nF4, smpsNoAttack
	smpsAlterNote       $F5
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $01
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$08, nRst, $03, smpsNoAttack, nF4, $15, nRst, $03, nAb4, $02, smpsNoAttack
	smpsAlterNote       $04
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $08
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0C
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $10
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $14
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $18
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1C
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E3
	dc.b	nA4, smpsNoAttack
	smpsAlterNote       $E7
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $EB
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $EF
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F3
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F7
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FB
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$1B

AnotherPartOfMe_Loop1C:
	dc.b	smpsNoAttack
	smpsAlterNote       $08
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $10
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $08
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F8
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F0
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $F8
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01
	smpsLoop            $00, $03, AnotherPartOfMe_Loop1C
	dc.b	smpsNoAttack
	smpsAlterNote       $08
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $10
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $08
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F8
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F0
	dc.b	$01, nRst, $08
	smpsAlterNote       $00
	dc.b	nAb4, $01, smpsNoAttack
	smpsAlterNote       $0C
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $18
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E7
	dc.b	nA4, smpsNoAttack
	smpsAlterNote       $F3
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$08, nRst, $03

AnotherPartOfMe_Loop1E:
	dc.b	nG4, $08, nRst, nF4, nAb4, $02, smpsNoAttack
	smpsAlterNote       $04
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $08
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0C
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $10
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $14
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $18
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1C
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E3
	dc.b	nA4, smpsNoAttack
	smpsAlterNote       $E7
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $EB
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $EF
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F3
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F7
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FB
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$1B

AnotherPartOfMe_Loop1D:
	dc.b	smpsNoAttack
	smpsAlterNote       $08
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $10
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $08
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F8
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F0
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $F8
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01
	smpsLoop            $00, $02, AnotherPartOfMe_Loop1D
	dc.b	smpsNoAttack
	smpsAlterNote       $08
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $10
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $08
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F8
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F0
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $F8
	dc.b	$01, nRst, $10
	smpsAlterNote       $00
	dc.b	nAb4, $01, smpsNoAttack
	smpsAlterNote       $0C
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $18
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E7
	dc.b	nA4, smpsNoAttack
	smpsAlterNote       $F3
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$05, nRst, $06
	smpsLoop            $01, $02, AnotherPartOfMe_Loop1E
	dc.b	nG4, $08, nRst, nF4, nFs4, $02, smpsNoAttack
	smpsAlterNote       $04
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $08
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0C
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $10
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $14
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $18
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E6
	dc.b	nG4, smpsNoAttack
	smpsAlterNote       $EA
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $EE
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F2
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F6
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $02
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$1B

AnotherPartOfMe_Loop1F:
	dc.b	smpsNoAttack
	smpsAlterNote       $08
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $10
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $08
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F8
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F0
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $F8
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01
	smpsLoop            $00, $02, AnotherPartOfMe_Loop1F
	dc.b	smpsNoAttack
	smpsAlterNote       $08
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $10
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $08
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F8
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F0
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $F8
	dc.b	$01, nRst, $10
	smpsAlterNote       $00
	dc.b	nE4, $01, smpsNoAttack
	smpsAlterNote       $0C
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E9
	dc.b	nF4, smpsNoAttack
	smpsAlterNote       $F5
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $01
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$08, nRst, $03, smpsNoAttack, nF4, $15, nRst, $03, nAb4, $02, smpsNoAttack
	smpsAlterNote       $04
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $08
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0C
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $10
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $14
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $18
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $1C
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E3
	dc.b	nA4, smpsNoAttack
	smpsAlterNote       $E7
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $EB
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $EF
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F3
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F7
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FB
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$1B

AnotherPartOfMe_Loop20:
	dc.b	smpsNoAttack
	smpsAlterNote       $08
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $10
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $08
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F8
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F0
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $F8
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01
	smpsLoop            $00, $03, AnotherPartOfMe_Loop20
	dc.b	smpsNoAttack
	smpsAlterNote       $08
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $10
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $08
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F8
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F0
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00

AnotherPartOfMe_Loop21:
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $F8
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $08
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $10
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $08
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F8
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F0
	smpsLoop            $00, $03, AnotherPartOfMe_Loop21
	dc.b	$02, nRst, $10
	smpsAlterNote       $00
	dc.b	nA4, $08, nRst
	smpsAlterNote       $01
	dc.b	nBb4, $10, $08, $1F, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FD
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FC
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FB
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F9
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F8
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F7
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F6
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F5
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F4
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F3
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F2
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F1
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F0
	dc.b	$01, nRst, $28
	smpsAlterNote       $00
	dc.b	nG4, $08, nRst, nA4, $10, $08, $10, smpsNoAttack, nG4, $08, smpsNoAttack, nF4
	dc.b	$09

AnotherPartOfMe_Loop22:
	dc.b	smpsNoAttack
	smpsAlterNote       $08
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $10
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $08
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F8
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F0
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $F8
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01
	smpsLoop            $00, $03, AnotherPartOfMe_Loop22
	dc.b	smpsNoAttack
	smpsAlterNote       $08
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $10
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $08
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F8
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F0
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $F8
	dc.b	$01, nRst, $10
	smpsAlterNote       $00
	dc.b	nD4, $08, nRst
	smpsAlterNote       $01
	dc.b	nBb4, $10, $08, $1F, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FD
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FC
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FB
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F9
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F8
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F7
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F6
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F5
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F4
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F3
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F2
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F1
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F0
	dc.b	$01, nRst, $18
	smpsAlterNote       $01
	dc.b	nBb4, $08, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nA4, smpsNoAttack, nG4, nA4, $10, smpsNoAttack, nG4, $08, smpsNoAttack, nF4, $50, nRst
	dc.b	$10, smpsNoAttack, nF4, $08, nRst, nG4, $10, $08, $17, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FD
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FC
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FB
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F9
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F8
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F7
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F6
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F5
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F4
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F3
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F2
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F1
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F0
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $EF
	dc.b	$01, nRst, $08
	smpsAlterNote       $00
	dc.b	nG4, nRst, nG4, nRst, nG4, nRst, nF4, $18, $09

AnotherPartOfMe_Loop23:
	dc.b	smpsNoAttack
	smpsAlterNote       $08
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $10
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $08
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F8
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F0
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $F8
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01
	smpsLoop            $00, $07, AnotherPartOfMe_Loop23
	dc.b	smpsNoAttack
	smpsAlterNote       $08
	dc.b	$01, nRst, $10
	smpsAlterNote       $00
	dc.b	nF4, $08, nRst, nG4, $10, $08, $17, smpsNoAttack
	smpsAlterNote       $FF
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FE
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FD
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FC
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FB
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F9
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F8
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F7
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F6
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F5
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F4
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F3
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F2
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F1
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F0
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $EF
	dc.b	$01, nRst, $08
	smpsAlterNote       $00
	dc.b	nG4, nRst, nA4, nRst
	smpsAlterNote       $01
	dc.b	nBb4
	smpsAlterNote       $00
	dc.b	nA4, $13

AnotherPartOfMe_Loop24:
	dc.b	smpsNoAttack
	smpsAlterNote       $08
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $10
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $08
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F8
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F0
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $F8
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01
	smpsLoop            $00, $0C, AnotherPartOfMe_Loop24
	dc.b	smpsNoAttack
	smpsAlterNote       $08
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $10
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $08
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01, nRst, $10, nCs4, $02, smpsNoAttack, nD4, $06, nRst, $08, nF4, $10
	dc.b	nA4, nG4, nF4, nEb4, $02, smpsNoAttack, nE4, $0E, nC4, $10, nD4, $13

AnotherPartOfMe_Loop25:
	dc.b	smpsNoAttack
	smpsAlterNote       $08
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $10
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $08
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F8
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F0
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $F8
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01
	smpsLoop            $00, $0A, AnotherPartOfMe_Loop25
	dc.b	smpsNoAttack
	smpsAlterNote       $08
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $10
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $08
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F8
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F0
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $F8
	dc.b	$01, nRst, $7F, $01
	smpsSetvoice        $03
	smpsPan             panCenter, $00
	smpsAlterNote       $00
	smpsJump            AnotherPartOfMe_Jump04

; FM2 Data
AnotherPartOfMe_FM2:
	smpsSetvoice        $00
	smpsAlterVol        $7F
	smpsPan             panCenter, $00
	dc.b	nRst, $03
	smpsSetvoice        $02
	smpsAlterVol        $87
	dc.b	nD2, $70
	smpsSetvoice        $04
	smpsAlterVol        $0E
	dc.b	nA4, $10
	smpsSetvoice        $05
	smpsAlterVol        $F2

AnotherPartOfMe_Loop16:
	dc.b	nD3, $08, nD3, nRst, $20, nD2, $08, nD2, nRst, $28, nG2, $08
	dc.b	nA2, nC3, nD3, nD3, nRst, $20, nD2, $08, nD2, nRst, $28, nF2
	dc.b	$08, nG2
	smpsAlterNote       $01
	dc.b	nBb2

AnotherPartOfMe_Jump03:
	smpsAlterNote       $00
	dc.b	nC3, nC3, nRst, $20, nC2, $08, nC2, nRst, $28, nC2, $08, nD2
	dc.b	nEb2, nE2, nE2, nRst, $28, nA2, $10, $08, nG2, nRst, nF2, nRst
	dc.b	nE2, nRst
	smpsLoop            $00, $03, AnotherPartOfMe_Loop16
	dc.b	nD3, nD3, nRst, $20, nD2, $08, nD2, nRst, $28, nG2, $08, nA2
	dc.b	nC3, nD3, nD3, nRst, $20, nD2, $08, nD2, nRst, $28, nF2, $08
	dc.b	nG2
	smpsAlterNote       $01
	dc.b	nBb2
	smpsAlterNote       $00
	dc.b	nC3, nC3, nRst, $20, nC2, $08, nC2, nRst, $28, nC2, $08, nD2
	dc.b	nEb2, nE2, nE2, nRst, $28, nA2, $10, $08, nG2, nRst, nF2, nRst
	dc.b	nA2, nRst
	smpsAlterNote       $01
	dc.b	nBb2, nBb2, nRst, $20, nBb2, $08, nBb2, nRst, $28, nBb2, $08
	smpsAlterNote       $00
	dc.b	nC3, nC3, nD3, nD3, nRst, $28, nD2, $08, $18, $08, nF2, $10
	dc.b	nD2
	smpsAlterNote       $01
	dc.b	nBb2, $08, nBb2, nRst, $20, nBb2, $08, nBb2, nRst, $28, nBb2, $08
	smpsAlterNote       $00
	dc.b	nC3, nC3, nD3, nD3, nRst, $28, nD2, $08, $18, $08, nF2, $10
	dc.b	nD2, nEb2, $08, nEb2, nRst, $20, nEb3, $08, nEb2, nRst, $28, nEb2
	dc.b	$08, nF2, nCs2, nD3, nD3, nRst, $28, nD2, $08, $18, $08, nF2
	dc.b	$10, nD2, nE2, $08, nE2, nRst, $20, nE3, $08, nE2, nRst, $18
	dc.b	nE2, $08, nG2, nRst, nA2, nRst, $18, nA2

AnotherPartOfMe_Loop17:
	dc.b	$10
	smpsLoop            $00, $08, AnotherPartOfMe_Loop17
	dc.b	nRst, $58, nC3, $08, $10, nD3, $08, nD3, nRst, $20, nD2, $08
	dc.b	nD2, nRst, $28, nG2, $08, nA2, nC3, nD3, nD3, nRst, $20, nD2
	dc.b	$08, nD2, nRst, $28, nF2, $08, nG2
	smpsAlterNote       $01
	dc.b	nBb2
	smpsPan             panCenter, $00
	smpsAlterNote       $01
	smpsJump            AnotherPartOfMe_Jump03

; FM3 Data
AnotherPartOfMe_FM3:
	smpsSetvoice        $00
	smpsAlterVol        $7F
	smpsPan             panCenter, $00
	dc.b	nRst, $03
	smpsSetvoice        $01
	smpsAlterVol        $95
	smpsPan             panLeft, $00
	dc.b	nG4, $70
	smpsSetvoice        $04
	smpsAlterVol        $FA
	dc.b	nC6, $10
	smpsSetvoice        $06
	smpsAlterVol        $06
	smpsPan             panCenter, $00
	dc.b	nRst, nF2, $08, nRst, nG2, $20, nRst, $08, nF2, nRst, nG2, nRst
	dc.b	$30, nF2, $08, nRst, nG2, $20, nRst, $08, nF2, nRst, nG2, nRst
	dc.b	$20

AnotherPartOfMe_Jump02:
	dc.b	nRst, $10, nEb2, $08, nRst, nF2, $20, nRst, $08, nEb2, nRst, nF2
	dc.b	nRst, $30, nE2, $08, nRst, nE2, $12, nRst, $06, nA2, $08, nRst
	dc.b	nA2, nRst, nA2

AnotherPartOfMe_Loop0C:
	dc.b	nRst, $30, nF2, $08, nRst, nG2, $20, nRst, $08, nF2, nRst, nG2
	smpsLoop            $00, $02, AnotherPartOfMe_Loop0C
	dc.b	nRst, $30, nEb2, $08, nRst, nF2, $20, nRst, $08, nEb2, nRst, nF2
	dc.b	nRst, $30, nE2, $08, nRst, nE2, $12, nRst, $06, nA2, $08, nRst
	dc.b	nA2, nRst, nA2, nRst, $20
	smpsPan             panLeft, $00
	dc.b	smpsNoAttack, $10

AnotherPartOfMe_Loop0D:
	dc.b	nF2, $08, nRst, nG2, $20, nRst, $08, nF2, nRst, nG2, nRst, $30
	smpsLoop            $00, $02, AnotherPartOfMe_Loop0D
	dc.b	nEb2, $08, nRst, nF2, $20, nRst, $08, nEb2, nRst, nF2, nRst, $30
	dc.b	nE2, $08, nRst, nE2, $12, nRst, $06, nA2, $08, nRst, nA2, nRst
	dc.b	nA2

AnotherPartOfMe_Loop0E:
	dc.b	nRst, $30, nF2, $08, nRst, nG2, $20, nRst, $08, nF2, nRst, nG2
	smpsLoop            $00, $02, AnotherPartOfMe_Loop0E
	dc.b	nRst, $30, nEb2, $08, nRst, nF2, $20, nRst, $08, nEb2, nRst, nF2
	dc.b	nRst, $30, nE2, $08, nRst, nE2, $12, nRst, $06, nA2, $08, nRst
	dc.b	nA2, nRst, nA2, nRst, $20
	smpsSetvoice        $08
	smpsAlterVol        $0E
	smpsAlterNote       $01
	dc.b	nBb3, $09

AnotherPartOfMe_Loop0F:
	dc.b	smpsNoAttack
	smpsAlterNote       $07
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0D
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $07
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $01
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FB
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F5
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $FB
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $01
	dc.b	$01
	smpsLoop            $00, $0B, AnotherPartOfMe_Loop0F
	dc.b	smpsNoAttack
	smpsAlterNote       $07
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0D
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $07
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $01
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FB
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F5
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $FB
	dc.b	$01
	smpsAlterNote       $00
	dc.b	nD4, $09

AnotherPartOfMe_Loop10:
	dc.b	smpsNoAttack
	smpsAlterNote       $06
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0C
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $06
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F4
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01
	smpsLoop            $00, $0B, AnotherPartOfMe_Loop10
	dc.b	smpsNoAttack
	smpsAlterNote       $06
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0C
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $06
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F4
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	$01
	smpsAlterNote       $01
	dc.b	nBb3, $09

AnotherPartOfMe_Loop11:
	dc.b	smpsNoAttack
	smpsAlterNote       $07
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0D
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $07
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $01
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FB
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F5
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $FB
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $01
	dc.b	$01
	smpsLoop            $00, $0B, AnotherPartOfMe_Loop11
	dc.b	smpsNoAttack
	smpsAlterNote       $07
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0D
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $07
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $01
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FB
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F5
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $FB
	dc.b	$01
	smpsAlterNote       $00
	dc.b	nD4, $08
	smpsSetvoice        $09
	smpsAlterVol        $EC
	dc.b	nD5, nRst, nD5, nRst, nD5, nRst, nD5, $0F, smpsNoAttack
	smpsAlterNote       $F4
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $10
	dc.b	nCs5, smpsNoAttack
	smpsAlterNote       $04
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F8
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $13
	dc.b	nC5, smpsNoAttack
	smpsAlterNote       $07
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FB
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $EF
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $09
	dc.b	nB4, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nA4, $09

AnotherPartOfMe_Loop12:
	dc.b	smpsNoAttack
	smpsAlterNote       $06
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0C
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $06
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F4
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01
	smpsLoop            $00, $03, AnotherPartOfMe_Loop12
	dc.b	smpsNoAttack
	smpsAlterNote       $06
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0C
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $06
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F4
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	$01
	smpsSetvoice        $08
	smpsAlterVol        $14
	smpsAlterNote       $00
	dc.b	nEb4, $09

AnotherPartOfMe_Loop13:
	dc.b	smpsNoAttack
	smpsAlterNote       $06
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0C
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $06
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F4
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01
	smpsLoop            $00, $0B, AnotherPartOfMe_Loop13
	dc.b	smpsNoAttack
	smpsAlterNote       $06
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0C
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $06
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F4
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	$01
	smpsAlterNote       $00
	dc.b	nD4, $09
	smpsLoop            $01, $02, AnotherPartOfMe_Loop13

AnotherPartOfMe_Loop14:
	dc.b	smpsNoAttack
	smpsAlterNote       $06
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0C
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $06
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F4
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01
	smpsLoop            $00, $0B, AnotherPartOfMe_Loop14
	dc.b	smpsNoAttack
	smpsAlterNote       $06
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0C
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $06
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F4
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	$01
	smpsSetvoice        $04
	smpsAlterVol        $EE
	dc.b	nRst, $10
	smpsAlterNote       $00

AnotherPartOfMe_Loop15:
	dc.b	nE4, $07, nRst, $09
	smpsLoop            $00, $07, AnotherPartOfMe_Loop15
	dc.b	nF4, $10, nRst, $70
	smpsSetvoice        $06
	smpsAlterVol        $04
	smpsPan             panCenter, $00
	dc.b	smpsNoAttack, $10, nF2, $08, nRst, nG2, $20, nRst, $08, nF2, nRst, nG2
	dc.b	nRst, $30, nF2, $08, nRst, nG2, $20, nRst, $08, nF2, nRst, nG2
	dc.b	nRst, $20
	smpsPan             panCenter, $00
	smpsJump            AnotherPartOfMe_Jump02

; FM4 Data
AnotherPartOfMe_FM4:
	smpsSetvoice        $00
	smpsAlterVol        $7F
	smpsPan             panCenter, $00
	dc.b	nRst, $03
	smpsSetvoice        $01
	smpsAlterVol        $95
	smpsPan             panRight, $00
	dc.b	nD4, $70
	smpsSetvoice        $04
	smpsAlterVol        $FA
	dc.b	nG5, $10
	smpsSetvoice        $06
	smpsAlterVol        $06
	dc.b	nRst, nC2, $08, nRst, nD2, $20, nRst, $08, nC2, nRst, nD2, nRst
	dc.b	$30, nC2, $08, nRst, nD2, $20, nRst, $08, nC2, nRst, nD2, nRst
	dc.b	$20

AnotherPartOfMe_Jump01:
	dc.b	nRst, $10

AnotherPartOfMe_Loop03:
	smpsAlterNote       $01
	dc.b	nBb1, $08, nRst
	smpsAlterNote       $00
	dc.b	nC2, $20, nRst, $08
	smpsAlterNote       $01
	dc.b	nBb1, nRst
	smpsAlterNote       $00
	dc.b	nC2, nRst, $30, nD2, $08, nRst, nD2, $12, nRst, $06, nF2, $08
	dc.b	nRst, nF2, nRst, nF2

AnotherPartOfMe_Loop02:
	dc.b	nRst, $30, nC2, $08, nRst, nD2, $20, nRst, $08, nC2, nRst, nD2
	smpsLoop            $00, $02, AnotherPartOfMe_Loop02
	dc.b	nRst, $30
	smpsLoop            $01, $03, AnotherPartOfMe_Loop03
	smpsAlterNote       $01
	dc.b	nBb1, $08, nRst
	smpsAlterNote       $00
	dc.b	nC2, $20, nRst, $08
	smpsAlterNote       $01
	dc.b	nBb1, nRst
	smpsAlterNote       $00
	dc.b	nC2, nRst, $30, nD2, $08, nRst, nD2, $12, nRst, $06, nF2, $08
	dc.b	nRst, nF2, nRst, nF2, nRst, $20
	smpsSetvoice        $08
	smpsAlterVol        $0E
	dc.b	nF3, $09

AnotherPartOfMe_Loop04:
	dc.b	smpsNoAttack
	smpsAlterNote       $06
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0C
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $06
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F4
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01
	smpsLoop            $00, $0B, AnotherPartOfMe_Loop04
	dc.b	smpsNoAttack
	smpsAlterNote       $06
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0C
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $06
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F4
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	$01
	smpsAlterNote       $00
	dc.b	nA3, $09

AnotherPartOfMe_Loop05:
	dc.b	smpsNoAttack
	smpsAlterNote       $06
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0C
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $06
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F4
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01
	smpsLoop            $00, $0B, AnotherPartOfMe_Loop05
	dc.b	smpsNoAttack
	smpsAlterNote       $06
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0C
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $06
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F4
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	$01
	smpsAlterNote       $00
	dc.b	nF3, $09

AnotherPartOfMe_Loop06:
	dc.b	smpsNoAttack
	smpsAlterNote       $06
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0C
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $06
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F4
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01
	smpsLoop            $00, $0B, AnotherPartOfMe_Loop06
	dc.b	smpsNoAttack
	smpsAlterNote       $06
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0C
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $06
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F4
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	$01
	smpsAlterNote       $00
	dc.b	nA3, $08
	smpsSetvoice        $09
	smpsAlterVol        $EC
	dc.b	nA4, nRst, nA4, nRst, nA4, nRst, nA4, $0F, smpsNoAttack
	smpsAlterNote       $F4
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E8
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $19
	dc.b	nAb4, smpsNoAttack
	smpsAlterNote       $0D
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $01
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F5
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $E9
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $17
	dc.b	nG4, smpsNoAttack
	smpsAlterNote       $0B
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	nF4, $09

AnotherPartOfMe_Loop07:
	dc.b	smpsNoAttack
	smpsAlterNote       $06
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0C
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $06
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F4
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01
	smpsLoop            $00, $03, AnotherPartOfMe_Loop07
	dc.b	smpsNoAttack
	smpsAlterNote       $06
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0C
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $06
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F4
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	$01
	smpsSetvoice        $08
	smpsAlterVol        $14
	smpsAlterNote       $01
	dc.b	nBb3, $09

AnotherPartOfMe_Loop08:
	dc.b	smpsNoAttack
	smpsAlterNote       $07
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0D
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $07
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $01
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FB
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F5
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $FB
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $01
	dc.b	$01
	smpsLoop            $00, $0B, AnotherPartOfMe_Loop08
	dc.b	smpsNoAttack
	smpsAlterNote       $07
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0D
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $07
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $01
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FB
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F5
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $FB
	dc.b	$01
	smpsAlterNote       $00
	dc.b	nA3, $09

AnotherPartOfMe_Loop09:
	dc.b	smpsNoAttack
	smpsAlterNote       $06
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0C
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $06
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F4
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01
	smpsLoop            $00, $0B, AnotherPartOfMe_Loop09
	dc.b	smpsNoAttack
	smpsAlterNote       $06
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0C
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $06
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $00
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F4
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $FA
	dc.b	$01
	smpsAlterNote       $01
	dc.b	nBb3, $09

AnotherPartOfMe_Loop0A:
	dc.b	smpsNoAttack
	smpsAlterNote       $07
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0D
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $07
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $01
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FB
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F5
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $FB
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $01
	dc.b	$01
	smpsLoop            $00, $0B, AnotherPartOfMe_Loop0A
	dc.b	smpsNoAttack
	smpsAlterNote       $07
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $0D
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $07
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $01
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $FB
	dc.b	$01, smpsNoAttack
	smpsAlterNote       $F5
	dc.b	$02, smpsNoAttack
	smpsAlterNote       $FB
	dc.b	$01
	smpsSetvoice        $04
	smpsAlterVol        $EE
	dc.b	nRst, $10
	smpsAlterNote       $00

AnotherPartOfMe_Loop0B:
	dc.b	nD4, $07, nRst, $09
	smpsLoop            $00, $07, AnotherPartOfMe_Loop0B
	dc.b	nCs4, $10
	smpsAlterVol        $04
	smpsPan             panCenter, $00
	dc.b	nCs3, $02, smpsNoAttack, nD3, $06, nRst, $08, nF3, $10, nA3, nG3, nF3
	dc.b	nEb3, $02, smpsNoAttack, nE3, $0E, nC3, $10
	smpsSetvoice        $06
	smpsPan             panRight, $00
	dc.b	nRst, nC2, $08, nRst, nD2, $20, nRst, $08, nC2, nRst, nD2, nRst
	dc.b	$30, nC2, $08, nRst, nD2, $20, nRst, $08, nC2, nRst, nD2, nRst
	dc.b	$20
	smpsPan             panRight, $00
	smpsJump            AnotherPartOfMe_Jump01

; FM5 Data
AnotherPartOfMe_FM5:
	smpsSetvoice        $00
	smpsAlterVol        $7F
	smpsPan             panCenter, $00
	dc.b	nRst, $03
	smpsSetvoice        $01
	smpsAlterVol        $91
	dc.b	nG3, $70
	smpsSetvoice        $04
	dc.b	nD5, $10
	smpsSetvoice        $06
	smpsAlterVol        $04
	smpsPan             panLeft, $00
	dc.b	nRst, nA1, $08, nRst, nB1, $20, nRst, $08, nA1, nRst, nB1, nRst
	dc.b	$30, nA1, $08, nRst, nB1, $20, nRst, $08, nA1, nRst, nB1, nRst
	dc.b	$20

AnotherPartOfMe_Jump00:
	dc.b	nRst, $10, nG1, $08, nRst, nA1, $20, nRst, $08, nG1, nRst, nA1
	dc.b	nRst, $30
	smpsAlterNote       $01
	dc.b	nBb1, $08, nRst, nBb1, $12, nRst, $06
	smpsAlterNote       $00
	dc.b	nCs2, $08, nRst, nCs2, nRst, nCs2, nRst, $20
	smpsSetvoice        $07
	smpsAlterVol        $FC
	smpsPan             panCenter, $00
	dc.b	nD5, $08, nF5, nD5, nRst, $50, nG4, $08, nA4, nC5, nD5, nF5
	dc.b	nD5, nRst, $50, nF4, $08, nG4
	smpsAlterNote       $01
	dc.b	nBb4
	smpsAlterNote       $00
	dc.b	nC5, nEb5, nC5, nRst, $7F, $29
	smpsSetvoice        $06
	smpsAlterVol        $04
	smpsPan             panLeft, $00
	dc.b	smpsNoAttack, $08, nCs2, nRst, nCs2, nRst, $20
	smpsSetvoice        $07
	smpsAlterVol        $FC
	smpsPan             panCenter, $00

AnotherPartOfMe_Loop00:
	dc.b	nD5, $08, nF5, nD5, nRst, $50, nG4, $08, nA4, nC5, nD5, nF5
	dc.b	nD5, nRst, $50, nF4, $08, nG4
	smpsAlterNote       $01
	dc.b	nBb4
	smpsAlterNote       $00
	dc.b	nC5, nEb5, nC5, nRst, $7F, $69
	smpsLoop            $00, $02, AnotherPartOfMe_Loop00
	smpsSetvoice        $08
	smpsAlterVol        $10
	dc.b	nD4, $60, nE4, $20, nF4, $60, nG4, $20, nD4, $60
	smpsAlterNote       $01
	dc.b	nBb4, $20
	smpsAlterNote       $00
	dc.b	nA4, $60, nF4, $20
	smpsSetvoice        $0A
	smpsAlterVol        $EE
	smpsPan             panRight, $00
	dc.b	nG6, $60, nEb6, $20, nF6, $40, nD6, nE6, $7F, smpsNoAttack, $01
	smpsSetvoice        $03
	smpsPan             panCenter, $00
	dc.b	nRst, $10

AnotherPartOfMe_Loop01:
	dc.b	nA5, $07, nRst, $09
	smpsLoop            $00, $07, AnotherPartOfMe_Loop01
	dc.b	nA5, $10, nRst, $70
	smpsSetvoice        $06
	smpsAlterVol        $06
	smpsPan             panLeft, $00
	dc.b	smpsNoAttack, $10, nA1, $08, nRst, nB1, $20, nRst, $08, nA1, nRst, nB1
	dc.b	nRst, $30, nA1, $08, nRst, nB1, $20, nRst, $08, nA1, nRst, nB1
	dc.b	nRst, $20
	smpsPan             panLeft, $00
	smpsJump            AnotherPartOfMe_Jump00

; PSG1 Data
AnotherPartOfMe_PSG1:
	dc.b	nRst, $7F, $14
	smpsPSGAlterVol     $05

AnotherPartOfMe_Loop5C:
	dc.b	nA0, $08, nRst, nB0, $20, nRst, $08, nA0, nRst, nB0, nRst, $30
	smpsLoop            $00, $02, AnotherPartOfMe_Loop5C

AnotherPartOfMe_Jump07:
	dc.b	nRst, $10, nG0, $08, nRst, nA0, $20, nRst, $08, nG0, nRst, nA0
	dc.b	nRst, $30, nBb0, $08, nRst, nBb0, $12, nRst, $06, nCs1, $08, nRst
	dc.b	nCs1, nRst, nCs1

AnotherPartOfMe_Loop5D:
	dc.b	nRst, $30, nA0, $08, nRst, nB0, $20, nRst, $08, nA0, nRst, nB0
	smpsLoop            $00, $02, AnotherPartOfMe_Loop5D
	dc.b	nRst, $30, nG0, $08, nRst, nA0, $20, nRst, $08, nG0, nRst, nA0
	dc.b	nRst, $30, nBb0, $08, nRst, nBb0, $12, nRst, $06, nCs1, $08, nRst
	dc.b	nCs1, nRst, nCs1, nRst, $30
	smpsPSGAlterVol     $FE

AnotherPartOfMe_Loop5E:
	dc.b	nA0, $08, nRst, nB0, $20, nRst, $08, nA0, nRst, nB0, nRst, $30
	smpsLoop            $00, $02, AnotherPartOfMe_Loop5E
	dc.b	nG0, $08, nRst, nA0, $20, nRst, $08, nG0, nRst, nA0, nRst, $30
	dc.b	nBb0, $08, nRst, nBb0, $12, nRst, $06, nCs1, $08, nRst, nCs1, nRst
	dc.b	nCs1

AnotherPartOfMe_Loop5F:
	dc.b	nRst, $30, nA0, $08, nRst, nB0, $20, nRst, $08, nA0, nRst, nB0
	smpsLoop            $00, $02, AnotherPartOfMe_Loop5F
	dc.b	nRst, $30, nG0, $08, nRst, nA0, $20, nRst, $08, nG0, nRst, nA0
	dc.b	nRst, $30, nBb0, $08, nRst, nBb0, $12, nRst, $06, nCs1, $08, nRst
	dc.b	nCs1, nRst, nCs1, nRst, $20
	smpsPSGAlterVol     $02

AnotherPartOfMe_Loop62:
	dc.b	nD1, $09

AnotherPartOfMe_Loop60:
	smpsAlterNote       $02
	dc.b	$01
	smpsAlterNote       $04
	dc.b	$02
	smpsAlterNote       $02
	dc.b	$01
	smpsAlterNote       $00
	dc.b	nD1
	smpsAlterNote       $FE
	dc.b	nD1
	smpsAlterNote       $FC
	dc.b	$02
	smpsAlterNote       $FE
	dc.b	$01
	smpsAlterNote       $00
	dc.b	nD1
	smpsLoop            $00, $0B, AnotherPartOfMe_Loop60
	smpsAlterNote       $02
	dc.b	nD1
	smpsAlterNote       $04
	dc.b	$02
	smpsAlterNote       $02
	dc.b	$01
	smpsAlterNote       $00
	dc.b	nD1
	smpsAlterNote       $FE
	dc.b	nD1
	smpsAlterNote       $FC
	dc.b	$02
	smpsAlterNote       $FE
	dc.b	$01
	smpsAlterNote       $00
	dc.b	nF1, $09

AnotherPartOfMe_Loop61:
	smpsAlterNote       $02
	dc.b	$01
	smpsAlterNote       $04
	dc.b	$02
	smpsAlterNote       $02
	dc.b	$01
	smpsAlterNote       $00
	dc.b	nF1
	smpsAlterNote       $FE
	dc.b	nF1
	smpsAlterNote       $FC
	dc.b	$02
	smpsAlterNote       $FE
	dc.b	$01
	smpsAlterNote       $00
	dc.b	nF1
	smpsLoop            $00, $0B, AnotherPartOfMe_Loop61
	smpsAlterNote       $02
	dc.b	nF1
	smpsAlterNote       $04
	dc.b	$02
	smpsAlterNote       $02
	dc.b	$01
	smpsAlterNote       $00
	dc.b	nF1
	smpsAlterNote       $FE
	dc.b	nF1
	smpsAlterNote       $FC
	dc.b	$02
	smpsAlterNote       $FE
	dc.b	$01
	smpsAlterNote       $00
	smpsLoop            $01, $02, AnotherPartOfMe_Loop62
	dc.b	nG1, $09

AnotherPartOfMe_Loop63:
	smpsAlterNote       $02
	dc.b	$01
	smpsAlterNote       $04
	dc.b	$02
	smpsAlterNote       $02
	dc.b	$01
	smpsAlterNote       $00
	dc.b	nG1
	smpsAlterNote       $FE
	dc.b	nG1
	smpsAlterNote       $FC
	dc.b	$02
	smpsAlterNote       $FE
	dc.b	$01
	smpsAlterNote       $00
	dc.b	nG1
	smpsLoop            $00, $0B, AnotherPartOfMe_Loop63
	smpsAlterNote       $02
	dc.b	nG1
	smpsAlterNote       $04
	dc.b	$02
	smpsAlterNote       $02
	dc.b	$01
	smpsAlterNote       $00
	dc.b	nG1
	smpsAlterNote       $FE
	dc.b	nG1
	smpsAlterNote       $FC
	dc.b	$02
	smpsAlterNote       $FE
	dc.b	$01
	smpsAlterNote       $00
	dc.b	nF1, $09

AnotherPartOfMe_Loop64:
	smpsAlterNote       $02
	dc.b	$01
	smpsAlterNote       $04
	dc.b	$02
	smpsAlterNote       $02
	dc.b	$01
	smpsAlterNote       $00
	dc.b	nF1
	smpsAlterNote       $FE
	dc.b	nF1
	smpsAlterNote       $FC
	dc.b	$02
	smpsAlterNote       $FE
	dc.b	$01
	smpsAlterNote       $00
	dc.b	nF1
	smpsLoop            $00, $0B, AnotherPartOfMe_Loop64
	smpsAlterNote       $02
	dc.b	nF1
	smpsAlterNote       $04
	dc.b	$02
	smpsAlterNote       $02
	dc.b	$01
	smpsAlterNote       $00
	dc.b	nF1
	smpsAlterNote       $FE
	dc.b	nF1
	smpsAlterNote       $FC
	dc.b	$02
	smpsAlterNote       $FE
	dc.b	$01
	smpsAlterNote       $00
	dc.b	nG1, $09

AnotherPartOfMe_Loop65:
	smpsAlterNote       $02
	dc.b	$01
	smpsAlterNote       $04
	dc.b	$02
	smpsAlterNote       $02
	dc.b	$01
	smpsAlterNote       $00
	dc.b	nG1
	smpsAlterNote       $FE
	dc.b	nG1
	smpsAlterNote       $FC
	dc.b	$02
	smpsAlterNote       $FE
	dc.b	$01
	smpsAlterNote       $00
	dc.b	nG1
	smpsLoop            $00, $0B, AnotherPartOfMe_Loop65
	smpsAlterNote       $02
	dc.b	nG1
	smpsAlterNote       $04
	dc.b	$02
	smpsAlterNote       $02
	dc.b	$01
	smpsAlterNote       $00
	dc.b	nG1
	smpsAlterNote       $FE
	dc.b	nG1
	smpsAlterNote       $FC
	dc.b	$02
	smpsAlterNote       $FE
	dc.b	$01, nRst, $10
	smpsPSGAlterVol     $FE

AnotherPartOfMe_Loop66:
	smpsAlterNote       $00
	dc.b	nA1, $07, nRst, $09
	smpsLoop            $00, $07, AnotherPartOfMe_Loop66
	smpsAlterNote       $00
	dc.b	nA1, $10, nRst, $7F, $01
	smpsPSGAlterVol     $02
	dc.b	nA0, $08, nRst, nB0, $20, nRst, $08, nA0, nRst, nB0, nRst, $30
	dc.b	nA0, $08, nRst, nB0, $20, nRst, $08, nA0, nRst, nB0, nRst, $20
	smpsJump            AnotherPartOfMe_Jump07

; PSG2 Data
AnotherPartOfMe_PSG2:
	dc.b	nRst, $7F, $14
	smpsPSGAlterVol     $05

AnotherPartOfMe_Loop51:
	dc.b	nF0, $08, nRst, nG0, $20, nRst, $08, nF0, nRst, nG0, nRst, $30
	smpsLoop            $00, $02, AnotherPartOfMe_Loop51

AnotherPartOfMe_Jump06:
	dc.b	nRst, $10, nEb0, $08, nRst, nF0, $20, nRst, $08, nEb0, nRst, nF0
	dc.b	nRst, $30, nG0, $08, nRst, nG0, $12, nRst, $06, nG0, $08, nRst
	dc.b	nG0

AnotherPartOfMe_Loop52:
	dc.b	nRst, nG0, nRst, $30, nF0, $08, nRst, nG0, $20, nRst, $08, nF0
	smpsLoop            $00, $02, AnotherPartOfMe_Loop52
	dc.b	nRst, nG0, nRst, $30, nEb0, $08, nRst, nF0, $20, nRst, $08, nEb0
	dc.b	nRst, nF0, nRst, $30, nG0, $08, nRst, nG0, $12, nRst, $06, nG0
	dc.b	$08, nRst, nG0, nRst, nG0, nRst, $30
	smpsPSGAlterVol     $FE

AnotherPartOfMe_Loop53:
	dc.b	nF0, $08, nRst, nG0, $20, nRst, $08, nF0, nRst, nG0, nRst, $30
	smpsLoop            $00, $02, AnotherPartOfMe_Loop53
	dc.b	nEb0, $08, nRst, nF0, $20, nRst, $08, nEb0, nRst, nF0, nRst, $30
	dc.b	nG0, $08, nRst, nG0, $12, nRst, $06, nG0, $08, nRst, nG0

AnotherPartOfMe_Loop54:
	dc.b	nRst, nG0, nRst, $30, nF0, $08, nRst, nG0, $20, nRst, $08, nF0
	smpsLoop            $00, $02, AnotherPartOfMe_Loop54
	dc.b	nRst, nG0, nRst, $30, nEb0, $08, nRst, nF0, $20, nRst, $08, nEb0
	dc.b	nRst, nF0, nRst, $30, nG0, $08, nRst, nG0, $12, nRst, $06, nG0
	dc.b	$08, nRst, nG0, nRst, nG0, nRst, $20
	smpsPSGAlterVol     $02

AnotherPartOfMe_Loop57:
	dc.b	nBb0, $09

AnotherPartOfMe_Loop55:
	smpsAlterNote       $02
	dc.b	$01
	smpsAlterNote       $04
	dc.b	$02
	smpsAlterNote       $02
	dc.b	$01
	smpsAlterNote       $00
	dc.b	nBb0
	smpsAlterNote       $FE
	dc.b	nBb0
	smpsAlterNote       $FC
	dc.b	$02
	smpsAlterNote       $FE
	dc.b	$01
	smpsAlterNote       $00
	dc.b	nBb0
	smpsLoop            $00, $0B, AnotherPartOfMe_Loop55
	smpsAlterNote       $02
	dc.b	nBb0
	smpsAlterNote       $04
	dc.b	$02
	smpsAlterNote       $02
	dc.b	$01
	smpsAlterNote       $00
	dc.b	nBb0
	smpsAlterNote       $FE
	dc.b	nBb0
	smpsAlterNote       $FC
	dc.b	$02
	smpsAlterNote       $FE
	dc.b	$01
	smpsAlterNote       $00
	dc.b	nD1, $09

AnotherPartOfMe_Loop56:
	smpsAlterNote       $02
	dc.b	$01
	smpsAlterNote       $04
	dc.b	$02
	smpsAlterNote       $02
	dc.b	$01
	smpsAlterNote       $00
	dc.b	nD1
	smpsAlterNote       $FE
	dc.b	nD1
	smpsAlterNote       $FC
	dc.b	$02
	smpsAlterNote       $FE
	dc.b	$01
	smpsAlterNote       $00
	dc.b	nD1
	smpsLoop            $00, $0B, AnotherPartOfMe_Loop56
	smpsAlterNote       $02
	dc.b	nD1
	smpsAlterNote       $04
	dc.b	$02
	smpsAlterNote       $02
	dc.b	$01
	smpsAlterNote       $00
	dc.b	nD1
	smpsAlterNote       $FE
	dc.b	nD1
	smpsAlterNote       $FC
	dc.b	$02
	smpsAlterNote       $FE
	dc.b	$01
	smpsAlterNote       $00
	smpsLoop            $01, $02, AnotherPartOfMe_Loop57
	dc.b	nEb1, $09

AnotherPartOfMe_Loop58:
	smpsAlterNote       $02
	dc.b	$01
	smpsAlterNote       $04
	dc.b	$02
	smpsAlterNote       $02
	dc.b	$01
	smpsAlterNote       $00
	dc.b	nEb1
	smpsAlterNote       $FE
	dc.b	nEb1
	smpsAlterNote       $FC
	dc.b	$02
	smpsAlterNote       $FE
	dc.b	$01
	smpsAlterNote       $00
	dc.b	nEb1
	smpsLoop            $00, $0B, AnotherPartOfMe_Loop58
	smpsAlterNote       $02
	dc.b	nEb1
	smpsAlterNote       $04
	dc.b	$02
	smpsAlterNote       $02
	dc.b	$01
	smpsAlterNote       $00
	dc.b	nEb1
	smpsAlterNote       $FE
	dc.b	nEb1
	smpsAlterNote       $FC
	dc.b	$02
	smpsAlterNote       $FE
	dc.b	$01
	smpsAlterNote       $00
	dc.b	nD1, $09

AnotherPartOfMe_Loop59:
	smpsAlterNote       $02
	dc.b	$01
	smpsAlterNote       $04
	dc.b	$02
	smpsAlterNote       $02
	dc.b	$01
	smpsAlterNote       $00
	dc.b	nD1
	smpsAlterNote       $FE
	dc.b	nD1
	smpsAlterNote       $FC
	dc.b	$02
	smpsAlterNote       $FE
	dc.b	$01
	smpsAlterNote       $00
	dc.b	nD1
	smpsLoop            $00, $0B, AnotherPartOfMe_Loop59
	smpsAlterNote       $02
	dc.b	nD1
	smpsAlterNote       $04
	dc.b	$02
	smpsAlterNote       $02
	dc.b	$01
	smpsAlterNote       $00
	dc.b	nD1
	smpsAlterNote       $FE
	dc.b	nD1
	smpsAlterNote       $FC
	dc.b	$02
	smpsAlterNote       $FE
	dc.b	$01
	smpsAlterNote       $00
	dc.b	nE1, $09

AnotherPartOfMe_Loop5A:
	smpsAlterNote       $02
	dc.b	$01
	smpsAlterNote       $04
	dc.b	$02
	smpsAlterNote       $02
	dc.b	$01
	smpsAlterNote       $00
	dc.b	nE1
	smpsAlterNote       $FE
	dc.b	nE1
	smpsAlterNote       $FC
	dc.b	$02
	smpsAlterNote       $FE
	dc.b	$01
	smpsAlterNote       $00
	dc.b	nE1
	smpsLoop            $00, $0B, AnotherPartOfMe_Loop5A
	smpsAlterNote       $02
	dc.b	nE1
	smpsAlterNote       $04
	dc.b	$02
	smpsAlterNote       $02
	dc.b	$01
	smpsAlterNote       $00
	dc.b	nE1
	smpsAlterNote       $FE
	dc.b	nE1
	smpsAlterNote       $FC
	dc.b	$02
	smpsAlterNote       $FE
	dc.b	$01, nRst, $10
	smpsPSGAlterVol     $FE

AnotherPartOfMe_Loop5B:
	smpsAlterNote       $00
	dc.b	nG1, $07, nRst, $09
	smpsLoop            $00, $07, AnotherPartOfMe_Loop5B
	smpsAlterNote       $00
	dc.b	nG1, $10, nRst, $7F, $01
	smpsPSGAlterVol     $02
	dc.b	nF0, $08, nRst, nG0, $20, nRst, $08, nF0, nRst, nG0, nRst, $30
	dc.b	nF0, $08, nRst, nG0, $20, nRst, $08, nF0, nRst, nG0, nRst, $20
	smpsJump            AnotherPartOfMe_Jump06

; PSG3 Data
AnotherPartOfMe_PSG3:
	dc.b	nRst, $03
	smpsPSGAlterVol     $03
	smpsPSGform         $E7
	smpsAlterNote       $01
	dc.b	nMaxPSG, $02
	smpsPSGAlterVol     $02
	smpsAlterNote       $01
	dc.b	$01
	smpsPSGAlterVol     $01
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $01
	smpsAlterNote       $01
	dc.b	$02
	smpsPSGAlterVol     $01
	smpsAlterNote       $01
	dc.b	$03
	smpsPSGAlterVol     $01
	smpsAlterNote       $01
	dc.b	$07, nRst, $60
	smpsPSGAlterVol     $FA
	smpsAlterNote       $01
	dc.b	nMaxPSG, $02
	smpsPSGAlterVol     $02
	smpsAlterNote       $01
	dc.b	$01
	smpsPSGAlterVol     $01
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $01
	smpsAlterNote       $01
	dc.b	$02
	smpsPSGAlterVol     $01
	smpsAlterNote       $01
	dc.b	$03
	smpsPSGAlterVol     $01
	smpsAlterNote       $01
	dc.b	$07
	smpsPSGAlterVol     $FA
	smpsAlterNote       $01
	dc.b	$02

AnotherPartOfMe_Loop26:
	dc.b	nRst, $06
	smpsAlterNote       $01
	dc.b	nMaxPSG, $02
	smpsLoop            $00, $04, AnotherPartOfMe_Loop26
	smpsPSGAlterVol     $02
	smpsAlterNote       $01
	dc.b	$01
	smpsPSGAlterVol     $01
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $01
	smpsAlterNote       $01
	dc.b	$02
	smpsPSGAlterVol     $01
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $FB
	smpsAlterNote       $01
	dc.b	nMaxPSG, nRst, $06

AnotherPartOfMe_Loop27:
	smpsAlterNote       $01
	dc.b	nMaxPSG, $02
	smpsPSGAlterVol     $02
	smpsAlterNote       $01
	dc.b	$01
	smpsPSGAlterVol     $01
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $01
	smpsAlterNote       $01
	dc.b	$02
	smpsPSGAlterVol     $01
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $FB
	smpsLoop            $00, $02, AnotherPartOfMe_Loop27
	smpsAlterNote       $01
	dc.b	nMaxPSG

AnotherPartOfMe_Loop28:
	dc.b	nRst, $06
	smpsAlterNote       $01
	dc.b	nMaxPSG, $02
	smpsLoop            $00, $04, AnotherPartOfMe_Loop28
	smpsPSGAlterVol     $02
	smpsAlterNote       $01
	dc.b	$01
	smpsPSGAlterVol     $01
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $01
	smpsAlterNote       $01
	dc.b	$02
	smpsPSGAlterVol     $01
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $FB
	smpsAlterNote       $01
	dc.b	nMaxPSG

AnotherPartOfMe_Loop29:
	dc.b	nRst, $06
	smpsAlterNote       $01
	dc.b	nMaxPSG, $02
	smpsLoop            $00, $07, AnotherPartOfMe_Loop29
	smpsPSGAlterVol     $02
	smpsAlterNote       $01
	dc.b	$01
	smpsPSGAlterVol     $01
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $01
	smpsAlterNote       $01
	dc.b	$02
	smpsPSGAlterVol     $01
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $FB
	smpsAlterNote       $01
	dc.b	nMaxPSG, nRst, $06

AnotherPartOfMe_Loop2A:
	smpsAlterNote       $01
	dc.b	nMaxPSG, $02
	smpsPSGAlterVol     $02
	smpsAlterNote       $01
	dc.b	$01
	smpsPSGAlterVol     $01
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $01
	smpsAlterNote       $01
	dc.b	$02
	smpsPSGAlterVol     $01
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $FB
	smpsLoop            $00, $02, AnotherPartOfMe_Loop2A
	smpsAlterNote       $01
	dc.b	nMaxPSG

AnotherPartOfMe_Loop2B:
	dc.b	nRst, $06
	smpsAlterNote       $01
	dc.b	nMaxPSG, $02
	smpsLoop            $00, $04, AnotherPartOfMe_Loop2B
	smpsPSGAlterVol     $02
	smpsAlterNote       $01
	dc.b	$01
	smpsPSGAlterVol     $01
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $01
	smpsAlterNote       $01
	dc.b	$02
	smpsPSGAlterVol     $01
	smpsAlterNote       $01
	dc.b	nMaxPSG
	smpsPSGAlterVol     $FB
	smpsAlterNote       $01
	dc.b	nMaxPSG

AnotherPartOfMe_Loop2C:
	dc.b	nRst, $06
	smpsAlterNote       $01
	dc.b	nMaxPSG, $02
	smpsLoop            $00, $02, AnotherPartOfMe_Loop2C

AnotherPartOfMe_Loop2D:
	dc.b	nRst, $06

AnotherPartOfMe_Jump05:
	smpsAlterNote       $00
	dc.b	nMaxPSG, $02
	smpsLoop            $00, $05, AnotherPartOfMe_Loop2D
	smpsPSGAlterVol     $02
	smpsAlterNote       $00
	dc.b	$01
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	nMaxPSG
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	$02
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	nMaxPSG
	smpsPSGAlterVol     $FB
	smpsAlterNote       $00
	dc.b	nMaxPSG, nRst, $06

AnotherPartOfMe_Loop2E:
	smpsAlterNote       $00
	dc.b	nMaxPSG, $02
	smpsPSGAlterVol     $02
	smpsAlterNote       $00
	dc.b	$01
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	nMaxPSG
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	$02
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	nMaxPSG
	smpsPSGAlterVol     $FB
	smpsLoop            $00, $02, AnotherPartOfMe_Loop2E
	smpsAlterNote       $00
	dc.b	nMaxPSG

AnotherPartOfMe_Loop2F:
	dc.b	nRst, $06
	smpsAlterNote       $00
	dc.b	nMaxPSG, $02
	smpsLoop            $00, $04, AnotherPartOfMe_Loop2F

AnotherPartOfMe_Loop31:
	smpsPSGAlterVol     $02
	smpsAlterNote       $00
	dc.b	$01
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	nMaxPSG
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	$02
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	nMaxPSG
	smpsPSGAlterVol     $FB
	smpsAlterNote       $00
	dc.b	nMaxPSG

AnotherPartOfMe_Loop30:
	dc.b	nRst, $06
	smpsAlterNote       $00
	dc.b	nMaxPSG, $02
	smpsLoop            $00, $07, AnotherPartOfMe_Loop30
	smpsLoop            $01, $03, AnotherPartOfMe_Loop31

AnotherPartOfMe_Loop35:
	smpsPSGAlterVol     $02
	smpsAlterNote       $00
	dc.b	$01
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	nMaxPSG
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	$02
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	nMaxPSG
	smpsPSGAlterVol     $FB
	smpsAlterNote       $00
	dc.b	nMaxPSG, nRst, $06

AnotherPartOfMe_Loop32:
	smpsAlterNote       $00
	dc.b	nMaxPSG, $02
	smpsPSGAlterVol     $02
	smpsAlterNote       $00
	dc.b	$01
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	nMaxPSG
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	$02
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	nMaxPSG
	smpsPSGAlterVol     $FB
	smpsLoop            $00, $02, AnotherPartOfMe_Loop32
	smpsAlterNote       $00
	dc.b	nMaxPSG

AnotherPartOfMe_Loop33:
	dc.b	nRst, $06
	smpsAlterNote       $00
	dc.b	nMaxPSG, $02
	smpsLoop            $00, $04, AnotherPartOfMe_Loop33
	smpsPSGAlterVol     $02
	smpsAlterNote       $00
	dc.b	$01
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	nMaxPSG
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	$02
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	nMaxPSG
	smpsPSGAlterVol     $FB
	smpsAlterNote       $00
	dc.b	nMaxPSG

AnotherPartOfMe_Loop34:
	dc.b	nRst, $06
	smpsAlterNote       $00
	dc.b	nMaxPSG, $02
	smpsLoop            $00, $07, AnotherPartOfMe_Loop34
	smpsLoop            $01, $03, AnotherPartOfMe_Loop35

AnotherPartOfMe_Loop37:
	smpsPSGAlterVol     $02
	smpsAlterNote       $00
	dc.b	$01
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	nMaxPSG
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	$02
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	nMaxPSG
	smpsPSGAlterVol     $FB
	smpsAlterNote       $00
	dc.b	nMaxPSG

AnotherPartOfMe_Loop36:
	dc.b	nRst, $06
	smpsAlterNote       $00
	dc.b	nMaxPSG, $02
	smpsLoop            $00, $07, AnotherPartOfMe_Loop36
	smpsLoop            $01, $02, AnotherPartOfMe_Loop37

AnotherPartOfMe_Loop3B:
	smpsPSGAlterVol     $02
	smpsAlterNote       $00
	dc.b	$01
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	nMaxPSG
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	$02
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	nMaxPSG
	smpsPSGAlterVol     $FB
	smpsAlterNote       $00
	dc.b	nMaxPSG, nRst, $06

AnotherPartOfMe_Loop38:
	smpsAlterNote       $00
	dc.b	nMaxPSG, $02
	smpsPSGAlterVol     $02
	smpsAlterNote       $00
	dc.b	$01
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	nMaxPSG
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	$02
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	nMaxPSG
	smpsPSGAlterVol     $FB
	smpsLoop            $00, $02, AnotherPartOfMe_Loop38
	smpsAlterNote       $00
	dc.b	nMaxPSG

AnotherPartOfMe_Loop39:
	dc.b	nRst, $06
	smpsAlterNote       $00
	dc.b	nMaxPSG, $02
	smpsLoop            $00, $04, AnotherPartOfMe_Loop39
	smpsPSGAlterVol     $02
	smpsAlterNote       $00
	dc.b	$01
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	nMaxPSG
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	$02
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	nMaxPSG
	smpsPSGAlterVol     $FB
	smpsAlterNote       $00
	dc.b	nMaxPSG

AnotherPartOfMe_Loop3A:
	dc.b	nRst, $06
	smpsAlterNote       $00
	dc.b	nMaxPSG, $02
	smpsLoop            $00, $07, AnotherPartOfMe_Loop3A
	smpsLoop            $01, $03, AnotherPartOfMe_Loop3B

AnotherPartOfMe_Loop3D:
	smpsPSGAlterVol     $02
	smpsAlterNote       $00
	dc.b	$01
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	nMaxPSG
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	$02
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	nMaxPSG
	smpsPSGAlterVol     $FB
	smpsAlterNote       $00
	dc.b	nMaxPSG

AnotherPartOfMe_Loop3C:
	dc.b	nRst, $06
	smpsAlterNote       $00
	dc.b	nMaxPSG, $02
	smpsLoop            $00, $07, AnotherPartOfMe_Loop3C
	smpsLoop            $01, $02, AnotherPartOfMe_Loop3D

AnotherPartOfMe_Loop41:
	smpsPSGAlterVol     $02
	smpsAlterNote       $00
	dc.b	$01
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	nMaxPSG
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	$02
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	nMaxPSG
	smpsPSGAlterVol     $FB
	smpsAlterNote       $00
	dc.b	nMaxPSG, nRst, $06

AnotherPartOfMe_Loop3E:
	smpsAlterNote       $00
	dc.b	nMaxPSG, $02
	smpsPSGAlterVol     $02
	smpsAlterNote       $00
	dc.b	$01
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	nMaxPSG
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	$02
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	nMaxPSG
	smpsPSGAlterVol     $FB
	smpsLoop            $00, $02, AnotherPartOfMe_Loop3E
	smpsAlterNote       $00
	dc.b	nMaxPSG

AnotherPartOfMe_Loop3F:
	dc.b	nRst, $06
	smpsAlterNote       $00
	dc.b	nMaxPSG, $02
	smpsLoop            $00, $04, AnotherPartOfMe_Loop3F
	smpsPSGAlterVol     $02
	smpsAlterNote       $00
	dc.b	$01
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	nMaxPSG
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	$02
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	nMaxPSG
	smpsPSGAlterVol     $FB
	smpsAlterNote       $00
	dc.b	nMaxPSG

AnotherPartOfMe_Loop40:
	dc.b	nRst, $06
	smpsAlterNote       $00
	dc.b	nMaxPSG, $02
	smpsLoop            $00, $07, AnotherPartOfMe_Loop40
	smpsLoop            $01, $03, AnotherPartOfMe_Loop41

AnotherPartOfMe_Loop43:
	smpsPSGAlterVol     $02
	smpsAlterNote       $00
	dc.b	$01
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	nMaxPSG
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	$02
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	nMaxPSG
	smpsPSGAlterVol     $FB
	smpsAlterNote       $00
	dc.b	nMaxPSG

AnotherPartOfMe_Loop42:
	dc.b	nRst, $06
	smpsAlterNote       $00
	dc.b	nMaxPSG, $02
	smpsLoop            $00, $07, AnotherPartOfMe_Loop42
	smpsLoop            $01, $08, AnotherPartOfMe_Loop43
	smpsPSGAlterVol     $02
	smpsAlterNote       $00
	dc.b	$01
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	nMaxPSG
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	$02
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	nMaxPSG
	smpsPSGAlterVol     $FB
	smpsAlterNote       $00
	dc.b	nMaxPSG

AnotherPartOfMe_Loop44:
	dc.b	nRst, $06
	smpsAlterNote       $00
	dc.b	nMaxPSG, $02
	smpsLoop            $00, $04, AnotherPartOfMe_Loop44
	smpsPSGAlterVol     $02
	smpsAlterNote       $00
	dc.b	$01
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	nMaxPSG
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	$02
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	nMaxPSG
	smpsPSGAlterVol     $FB
	smpsAlterNote       $00
	dc.b	nMaxPSG

AnotherPartOfMe_Loop45:
	dc.b	nRst, $06
	smpsAlterNote       $00
	dc.b	nMaxPSG, $02
	smpsLoop            $00, $02, AnotherPartOfMe_Loop45

AnotherPartOfMe_Loop47:
	smpsPSGAlterVol     $02
	smpsAlterNote       $00
	dc.b	$01
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	nMaxPSG
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	$02
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	nMaxPSG
	smpsPSGAlterVol     $FB
	smpsAlterNote       $00
	dc.b	nMaxPSG

AnotherPartOfMe_Loop46:
	dc.b	nRst, $06
	smpsAlterNote       $00
	dc.b	nMaxPSG, $02
	smpsLoop            $00, $07, AnotherPartOfMe_Loop46
	smpsLoop            $01, $06, AnotherPartOfMe_Loop47
	smpsPSGAlterVol     $02
	smpsAlterNote       $00
	dc.b	$01
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	nMaxPSG
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	$02
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	nMaxPSG
	smpsPSGAlterVol     $FB
	smpsAlterNote       $00
	dc.b	nMaxPSG

AnotherPartOfMe_Loop48:
	dc.b	nRst, $06
	smpsAlterNote       $00
	dc.b	nMaxPSG, $02
	smpsLoop            $00, $03, AnotherPartOfMe_Loop48

AnotherPartOfMe_Loop49:
	smpsPSGAlterVol     $02
	smpsAlterNote       $00
	dc.b	$01
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	nMaxPSG
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	$02
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	$03
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	$07
	smpsPSGAlterVol     $FA
	smpsAlterNote       $00
	dc.b	$02
	smpsLoop            $00, $08, AnotherPartOfMe_Loop49
	smpsPSGAlterVol     $02
	smpsAlterNote       $00
	dc.b	$01
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	nMaxPSG
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	$02
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	$03
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	$07, nRst, $70
	smpsPSGAlterVol     $FA

AnotherPartOfMe_Loop4A:
	smpsAlterNote       $00
	dc.b	nMaxPSG, $02, nRst, $06
	smpsLoop            $00, $04, AnotherPartOfMe_Loop4A
	smpsAlterNote       $00
	dc.b	nMaxPSG, $02
	smpsPSGAlterVol     $02
	smpsAlterNote       $00
	dc.b	$01
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	nMaxPSG
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	$02
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	nMaxPSG
	smpsPSGAlterVol     $FB
	smpsAlterNote       $00
	dc.b	nMaxPSG, nRst, $06

AnotherPartOfMe_Loop4B:
	smpsAlterNote       $00
	dc.b	nMaxPSG, $02
	smpsPSGAlterVol     $02
	smpsAlterNote       $00
	dc.b	$01
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	nMaxPSG
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	$02
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	nMaxPSG
	smpsPSGAlterVol     $FB
	smpsLoop            $00, $02, AnotherPartOfMe_Loop4B
	smpsAlterNote       $00
	dc.b	nMaxPSG

AnotherPartOfMe_Loop4C:
	dc.b	nRst, $06
	smpsAlterNote       $00
	dc.b	nMaxPSG, $02
	smpsLoop            $00, $04, AnotherPartOfMe_Loop4C
	smpsPSGAlterVol     $02
	smpsAlterNote       $00
	dc.b	$01
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	nMaxPSG
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	$02
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	nMaxPSG
	smpsPSGAlterVol     $FB
	smpsAlterNote       $00
	dc.b	nMaxPSG

AnotherPartOfMe_Loop4D:
	dc.b	nRst, $06
	smpsAlterNote       $00
	dc.b	nMaxPSG, $02
	smpsLoop            $00, $07, AnotherPartOfMe_Loop4D
	smpsPSGAlterVol     $02
	smpsAlterNote       $00
	dc.b	$01
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	nMaxPSG
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	$02
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	nMaxPSG
	smpsPSGAlterVol     $FB
	smpsAlterNote       $00
	dc.b	nMaxPSG, nRst, $06

AnotherPartOfMe_Loop4E:
	smpsAlterNote       $00
	dc.b	nMaxPSG, $02
	smpsPSGAlterVol     $02
	smpsAlterNote       $00
	dc.b	$01
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	nMaxPSG
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	$02
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	nMaxPSG
	smpsPSGAlterVol     $FB
	smpsLoop            $00, $02, AnotherPartOfMe_Loop4E
	smpsAlterNote       $00
	dc.b	nMaxPSG

AnotherPartOfMe_Loop4F:
	dc.b	nRst, $06
	smpsAlterNote       $00
	dc.b	nMaxPSG, $02
	smpsLoop            $00, $04, AnotherPartOfMe_Loop4F
	smpsPSGAlterVol     $02
	smpsAlterNote       $00
	dc.b	$01
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	nMaxPSG
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	$02
	smpsPSGAlterVol     $01
	smpsAlterNote       $00
	dc.b	nMaxPSG
	smpsPSGAlterVol     $FB
	smpsAlterNote       $00
	dc.b	nMaxPSG

AnotherPartOfMe_Loop50:
	dc.b	nRst, $06
	smpsAlterNote       $00
	dc.b	nMaxPSG, $02
	smpsLoop            $00, $02, AnotherPartOfMe_Loop50
	dc.b	nRst, $06
	smpsJump            AnotherPartOfMe_Jump05

AnotherPartOfMe_Voices:
;	Voice $00
;	$00
;	$00, $00, $00, $00, 	$00, $00, $00, $00, 	$00, $00, $00, $00
;	$00, $00, $00, $00, 	$00, $00, $00, $00, 	$7F, $7F, $7F, $00
	smpsVcAlgorithm     $00
	smpsVcFeedback      $00
	smpsVcUnusedBits    $00
	smpsVcDetune        $00, $00, $00, $00
	smpsVcCoarseFreq    $00, $00, $00, $00
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $00, $00, $00, $00
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $00, $00, $00, $00
	smpsVcDecayRate2    $00, $00, $00, $00
	smpsVcDecayLevel    $00, $00, $00, $00
	smpsVcReleaseRate   $00, $00, $00, $00
	smpsVcTotalLevel    $00, $7F, $7F, $7F

;	Voice $01
;	$37
;	$52, $31, $34, $50, 	$1F, $1F, $1F, $1F, 	$00, $00, $00, $00
;	$00, $00, $00, $00, 	$0F, $0F, $0F, $0F, 	$00, $00, $00, $00
	smpsVcAlgorithm     $07
	smpsVcFeedback      $06
	smpsVcUnusedBits    $00
	smpsVcDetune        $05, $03, $03, $05
	smpsVcCoarseFreq    $00, $04, $01, $02
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $1F, $1F, $1F, $1F
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $00, $00, $00, $00
	smpsVcDecayRate2    $00, $00, $00, $00
	smpsVcDecayLevel    $00, $00, $00, $00
	smpsVcReleaseRate   $0F, $0F, $0F, $0F
	smpsVcTotalLevel    $00, $00, $00, $00

;	Voice $02
;	$06
;	$61, $03, $32, $71, 	$1F, $1F, $1F, $1F, 	$00, $00, $00, $00
;	$00, $00, $00, $00, 	$0F, $0F, $0F, $0F, 	$1E, $00, $00, $00
	smpsVcAlgorithm     $06
	smpsVcFeedback      $00
	smpsVcUnusedBits    $00
	smpsVcDetune        $07, $03, $00, $06
	smpsVcCoarseFreq    $01, $02, $03, $01
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $1F, $1F, $1F, $1F
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $00, $00, $00, $00
	smpsVcDecayRate2    $00, $00, $00, $00
	smpsVcDecayLevel    $00, $00, $00, $00
	smpsVcReleaseRate   $0F, $0F, $0F, $0F
	smpsVcTotalLevel    $00, $00, $00, $1E

;	Voice $03
;	$3C
;	$31, $52, $50, $30, 	$52, $53, $52, $53, 	$08, $00, $08, $00
;	$04, $00, $04, $00, 	$1F, $0F, $1F, $0F, 	$1A, $00, $16, $00
	smpsVcAlgorithm     $04
	smpsVcFeedback      $07
	smpsVcUnusedBits    $00
	smpsVcDetune        $03, $05, $05, $03
	smpsVcCoarseFreq    $00, $00, $02, $01
	smpsVcRateScale     $01, $01, $01, $01
	smpsVcAttackRate    $13, $12, $13, $12
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $00, $08, $00, $08
	smpsVcDecayRate2    $00, $04, $00, $04
	smpsVcDecayLevel    $00, $01, $00, $01
	smpsVcReleaseRate   $0F, $0F, $0F, $0F
	smpsVcTotalLevel    $00, $16, $00, $1A

;	Voice $04
;	$3D
;	$01, $01, $01, $01, 	$8E, $52, $14, $4C, 	$08, $08, $0E, $03
;	$00, $00, $00, $00, 	$1F, $1F, $1F, $1F, 	$1B, $00, $00, $00
	smpsVcAlgorithm     $05
	smpsVcFeedback      $07
	smpsVcUnusedBits    $00
	smpsVcDetune        $00, $00, $00, $00
	smpsVcCoarseFreq    $01, $01, $01, $01
	smpsVcRateScale     $01, $00, $01, $02
	smpsVcAttackRate    $0C, $14, $12, $0E
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $03, $0E, $08, $08
	smpsVcDecayRate2    $00, $00, $00, $00
	smpsVcDecayLevel    $01, $01, $01, $01
	smpsVcReleaseRate   $0F, $0F, $0F, $0F
	smpsVcTotalLevel    $00, $00, $00, $1B

;	Voice $05
;	$3A
;	$60, $66, $60, $61, 	$1F, $94, $1F, $1F, 	$0F, $10, $05, $0D
;	$07, $06, $06, $07, 	$2F, $4F, $1F, $5F, 	$21, $14, $28, $00
	smpsVcAlgorithm     $02
	smpsVcFeedback      $07
	smpsVcUnusedBits    $00
	smpsVcDetune        $06, $06, $06, $06
	smpsVcCoarseFreq    $01, $00, $06, $00
	smpsVcRateScale     $00, $00, $02, $00
	smpsVcAttackRate    $1F, $1F, $14, $1F
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $0D, $05, $10, $0F
	smpsVcDecayRate2    $07, $06, $06, $07
	smpsVcDecayLevel    $05, $01, $04, $02
	smpsVcReleaseRate   $0F, $0F, $0F, $0F
	smpsVcTotalLevel    $00, $28, $14, $21

;	Voice $06
;	$2C
;	$74, $74, $34, $34, 	$1F, $12, $1F, $1F, 	$00, $00, $00, $00
;	$00, $01, $00, $01, 	$0F, $3F, $0F, $3F, 	$16, $00, $17, $00
	smpsVcAlgorithm     $04
	smpsVcFeedback      $05
	smpsVcUnusedBits    $00
	smpsVcDetune        $03, $03, $07, $07
	smpsVcCoarseFreq    $04, $04, $04, $04
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $1F, $1F, $12, $1F
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $00, $00, $00, $00
	smpsVcDecayRate2    $01, $00, $01, $00
	smpsVcDecayLevel    $03, $00, $03, $00
	smpsVcReleaseRate   $0F, $0F, $0F, $0F
	smpsVcTotalLevel    $00, $17, $00, $16

;	Voice $07
;	$08
;	$0A, $70, $30, $00, 	$1F, $1F, $5F, $5F, 	$12, $0E, $0A, $0A
;	$00, $04, $04, $03, 	$2F, $2F, $2F, $2F, 	$24, $2D, $13, $00
	smpsVcAlgorithm     $00
	smpsVcFeedback      $01
	smpsVcUnusedBits    $00
	smpsVcDetune        $00, $03, $07, $00
	smpsVcCoarseFreq    $00, $00, $00, $0A
	smpsVcRateScale     $01, $01, $00, $00
	smpsVcAttackRate    $1F, $1F, $1F, $1F
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $0A, $0A, $0E, $12
	smpsVcDecayRate2    $03, $04, $04, $00
	smpsVcDecayLevel    $02, $02, $02, $02
	smpsVcReleaseRate   $0F, $0F, $0F, $0F
	smpsVcTotalLevel    $00, $13, $2D, $24

;	Voice $08
;	$3D
;	$01, $02, $02, $02, 	$1F, $08, $8A, $0A, 	$08, $08, $08, $08
;	$00, $01, $00, $00, 	$0F, $1F, $1F, $1F, 	$1F, $00, $00, $00
	smpsVcAlgorithm     $05
	smpsVcFeedback      $07
	smpsVcUnusedBits    $00
	smpsVcDetune        $00, $00, $00, $00
	smpsVcCoarseFreq    $02, $02, $02, $01
	smpsVcRateScale     $00, $02, $00, $00
	smpsVcAttackRate    $0A, $0A, $08, $1F
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $08, $08, $08, $08
	smpsVcDecayRate2    $00, $00, $01, $00
	smpsVcDecayLevel    $01, $01, $01, $00
	smpsVcReleaseRate   $0F, $0F, $0F, $0F
	smpsVcTotalLevel    $00, $00, $00, $1F

;	Voice $09
;	$38
;	$02, $02, $02, $01, 	$1F, $11, $11, $10, 	$00, $00, $00, $02
;	$01, $01, $01, $01, 	$0F, $0F, $0F, $3F, 	$2C, $22, $22, $00
	smpsVcAlgorithm     $00
	smpsVcFeedback      $07
	smpsVcUnusedBits    $00
	smpsVcDetune        $00, $00, $00, $00
	smpsVcCoarseFreq    $01, $02, $02, $02
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $10, $11, $11, $1F
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $02, $00, $00, $00
	smpsVcDecayRate2    $01, $01, $01, $01
	smpsVcDecayLevel    $03, $00, $00, $00
	smpsVcReleaseRate   $0F, $0F, $0F, $0F
	smpsVcTotalLevel    $00, $22, $22, $2C

;	Voice $0A
;	$38
;	$35, $05, $10, $01, 	$14, $14, $10, $0E, 	$05, $08, $02, $08
;	$00, $00, $00, $00, 	$9F, $0F, $0F, $1F, 	$25, $31, $2A, $00
	smpsVcAlgorithm     $00
	smpsVcFeedback      $07
	smpsVcUnusedBits    $00
	smpsVcDetune        $00, $01, $00, $03
	smpsVcCoarseFreq    $01, $00, $05, $05
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $0E, $10, $14, $14
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $08, $02, $08, $05
	smpsVcDecayRate2    $00, $00, $00, $00
	smpsVcDecayLevel    $01, $00, $00, $09
	smpsVcReleaseRate   $0F, $0F, $0F, $0F
	smpsVcTotalLevel    $00, $2A, $31, $25

