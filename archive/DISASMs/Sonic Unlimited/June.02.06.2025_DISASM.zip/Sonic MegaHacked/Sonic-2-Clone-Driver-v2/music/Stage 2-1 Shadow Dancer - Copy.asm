ShadowDancerStageTwoOne_Header:
	smpsHeaderStartSong 1
	smpsHeaderVoice     ShadowDancerStageTwoOne_Voices
	smpsHeaderChan      $06, $02
	smpsHeaderTempo     $02, $04

	smpsHeaderDAC       ShadowDancerStageTwoOne_DAC
	smpsHeaderFM        ShadowDancerStageTwoOne_FM1,	$F4, $10
	smpsHeaderFM        ShadowDancerStageTwoOne_FM2,	$F4, $0A
	smpsHeaderFM        ShadowDancerStageTwoOne_FM3,	$F4, $10
	smpsHeaderFM        ShadowDancerStageTwoOne_FM4,	$F4, $10
	smpsHeaderFM        ShadowDancerStageTwoOne_FM5,	$F4, $19
	smpsHeaderPSG       ShadowDancerStageTwoOne_PSG1,	$D0, $05, $00, fTone_05
	smpsHeaderPSG       ShadowDancerStageTwoOne_PSG2,	$D0, $05, $00, fTone_05

; FM5 Data
ShadowDancerStageTwoOne_FM5:
	dc.b	nRst, $06
	smpsJump            ShadowDancerStageTwoOne_Jump00

ShadowDancerStageTwoOne_Call02:
	dc.b	nG5, $24, nFs5, $0C, nC5, $18, nD5
	smpsReturn

ShadowDancerStageTwoOne_Call03:
	dc.b	nG5, $09, nA5, nE6, $06, nD6, $12, nE6, $06, nG6, $09, nFs6
	dc.b	$21, nE6, $03, nFs6, nB5, $09, nC6, nA6, $06, nG6, $12, nB6
	dc.b	$06, nC7, $09, nB6, nG6, $03, nA6, nFs6, $09, nG6, $06, nD6
	dc.b	nB5, $03
	smpsReturn

; FM1 Data
ShadowDancerStageTwoOne_FM1:
	smpsModSet          $0A, $01, $04, $04

ShadowDancerStageTwoOne_Jump00:
	smpsSetvoice        $00
	dc.b	nRst, $2D

ShadowDancerStageTwoOne_Loop0A:
	smpsCall            ShadowDancerStageTwoOne_Call02
	smpsLoop            $00, $02, ShadowDancerStageTwoOne_Loop0A
	smpsCall            ShadowDancerStageTwoOne_Call03
	smpsCall            ShadowDancerStageTwoOne_Call02
	smpsCall            ShadowDancerStageTwoOne_Call03

ShadowDancerStageTwoOne_Loop0B:
	dc.b	nE6, $09, nB5, $09, nD6, $09, nE6, $09, nA6, $09, nAb6, $06
	dc.b	nE6, $0F, nB6, $06, nA6, $06, nD7, $09, nCs7, $03, nA6, nB6
	dc.b	nE6, nA6, nD6, nAb6, nCs6, nFs6, nB5, nE6, nCs6, nD6, $06, nE6
	dc.b	nRst, $03, nA6, nFs6, nRst, nCs6, nRst, nD6, $06, nE6, nAb5, nB5
	dc.b	$03, nFs5, $06, nAb5, nE5
	smpsLoop            $00, $02, ShadowDancerStageTwoOne_Loop0B
	smpsJump            ShadowDancerStageTwoOne_Loop0A

; FM2 Data
ShadowDancerStageTwoOne_FM2:
	smpsSetvoice        $01
	dc.b	nA3, $06, nG3, $03, nA3, nRst, $06, nA3, $03, nRst, $06, nA3
	dc.b	$03, nRst, $06, nA3, $03, nRst, nA3

ShadowDancerStageTwoOne_Loop08:
	dc.b	nA3, $03, nA3, nA3, nA3, nA3, nA3, nA3, nA3, nA3, nA3, nA3
	dc.b	nA3, nA3, nA3, nA3, nG3, nA3, nA3, nA3, nA3, nA3, nA3, nA3
	dc.b	nA3, nA3, nD4, nRst, nD4, nRst, nD4, nG3, nA3
	smpsLoop            $00, $07, ShadowDancerStageTwoOne_Loop08

ShadowDancerStageTwoOne_Loop09:
	dc.b	nE3, $03, nRst, nE3, nRst, nE4, nE3, nRst, $06, nE3, $03, nRst
	dc.b	$06, nE3, $03, nRst, nE4, nRst, nE3, nRst, $06, nE3, $03, nRst
	dc.b	nE3, nE4, nRst, $06, nE3, $03, nRst, $06, nE4, $03, nRst, nE3
	dc.b	nRst, nE3
	smpsLoop            $00, $04, ShadowDancerStageTwoOne_Loop09
	smpsJump            ShadowDancerStageTwoOne_Loop08

; PSG1 Data
ShadowDancerStageTwoOne_PSG1:
	smpsJump            ShadowDancerStageTwoOne_Jump02

; FM3 Data
ShadowDancerStageTwoOne_FM3:
	smpsPan             panLeft, $00
	smpsModSet          $0A, $01, $01, $04
	smpsSetvoice        $02

ShadowDancerStageTwoOne_Jump02:
	dc.b	nRst, $2D

ShadowDancerStageTwoOne_Loop06:
	dc.b	nC6, $06, nE5, $03, nD6, $09, nC6, $03, nD6, nE5, nC6, nRst
	dc.b	nC6, $09, nB5, $03, nC6, nE5, nA6, nE5, nD6, $09, nC6, $03
	dc.b	nD6, nE5, nG6, nRst, nG6, $09, nFs6, $03, nB5
	smpsLoop            $00, $07, ShadowDancerStageTwoOne_Loop06

ShadowDancerStageTwoOne_Loop07:
	dc.b	nE6, $03, nRst, nD6, nRst, nD6, nE6, nRst, $06, nE6, $03, nRst
	dc.b	$06, nD6, $03, nRst, nE6, nRst, nE6, nRst, $06, nD6, $03, nRst
	dc.b	nD6, nE6, nRst, $06, nE6, $03, nRst, $06, nE6, $03, nRst, nD6
	dc.b	nRst, nD6
	smpsLoop            $00, $04, ShadowDancerStageTwoOne_Loop07
	smpsJump            ShadowDancerStageTwoOne_Loop06

; PSG2 Data
ShadowDancerStageTwoOne_PSG2:
	smpsJump            ShadowDancerStageTwoOne_Jump01

; FM4 Data
ShadowDancerStageTwoOne_FM4:
	smpsPan             panRight, $00
	smpsModSet          $0A, $01, $01, $03
	smpsSetvoice        $02

ShadowDancerStageTwoOne_Jump01:
	dc.b	nRst, $2D

ShadowDancerStageTwoOne_Loop04:
	dc.b	nG5, $06, nC5, $03, nG5, $09, nG5, $03, nG5, nC5, nG5, nRst
	dc.b	nG5, $09, nG5, $06, nC5, $03, nE6, nC5, nA5, $09, nA5, $03
	dc.b	nA5, nC5, nD6, nRst, nD6, $09, nD6, $03, nE5
	smpsLoop            $00, $07, ShadowDancerStageTwoOne_Loop04

ShadowDancerStageTwoOne_Loop05:
	dc.b	nAb5, $03, nRst, nFs5, nRst, nFs5, nAb5, nRst, $06, nAb5, $03, nRst
	dc.b	$06, nFs5, $03, nRst, nAb5, nRst, nAb5, nRst, $06, nFs5, $03, nRst
	dc.b	nFs5, nAb5, nRst, $06, nAb5, $03, nRst, $06, nAb5, $03, nRst, nFs5
	dc.b	nRst, nAb5
	smpsLoop            $00, $04, ShadowDancerStageTwoOne_Loop05
	smpsJump            ShadowDancerStageTwoOne_Loop04

; DAC Data
ShadowDancerStageTwoOne_DAC:
	dc.b	dKick, $06, dKick, $03, dKick, $09, dKick, $09, dKick, $09, dSnare, $06
	dc.b	dKick, $03

ShadowDancerStageTwoOne_Loop00:
	smpsCall            ShadowDancerStageTwoOne_Call00
	smpsLoop            $00, $02, ShadowDancerStageTwoOne_Loop00

ShadowDancerStageTwoOne_Loop01:
	smpsCall            ShadowDancerStageTwoOne_Call01
	smpsLoop            $00, $02, ShadowDancerStageTwoOne_Loop01
	smpsCall            ShadowDancerStageTwoOne_Call00

ShadowDancerStageTwoOne_Loop02:
	smpsCall            ShadowDancerStageTwoOne_Call01
	smpsLoop            $00, $02, ShadowDancerStageTwoOne_Loop02

ShadowDancerStageTwoOne_Loop03:
	dc.b	dSnare, $03, dKick, $06, dKick, $03, dSnare, dKick, $09, dSnare, $03, dKick
	dc.b	$06, dSnare, $06, dKick, $06, dSnare, $09, dKick, $06, dKick, $03, dSnare
	dc.b	dKick, $06, dSnare, $03, dKick, dKick, dSnare, dKick, dSnare, $06, dKick, $03
	smpsLoop            $00, $04, ShadowDancerStageTwoOne_Loop03
	smpsJump            ShadowDancerStageTwoOne_Loop00

ShadowDancerStageTwoOne_Call00:
	dc.b	dSnare, $03, dKick, $06, dKick, $03, dSnare, dKick, $06, dKick, $03, dSnare
	dc.b	dKick, $06, dKick, $03, dSnare, dKick, $06, dKick, $03, dSnare, dKick, $06
	dc.b	dKick, $03, dSnare, dKick, $06, dKick, $03, dKick, dSnare, dKick, dSnare, dKick
	dc.b	dSnare, dKick, dSnare
	smpsReturn

ShadowDancerStageTwoOne_Call01:
	dc.b	dSnare, $03, dKick, dSnare, dKick, $06, dKick, $03, dSnare, dKick, $06, dKick
	dc.b	$03, dSnare, dKick, $06, dKick, $03, dSnare, $03, dKick, $06, dKick, $03
	dc.b	dSnare, dKick, dKick, dKick, dSnare, dKick, dKick, dSnare, dKick, dSnare, dKick, dSnare
	dc.b	dKick, dSnare
	smpsReturn

ShadowDancerStageTwoOne_Voices:
;	Voice $00
;	$FC
;	$61, $31, $30, $60, 	$1F, $1F, $1F, $1F, 	$01, $01, $01, $01
;	$00, $06, $00, $06, 	$2F, $2F, $4F, $1F, 	$1E, $81, $95, $81
	smpsVcAlgorithm     $04
	smpsVcFeedback      $07
	smpsVcUnusedBits    $03
	smpsVcDetune        $06, $03, $03, $06
	smpsVcCoarseFreq    $00, $00, $01, $01
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $1F, $1F, $1F, $1F
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $01, $01, $01, $01
	smpsVcDecayRate2    $06, $00, $06, $00
	smpsVcDecayLevel    $01, $04, $02, $02
	smpsVcReleaseRate   $0F, $0F, $0F, $0F
	smpsVcTotalLevel    $01, $95, $01, $1E

;	Voice $01
;	$18
;	$37, $30, $30, $31, 	$9E, $DC, $1C, $9C, 	$0D, $06, $04, $01
;	$08, $0A, $03, $05, 	$BF, $BF, $3F, $2F, 	$2C, $22, $14, $80
	smpsVcAlgorithm     $00
	smpsVcFeedback      $03
	smpsVcUnusedBits    $00
	smpsVcDetune        $03, $03, $03, $03
	smpsVcCoarseFreq    $01, $00, $00, $07
	smpsVcRateScale     $02, $00, $03, $02
	smpsVcAttackRate    $1C, $1C, $1C, $1E
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $01, $04, $06, $0D
	smpsVcDecayRate2    $05, $03, $0A, $08
	smpsVcDecayLevel    $02, $03, $0B, $0B
	smpsVcReleaseRate   $0F, $0F, $0F, $0F
	smpsVcTotalLevel    $00, $14, $22, $2C

;	Voice $02
;	$18
;	$28, $72, $31, $12, 	$1F, $1F, $1F, $1F, 	$12, $0B, $0C, $0D
;	$01, $05, $05, $06, 	$5F, $0F, $1F, $1F, 	$24, $20, $19, $80
	smpsVcAlgorithm     $00
	smpsVcFeedback      $03
	smpsVcUnusedBits    $00
	smpsVcDetune        $01, $03, $07, $02
	smpsVcCoarseFreq    $02, $01, $02, $08
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $1F, $1F, $1F, $1F
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $0D, $0C, $0B, $12
	smpsVcDecayRate2    $06, $05, $05, $01
	smpsVcDecayLevel    $01, $01, $00, $05
	smpsVcReleaseRate   $0F, $0F, $0F, $0F
	smpsVcTotalLevel    $00, $19, $20, $24

