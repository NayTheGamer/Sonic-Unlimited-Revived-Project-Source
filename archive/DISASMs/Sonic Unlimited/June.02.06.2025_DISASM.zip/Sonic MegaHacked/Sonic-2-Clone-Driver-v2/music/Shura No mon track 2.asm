ShuranomonTrack2_Header:
	smpsHeaderStartSong 2
	smpsHeaderVoice     ShuranomonTrack2_Voices
	smpsHeaderChan      $06, $03
	smpsHeaderTempo     $01, $F0

	smpsHeaderDAC       ShuranomonTrack2_DAC,	$00, $02
	smpsHeaderFM        ShuranomonTrack2_FM1,	$F4, $10
	smpsHeaderFM        ShuranomonTrack2_FM2,	$F4, $0B
	smpsHeaderFM        ShuranomonTrack2_FM3,	$00, $0D
	smpsHeaderFM        ShuranomonTrack2_FM4,	$E8, $10
	smpsHeaderFM        ShuranomonTrack2_FM5,	$F4, $13
	smpsHeaderPSG       ShuranomonTrack2_PSG1,	$C4, $03, $07, fTone_03
	smpsHeaderPSG       ShuranomonTrack2_PSG2,	$C4, $03, $07, fTone_03
	smpsHeaderPSG       ShuranomonTrack2_PSG3,	$00, $03, $00, fTone_02

; The following track data was present at -1 bytes from the start of the song.
ShuranomonTrack2_Call01:

; FM5 Data
ShuranomonTrack2_FM5:
	smpsSetvoice        $00
	smpsAlterNote       $FB
	dc.b	nRst, $0C
	smpsCall            ShuranomonTrack2_Call09
	smpsModOff
	dc.b	$07
	smpsPan             panLeft, $00
	smpsSetvoice        $00
	smpsModSet          $20, $01, $04, $08
	smpsAlterNote       $FB
	smpsCall            ShuranomonTrack2_Call0A
	smpsAlterNote       $FB
	smpsCall            ShuranomonTrack2_Call0B
	smpsAlterNote       $FB
	smpsJump            ShuranomonTrack2_Jump02

ShuranomonTrack2_Jump02:
ShuranomonTrack2_Call09:
	smpsSetvoice        $07
	smpsAlterVol        $FB
	dc.b	nRst, $60, nRst, $60, nRst, $60
	smpsPan             panRight, $00
	dc.b	nRst, $3C, nA6, $0C
	smpsPan             panLeft, $00
	dc.b	nRst, nA6, nRst, $60, nRst, $60, nRst, $60
	smpsPan             panRight, $00
	dc.b	nRst, $3C, nA6, $0C
	smpsPan             panLeft, $00
	dc.b	nRst, nA6
	smpsSetvoice        $00
	smpsAlterVol        $05
	smpsWeirdD1LRR
	dc.b	nE6, $3C, nCs6, $0C, nD6, nE6, smpsNoAttack, $0C, nD6, $18, nCs6, nD6
	dc.b	nC6, $0C, smpsNoAttack, $30, nC6, $18, nB5, $0C, nA5, smpsNoAttack, $30, nE5
	dc.b	$0C, nA5, nB5, nC6, smpsNoAttack, $30, nA5, $0C, nC6, nE6, nD6, smpsNoAttack
	dc.b	$0C, nC6, $18, nB5, nC6, nD6, $0C, smpsNoAttack, $3C, nCs6, $0C, nD6
	dc.b	nE6, smpsNoAttack, $60, nE6, $3C, nCs6, $0C, nD6, nE6, smpsNoAttack, $0C, nD6
	dc.b	$18, nCs6, nD6, nC6, $0C, smpsNoAttack, $30, nC6, $18, nB5, $0C, nA5
	dc.b	$0C, smpsNoAttack, $30, nE5, $0C, nA5, nC6, nE6, smpsNoAttack, $30, nA5, $0C
	dc.b	nC6, nE6, nD6, smpsNoAttack, $0C, nC6, $18, nB5, nG6, nG6, $0C, smpsNoAttack
	dc.b	$3C, nD6, $0C, nG6, nA6, smpsNoAttack, $60, nE6, $30, nA5, $0C, nC6
	dc.b	nE6, nD6, $18, nC6, $18, nB5, nC6, nD6, $3C, nD6, $0C, nC6
	dc.b	nB5, nA5, $3C, nE5, $0C, nA5, nB5, nC6, $3C, nA5, $0C, nC6
	dc.b	nE6, nD6, $18, nC6, $18, nB5, nG6, nG6, $48, nD6, $0C, nG6
	dc.b	nA6, $30, smpsNoAttack
	dc.b	$FC 
	dc.b	$01, nA6
	dc.b	$FE 
	dc.b	$30
	dc.b	$FC 
	dc.b	$00
	smpsSetvoice        $05
	smpsAlterVol        $FF
	dc.b	nF6, $48
	smpsWeirdD1LRR
	dc.b	nD6, $0C, nE6, nF6, $30, nG6, $0C, nA6, nG6, nF6, nE6, $48
	dc.b	nC6, $0C, nD6, nE6, $30, nF6, $0C, nG6, nF6, nE6, nF6, $3C
	dc.b	nA5, $0C, nD6, nE6, nF6, $30, nG6, $0C, nA6, nG6, nF6, nG6
	dc.b	$48, nEb6, $0C, nF6, nG6, $48, nEb6, $0C, nF6, nG6, $48, nE6
	dc.b	$0C, nC6, nE6, nG6, nE6, nC6, nA6, $54, smpsNoAttack
	dc.b	$FC 
	dc.b	$01, nA6
	dc.b	$FE 
	dc.b	$48
	dc.b	$FC 
	dc.b	$00
	smpsAlterVol        $01
	smpsWeirdD1LRR
	smpsSetvoice        $01
	dc.b	nA3, $0C, nD4, nE4, nA3, nA4, nA3, nE4, nG4, smpsNoAttack, $0C, nA4
	dc.b	nG4, nE4, nD4, nE4, nD4, nG3, nA3, nD4, nE4, nA3, nA4, nA3
	dc.b	nE4, nG4, smpsNoAttack, $0C, nA4, nG4, nE4, nD4, nE4, nD4, nG3
	smpsLoop            $00, $02, ShuranomonTrack2_Loop02
	dc.b	nA3, nD4, nE4, nA3, nA4, nA3, nE4, nG4, smpsNoAttack, $0C, nA4, nG4
	dc.b	nE4, nD4, nE4, nD4, nG3, nG3, nC4, nD4, nG3, nF4, nC4, nD4
	dc.b	nG4, smpsNoAttack, $0C, nF4, nC4, nD4, nG3, nG3, nF3, nE3, nD3, nG3
	dc.b	nA3, nD3, nD4, nD3, nG3, nE3, smpsNoAttack, $0C, nA3, nB3, nE3, nE4
	dc.b	nA3, nB3, nA3, smpsNoAttack, $0C, nA3, nD4, nD4, nE4, nE4, nG4, nA4
	dc.b	smpsNoAttack, $0C, nA4, nE4, nE4, nD4, nE4, nD4, nA3
	smpsLoop            $00, $02, ShuranomonTrack2_Loop03
	dc.b	nF3, nF3, nG3, nG3, nA3, nA3, nF3, nG3, smpsNoAttack, $0C, nG3, nA3
	dc.b	nA3, nB3, nB3, nD4, nA3, smpsNoAttack, $0C, nA3, nB3, nB3, nC4, nC4
	dc.b	nD4, nE4, smpsNoAttack, $0C, nE4, nD4, nD4, nC4, nC4, nB3, nF3, smpsNoAttack
	dc.b	$0C, nF3, nG3, nG3, nA3, nA3, nF3, nE3, smpsNoAttack, $0C, nE3, nB3
	dc.b	nB3, nE4, nE4, nE3, nE3, nA3, nA4, nA3, nA3, nA4, nA3, nA3
	dc.b	nA4, smpsNoAttack, $0C, nA4, nG4, nE4, nD4, nC4, nA3, nBb3, smpsNoAttack, $0C
	dc.b	nBb3, nD4, nD4, nF4, nF4, nD4, nBb4, smpsNoAttack, $0C, nBb4, nF4, nF4
	dc.b	nD4, nD4, nBb3, nA3, smpsNoAttack, $0C, nA3, nC4, nC4, nE4, nE4, nC4
	dc.b	nA4, smpsNoAttack, $0C, nA4, nE4, nE4, nC4, nC4, nA3, nBb3, smpsNoAttack, $0C
	dc.b	nBb3, nD4, nD4, nF4, nF4, nD4, nBb4, smpsNoAttack, $0C, nBb4, nF4, nF4
	dc.b	nD4, nD4, nBb3, nEb4, smpsNoAttack, $0C, nEb4, nBb4, nBb4, nEb5, nEb5, nEb4
	dc.b	nAb3, smpsNoAttack, $0C, nAb3, nEb4, nEb4, nAb4, nAb4, nAb3, nF3, smpsNoAttack, $0C
	dc.b	nF3, nC4, nC4, nF4, nF4, nC4, nF3, nD4, $24, nE4, $3C, nRst
	dc.b	$0C, nE5, nD5, nB4, nD5, nB4, nA4, nG4
	smpsJump            ShuranomonTrack2_Loop03

ShuranomonTrack2_Call0A:
	dc.b	nE6, $3C, nCs6, $0C, nD6, nE6, smpsNoAttack, $0C, nD6, $18, nCs6, nD6
	dc.b	nC6, $0C, smpsNoAttack, $30, nC6, $18, nB5, $0C, nA5, smpsNoAttack, $30, nE5
	dc.b	$0C, nA5, nB5, nC6, smpsNoAttack, $30, nA5, $0C, nC6, nE6, nD6, smpsNoAttack
	dc.b	$0C, nC6, $18, nB5, nC6, nD6, $0C, smpsNoAttack, $3C, nCs6, $0C, nD6
	dc.b	nE6, smpsNoAttack, $60, nE6, $3C, nCs6, $0C, nD6, nE6, smpsNoAttack, $0C, nD6
	dc.b	$18, nCs6, nD6, nC6, $0C, smpsNoAttack, $30, nC6, $18, nB5, $0C, nA5
	dc.b	$0C, smpsNoAttack, $30, nE5, $0C, nA5, nC6, nE6, smpsNoAttack, $30, nA5, $0C
	dc.b	nC6, nE6, nD6, smpsNoAttack, $0C, nC6, $18, nB5, nG6, nG6, $0C, smpsNoAttack
	dc.b	$3C, nD6, $0C, nG6, nA6, smpsNoAttack, $60, nE6, $30, nA5, $0C, nC6
	dc.b	nE6, nD6, $18, nC6, $18, nB5, nC6, nD6, $3C, nD6, $0C, nC6
	dc.b	nB5, nA5, $3C, nE5, $0C, nA5, nB5, nC6, $3C, nA5, $0C, nC6
	dc.b	nE6, nD6, $18, nC6, $18, nB5, nG6, nG6, $48, nD6, $0C, nG6
	dc.b	nA6, $30, smpsNoAttack
	dc.b	$FC 
	dc.b	$01, nA6
	dc.b	$FE 
	dc.b	$30
	dc.b	$FC 
	dc.b	$00
	smpsSetvoice        $05
	smpsAlterVol        $FF
	dc.b	nF6, $48
	smpsWeirdD1LRR
	dc.b	nD6, $0C, nE6, nF6, $30, nG6, $0C, nA6, nG6, nF6, nE6, $48
	dc.b	nC6, $0C, nD6, nE6, $30, nF6, $0C, nG6, nF6, nE6, nF6, $3C
	dc.b	nA5, $0C, nD6, nE6, nF6, $30, nG6, $0C, nA6, nG6, nF6, nG6
	dc.b	$48, nEb6, $0C, nF6, nG6, $48, nEb6, $0C, nF6, nG6, $48, nE6
	dc.b	$0C, nC6, nE6, nG6, nE6, nC6, nA6, $54, smpsNoAttack
	dc.b	$FC 
	dc.b	$01, nA6
	dc.b	$FE 
	dc.b	$48
	dc.b	$FC 
	dc.b	$00
	smpsAlterVol        $01
	smpsWeirdD1LRR
	smpsSetvoice        $01
	dc.b	nA3, $0C, nD4, nE4, nA3, nA4, nA3, nE4, nG4, smpsNoAttack, $0C, nA4
	dc.b	nG4, nE4, nD4, nE4, nD4, nG3, nA3, nD4, nE4, nA3, nA4, nA3
	dc.b	nE4, nG4, smpsNoAttack, $0C, nA4, nG4, nE4, nD4, nE4, nD4, nG3
	smpsLoop            $00, $02, ShuranomonTrack2_Loop02
	dc.b	nA3, nD4, nE4, nA3, nA4, nA3, nE4, nG4, smpsNoAttack, $0C, nA4, nG4
	dc.b	nE4, nD4, nE4, nD4, nG3, nG3, nC4, nD4, nG3, nF4, nC4, nD4
	dc.b	nG4, smpsNoAttack, $0C, nF4, nC4, nD4, nG3, nG3, nF3, nE3, nD3, nG3
	dc.b	nA3, nD3, nD4, nD3, nG3, nE3, smpsNoAttack, $0C, nA3, nB3, nE3, nE4
	dc.b	nA3, nB3, nA3, smpsNoAttack, $0C, nA3, nD4, nD4, nE4, nE4, nG4, nA4
	dc.b	smpsNoAttack, $0C, nA4, nE4, nE4, nD4, nE4, nD4, nA3
	smpsLoop            $00, $02, ShuranomonTrack2_Loop03
	dc.b	nF3, nF3, nG3, nG3, nA3, nA3, nF3, nG3, smpsNoAttack, $0C, nG3, nA3
	dc.b	nA3, nB3, nB3, nD4, nA3, smpsNoAttack, $0C, nA3, nB3, nB3, nC4, nC4
	dc.b	nD4, nE4, smpsNoAttack, $0C, nE4, nD4, nD4, nC4, nC4, nB3, nF3, smpsNoAttack
	dc.b	$0C, nF3, nG3, nG3, nA3, nA3, nF3, nE3, smpsNoAttack, $0C, nE3, nB3
	dc.b	nB3, nE4, nE4, nE3, nE3, nA3, nA4, nA3, nA3, nA4, nA3, nA3
	dc.b	nA4, smpsNoAttack, $0C, nA4, nG4, nE4, nD4, nC4, nA3, nBb3, smpsNoAttack, $0C
	dc.b	nBb3, nD4, nD4, nF4, nF4, nD4, nBb4, smpsNoAttack, $0C, nBb4, nF4, nF4
	dc.b	nD4, nD4, nBb3, nA3, smpsNoAttack, $0C, nA3, nC4, nC4, nE4, nE4, nC4
	dc.b	nA4, smpsNoAttack, $0C, nA4, nE4, nE4, nC4, nC4, nA3, nBb3, smpsNoAttack, $0C
	dc.b	nBb3, nD4, nD4, nF4, nF4, nD4, nBb4, smpsNoAttack, $0C, nBb4, nF4, nF4
	dc.b	nD4, nD4, nBb3, nEb4, smpsNoAttack, $0C, nEb4, nBb4, nBb4, nEb5, nEb5, nEb4
	dc.b	nAb3, smpsNoAttack, $0C, nAb3, nEb4, nEb4, nAb4, nAb4, nAb3, nF3, smpsNoAttack, $0C
	dc.b	nF3, nC4, nC4, nF4, nF4, nC4, nF3, nD4, $24, nE4, $3C, nRst
	dc.b	$0C, nE5, nD5, nB4, nD5, nB4, nA4, nG4
	smpsJump            ShuranomonTrack2_Loop03

ShuranomonTrack2_Call0B:
	dc.b	nD6, $0C, nE6, nF6, $30, nG6, $0C, nA6, nG6, nF6, nE6, $48
	dc.b	nC6, $0C, nD6, nE6, $30, nF6, $0C, nG6, nF6, nE6, nF6, $3C
	dc.b	nA5, $0C, nD6, nE6, nF6, $30, nG6, $0C, nA6, nG6, nF6, nG6
	dc.b	$48, nEb6, $0C, nF6, nG6, $48, nEb6, $0C, nF6, nG6, $48, nE6
	dc.b	$0C, nC6, nE6, nG6, nE6, nC6, nA6, $54, smpsNoAttack
	dc.b	$FC 
	dc.b	$01, nA6
	dc.b	$FE 
	dc.b	$48
	dc.b	$FC 
	dc.b	$00
	smpsAlterVol        $01
	smpsWeirdD1LRR

; FM2 Data
ShuranomonTrack2_FM2:
	smpsSetvoice        $01

ShuranomonTrack2_Loop02:
	dc.b	nA3, $0C, nD4, nE4, nA3, nA4, nA3, nE4, nG4, smpsNoAttack, $0C, nA4
	dc.b	nG4, nE4, nD4, nE4, nD4, nG3, nA3, nD4, nE4, nA3, nA4, nA3
	dc.b	nE4, nG4, smpsNoAttack, $0C, nA4, nG4, nE4, nD4, nE4, nD4, nG3
	smpsLoop            $00, $02, ShuranomonTrack2_Loop02

ShuranomonTrack2_Loop03:
	dc.b	nA3, nD4, nE4, nA3, nA4, nA3, nE4, nG4, smpsNoAttack, $0C, nA4, nG4
	dc.b	nE4, nD4, nE4, nD4, nG3, nG3, nC4, nD4, nG3, nF4, nC4, nD4
	dc.b	nG4, smpsNoAttack, $0C, nF4, nC4, nD4, nG3, nG3, nF3, nE3, nD3, nG3
	dc.b	nA3, nD3, nD4, nD3, nG3, nE3, smpsNoAttack, $0C, nA3, nB3, nE3, nE4
	dc.b	nA3, nB3, nA3, smpsNoAttack, $0C, nA3, nD4, nD4, nE4, nE4, nG4, nA4
	dc.b	smpsNoAttack, $0C, nA4, nE4, nE4, nD4, nE4, nD4, nA3
	smpsLoop            $00, $02, ShuranomonTrack2_Loop03
	dc.b	nF3, nF3, nG3, nG3, nA3, nA3, nF3, nG3, smpsNoAttack, $0C, nG3, nA3
	dc.b	nA3, nB3, nB3, nD4, nA3, smpsNoAttack, $0C, nA3, nB3, nB3, nC4, nC4
	dc.b	nD4, nE4, smpsNoAttack, $0C, nE4, nD4, nD4, nC4, nC4, nB3, nF3, smpsNoAttack
	dc.b	$0C, nF3, nG3, nG3, nA3, nA3, nF3, nE3, smpsNoAttack, $0C, nE3, nB3
	dc.b	nB3, nE4, nE4, nE3, nE3, nA3, nA4, nA3, nA3, nA4, nA3, nA3
	dc.b	nA4, smpsNoAttack, $0C, nA4, nG4, nE4, nD4, nC4, nA3, nBb3, smpsNoAttack, $0C
	dc.b	nBb3, nD4, nD4, nF4, nF4, nD4, nBb4, smpsNoAttack, $0C, nBb4, nF4, nF4
	dc.b	nD4, nD4, nBb3, nA3, smpsNoAttack, $0C, nA3, nC4, nC4, nE4, nE4, nC4
	dc.b	nA4, smpsNoAttack, $0C, nA4, nE4, nE4, nC4, nC4, nA3, nBb3, smpsNoAttack, $0C
	dc.b	nBb3, nD4, nD4, nF4, nF4, nD4, nBb4, smpsNoAttack, $0C, nBb4, nF4, nF4
	dc.b	nD4, nD4, nBb3, nEb4, smpsNoAttack, $0C, nEb4, nBb4, nBb4, nEb5, nEb5, nEb4
	dc.b	nAb3, smpsNoAttack, $0C, nAb3, nEb4, nEb4, nAb4, nAb4, nAb3, nF3, smpsNoAttack, $0C
	dc.b	nF3, nC4, nC4, nF4, nF4, nC4, nF3, nD4, $24, nE4, $3C, nRst
	dc.b	$0C, nE5, nD5, nB4, nD5, nB4, nA4, nG4
	smpsJump            ShuranomonTrack2_Loop03

; FM1 Data
ShuranomonTrack2_FM1:
	smpsSetTempoMod     $F6
	dc.b	$00
	smpsSetvoice        $00
	smpsModSet          $20, $01, $04, $08
	smpsCall            ShuranomonTrack2_Call09

ShuranomonTrack2_Jump01:
	smpsSetvoice        $00
	smpsPan             panCenter, $00
	smpsCall            ShuranomonTrack2_Call0A
	smpsCall            ShuranomonTrack2_Call0B
	smpsJump            ShuranomonTrack2_Jump01

; FM3 Data
ShuranomonTrack2_FM3:
	smpsSetvoice        $07
	smpsAlterVol        $FC
	dc.b	nRst, $60, nRst, $60, nRst, $60
	smpsPan             panRight, $00
	dc.b	nRst, $3C, nE5, $0C
	smpsPan             panLeft, $00
	dc.b	nRst, nE5, nRst, $60, nRst, $60, nRst, $60
	smpsPan             panRight, $00
	dc.b	nRst, $3C, nE5, $0C
	smpsPan             panLeft, $00
	dc.b	nRst, nE5
	smpsAlterVol        $04
	smpsSetvoice        $02
	smpsFade

; FM4 Data
ShuranomonTrack2_FM4:
	smpsSetvoice        $01
	smpsAlterNote       $F5
	dc.b	$FB 
	dc.b	$0C

ShuranomonTrack2_Loop00:
	dc.b	nA3, $0C, nD4, nE4, nA3, nA4, nA3, nE4, nG4, smpsNoAttack, $0C, nA4
	dc.b	nG4, nE4, nD4, nE4, nD4, nG3, nA3, nD4, nE4, nA3, nA4, nA3
	dc.b	nE4, nG4, smpsNoAttack, $0C, nA4, nG4, nE4, nD4, nE4, nD4, nG3
	smpsLoop            $00, $02, ShuranomonTrack2_Loop00
	smpsAlterNote       $00
	dc.b	$FB 
	smpsModOff

ShuranomonTrack2_Loop01:
	smpsModOff
	dc.b	$01
	smpsModSet          $04, $01, $02, $04
	smpsSetvoice        $03
	smpsPan             panRight, $00
	dc.b	nB5, $54, nG5, $0C, smpsNoAttack, $60, nF5, $60, smpsNoAttack, $60, nF5, $54
	dc.b	nG5, $0C, smpsNoAttack, $54, nB5, $0C, smpsNoAttack, $54, nCs6, $0C, smpsNoAttack, $60
	smpsLoop            $00, $02, ShuranomonTrack2_Loop01
	dc.b	nC6, $24, nC6, $24, nC7, $06, nRst, $06, nB5, $0C, smpsNoAttack, $24
	dc.b	nG6, $24, nB6, $06, nRst, $06, nD6, $0C, smpsNoAttack, $24, nB5, $24
	dc.b	nD6, $06, nRst, $06, nC7, $0C, smpsNoAttack, $24, nE6, $24, nC6, $06
	dc.b	nRst, $06, nE6, $0C, smpsNoAttack, $24, nC6, $24, nE6, $0C, nD6, $0C
	dc.b	smpsNoAttack, $24, nB5, $24, nD6, $0C, nRst, $0C, nRst, $0C, nE6, $06
	dc.b	nRst, $1E, nE6, $06, nRst, $1E, nA6, $0C, nRst, $54, nA5, $0C
	dc.b	smpsNoAttack, $3C, nA5, $0C, nRst, $0C, nA5, $0C, smpsNoAttack, $3C, nA5, $0C
	dc.b	nRst, $0C, nE6, $0C, smpsNoAttack, $3C, nE5, $0C, nRst, $0C, nE6, $0C
	dc.b	smpsNoAttack, $3C, nE5, $0C, nRst, $0C, nA5, $0C, smpsNoAttack, $3C, nA5, $0C
	dc.b	nRst, $0C, nD6, $0C, smpsNoAttack, $3C, nA5, $0C, nRst, $0C, nG6, $0C
	dc.b	smpsNoAttack, $3C, nG6, $0C, nRst, $0C, nG6, $0C, smpsNoAttack, $3C, nEb6, $12
	dc.b	nRst, $06, nG6, $0C, smpsNoAttack, $54, nRst, $0C, nE6, $24, nA6, $3C
	dc.b	smpsNoAttack, $48, nRst, $18
	smpsJump            ShuranomonTrack2_Loop01

; PSG1 Data
ShuranomonTrack2_PSG1:
	dc.b	nRst, $60, nRst, $60, nRst, $60, nRst, $60, nRst, $60, nRst, $60
	dc.b	nRst, $60, nRst, $60

ShuranomonTrack2_Loop06:
	dc.b	nCs6, $54, nD6, $0C, smpsNoAttack, $60, nA5, $60, smpsNoAttack, $60, nA5, $54
	dc.b	nD6, $0C, smpsNoAttack, $54, nD6, $0C, smpsNoAttack, $54, nA5, $0C, smpsNoAttack, $60
	smpsLoop            $00, $02, ShuranomonTrack2_Loop06
	dc.b	nA5, $24, nE6, $24, nE6, $06, nRst, $06, nD6, $0C, smpsNoAttack, $24
	dc.b	nD6, $24, nD6, $06, nRst, $06, nB5, $0C, smpsNoAttack, $24, nG6, $24
	dc.b	nD6, $06, nRst, $06, nA6, $0C, smpsNoAttack, $24, nA6, $24, nE6, $06
	dc.b	nRst, $06, nC6, $0C, smpsNoAttack, $24, nE6, $24, nC7, $06, nRst, $06
	dc.b	nB5, $0C, smpsNoAttack, $24, nD6, $24, nG6, $06, nRst, $12, nRst, $0C
	dc.b	nD6, $06, nRst, $1E, nD6, $06, nRst, $1E, nE6, $0C, nRst, $54
	dc.b	nF6, $0C, smpsNoAttack, $3C, nF6, $0C, nRst, $0C, nF6, $0C, smpsNoAttack, $3C
	dc.b	nA5, $0C, nRst, $0C, nC6, $0C, smpsNoAttack, $3C, nE6, $0C, nRst, $0C
	dc.b	nC6, $0C, smpsNoAttack, $3C, nE6, $0C, nRst, $0C, nD6, $0C, smpsNoAttack, $3C
	dc.b	nD6, $0C, nRst, $0C, nD6, $0C, smpsNoAttack, $3C, nF6, $0C, nRst, $0C
	dc.b	nD6, $0C, smpsNoAttack, $3C, nBb5, $0C, nRst, $0C, nEb6, $0C, smpsNoAttack, $3C
	dc.b	nC6, $0C, nRst, $0C, nC6, $0C, smpsNoAttack, $54, nRst, $0C, nC6, $24
	dc.b	nFs6, $3C, smpsNoAttack, $48, nRst, $18
	smpsJump            ShuranomonTrack2_Loop06

; PSG2 Data
ShuranomonTrack2_PSG2:
	dc.b	nRst, $60, nRst, $60, nRst, $60, nRst, $60, nRst, $60, nRst, $60
	dc.b	nRst, $60, nRst, $60

ShuranomonTrack2_Loop05:
	dc.b	nE6, $54, nB5, $0C, smpsNoAttack, $60, nC6, $60, smpsNoAttack, $60, nC6, $54
	dc.b	nB5, $0C, smpsNoAttack, $54, nG5, $0C, smpsNoAttack, $54, nE6, $0C, smpsNoAttack, $60
	smpsLoop            $00, $02, ShuranomonTrack2_Loop05
	dc.b	nE6, $24, nA6, $24, nA6, $06, nRst, nG5, $0C, smpsNoAttack, $24, nB5
	dc.b	$24, nG6, $06, nRst, $06, nG5, $0C, smpsNoAttack, $24, nD6, $24, nG6
	dc.b	$06, nRst, $06, nE6, $0C, smpsNoAttack, $24, nC6, $24, nA5, $06, nRst
	dc.b	$06, nA5, $0C, smpsNoAttack, $24, nA6, $24, nA6, $06, nRst, $06, nG5
	dc.b	$0C, smpsNoAttack, $24, nG6, $24, nB6, $06, nRst, $12, nRst, $0C, nA6
	dc.b	$06, nRst, $1E, nA6, $06, nRst, $1E, nCs6, $0C, nRst, $54, nD6
	dc.b	$0C, smpsNoAttack, $30, nRst, $0C, nD6, $0C, nRst, $0C, nD6, $0C, smpsNoAttack
	dc.b	$30, nRst, $0C, nD6, $0C, nRst, $0C, nG5, $0C, smpsNoAttack, $30, nRst
	dc.b	$0C, nC6, $0C, nRst, $0C, nG5, $0C, smpsNoAttack, $30, nRst, $0C, nC6
	dc.b	$0C, nRst, $0C, nF6, $0C, smpsNoAttack, $30, nRst, $0C, nF6, $0C, nRst
	dc.b	$0C, nF6, $0C, smpsNoAttack, $30, nRst, $0C, nD6, $0C, nRst, $0C, nBb5
	dc.b	$0C, smpsNoAttack, $30, nRst, $0C, nD6, $0C, nRst, $0C, nC6, $0C, smpsNoAttack
	dc.b	$30, nRst, $0C, nG6, $0C, nRst, $0C, nE6, $0C, smpsNoAttack, $54, nRst
	dc.b	$0C, nG6, $24, nD6, $3C, smpsNoAttack, $48, nRst, $18
	smpsJump            ShuranomonTrack2_Loop05

; PSG3 Data
ShuranomonTrack2_PSG3:
	smpsPSGform         $E7
	smpsAlterNote       $FF
	smpsCall            ShuranomonTrack2_Call0C
	smpsCall            ShuranomonTrack2_Call0D

ShuranomonTrack2_Call0D:
	smpsLoop            $00, $02, ShuranomonTrack2_PSG3
	smpsPSGform         $E7
	smpsCall            ShuranomonTrack2_Call0C
	smpsCall            ShuranomonTrack2_Call0E

ShuranomonTrack2_Call0E:
	smpsCall            ShuranomonTrack2_Call0C
	smpsCall            ShuranomonTrack2_Call0F

ShuranomonTrack2_Call0F:
	smpsLoop            $00, $04, ShuranomonTrack2_Loop04

ShuranomonTrack2_Loop04:
	smpsCall            ShuranomonTrack2_Call0C
	dc.b	nAb5, $06, nRst, nAb5, nRst, nAb5, nRst, nAb5, nRst, nAb5, $06, nRst
	dc.b	nAb5, nRst, nAb5, nRst, nAb5, nRst, nAb5, $06, nRst, nAb5, nRst, nAb5
	dc.b	nRst, nAb5, nRst, nAb5, $06, nRst, nAb5, nRst, nAb5, $08, nAb5, $06
	smpsPSGform         $00
	smpsPSGAlterVol     $02
	dc.b	$FB 
	dc.b	nG6
	smpsPSGvoice        fTone_03
	dc.b	nB5, $04, nF5, nMaxPSG, nD6, nMaxPSG, nD6, nF6, nD6, nF6, nA6, nF6
	dc.b	nA6, nD7, nF7, nD7, nA6, nD7, nA6, nF6, nA6, nF6, nD6, nF6
	dc.b	nD6, nMaxPSG, nMaxPSG, nD6, nF6, nD6, nF6, nA6, nF6, nA6, nD7, nA6
	dc.b	nD7, nF7, nA7, nF7, nD7, nF7, nD7, nA6, nD7, nA6, nF6, nA6
	dc.b	nF6, nD6, nG5, nC6, nE6, nC6, nE6, nG6, nE6, nG6, nC7, nG6
	dc.b	nC7, nE7, nG7, nE7, nC7, nE7, nC7, nG6, nC7, nG6, nE6, nG6
	dc.b	nE6, nC6, nG5, nC6, nE6, nC6, nE6, nG6, nE6, nG6, nC7, nG6
	dc.b	nC7, nE7, nG7, nE7, nC7, nE7, nC7, nG6, nC7, nG6, nE6, nG6
	dc.b	nE6, nC6, nF5, nMaxPSG, nD6, nMaxPSG, nD6, nF6, nD6, nF6, nA6, nF6
	dc.b	nA6, nD7, nF7, nD7, nA6, nD7, nA6, nF6, nA6, nF6, nD6, nF6
	dc.b	nD6, nMaxPSG, nMaxPSG, nD6, nF6, nD6, nF6, nA6, nF6, nA6, nD7, nA6
	dc.b	nD7, nF7, nA7, nF7, nD7, nF7, nD7, nA6, nD7, nA6, nF6, nA6
	dc.b	nF6, nD6, nG5, nBb5, nD6, nBb5, nD6, nG6, nD6, nG6, nBb6, nG6
	dc.b	nBb6, nD7, nG7, nD7, nBb6, nD7, nBb6, nG6, nBb6, nG6, nD6, nG6
	dc.b	nD6, nBb5, nG5, nC6, nEb6, nC6, nEb6, nG6, nEb6, nG6, nC7, nG6
	dc.b	nC7, nEb7, nG7, nEb7, nC7, nEb7, nC7, nG6, nC7, nG6, nEb6, nG6
	dc.b	nEb6, nC6, nG5, nC6, nE6, nC6, nE6, nG6, nE6, nG6, nC7, nG6
	dc.b	nC7, nE7, nG7, nE7, nC7, nE7, nC7, nG6, nC7, nG6, nE6, nG6
	dc.b	nE6, nC6, nG5, nC6, nE6, nG5, nC6, nE6, nC6, nE6, nG6, nG6
	dc.b	nC7, nG6, nD5, nFs5, nMaxPSG, nFs5, nMaxPSG, nD6, nMaxPSG, nD6, nFs6, nD6
	dc.b	nFs6, nA6, nFs6, nA6, nD7, nD6, nFs6, nA6, nFs6, nA6, nD7, nA6
	dc.b	nD7, nFs7, nA7, nFs7, nD7, nA7, nFs7, nD7, nFs7, nD7, nA6, nD7
	dc.b	nA6, nFs6, nA6, $06
	dc.b	$FB 
	dc.b	$30
	smpsPSGAlterVol     $FE
	smpsPSGform         $E7
	smpsPSGvoice        fTone_02
	smpsCall            ShuranomonTrack2_Call0C
	smpsCall            ShuranomonTrack2_Call10

ShuranomonTrack2_Call10:
	smpsJump            ShuranomonTrack2_Jump03

ShuranomonTrack2_Jump03:
ShuranomonTrack2_Call0C:
	dc.b	nAb5, $06, nRst, nAb5, nRst, nAb5, nRst, nAb5, nRst, nAb5, $06, nRst
	dc.b	nAb5, nRst, nAb5, nRst, nAb5, nRst, nAb5, $06, nRst, nAb5, nRst, nAb5
	dc.b	nRst, nAb5, nRst, nAb5, $06, nRst, nAb5, nRst, nAb5, nRst
	smpsPSGvoice        fTone_03
	dc.b	nAb5, $0C
	smpsPSGvoice        fTone_02
	smpsWeirdD1LRR

; DAC Data
ShuranomonTrack2_DAC:
	smpsCall            ShuranomonTrack2_Call00
	smpsCall            ShuranomonTrack2_Call01
	smpsCall            ShuranomonTrack2_Call00
	smpsCall            ShuranomonTrack2_Call01
	smpsCall            ShuranomonTrack2_Call00
	smpsCall            ShuranomonTrack2_Call00
	smpsCall            ShuranomonTrack2_Call00
	smpsCall            ShuranomonTrack2_Call00
	smpsCall            ShuranomonTrack2_Call00
	smpsCall            ShuranomonTrack2_Call00
	smpsCall            ShuranomonTrack2_Call00
	smpsCall            ShuranomonTrack2_Call02

ShuranomonTrack2_Call02:
	smpsCall            ShuranomonTrack2_Call00
	smpsCall            ShuranomonTrack2_Call00
	smpsCall            ShuranomonTrack2_Call00
	smpsCall            ShuranomonTrack2_Call03

ShuranomonTrack2_Call03:
	smpsCall            ShuranomonTrack2_Call04

ShuranomonTrack2_Call04:
	smpsCall            ShuranomonTrack2_Call05

ShuranomonTrack2_Call05:
	smpsCall            ShuranomonTrack2_Call06

ShuranomonTrack2_Call06:
	smpsCall            ShuranomonTrack2_Call07

ShuranomonTrack2_Call07:
	smpsCall            ShuranomonTrack2_Call08

ShuranomonTrack2_Call08:
	smpsJump            ShuranomonTrack2_Jump00

ShuranomonTrack2_Jump00:
ShuranomonTrack2_Call00:
	dc.b	dKick, $0C, dKick, dSnare, nRst, $0C, dKick, nRst, $0C, dSnare, dKick, nRst
	dc.b	$0C, dKick, dSnare, nRst, $0C, dKick, nRst, $0C, dSnare, nRst, $0C
	smpsWeirdD1LRR
	dc.b	dKick, $0C, $85, dKick, dKick, $85, dKick, dKick, dClap, nRst, $85, $06
	dc.b	$85, $85, $0C, $85, $84, $84, dClap, dSnare
	smpsWeirdD1LRR
	dc.b	nRst, $0C, dKick, dSnare, nRst, $0C, $85, $06, $85, $84, $0C, dSnare
	dc.b	dKick, nRst, $0C, dKick, dSnare, nRst, $0C, dKick, $85, dSnare, dKick
	smpsWeirdD1LRR
	dc.b	nRst, $0C, dKick, dSnare, nRst, $0C, $85, $06, $85, $84, $0C, dSnare
	dc.b	dClap, dKick, dSnare, dSnare, dClap, nRst, $0C, nRst, $0C, dKick, $0C, dSnare
	dc.b	nRst, $0C, $85, $06, $85, $85, $0C, $85, $84, $84, dClap, dClap
	smpsWeirdD1LRR
	dc.b	dKick, $0C, dKick, dSnare, nRst, $0C, dKick, nRst, $0C, dSnare, dKick, nRst
	dc.b	$0C, dKick, dSnare, nRst, $0C, dSnare, $85, $84, dClap
	smpsWeirdD1LRR
	dc.b	nRst, $0C, dKick, dSnare, nRst, $0C, dKick, nRst, $0C, dSnare, dKick, nRst
	dc.b	$0C, dKick, dSnare, nRst, $0C, dKick, nRst, $0C, dSnare, dKick
	smpsWeirdD1LRR
	dc.b	nRst, $0C, dKick, dSnare, nRst, $0C, dKick, nRst, $0C, dSnare, dKick, nRst
	dc.b	$0C, dKick, dSnare, nRst, $0C, dKick, $85, dSnare, dKick
	smpsWeirdD1LRR
	dc.b	$3D, $01, $62, $03, $21, $30, $1F, $13, $26, $08, $08, $08
	dc.b	$03, $05, $00, $03, $00, $0F, $1B, $1B, $1B, $1A, dKick, $85
	dc.b	dMidTimpani, $03, $09, $00, $00, $00, $1F, $1F, $1F, $1F, $10, $02
	dc.b	$0D, $0D, $04, $00, $00, $00, $CF
	dc.b	$FF 
	dc.b	$FF 
	dc.b	$FF 
	dc.b	$25, $19, $19, dKick, $0C, $41, $00, $20, $00, $1F, $1F, $1F
	dc.b	$1F, $0F, $0D, $0C, $0D, $10, $09, $00, $09, $4F, $5F, $AF
	dc.b	$8F, $1B, nRst, $1D, nRst, $3A, $34, $72, $51, $73, $1F, $5F
	dc.b	$1F, $5F, $10, $10, $10, $00, $08, $00, $00, $00, $1A, $18
	dc.b	$18, $09, $17, $22, $19, dClap, $2C, $41, $00, $22, $00, $1F
	dc.b	$1F, $1F, $1F, $0D, $0C, $0C, $0C, $10, $09, $00, $09, $4F
	dc.b	$5F, $AF, $8F, $13, $84, $15, $84, $3C, $01, $62, $01, $22
	dc.b	$17, $1F, $1F, $1F, $08, $08, $08, $09, $05, $00, $03, $00
	dc.b	$0F, $1B, $1B, $1B, $18, nRst, $08, nRst, $4D, $42, $00, $21
	dc.b	$00, $17, $1D, $1D, $1D, $05, $0E, $08, $0C, $10, $03, $00
	dc.b	$03, $4F, $5F, $AF, $8F, $21, $8F, $84, $8F, $28, $05, $14
	dc.b	$32, $70, $1F, $1F, $1F, $1F, $0E, $0E, $0C, $0A, $00, $00
	dc.b	$00, $00, $4F, $4F, $AF, $AB, $1D, $1B, $18, dSnare

ShuranomonTrack2_Voices:
	dc.b	$3D, $01, $03, $62, $21, $30, $13, $1F, $26, $08, $08, $08
	dc.b	$03, $05, $03, $00, $00, $0F, $1B, $1B, $1B, $1A, $85, dKick
	dc.b	dMidTimpani, $03, $09, $00, $00, $00, $1F, $1F, $1F, $1F, $10, $0D
	dc.b	$02, $0D, $04, $00, $00, $00, $CF
	dc.b	$FF 
	dc.b	$FF 
	dc.b	$FF 
	dc.b	$25, $19, $19, dKick, $0C, $41, $20, $00, $00, $1F, $1F, $1F
	dc.b	$1F, $0F, $0C, $0D, $0D, $10, $00, $09, $09, $4F, $AF, $5F
	dc.b	$8F, $1B, $1D, nRst, nRst, $3A, $34, $51, $72, $73, $1F, $1F
	dc.b	$5F, $5F, $10, $10, $10, $00, $08, $00, $00, $00, $1A, $18
	dc.b	$18, $09, $17, $19, $22, dClap, $2C, $41, $22, $00, $00, $1F
	dc.b	$1F, $1F, $1F, $0D, $0C, $0C, $0C, $10, $00, $09, $09, $4F
	dc.b	$AF, $5F, $8F, $13, $15, $84, $84, $3C, $01, $01, $62, $22
	dc.b	$17, $1F, $1F, $1F, $08, $08, $08, $09, $05, $03, $00, $00
	dc.b	$0F, $1B, $1B, $1B, $18, $08, nRst, nRst, $4D, $42, $21, $00
	dc.b	$00, $17, $1D, $1D, $1D, $05, $08, $0E, $0C, $10, $00, $03
	dc.b	$03, $4F, $AF, $5F, $8F, $21, $84, $8F, $8F, $28, $05, $32
	dc.b	$14, $70, $1F, $1F, $1F, $1F, $0E, $0C, $0E, $0A, $00, $00
	dc.b	$00, $00, $4F, $AF, $4F, $AB, $1D, $18, $1B, dSnare