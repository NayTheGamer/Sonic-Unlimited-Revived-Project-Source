CosmicCarnageTitle_Header:
	smpsHeaderStartSong 1
	smpsHeaderVoice     CosmicCarnageTitle_Voices
	smpsHeaderChan      $06, $03
	smpsHeaderTempo     $02, $0C

	smpsHeaderDAC       CosmicCarnageTitle_DAC
	smpsHeaderFM        CosmicCarnageTitle_FM1,	$F4, $12
	smpsHeaderFM        CosmicCarnageTitle_FM2,	$F4, $17
	smpsHeaderFM        CosmicCarnageTitle_FM3,	$F4, $17
	smpsHeaderFM        CosmicCarnageTitle_FM4,	$F4, $1B
	smpsHeaderFM        CosmicCarnageTitle_FM5,	$F4, $1B
	smpsHeaderPSG       CosmicCarnageTitle_PSG1,	$D0, $04, $00, $00
	smpsHeaderPSG       CosmicCarnageTitle_PSG2,	$D0, $06, $00, $00
	smpsHeaderPSG       CosmicCarnageTitle_PSG3,	$00, $03, $00, $00

; FM1 Data
CosmicCarnageTitle_FM1:
	smpsSetvoice        $00
	dc.b	nC4, $03, nC5, nBb4, nC4, nBb4, nG4, nC4, nG4, nF4, nC4, nF4
	dc.b	nEb4, nC4, nF4, nG4, nC5, nC4, nC5, nBb4, nC4, nBb4, nG4, nC4
	dc.b	nG4, nF4, nC4, nF4, nEb4, nC4, nF4, nG4, nC5
	smpsSetvoice        $03
	dc.b	nRst, $06, nC4, $30, smpsNoAttack, $0C
	smpsStop

; FM2 Data
CosmicCarnageTitle_FM2:
	smpsPan             panCenter, $00

CosmicCarnageTitle_Jump00:
	smpsAlterPitch      $E8
	smpsSetvoice        $01
	dc.b	nRst, $06, nG6, $03, nRst, $06, nG6, $03, nRst, $06, nG6, $09
	dc.b	nG6, $03, nRst, $06, nG6, $03, nRst, $03, nRst, $06, nAb6, $03
	dc.b	nRst, $06, nAb6, $03, nRst, $06, nAb6, $09, nAb6, $03, nRst, $06
	dc.b	nAb6, $03, nRst, $03, nRst, $06, nG6, $30, smpsNoAttack, $0C
	smpsStop

; FM3 Data
CosmicCarnageTitle_FM3:
	smpsPan             panCenter, $00

CosmicCarnageTitle_Jump01:
	smpsAlterPitch      $E8
	smpsSetvoice        $01
	dc.b	nRst, $06, nEb6, $03, nRst, $06, nEb6, $03, nRst, $06, nEb6, $09
	dc.b	nEb6, $03, nRst, $06, nEb6, $03, nRst, $03, nRst, $06, nF6, $03
	dc.b	nRst, $06, nF6, $03, nRst, $06, nF6, $09, nF6, $03, nRst, $06
	dc.b	nF6, $03, nRst, $03, nRst, $06, nEb6, $30, smpsNoAttack, $0C
	smpsStop

; FM4 Data
CosmicCarnageTitle_FM4:
	smpsPan             panRight, $00
	smpsAlterNote       $0B
	smpsJump            CosmicCarnageTitle_Jump01

; FM5 Data
CosmicCarnageTitle_FM5:
	smpsPan             panLeft, $00
	smpsAlterNote       $0B
	smpsJump            CosmicCarnageTitle_Jump00

; PSG1 Data
CosmicCarnageTitle_PSG1:
	dc.b	nG5, $03, nC6, nG6, nC6, nC7, nG6, nC6, nG5, nG6, nC6, nG5
	dc.b	nG6, nC6, nG5, nC6, nG6, nG5, nC6, nG6, nC6, nC7, nG6, nC6
	dc.b	nG5, nG6, nC6, nG5, nG6, nC6, nG5, nC6, nG6
	smpsStop

; PSG2 Data
CosmicCarnageTitle_PSG2:
	dc.b	nRst, $03
	smpsAlterNote       $01
	dc.b	nG5, $03, nC6, nG6, nC6, nC7, nG6, nC6, nG5, nG6, nC6, nG5
	dc.b	nG6, nC6, nG5, nC6, nG6, nG5, nC6, nG6, nC6, nC7, nG6, nC6
	dc.b	nG5, nG6, nC6, nG5, nG6, nC6, nG5, nC6
	smpsStop

; PSG3 Data
CosmicCarnageTitle_PSG3:
	smpsPSGform         $E7
	smpsPSGvoice        fTone_02
	dc.b	nBb5, $06
	smpsPSGvoice        fTone_06
	dc.b	nBb5
	smpsPSGvoice        fTone_02
	dc.b	nBb5, $06
	smpsPSGvoice        fTone_06
	dc.b	nBb5
	smpsPSGvoice        fTone_02
	dc.b	nBb5, $06
	smpsPSGvoice        fTone_06
	dc.b	nBb5
	smpsPSGvoice        fTone_02
	dc.b	nBb5, $06
	smpsPSGvoice        fTone_06
	dc.b	nBb5
	smpsPSGvoice        fTone_02
	dc.b	nBb5, $06
	smpsPSGvoice        fTone_06
	dc.b	nBb5
	smpsPSGvoice        fTone_02
	dc.b	nBb5, $06
	smpsPSGvoice        fTone_06
	dc.b	nBb5
	smpsPSGvoice        fTone_02
	dc.b	nBb5, $06
	smpsPSGvoice        fTone_06
	dc.b	nBb5
	smpsPSGvoice        fTone_02
	dc.b	nBb5, $06
	smpsPSGvoice        fTone_06
	dc.b	nBb5
	smpsStop

; DAC Data
CosmicCarnageTitle_DAC:
	dc.b	dKick, $0C, dSnare, $09, $03, dKick, $0C, dSnare, $06, dKick, dKick, $0C
	dc.b	dSnare, $09, $03, dKick, $91, $91, $91, dSnare, dSnare, $93, $93, dKick
	dc.b	dKick, $8C, $2A
	smpsStop

CosmicCarnageTitle_Voices:
;	Voice $00
;	$35
;	$01, $31, $72, $00, 	$1F, $1F, $10, $1F, 	$09, $0F, $0F, $0F
;	$12, $17, $17, $17, 	$80, $9F, $9F, $9F, 	$13, $80, $80, $80
	smpsVcAlgorithm     $05
	smpsVcFeedback      $06
	smpsVcUnusedBits    $00
	smpsVcDetune        $00, $07, $03, $00
	smpsVcCoarseFreq    $00, $02, $01, $01
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $1F, $10, $1F, $1F
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $0F, $0F, $0F, $09
	smpsVcDecayRate2    $17, $17, $17, $12
	smpsVcDecayLevel    $09, $09, $09, $08
	smpsVcReleaseRate   $0F, $0F, $0F, $00
	smpsVcTotalLevel    $00, $00, $00, $13

;	Voice $01
;	$2C
;	$13, $03, $12, $02, 	$10, $1A, $10, $1A, 	$03, $02, $03, $02
;	$07, $0E, $07, $0E, 	$0C, $6F, $0C, $6F, 	$11, $83, $14, $84
	smpsVcAlgorithm     $04
	smpsVcFeedback      $05
	smpsVcUnusedBits    $00
	smpsVcDetune        $00, $01, $00, $01
	smpsVcCoarseFreq    $02, $02, $03, $03
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $1A, $10, $1A, $10
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $02, $03, $02, $03
	smpsVcDecayRate2    $0E, $07, $0E, $07
	smpsVcDecayLevel    $06, $00, $06, $00
	smpsVcReleaseRate   $0F, $0C, $0F, $0C
	smpsVcTotalLevel    $04, $14, $03, $11

;	Voice $02
;	$26
;	$02, $11, $71, $01, 	$1F, $1F, $1F, $1F, 	$1A, $12, $0E, $0B
;	$14, $12, $12, $13, 	$1F, $9F, $1F, $1F, 	$08, $80, $80, $80
	smpsVcAlgorithm     $06
	smpsVcFeedback      $04
	smpsVcUnusedBits    $00
	smpsVcDetune        $00, $07, $01, $00
	smpsVcCoarseFreq    $01, $01, $01, $02
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $1F, $1F, $1F, $1F
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $0B, $0E, $12, $1A
	smpsVcDecayRate2    $13, $12, $12, $14
	smpsVcDecayLevel    $01, $01, $09, $01
	smpsVcReleaseRate   $0F, $0F, $0F, $0F
	smpsVcTotalLevel    $00, $00, $00, $08

;	Voice $03
;	$35
;	$01, $31, $72, $00, 	$1F, $1F, $10, $1F, 	$09, $0C, $0C, $0C
;	$09, $07, $07, $07, 	$30, $4F, $4F, $4F, 	$13, $80, $80, $80
	smpsVcAlgorithm     $05
	smpsVcFeedback      $06
	smpsVcUnusedBits    $00
	smpsVcDetune        $00, $07, $03, $00
	smpsVcCoarseFreq    $00, $02, $01, $01
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $1F, $10, $1F, $1F
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $0C, $0C, $0C, $09
	smpsVcDecayRate2    $07, $07, $07, $09
	smpsVcDecayLevel    $04, $04, $04, $03
	smpsVcReleaseRate   $0F, $0F, $0F, $00
	smpsVcTotalLevel    $00, $00, $00, $13

