GoldenAxeIIITrackOne_Header:
	smpsHeaderStartSong 1
	smpsHeaderVoice     GoldenAxeIIITrackOne_Voices
;	smpsHeaderVoiceUVB
	smpsHeaderChan      $06, $03
	smpsHeaderTempo     $01, $00

	smpsHeaderDAC       GoldenAxeIIITrackOne_DAC
	smpsHeaderFM        GoldenAxeIIITrackOne_FM1,	$E8, $19
	smpsHeaderFM        GoldenAxeIIITrackOne_FM2,	$DC, $10
	smpsHeaderFM        GoldenAxeIIITrackOne_FM3,	$E8, $19
	smpsHeaderFM        GoldenAxeIIITrackOne_FM4,	$E8, $19
	smpsHeaderFM        GoldenAxeIIITrackOne_FM5,	$E8, $17
	smpsHeaderPSG       GoldenAxeIIITrackOne_PSG1,	$DC, $05, $00, $00
	smpsHeaderPSG       GoldenAxeIIITrackOne_PSG2,	$DC, $06, $00, $00
	smpsHeaderPSG       GoldenAxeIIITrackOne_PSG3,	$00, $03, $00, $00

; FM1 Data
GoldenAxeIIITrackOne_FM1:
	smpsCall            GoldenAxeIIITrackOne_Call11
	smpsSetvoice        $01

GoldenAxeIIITrackOne_Loop0C:
	smpsCall            GoldenAxeIIITrackOne_Call12
	smpsLoop            $01, $02, GoldenAxeIIITrackOne_Loop0C
	smpsAlterPitch      $0C
	smpsModSet          $20, $01, $05, $05
	smpsSetvoice        $04
	smpsCall            GoldenAxeIIITrackOne_Call0A
	dc.b	smpsNoAttack, $30, smpsNoAttack, $30
	smpsCall            GoldenAxeIIITrackOne_Call0A
	dc.b	smpsNoAttack, $30
	smpsAlterPitch      $F4
	smpsCall            GoldenAxeIIITrackOne_Call0B
	dc.b	nE6, $0C

GoldenAxeIIITrackOne_Loop0D:
	dc.b	smpsNoAttack, $18
	smpsAlterVol        $FE
	smpsLoop            $00, $04, GoldenAxeIIITrackOne_Loop0D
	smpsModSet          $0A, $01, $D6, $FF

GoldenAxeIIITrackOne_Loop0E:
	dc.b	nE7, $18
	smpsAlterVol        $0A
	smpsLoop            $00, $04, GoldenAxeIIITrackOne_Loop0E
	smpsAlterVol        $D8
	smpsAlterVol        $08
	smpsModSet          $40, $01, $05, $05

GoldenAxeIIITrackOne_Loop0F:
	smpsCall            GoldenAxeIIITrackOne_Call0C
	smpsLoop            $00, $02, GoldenAxeIIITrackOne_Loop0F
	smpsSetvoice        $01
	smpsJump            GoldenAxeIIITrackOne_Loop0C

GoldenAxeIIITrackOne_Call11:
	smpsSetvoice        $03
	dc.b	nG6, $06, nG6, nG6, nG6, nRst, $18, nG6, $06, nG6, nG6, nG6
	dc.b	nRst, $18, nRst, $06, nG6, $06, $06, nRst, nG6, $08, $08, $08
	dc.b	nRst, $30
	smpsReturn

GoldenAxeIIITrackOne_Call12:
	smpsModSet          $36, $01, $1B, $FF
	dc.b	nE5, $30, smpsNoAttack, $30
	smpsModSet          $0A, $01, $D6, $FF

GoldenAxeIIITrackOne_Loop1E:
	dc.b	nE6, $18
	smpsAlterVol        $0A
	smpsLoop            $00, $04, GoldenAxeIIITrackOne_Loop1E
	smpsAlterVol        $D8
	smpsModSet          $36, $01, $1B, $FF
	dc.b	nFs5, $30, smpsNoAttack, $30
	smpsModSet          $0A, $01, $D6, $FF

GoldenAxeIIITrackOne_Loop1F:
	dc.b	nFs6, $18
	smpsAlterVol        $0A
	smpsLoop            $00, $04, GoldenAxeIIITrackOne_Loop1F
	smpsAlterVol        $D8
	smpsReturn

GoldenAxeIIITrackOne_Call0A:
	dc.b	nE6, $48, nG6, $18, nFs6, $30, $10, nD6, nFs6, nFs6, $24, nE6
	dc.b	$3C, smpsNoAttack, $30, smpsNoAttack, $30, nE6, $48, nG6, $18, nFs6, $30, $10
	dc.b	nG6, nA6, nA6, $24, nG6, $06, nFs6, nE6, $30
	smpsReturn

GoldenAxeIIITrackOne_Call0B:
	smpsSetvoice        $05
	smpsModSet          $08, $01, $06, $05
	dc.b	smpsNoAttack, $18, nA5, $0C, nB5, nC6, $24, nB5, $0C, nA5, nC6, nB6
	dc.b	nG6, smpsNoAttack, $24, nD6, $0C, nF6, $18, nE6, nD6, $06, nC6, nRst
	dc.b	nC6, nRst, nC6, nB5, $0C, nC6, nA5, nRst, $18, nD6, $06, nC6
	dc.b	nRst, nC6, nRst, nC6, nB5, $0C, nC6, $06, nE5, nRst, nG5, nRst
	dc.b	nA5, nRst, nB5, nC6, $24, nB5, $0C, nA5, nC6, nB6, nG6, smpsNoAttack
	dc.b	$24, nD6, $0C, nF6, $06, nE6, nRst, nD6, nRst, nC6
	smpsReturn

GoldenAxeIIITrackOne_Call0C:
	smpsAlterPitch      $0C
	smpsSetvoice        $07
	dc.b	nC7, $12, nB6, nA6, $0C, smpsNoAttack, $06
	smpsAlterPitch      $F4
	smpsSetvoice        $08
	dc.b	nD5, nE5, nG5, nD5, nE5, nG5, nD5, nC6, nC6, nB5, nA5, nRst
	dc.b	nA5, nG5, nA5, nC6, nA5
	smpsAlterPitch      $0C
	smpsSetvoice        $07
	dc.b	nG6, $0C, nA6, nG6, nB6, $12, nG6, nD6, $0C, smpsNoAttack, $0C, nC6
	dc.b	nB5, nG5, nB5, $12, nC6, nD6, $0C, smpsNoAttack, $06, nB5, $12, nD6
	dc.b	$0C, nG6
	smpsAlterPitch      $F4
	smpsReturn

; FM2 Data
GoldenAxeIIITrackOne_FM2:
	smpsSetvoice        $00
	smpsCall            GoldenAxeIIITrackOne_Call0D

GoldenAxeIIITrackOne_Loop0A:
	smpsCall            GoldenAxeIIITrackOne_Call0E
	smpsLoop            $00, $18, GoldenAxeIIITrackOne_Loop0A
	smpsCall            GoldenAxeIIITrackOne_Call0F
	smpsCall            GoldenAxeIIITrackOne_Call0E
	dc.b	nA4, $06, $06, nA5, $0C, nA4, $06, nA5, nA4, nA4, $06, $06
	dc.b	nG4, nRst, nG4, nRst, nG4, nRst, nG4
	smpsCall            GoldenAxeIIITrackOne_Call0F
	smpsCall            GoldenAxeIIITrackOne_Call0D

GoldenAxeIIITrackOne_Loop0B:
	smpsCall            GoldenAxeIIITrackOne_Call0E
	smpsCall            GoldenAxeIIITrackOne_Call0E
	smpsCall            GoldenAxeIIITrackOne_Call10
	smpsCall            GoldenAxeIIITrackOne_Call10
	smpsLoop            $00, $02, GoldenAxeIIITrackOne_Loop0B
	smpsJump            GoldenAxeIIITrackOne_Loop0A

GoldenAxeIIITrackOne_Call0D:
	dc.b	nE4, $06, nE4, nE4, nE4, nRst, $18, nE4, $06, nE4, nE4, nE4
	dc.b	nRst, $18, nRst, $06, nE4, $06, $06, nRst, nE4, $08, $08, $08
	dc.b	nRst, $30
	smpsReturn

GoldenAxeIIITrackOne_Call0E:
	dc.b	nA4, $06, $06, nA5, $0C, nA4, $06, nA5, nA4, nA4, $06, $06
	dc.b	nA5, nG5, nA4, nA4, $06, nG5, nA5, nA4
	smpsReturn

GoldenAxeIIITrackOne_Call0F:
	dc.b	nF4, $06, $06, nF5, $0C, nF4, $06, nF5, nF4, nF4, $06, $06
	dc.b	nF5, nC5, nF4, nF4, $06, nC5, nF5, nF4, nG4, $06, $06, nG5
	dc.b	$0C, nG4, $06, nG5, nG4, nG4, $06, $06, nG5, nD5, nG4, nG4
	dc.b	$06, nD5, nG5, nG4
	smpsReturn

GoldenAxeIIITrackOne_Call10:
	dc.b	nG4, $06, $06, nG5, $0C, nG4, $06, nG5, nG4, nG4, $06, $06
	dc.b	nG5, nD5, nG4, nG4, $06, nD5, nG5, nG4
	smpsReturn

; FM3 Data
GoldenAxeIIITrackOne_FM3:
	smpsCall            GoldenAxeIIITrackOne_Call08
	smpsSetvoice        $01

GoldenAxeIIITrackOne_Loop09:
	smpsCall            GoldenAxeIIITrackOne_Call09
	smpsLoop            $01, $02, GoldenAxeIIITrackOne_Loop09
	smpsAlterPitch      $0C
	smpsModSet          $00, $00, $00, $00
	smpsAlterVol        $0A
	smpsSetvoice        $04
	dc.b	nRst, $0C
	smpsCall            GoldenAxeIIITrackOne_Call0A
	dc.b	smpsNoAttack, $30, smpsNoAttack, $30
	smpsCall            GoldenAxeIIITrackOne_Call0A
	dc.b	smpsNoAttack, $30
	smpsAlterPitch      $F4
	smpsCall            GoldenAxeIIITrackOne_Call0B
	smpsAlterVol        $F6
	smpsCall            GoldenAxeIIITrackOne_Call08
	smpsAlterVol        $0A
	dc.b	nRst, $0C
	smpsCall            GoldenAxeIIITrackOne_Call0C
	smpsAlterPitch      $0C
	smpsSetvoice        $07
	dc.b	nC7, $12, nB6, nA6, $0C, smpsNoAttack, $06
	smpsAlterPitch      $F4
	smpsSetvoice        $08
	dc.b	nD5, nE5, nG5, nD5, nE5, nG5, nD5, nC6, nC6, nB5, nA5, nRst
	dc.b	nA5, nG5, nA5, nC6, nA5
	smpsAlterPitch      $0C
	smpsSetvoice        $07
	dc.b	nG6, $0C, nA6, nG6, nB6, $12, nG6, nD6, $0C, smpsNoAttack, $0C, nC6
	dc.b	nB5, nG5, nB5, $12, nC6, nD6, $0C, smpsNoAttack, $06, nB5, $12, nD6
	dc.b	$0C
	smpsAlterPitch      $F4
	smpsAlterVol        $F6
	smpsSetvoice        $01
	smpsJump            GoldenAxeIIITrackOne_Loop09

GoldenAxeIIITrackOne_Call08:
	smpsSetvoice        $03
	dc.b	nD6, $06, nD6, nD6, nD6, nRst, $18, nD6, $06, nD6, nD6, nD6
	dc.b	nRst, $18, nRst, $06, nD6, $06, $06, nRst, nD6, $08, $08, $08
	dc.b	nRst, $30
	smpsReturn

GoldenAxeIIITrackOne_Call09:
	smpsModSet          $36, $01, $1B, $FF
	dc.b	nC5, $30, smpsNoAttack, $30
	smpsModSet          $0A, $01, $D6, $FF

GoldenAxeIIITrackOne_Loop1C:
	dc.b	nC6, $18
	smpsAlterVol        $0A
	smpsLoop            $00, $04, GoldenAxeIIITrackOne_Loop1C
	smpsAlterVol        $D8
	smpsModSet          $36, $01, $1B, $FF
	dc.b	nD5, $30, smpsNoAttack, $30
	smpsModSet          $0A, $01, $D6, $FF

GoldenAxeIIITrackOne_Loop1D:
	dc.b	nD6, $18
	smpsAlterVol        $0A
	smpsLoop            $00, $04, GoldenAxeIIITrackOne_Loop1D
	smpsAlterVol        $D8
	smpsReturn

; FM4 Data
GoldenAxeIIITrackOne_FM4:
	smpsAlterPitch      $0C
	smpsCall            GoldenAxeIIITrackOne_Call05
	smpsSetvoice        $01

GoldenAxeIIITrackOne_Loop06:
	smpsCall            GoldenAxeIIITrackOne_Call06
	smpsLoop            $01, $02, GoldenAxeIIITrackOne_Loop06
	smpsAlterPitch      $F4

GoldenAxeIIITrackOne_Loop07:
	dc.b	nRst, $30
	smpsLoop            $00, $10, GoldenAxeIIITrackOne_Loop07
	smpsModSet          $20, $01, $05, $05
	smpsAlterPitch      $18
	smpsSetvoice        $04
	smpsCall            GoldenAxeIIITrackOne_Call07
	smpsAlterPitch      $E8
	smpsSetvoice        $06
	smpsAlterVol        $F6
	smpsPan             panRight, $00
	dc.b	nRst, $18, nA5, nC6, nE6, nG6, $30, nD6, $18, nB5, $0C, nG5
	dc.b	nA5, $30, nRst, $06, nA5, nG5, nA5, nRst, nA5, nG5, nA5, nA5
	dc.b	$30, nRst, $06, nG5, nRst, nB5, nRst, nD6, nRst, nF6, nRst, $18
	dc.b	nA5, nC6, nE6, nG6, $30, nD6, $30
	smpsAlterVol        $0A
	smpsPan             panCenter, $00
	smpsCall            GoldenAxeIIITrackOne_Call05
	smpsModSet          $40, $01, $05, $05
	smpsAlterVol        $05

GoldenAxeIIITrackOne_Loop08:
	smpsAlterPitch      $0C
	smpsSetvoice        $07
	dc.b	nE6, $12, nD6, nC6, $0C, smpsNoAttack, $06
	smpsAlterPitch      $F4
	smpsPan             panRight, $00
	smpsSetvoice        $08
	dc.b	nD5, nE5, nG5, nD5, nE5, nG5, nD5, nC6, nC6, nB5, nA5, nRst
	dc.b	nA5, nG5, nA5, nC6, nA5
	smpsAlterPitch      $0C
	smpsPan             panCenter, $00
	smpsSetvoice        $07
	dc.b	nB5, $0C, nC6, nB5, nD6, $12, nB5, nG5, $0C, smpsNoAttack, $0C, nF5
	dc.b	nD5, nB4, nD5, $12, nE5, nF5, $0C, smpsNoAttack, $06, nD5, $12, nG5
	dc.b	$0C, nB5
	smpsAlterPitch      $F4
	smpsLoop            $00, $02, GoldenAxeIIITrackOne_Loop08
	smpsAlterVol        $FB
	smpsSetvoice        $01
	smpsAlterPitch      $0C
	smpsJump            GoldenAxeIIITrackOne_Loop06

GoldenAxeIIITrackOne_Call05:
	smpsSetvoice        $03
	dc.b	nAb5, $06, nAb5, nAb5, nAb5, nRst, $18, nAb5, $06, nAb5, nAb5, nAb5
	dc.b	nRst, $18, nRst, $06, nAb5, $06, $06, nRst, nAb5, $08, $08, $08
	dc.b	nRst, $30
	smpsReturn

GoldenAxeIIITrackOne_Call06:
	smpsModSet          $36, $01, $1B, $FF
	dc.b	nA4, $30, smpsNoAttack, $30
	smpsModSet          $0A, $01, $D6, $FF

GoldenAxeIIITrackOne_Loop1A:
	dc.b	nA5, $18
	smpsAlterVol        $0A
	smpsLoop            $00, $04, GoldenAxeIIITrackOne_Loop1A
	smpsAlterVol        $D8
	smpsModSet          $36, $01, $1B, $FF
	dc.b	nA4, $30, smpsNoAttack, $30
	smpsModSet          $0A, $01, $D6, $FF

GoldenAxeIIITrackOne_Loop1B:
	dc.b	nA5, $18
	smpsAlterVol        $0A
	smpsLoop            $00, $04, GoldenAxeIIITrackOne_Loop1B
	smpsAlterVol        $D8
	smpsReturn

GoldenAxeIIITrackOne_Call07:
	dc.b	nC6, $48, nE6, $18, nD6, $30, $10, nB5, nD6, nD6, $24, nC6
	dc.b	$3C, smpsNoAttack, $30, smpsNoAttack, $30, nC6, $48, nE6, $18, nD6, $30, $10
	dc.b	nE6, nFs6, nFs6, $24, nE6, $06, nD6, nC6, $30, smpsNoAttack, $30, smpsNoAttack
	dc.b	$30
	smpsReturn

; FM5 Data
GoldenAxeIIITrackOne_FM5:
	smpsSetvoice        $02
	smpsCall            GoldenAxeIIITrackOne_Call03
	dc.b	nRst, $30, nRst, $30

GoldenAxeIIITrackOne_Loop04:
	smpsCall            GoldenAxeIIITrackOne_Call03
	smpsLoop            $00, $18, GoldenAxeIIITrackOne_Loop04
	smpsCall            GoldenAxeIIITrackOne_Call03
	smpsCall            GoldenAxeIIITrackOne_Call04
	smpsCall            GoldenAxeIIITrackOne_Call03
	dc.b	nE5, $06, nA4, nA4, nC5, nA4, nA4, nD5, nA4, nB4, nG4, nRst
	dc.b	nG4, nRst, nG4, nRst, nG4
	smpsCall            GoldenAxeIIITrackOne_Call03
	smpsCall            GoldenAxeIIITrackOne_Call04
	smpsSetvoice        $02
	smpsCall            GoldenAxeIIITrackOne_Call03
	dc.b	nRst, $30, nRst, $30

GoldenAxeIIITrackOne_Loop05:
	smpsCall            GoldenAxeIIITrackOne_Call03
	smpsCall            GoldenAxeIIITrackOne_Call03
	smpsCall            GoldenAxeIIITrackOne_Call04
	smpsCall            GoldenAxeIIITrackOne_Call04
	smpsLoop            $00, $02, GoldenAxeIIITrackOne_Loop05
	smpsJump            GoldenAxeIIITrackOne_Loop04

GoldenAxeIIITrackOne_Call03:
	dc.b	nE5, $06, nA4, nA4, nC5, nA4, nA4, nD5, nA4, nA4, nB4, nA4
	dc.b	nA4, nC5, nA4, nD5, nA4
	smpsReturn

GoldenAxeIIITrackOne_Call04:
	dc.b	nE5, $06, nG4, nG4, nB4, nG4, nG4, nD5, nG4, nG4, nB4, nG4
	dc.b	nG4, nC5, nG4, nD5, nG4
	smpsReturn

; PSG1 Data
GoldenAxeIIITrackOne_PSG1:
	smpsPSGvoice        fTone_03

GoldenAxeIIITrackOne_Loop15:
	dc.b	nRst, $30
	smpsLoop            $00, $14, GoldenAxeIIITrackOne_Loop15

GoldenAxeIIITrackOne_Loop16:
	smpsCall            GoldenAxeIIITrackOne_Call13
	smpsLoop            $00, $10, GoldenAxeIIITrackOne_Loop16
	smpsCall            GoldenAxeIIITrackOne_Call13
	smpsCall            GoldenAxeIIITrackOne_Call14
	smpsCall            GoldenAxeIIITrackOne_Call13
	dc.b	nE5, $06, nA4, nA4, nC5, nA4, nA4, nD5, nA4, nB4, nG4, nRst
	dc.b	nG4, nRst, nG4, nRst, nG4
	smpsCall            GoldenAxeIIITrackOne_Call13
	smpsCall            GoldenAxeIIITrackOne_Call14
	dc.b	nG6, $06, nG6, nG6, nG6, nRst, $18, nG6, $06, nG6, nG6, nG6
	dc.b	nRst, $18, nRst, $06, nG6, $06, $06, nRst, nG6, $08, $08, $08
	dc.b	nRst, $30
	smpsPSGAlterVol     $02
	smpsPSGvoice        fTone_01

GoldenAxeIIITrackOne_Loop17:
	dc.b	nE6, $06, nC6, nA5, nE6, nC6, nA5, nE6, nC6, nA5, nE6, nC6
	dc.b	nA5, nE6, nC6, nA5, nE6
	smpsLoop            $00, $02, GoldenAxeIIITrackOne_Loop17

GoldenAxeIIITrackOne_Loop18:
	dc.b	nD6, nB5, nG5, nD6, nB5, nG5, nD6, nB5, nG5, nD6, nB5, nG5
	dc.b	nD6, nB5, nG5, nD6
	smpsLoop            $00, $02, GoldenAxeIIITrackOne_Loop18
	smpsLoop            $01, $02, GoldenAxeIIITrackOne_Loop17
	smpsPSGvoice        fTone_03
	smpsPSGAlterVol     $FE

GoldenAxeIIITrackOne_Loop19:
	dc.b	nRst, $30
	smpsLoop            $00, $10, GoldenAxeIIITrackOne_Loop19
	smpsJump            GoldenAxeIIITrackOne_Loop16

GoldenAxeIIITrackOne_Call13:
	dc.b	nE5, $06, nA4, nA4, nC5, nA4, nA4, nD5, nA4, nA4, nB4, nA4
	dc.b	nA4, nC5, nA4, nD5, nA4
	smpsReturn

GoldenAxeIIITrackOne_Call14:
	dc.b	nE5, $06, nG4, nG4, nB4, nG4, nG4, nD5, nG4, nG4, nB4, nG4
	dc.b	nG4, nC5, nG4, nD5, nG4
	smpsReturn

; PSG2 Data
GoldenAxeIIITrackOne_PSG2:
	dc.b	nRst, $06
	smpsPSGvoice        fTone_03

GoldenAxeIIITrackOne_Loop10:
	dc.b	nRst, $30
	smpsLoop            $00, $14, GoldenAxeIIITrackOne_Loop10

GoldenAxeIIITrackOne_Loop11:
	smpsCall            GoldenAxeIIITrackOne_Call13
	smpsLoop            $00, $10, GoldenAxeIIITrackOne_Loop11
	smpsCall            GoldenAxeIIITrackOne_Call13
	smpsCall            GoldenAxeIIITrackOne_Call14
	smpsCall            GoldenAxeIIITrackOne_Call13
	dc.b	nE5, $06, nA4, nA4, nC5, nA4, nA4, nD5, nA4, nB4, nG4, nRst
	dc.b	nG4, nRst, nG4, nRst, nG4
	smpsCall            GoldenAxeIIITrackOne_Call13
	smpsCall            GoldenAxeIIITrackOne_Call14
	dc.b	nG5, $06, nG5, nG5, nG5, nRst, $18, nG5, $06, nG5, nG5, nG5
	dc.b	nRst, $18, nRst, $06, nG5, $06, $06, nRst, nG5, $08, $08, $08
	dc.b	nRst, $2A
	smpsPSGvoice        fTone_01
	smpsPSGAlterVol     $01

GoldenAxeIIITrackOne_Loop12:
	dc.b	nA6, $06, nE6, nC6, nA6, nE6, nC6, nA6, nE6, nC6, nA6, nE6
	dc.b	nC6, nA6, nE6, nC6, nA6
	smpsLoop            $00, $02, GoldenAxeIIITrackOne_Loop12

GoldenAxeIIITrackOne_Loop13:
	dc.b	nG6, nD6, nB5, nG6, nD6, nB5, nG6, nD6, nB5, nG6, nD6, nB5
	dc.b	nG6, nD6, nB5, nG6
	smpsLoop            $00, $02, GoldenAxeIIITrackOne_Loop13
	smpsLoop            $01, $02, GoldenAxeIIITrackOne_Loop12
	smpsPSGAlterVol     $FF
	smpsPSGvoice        fTone_03

GoldenAxeIIITrackOne_Loop14:
	dc.b	nRst, $30
	smpsLoop            $00, $10, GoldenAxeIIITrackOne_Loop14
	dc.b	nRst, $06
	smpsJump            GoldenAxeIIITrackOne_Loop11

; PSG3 Data
GoldenAxeIIITrackOne_PSG3:
	smpsPSGform         $E7
	smpsPSGvoice        fTone_02

GoldenAxeIIITrackOne_Jump00:
	dc.b	nG4, $06
	smpsPSGAlterVol     $03
	dc.b	$06
	smpsPSGAlterVol     $FD
	smpsJump            GoldenAxeIIITrackOne_Jump00

; DAC Data
GoldenAxeIIITrackOne_DAC:
	smpsCall            GoldenAxeIIITrackOne_Call00

GoldenAxeIIITrackOne_Loop00:
	smpsCall            GoldenAxeIIITrackOne_Call01
	smpsLoop            $00, $0E, GoldenAxeIIITrackOne_Loop00
	smpsCall            GoldenAxeIIITrackOne_Call02
	smpsLoop            $01, $03, GoldenAxeIIITrackOne_Loop00

GoldenAxeIIITrackOne_Loop01:
	smpsCall            GoldenAxeIIITrackOne_Call01
	smpsLoop            $00, $07, GoldenAxeIIITrackOne_Loop01
	dc.b	dKick, $06, dSnare, dKick, dSnare, dKick, dSnare, dKick, dSnare

GoldenAxeIIITrackOne_Loop02:
	smpsCall            GoldenAxeIIITrackOne_Call01
	smpsLoop            $00, $04, GoldenAxeIIITrackOne_Loop02
	smpsCall            GoldenAxeIIITrackOne_Call00

GoldenAxeIIITrackOne_Loop03:
	smpsCall            GoldenAxeIIITrackOne_Call01
	smpsLoop            $00, $0E, GoldenAxeIIITrackOne_Loop03
	smpsCall            GoldenAxeIIITrackOne_Call02
	smpsJump            GoldenAxeIIITrackOne_Loop00

GoldenAxeIIITrackOne_Call00:
	dc.b	dSnare, $06, dSnare, dSnare, dSnare, dKick, dSnare, dKick, dKick, dSnare, dSnare, dSnare
	dc.b	dSnare, dKick, dSnare, dKick, dKick, dKick, dSnare, dSnare, dKick, dSnare, $04, dSnare
	dc.b	dSnare, dSnare, dKick, dSnare, dSnare, $04, dSnare, dSnare, dClap, dClap, dClap, $84
	dc.b	$84, $84, $85, $85, $85
	smpsReturn

GoldenAxeIIITrackOne_Call01:
	dc.b	dKick, $0C, dSnare, dKick, $06, dKick, dSnare, $0C
	smpsReturn

GoldenAxeIIITrackOne_Call02:
	dc.b	dKick, $06, dSnare, dSnare, dSnare, dKick, dSnare, dKick, dSnare, dKick, $06, dSnare
	dc.b	dSnare, dSnare, dClap, dClap, $84, $85
	smpsReturn

GoldenAxeIIITrackOne_Voices:
;	Voice $00
;	$24
;	$71, $41, $71, $51, 	$1F, $1F, $1F, $1F, 	$0F, $07, $4F, $4F
;	$0B, $0B, $0E, $0A, 	$79, $79, $79, $79, 	$10, $80, $0E, $80
	smpsVcAlgorithm     $04
	smpsVcFeedback      $04
	smpsVcUnusedBits    $00
	smpsVcDetune        $05, $07, $04, $07
	smpsVcCoarseFreq    $01, $01, $01, $01
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $1F, $1F, $1F, $1F
	smpsVcAmpMod        $01, $01, $01, $01
	smpsVcDecayRate1    $0F, $0F, $07, $0F
	smpsVcDecayRate2    $0A, $0E, $0B, $0B
	smpsVcDecayLevel    $07, $07, $07, $07
	smpsVcReleaseRate   $09, $09, $09, $09
	smpsVcTotalLevel    $00, $0E, $00, $10

;	Voice $01
;	$3C
;	$14, $14, $32, $22, 	$1F, $1F, $1F, $1F, 	$12, $0E, $1F, $1F
;	$08, $05, $05, $05, 	$07, $0A, $07, $07, 	$14, $80, $19, $80
	smpsVcAlgorithm     $04
	smpsVcFeedback      $07
	smpsVcUnusedBits    $00
	smpsVcDetune        $02, $03, $01, $01
	smpsVcCoarseFreq    $02, $02, $04, $04
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $1F, $1F, $1F, $1F
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $1F, $1F, $0E, $12
	smpsVcDecayRate2    $05, $05, $05, $08
	smpsVcDecayLevel    $00, $00, $00, $00
	smpsVcReleaseRate   $07, $07, $0A, $07
	smpsVcTotalLevel    $00, $19, $00, $14

;	Voice $02
;	$03
;	$7F, $01, $42, $18, 	$1F, $1F, $1F, $1F, 	$17, $0E, $0F, $0D
;	$15, $0E, $0C, $0F, 	$1E, $1E, $1F, $1F, 	$17, $14, $14, $80
	smpsVcAlgorithm     $03
	smpsVcFeedback      $00
	smpsVcUnusedBits    $00
	smpsVcDetune        $01, $04, $00, $07
	smpsVcCoarseFreq    $08, $02, $01, $0F
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $1F, $1F, $1F, $1F
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $0D, $0F, $0E, $17
	smpsVcDecayRate2    $0F, $0C, $0E, $15
	smpsVcDecayLevel    $01, $01, $01, $01
	smpsVcReleaseRate   $0F, $0F, $0E, $0E
	smpsVcTotalLevel    $00, $14, $14, $17

;	Voice $03
;	$3B
;	$19, $15, $12, $12, 	$1F, $1F, $1F, $1F, 	$0F, $3E, $0E, $0F
;	$0F, $4E, $0F, $0D, 	$0F, $4F, $0E, $0D, 	$13, $0F, $1E, $80
	smpsVcAlgorithm     $03
	smpsVcFeedback      $07
	smpsVcUnusedBits    $00
	smpsVcDetune        $01, $01, $01, $01
	smpsVcCoarseFreq    $02, $02, $05, $09
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $1F, $1F, $1F, $1F
	smpsVcAmpMod        $00, $00, $01, $00
	smpsVcDecayRate1    $0F, $0E, $1E, $0F
	smpsVcDecayRate2    $0D, $0F, $4E, $0F
	smpsVcDecayLevel    $00, $00, $04, $00
	smpsVcReleaseRate   $0D, $0E, $0F, $0F
	smpsVcTotalLevel    $00, $1E, $0F, $13

;	Voice $04
;	$35
;	$11, $12, $12, $11, 	$0F, $0F, $0D, $0F, 	$07, $06, $08, $09
;	$07, $08, $08, $06, 	$06, $09, $06, $07, 	$12, $82, $84, $85
	smpsVcAlgorithm     $05
	smpsVcFeedback      $06
	smpsVcUnusedBits    $00
	smpsVcDetune        $01, $01, $01, $01
	smpsVcCoarseFreq    $01, $02, $02, $01
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $0F, $0D, $0F, $0F
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $09, $08, $06, $07
	smpsVcDecayRate2    $06, $08, $08, $07
	smpsVcDecayLevel    $00, $00, $00, $00
	smpsVcReleaseRate   $07, $06, $09, $06
	smpsVcTotalLevel    $05, $04, $02, $12

;	Voice $05
;	$37
;	$14, $16, $12, $72, 	$1F, $1F, $1F, $1F, 	$07, $08, $08, $09
;	$08, $08, $08, $08, 	$0B, $0B, $0B, $0B, 	$80, $80, $87, $82
	smpsVcAlgorithm     $07
	smpsVcFeedback      $06
	smpsVcUnusedBits    $00
	smpsVcDetune        $07, $01, $01, $01
	smpsVcCoarseFreq    $02, $02, $06, $04
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $1F, $1F, $1F, $1F
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $09, $08, $08, $07
	smpsVcDecayRate2    $08, $08, $08, $08
	smpsVcDecayLevel    $00, $00, $00, $00
	smpsVcReleaseRate   $0B, $0B, $0B, $0B
	smpsVcTotalLevel    $02, $07, $00, $00

;	Voice $06
;	$3A
;	$51, $01, $11, $01, 	$0F, $10, $0F, $0E, 	$08, $0A, $00, $06
;	$01, $01, $01, $01, 	$1F, $1F, $1F, $1F, 	$28, $29, $2D, $80
	smpsVcAlgorithm     $02
	smpsVcFeedback      $07
	smpsVcUnusedBits    $00
	smpsVcDetune        $00, $01, $00, $05
	smpsVcCoarseFreq    $01, $01, $01, $01
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $0E, $0F, $10, $0F
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $06, $00, $0A, $08
	smpsVcDecayRate2    $01, $01, $01, $01
	smpsVcDecayLevel    $01, $01, $01, $01
	smpsVcReleaseRate   $0F, $0F, $0F, $0F
	smpsVcTotalLevel    $00, $2D, $29, $28

;	Voice $07
;	$2B
;	$32, $21, $11, $02, 	$1F, $1F, $1F, $1F, 	$07, $06, $06, $05
;	$04, $05, $06, $05, 	$04, $06, $04, $06, 	$1A, $1D, $1C, $81
	smpsVcAlgorithm     $03
	smpsVcFeedback      $05
	smpsVcUnusedBits    $00
	smpsVcDetune        $00, $01, $02, $03
	smpsVcCoarseFreq    $02, $01, $01, $02
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $1F, $1F, $1F, $1F
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $05, $06, $06, $07
	smpsVcDecayRate2    $05, $06, $05, $04
	smpsVcDecayLevel    $00, $00, $00, $00
	smpsVcReleaseRate   $06, $04, $06, $04
	smpsVcTotalLevel    $01, $1C, $1D, $1A

;	Voice $08
;	$3D
;	$02, $02, $02, $02, 	$8E, $52, $14, $4C, 	$06, $08, $0F, $03
;	$00, $00, $00, $00, 	$3F, $1F, $1F, $1F, 	$1B, $80, $80, $80
	smpsVcAlgorithm     $05
	smpsVcFeedback      $07
	smpsVcUnusedBits    $00
	smpsVcDetune        $00, $00, $00, $00
	smpsVcCoarseFreq    $02, $02, $02, $02
	smpsVcRateScale     $01, $00, $01, $02
	smpsVcAttackRate    $0C, $14, $12, $0E
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $03, $0F, $08, $06
	smpsVcDecayRate2    $00, $00, $00, $00
	smpsVcDecayLevel    $01, $01, $01, $03
	smpsVcReleaseRate   $0F, $0F, $0F, $0F
	smpsVcTotalLevel    $00, $00, $00, $1B