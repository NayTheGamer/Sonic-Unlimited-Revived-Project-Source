ShuranomonTrack2_Header:
	smpsHeaderStartSong 1
	smpsHeaderVoice     ShuranomonTrack2_Voices
	smpsHeaderChan      $06, $03
	smpsHeaderTempo     $01, $30

	smpsHeaderDAC       ShuranomonTrack2_DAC,	$00, $02
	smpsHeaderFM        ShuranomonTrack2_FM1,	$F4, $10
	smpsHeaderFM        ShuranomonTrack2_FM2,	$F4, $0B
	smpsHeaderFM        ShuranomonTrack2_FM3,	$00, $0D
	smpsHeaderFM        ShuranomonTrack2_FM4,	$E8, $10
	smpsHeaderFM        ShuranomonTrack2_FM5,	$F4, $13
	smpsHeaderPSG       ShuranomonTrack2_PSG1,	$B8, $03, $07, fTone_03
	smpsHeaderPSG       ShuranomonTrack2_PSG2,	$B8, $03, $07, fTone_03
	smpsHeaderPSG       ShuranomonTrack2_PSG3,	$F4, $03, $00, fTone_02

; FM5 Data
ShuranomonTrack2_FM5:
	smpsSetvoice        $00
	smpsAlterNote       $FB
	dc.b	nRst, $0C
	smpsCall            ShuranomonTrack2_Call08

ShuranomonTrack2_Jump02:
	smpsPan             panLeft, $00
	smpsSetvoice        $00
	smpsModSet          $1F, $01, $04, $07
	smpsAlterNote       $FB
	smpsCall            ShuranomonTrack2_Call09
	smpsAlterNote       $FB
	smpsCall            ShuranomonTrack2_Call0A
	smpsAlterNote       $FB
	smpsJump            ShuranomonTrack2_Jump02

ShuranomonTrack2_Call08:
	smpsSetvoice        $07
	smpsAlterVol        $FB
	dc.b	nRst, $60, nRst, $60, nRst, $60
	smpsPan             panRight, $00
	dc.b	nRst, $3C, nA6, $0C
	smpsPan             panLeft, $00
	dc.b	nRst, nA6, nRst, $60, nRst, $60, nRst, $60
	smpsPan             panRight, $00
	dc.b	nRst, $3C, nA6, $0C
	smpsPan             panLeft, $00
	dc.b	nRst, nA6
	smpsSetvoice        $00
	smpsAlterVol        $05
	smpsReturn

ShuranomonTrack2_Call09:
	dc.b	nE6, $3C, nCs6, $0C, nD6, nE6, smpsNoAttack, $0C, nD6, $18, nCs6, nD6
	dc.b	nC6, $0C, smpsNoAttack, $30, nC6, $18, nB5, $0C, nA5, smpsNoAttack, $30, nE5
	dc.b	$0C, nA5, nB5, nC6, smpsNoAttack, $30, nA5, $0C, nC6, nE6, nD6, smpsNoAttack
	dc.b	$0C, nC6, $18, nB5, nC6, nD6, $0C, smpsNoAttack, $3C, nCs6, $0C, nD6
	dc.b	nE6, smpsNoAttack, $60, nE6, $3C, nCs6, $0C, nD6, nE6, smpsNoAttack, $0C, nD6
	dc.b	$18, nCs6, nD6, nC6, $0C, smpsNoAttack, $30, nC6, $18, nB5, $0C, nA5
	dc.b	$0C, smpsNoAttack, $30, nE5, $0C, nA5, nC6, nE6, smpsNoAttack, $30, nA5, $0C
	dc.b	nC6, nE6, nD6, smpsNoAttack, $0C, nC6, $18, nB5, nG6, nG6, $0C, smpsNoAttack
	dc.b	$3C, nD6, $0C, nG6, nA6, smpsNoAttack, $60, nE6, $30, nA5, $0C, nC6
	dc.b	nE6, nD6, $18, nC6, $18, nB5, nC6, nD6, $3C, nD6, $0C, nC6
	dc.b	nB5, nA5, $3C, nE5, $0C, nA5, nB5, nC6, $3C, nA5, $0C, nC6
	dc.b	nE6, nD6, $18, nC6, $18, nB5, nG6, nG6, $48, nD6, $0C, nG6
	dc.b	nA6, $30, smpsNoAttack, $05
	smpsAlterVol        $FF
	dc.b	nF6, $48
	smpsReturn

ShuranomonTrack2_Call0A:
	dc.b	nD6, $0C, nE6, nF6, $30, nG6, $0C, nA6, nG6, nF6, nE6, $48
	dc.b	nC6, $0C, nD6, nE6, $30, nF6, $0C, nG6, nF6, nE6, nF6, $3C
	dc.b	nA5, $0C, nD6, nE6, nF6, $30, nG6, $0C, nA6, nG6, nF6, nG6
	dc.b	$48, nEb6, $0C, nF6, nG6, $48, nEb6, $0C, nF6, nG6, $48, nE6
	dc.b	$0C, nC6, nE6, nG6, nE6, nC6, nA6, $54, smpsNoAttack, $01
	smpsReturn

; FM1 Data
ShuranomonTrack2_FM1:
	dc.b	nRst, $00
	smpsSetvoice        $00
	smpsModSet          $1F, $01, $04, $07
	smpsCall            ShuranomonTrack2_Call08

ShuranomonTrack2_Jump01:
	smpsSetvoice        $00
	smpsPan             panCenter, $00
	smpsCall            ShuranomonTrack2_Call09
	smpsCall            ShuranomonTrack2_Call0A
	smpsJump            ShuranomonTrack2_Jump01

; FM2 Data
ShuranomonTrack2_FM2:
	smpsSetvoice        $01

ShuranomonTrack2_Loop03:
	dc.b	nA3, $0C, nD4, nE4, nA3, nA4, nA3, nE4, nG4, smpsNoAttack, $0C, nA4
	dc.b	nG4, nE4, nD4, nE4, nD4, nG3, nA3, nD4, nE4, nA3, nA4, nA3
	dc.b	nE4, nG4, smpsNoAttack, $0C, nA4, nG4, nE4, nD4, nE4, nD4, nG3
	smpsLoop            $00, $02, ShuranomonTrack2_Loop03

ShuranomonTrack2_Loop04:
	dc.b	nA3, nD4, nE4, nA3, nA4, nA3, nE4, nG4, smpsNoAttack, $0C, nA4, nG4
	dc.b	nE4, nD4, nE4, nD4, nG3, nG3, nC4, nD4, nG3, nF4, nC4, nD4
	dc.b	nG4, smpsNoAttack, $0C, nF4, nC4, nD4, nG3, nG3, nF3, nE3, nD3, nG3
	dc.b	nA3, nD3, nD4, nD3, nG3, nE3, smpsNoAttack, $0C, nA3, nB3, nE3, nE4
	dc.b	nA3, nB3, nA3, smpsNoAttack, $0C, nA3, nD4, nD4, nE4, nE4, nG4, nA4
	dc.b	smpsNoAttack, $0C, nA4, nE4, nE4, nD4, nE4, nD4, nA3
	smpsLoop            $00, $02, ShuranomonTrack2_Loop04
	dc.b	nF3, nF3, nG3, nG3, nA3, nA3, nF3, nG3, smpsNoAttack, $0C, nG3, nA3
	dc.b	nA3, nB3, nB3, nD4, nA3, smpsNoAttack, $0C, nA3, nB3, nB3, nC4, nC4
	dc.b	nD4, nE4, smpsNoAttack, $0C, nE4, nD4, nD4, nC4, nC4, nB3, nF3, smpsNoAttack
	dc.b	$0C, nF3, nG3, nG3, nA3, nA3, nF3, nE3, smpsNoAttack, $0C, nE3, nB3
	dc.b	nB3, nE4, nE4, nE3, nE3, nA3, nA4, nA3, nA3, nA4, nA3, nA3
	dc.b	nA4, smpsNoAttack, $0C, nA4, nG4, nE4, nD4, nC4, nA3, nBb3, smpsNoAttack, $0C
	dc.b	nBb3, nD4, nD4, nF4, nF4, nD4, nBb4, smpsNoAttack, $0C, nBb4, nF4, nF4
	dc.b	nD4, nD4, nBb3, nA3, smpsNoAttack, $0C, nA3, nC4, nC4, nE4, nE4, nC4
	dc.b	nA4, smpsNoAttack, $0C, nA4, nE4, nE4, nC4, nC4, nA3, nBb3, smpsNoAttack, $0C
	dc.b	nBb3, nD4, nD4, nF4, nF4, nD4, nBb4, smpsNoAttack, $0C, nBb4, nF4, nF4
	dc.b	nD4, nD4, nBb3, nEb4, smpsNoAttack, $0C, nEb4, nBb4, nBb4, nEb5, nEb5, nEb4
	dc.b	nAb3, smpsNoAttack, $0C, nAb3, nEb4, nEb4, nAb4, nAb4, nAb3, nF3, smpsNoAttack, $0C
	dc.b	nF3, nC4, nC4, nF4, nF4, nC4, nF3, nD4, $24, nE4, $3C, nRst
	dc.b	$0C, nE5, nD5, nB4, nD5, nB4, nA4, nG4
	smpsJump            ShuranomonTrack2_Loop04

; FM3 Data
ShuranomonTrack2_FM3:
	smpsSetvoice        $07
	smpsAlterVol        $FC
	dc.b	nRst, $60, nRst, $60, nRst, $60
	smpsPan             panRight, $00
	dc.b	nRst, $3C, nE5, $0C
	smpsPan             panLeft, $00
	dc.b	nRst, nE5, nRst, $60, nRst, $60, nRst, $60
	smpsPan             panRight, $00
	dc.b	nRst, $3C, nE5, $0C
	smpsPan             panLeft, $00
	dc.b	nRst, nE5
	smpsAlterVol        $04

ShuranomonTrack2_Loop02:
	smpsSetvoice        $02
	smpsAlterVol        $72
	dc.b	$00, $00, $03, $01
	smpsPan             panLeft, $00
	dc.b	nA4, $0C, nE5, nA5, nCs6, nE6, nCs6, nA5, nG4, smpsNoAttack, $0C, nD5
	dc.b	nG5, nB5, nD6, nB5, nG5, nD5, nF4, nC5, nF5, nA5, nC6, nA5
	dc.b	nF5, nF6, nF5, nC6, nA5, nC5, nF5, nA5, nF5, nC5, nD4, nA4
	dc.b	nD5, nF5, nA5, nC6, nA5, nE4, nE4, nB4, nE5, nG5, nB5, nG5
	dc.b	nE5, nG4, nG4, nD5, nG5, nB5, nD6, nB5, nG5, nA4, nA4, nE5
	dc.b	nA5, nCs6, nE6, nCs6, nA5, nE5
	smpsLoop            $00, $02, ShuranomonTrack2_Loop02
	smpsSetvoice        $04
	dc.b	nA6, $0C, nF6, nB6, nF6, nC7, nF6, nD7, nB6, smpsNoAttack, $0C, nG6
	dc.b	nC7, nG6, nD7, nG6, nE7, nB6, smpsNoAttack, $0C, nG6, nC7, nG6, nD7
	dc.b	nG6, nG7, nA7, smpsNoAttack, $0C, nG7, nE7, nD7, nE7, nD7, nC7, nA6
	dc.b	smpsNoAttack, $0C, nF6, nB6, nF6, nC7, nF6, nD7, nB6, smpsNoAttack, $0C, nG6
	dc.b	nC7, nG6, nD7, nG6, nE7, $18, nA5, $0C, nD6, nE6, nD6, nA6
	dc.b	nD6, nE6, nA6
	smpsAlterVol        $FF
	dc.b	$02, $00, $03, $03, nE5, $08, nA5, nB5, nE6, nA5, nB5, nE6
	dc.b	nA6, nE6, nA6
	smpsSetvoice        $06
	dc.b	nB5, $04, nF5, nA5, nD6, nA5, nD6, nF6, nD6, nF6, nA6, nF6
	dc.b	nA6, nD7, nF7, nD7, nA6, nD7, nA6, nF6, nA6, nF6, nD6, nF6
	dc.b	nD6, nA5, nA5, nD6, nF6, nD6, nF6, nA6, nF6, nA6, nD7, nA6
	dc.b	nD7, nF7, nA7, nF7, nD7, nF7, nD7, nA6, nD7, nA6, nF6, nA6
	dc.b	nF6, nD6, nG5, nC6, nE6, nC6, nE6, nG6, nE6, nG6, nC7, nG6
	dc.b	nC7, nE7, nG7, nE7, nC7, nE7, nC7, nG6, nC7, nG6, nE6, nG6
	dc.b	nE6, nC6, nG5, nC6, nE6, nC6, nE6, nG6, nE6, nG6, nC7, nG6
	dc.b	nC7, nE7, nG7, nE7, nC7, nE7, nC7, nG6, nC7, nG6, nE6, nG6
	dc.b	nE6, nC6, nF5, nA5, nD6, nA5, nD6, nF6, nD6, nF6, nA6, nF6
	dc.b	nA6, nD7, nF7, nD7, nA6, nD7, nA6, nF6, nA6, nF6, nD6, nF6
	dc.b	nD6, nA5, nA5, nD6, nF6, nD6, nF6, nA6, nF6, nA6, nD7, nA6
	dc.b	nD7, nF7, nA7, nF7, nD7, nF7, nD7, nA6, nD7, nA6, nF6, nA6
	dc.b	nF6, nD6, nG5, nBb5, nD6, nBb5, nD6, nG6, nD6, nG6, nBb6, nG6
	dc.b	nBb6, nD7, nG7, nD7, nBb6, nD7, nBb6, nG6, nBb6, nG6, nD6, nG6
	dc.b	nD6, nBb5, nG5, nC6, nEb6, nC6, nEb6, nG6, nEb6, nG6, nC7, nG6
	dc.b	nC7, nEb7, nG7, nEb7, nC7, nEb7, nC7, nG6, nC7, nG6, nEb6, nG6
	dc.b	nEb6, nC6, nG5, nC6, nE6, nC6, nE6, nG6, nE6, nG6, nC7, nG6
	dc.b	nC7, nE7, nG7, nE7, nC7, nE7, nC7, nG6, nC7, nG6, nE6, nG6
	dc.b	nE6, nC6, nG5, nC6, nE6, nG5, nC6, nE6, nC6, nE6, nG6, nG6
	dc.b	nC7, nG6, nD5, nFs5, nA5, nFs5, nA5, nD6, nA5, nD6, nFs6, nD6
	dc.b	nFs6, nA6, nFs6, nA6, nD7, nD6, nFs6, nA6, nFs6, nA6, nD7, nA6
	dc.b	nD7, nFs7, nA7, nFs7, nD7, nA7, nFs7, nD7, nFs7, nD7, nA6, nD7
	dc.b	nA6, nFs6, nA6, nFs6, nD6
	smpsJump            ShuranomonTrack2_Loop02

; FM4 Data
ShuranomonTrack2_FM4:
	smpsSetvoice        $01
	smpsAlterNote       $F5
	smpsAlterPitch      $0C

ShuranomonTrack2_Loop00:
	dc.b	nA3, $0C, nD4, nE4, nA3, nA4, nA3, nE4, nG4, smpsNoAttack, $0C, nA4
	dc.b	nG4, nE4, nD4, nE4, nD4, nG3, nA3, nD4, nE4, nA3, nA4, nA3
	dc.b	nE4, nG4, smpsNoAttack, $0C, nA4, nG4, nE4, nD4, nE4, nD4, nG3
	smpsLoop            $00, $02, ShuranomonTrack2_Loop00
	smpsAlterNote       $00
	smpsAlterPitch      $F4

ShuranomonTrack2_Loop01:
	smpsModSet          $03, $01, $02, $03
	smpsSetvoice        $03
	smpsPan             panRight, $00
	dc.b	nB5, $54, nG5, $0C, smpsNoAttack, $60, nF5, $60, smpsNoAttack, $60, nF5, $54
	dc.b	nG5, $0C, smpsNoAttack, $54, nB5, $0C, smpsNoAttack, $54, nCs6, $0C, smpsNoAttack, $60
	smpsLoop            $00, $02, ShuranomonTrack2_Loop01
	dc.b	nC6, $24, nC6, $24, nC7, $06, nRst, $06, nB5, $0C, smpsNoAttack, $24
	dc.b	nG6, $24, nB6, $06, nRst, $06, nD6, $0C, smpsNoAttack, $24, nB5, $24
	dc.b	nD6, $06, nRst, $06, nC7, $0C, smpsNoAttack, $24, nE6, $24, nC6, $06
	dc.b	nRst, $06, nE6, $0C, smpsNoAttack, $24, nC6, $24, nE6, $0C, nD6, $0C
	dc.b	smpsNoAttack, $24, nB5, $24, nD6, $0C, nRst, $0C, nRst, $0C, nE6, $06
	dc.b	nRst, $1E, nE6, $06, nRst, $1E, nA6, $0C, nRst, $54, nA5, $0C
	dc.b	smpsNoAttack, $3C, nA5, $0C, nRst, $0C, nA5, $0C, smpsNoAttack, $3C, nA5, $0C
	dc.b	nRst, $0C, nE6, $0C, smpsNoAttack, $3C, nE5, $0C, nRst, $0C, nE6, $0C
	dc.b	smpsNoAttack, $3C, nE5, $0C, nRst, $0C, nA5, $0C, smpsNoAttack, $3C, nA5, $0C
	dc.b	nRst, $0C, nD6, $0C, smpsNoAttack, $3C, nA5, $0C, nRst, $0C, nG6, $0C
	dc.b	smpsNoAttack, $3C, nG6, $0C, nRst, $0C, nG6, $0C, smpsNoAttack, $3C, nEb6, $12
	dc.b	nRst, $06, nG6, $0C, smpsNoAttack, $54, nRst, $0C, nE6, $24, nA6, $3C
	dc.b	smpsNoAttack, $48, nRst, $18
	smpsJump            ShuranomonTrack2_Loop01

; PSG1 Data
ShuranomonTrack2_PSG1:
	dc.b	nRst, $60, nRst, $60, nRst, $60, nRst, $60, nRst, $60, nRst, $60
	dc.b	nRst, $60, nRst, $60

ShuranomonTrack2_Loop07:
	dc.b	nCs6, $54, nD6, $0C, smpsNoAttack, $60, nA6, $60, smpsNoAttack, $60, nA6, $54
	dc.b	nD6, $0C, smpsNoAttack, $54, nD6, $0C, smpsNoAttack, $54, nA6, $0C, smpsNoAttack, $60
	smpsLoop            $00, $02, ShuranomonTrack2_Loop07
	dc.b	nA6, $24, nE6, $24, nE6, $06, nRst, $06, nD6, $0C, smpsNoAttack, $24
	dc.b	nD6, $24, nD6, $06, nRst, $06, nB6, $0C, smpsNoAttack, $24, nG6, $24
	dc.b	nD6, $06, nRst, $06, nA6, $0C, smpsNoAttack, $24, nA6, $24, nE6, $06
	dc.b	nRst, $06, nC6, $0C, smpsNoAttack, $24, nE6, $24, nC7, $06, nRst, $06
	dc.b	nB6, $0C, smpsNoAttack, $24, nD6, $24, nG6, $06, nRst, $12, nRst, $0C
	dc.b	nD6, $06, nRst, $1E, nD6, $06, nRst, $1E, nE6, $0C, nRst, $54
	dc.b	nF6, $0C, smpsNoAttack, $3C, nF6, $0C, nRst, $0C, nF6, $0C, smpsNoAttack, $3C
	dc.b	nA6, $0C, nRst, $0C, nC6, $0C, smpsNoAttack, $3C, nE6, $0C, nRst, $0C
	dc.b	nC6, $0C, smpsNoAttack, $3C, nE6, $0C, nRst, $0C, nD6, $0C, smpsNoAttack, $3C
	dc.b	nD6, $0C, nRst, $0C, nD6, $0C, smpsNoAttack, $3C, nF6, $0C, nRst, $0C
	dc.b	nD6, $0C, smpsNoAttack, $3C, nBb6, $0C, nRst, $0C, nEb6, $0C, smpsNoAttack, $3C
	dc.b	nC6, $0C, nRst, $0C, nC6, $0C, smpsNoAttack, $54, nRst, $0C, nC6, $24
	dc.b	nFs6, $3C, smpsNoAttack, $48, nRst, $18
	smpsJump            ShuranomonTrack2_Loop07

; PSG2 Data
ShuranomonTrack2_PSG2:
	dc.b	nRst, $60, nRst, $60, nRst, $60, nRst, $60, nRst, $60, nRst, $60
	dc.b	nRst, $60, nRst, $60

ShuranomonTrack2_Loop06:
	dc.b	nE6, $54, nB6, $0C, smpsNoAttack, $60, nC6, $60, smpsNoAttack, $60, nC6, $54
	dc.b	nB6, $0C, smpsNoAttack, $54, nG6, $0C, smpsNoAttack, $54, nE6, $0C, smpsNoAttack, $60
	smpsLoop            $00, $02, ShuranomonTrack2_Loop06
	dc.b	nE6, $24, nA6, $24, nA6, $06, nRst, nG6, $0C, smpsNoAttack, $24, nB6
	dc.b	$24, nG6, $06, nRst, $06, nG6, $0C, smpsNoAttack, $24, nD6, $24, nG6
	dc.b	$06, nRst, $06, nE6, $0C, smpsNoAttack, $24, nC6, $24, nA6, $06, nRst
	dc.b	$06, nA6, $0C, smpsNoAttack, $24, nA6, $24, nA6, $06, nRst, $06, nG6
	dc.b	$0C, smpsNoAttack, $24, nG6, $24, nB6, $06, nRst, $12, nRst, $0C, nA6
	dc.b	$06, nRst, $1E, nA6, $06, nRst, $1E, nCs6, $0C, nRst, $54, nD6
	dc.b	$0C, smpsNoAttack, $30, nRst, $0C, nD6, $0C, nRst, $0C, nD6, $0C, smpsNoAttack
	dc.b	$30, nRst, $0C, nD6, $0C, nRst, $0C, nG6, $0C, smpsNoAttack, $30, nRst
	dc.b	$0C, nC6, $0C, nRst, $0C, nG6, $0C, smpsNoAttack, $30, nRst, $0C, nC6
	dc.b	$0C, nRst, $0C, nF6, $0C, smpsNoAttack, $30, nRst, $0C, nF6, $0C, nRst
	dc.b	$0C, nF6, $0C, smpsNoAttack, $30, nRst, $0C, nD6, $0C, nRst, $0C, nBb6
	dc.b	$0C, smpsNoAttack, $30, nRst, $0C, nD6, $0C, nRst, $0C, nC6, $0C, smpsNoAttack
	dc.b	$30, nRst, $0C, nG6, $0C, nRst, $0C, nE6, $0C, smpsNoAttack, $54, nRst
	dc.b	$0C, nG6, $24, nD6, $3C, smpsNoAttack, $48, nRst, $18
	smpsJump            ShuranomonTrack2_Loop06

; PSG3 Data
ShuranomonTrack2_PSG3:
	smpsPSGform         $E7
	smpsAlterNote       $FF
	smpsCall            ShuranomonTrack2_Call0B
	smpsCall            ShuranomonTrack2_Call0C
	smpsLoop            $00, $02, ShuranomonTrack2_PSG3
	smpsPSGform         $E7
	smpsCall            ShuranomonTrack2_Call0B
	smpsCall            ShuranomonTrack2_Call0C

ShuranomonTrack2_Loop05:
	smpsCall            ShuranomonTrack2_Call0B
	smpsCall            ShuranomonTrack2_Call0C
	smpsLoop            $00, $04, ShuranomonTrack2_Loop05
	smpsCall            ShuranomonTrack2_Call0B
	dc.b	nAb5, $06, nRst, nAb5, nRst, nAb5, nRst, nAb5, nRst, nAb5, $06, nRst
	dc.b	nAb5, nRst, nAb5, nRst, nAb5, nRst, nAb5, $06, nRst, nAb5, nRst, nAb5
	dc.b	nRst, nAb5, nRst, nAb5, $06, nRst, nAb5, nRst, nAb5, $08, nAb5, $06
	smpsPSGform         $00
	smpsPSGAlterVol     $02
	smpsAlterPitch      $D0
	smpsPSGvoice        fTone_03
	dc.b	nB5, $04, nF5, nA5, nD6, nA5, nD6, nF6, nD6, nF6, nA6, nF6
	dc.b	nA6, nD7, nF7, nD7, nA6, nD7, nA6, nF6, nA6, nF6, nD6, nF6
	dc.b	nD6, nA5, nA5, nD6, nF6, nD6, nF6, nA6, nF6, nA6, nD7, nA6
	dc.b	nD7, nF7, nA7, nF7, nD7, nF7, nD7, nA6, nD7, nA6, nF6, nA6
	dc.b	nF6, nD6, nG5, nC6, nE6, nC6, nE6, nG6, nE6, nG6, nC7, nG6
	dc.b	nC7, nE7, nG7, nE7, nC7, nE7, nC7, nG6, nC7, nG6, nE6, nG6
	dc.b	nE6, nC6, nG5, nC6, nE6, nC6, nE6, nG6, nE6, nG6, nC7, nG6
	dc.b	nC7, nE7, nG7, nE7, nC7, nE7, nC7, nG6, nC7, nG6, nE6, nG6
	dc.b	nE6, nC6, nF5, nA5, nD6, nA5, nD6, nF6, nD6, nF6, nA6, nF6
	dc.b	nA6, nD7, nF7, nD7, nA6, nD7, nA6, nF6, nA6, nF6, nD6, nF6
	dc.b	nD6, nA5, nA5, nD6, nF6, nD6, nF6, nA6, nF6, nA6, nD7, nA6
	dc.b	nD7, nF7, nA7, nF7, nD7, nF7, nD7, nA6, nD7, nA6, nF6, nA6
	dc.b	nF6, nD6, nG5, nBb5, nD6, nBb5, nD6, nG6, nD6, nG6, nBb6, nG6
	dc.b	nBb6, nD7, nG7, nD7, nBb6, nD7, nBb6, nG6, nBb6, nG6, nD6, nG6
	dc.b	nD6, nBb5, nG5, nC6, nEb6, nC6, nEb6, nG6, nEb6, nG6, nC7, nG6
	dc.b	nC7, nEb7, nG7, nEb7, nC7, nEb7, nC7, nG6, nC7, nG6, nEb6, nG6
	dc.b	nEb6, nC6, nG5, nC6, nE6, nC6, nE6, nG6, nE6, nG6, nC7, nG6
	dc.b	nC7, nE7, nG7, nE7, nC7, nE7, nC7, nG6, nC7, nG6, nE6, nG6
	dc.b	nE6, nC6, nG5, nC6, nE6, nG5, nC6, nE6, nC6, nE6, nG6, nG6
	dc.b	nC7, nG6, nD5, nFs5, nA5, nFs5, nA5, nD6, nA5, nD6, nFs6, nD6
	dc.b	nFs6, nA6, nFs6, nA6, nD7, nD6, nFs6, nA6, nFs6, nA6, nD7, nA6
	dc.b	nD7, nFs7, nA7, nFs7, nD7, nA7, nFs7, nD7, nFs7, nD7, nA6, nD7
	dc.b	nA6, nFs6, nA6, $06
	smpsAlterPitch      $30
	smpsPSGAlterVol     $FE
	smpsPSGform         $E7
	smpsPSGvoice        fTone_02
	smpsCall            ShuranomonTrack2_Call0B
	smpsCall            ShuranomonTrack2_Call0C
	smpsJump            ShuranomonTrack2_Loop05

ShuranomonTrack2_Call0B:
	dc.b	nAb5, $06, nRst, nAb5, nRst, nAb5, nRst, nAb5, nRst, nAb5, $06, nRst
	dc.b	nAb5, nRst, nAb5, nRst, nAb5, nRst, nAb5, $06, nRst, nAb5, nRst, nAb5
	dc.b	nRst, nAb5, nRst, nAb5, $06, nRst, nAb5, nRst, nAb5, nRst
	smpsPSGvoice        fTone_03
	dc.b	nAb5, $0C
	smpsPSGvoice        fTone_02
	smpsReturn

ShuranomonTrack2_Call0C:
	dc.b	nAb5, $06, nRst, nAb5, nRst, nAb5, nRst, nAb5, nRst, nAb5, $06, nRst
	dc.b	nAb5, nRst, nAb5, nRst, nAb5, nRst, nAb5, $06, nRst, nAb5, nRst, nAb5
	dc.b	nRst, nAb5, nRst, nAb5, $06, nRst
	smpsPSGvoice        fTone_03
	dc.b	nAb5, $0C
	smpsPSGvoice        fTone_02
	dc.b	nAb5, $06, nRst
	smpsPSGvoice        fTone_03
	dc.b	nAb5, $0C
	smpsPSGvoice        fTone_02
	smpsReturn

; DAC Data
ShuranomonTrack2_DAC:
	smpsCall            ShuranomonTrack2_Call00
	smpsCall            ShuranomonTrack2_Call01
	smpsCall            ShuranomonTrack2_Call00
	smpsCall            ShuranomonTrack2_Call01

ShuranomonTrack2_Jump00:
	smpsCall            ShuranomonTrack2_Call00
	smpsCall            ShuranomonTrack2_Call00
	smpsCall            ShuranomonTrack2_Call00
	smpsCall            ShuranomonTrack2_Call00
	smpsCall            ShuranomonTrack2_Call00
	smpsCall            ShuranomonTrack2_Call00
	smpsCall            ShuranomonTrack2_Call00
	smpsCall            ShuranomonTrack2_Call02
	smpsCall            ShuranomonTrack2_Call00
	smpsCall            ShuranomonTrack2_Call00
	smpsCall            ShuranomonTrack2_Call00
	smpsCall            ShuranomonTrack2_Call03
	smpsCall            ShuranomonTrack2_Call04
	smpsCall            ShuranomonTrack2_Call04
	smpsCall            ShuranomonTrack2_Call05
	smpsCall            ShuranomonTrack2_Call06
	smpsCall            ShuranomonTrack2_Call07
	smpsJump            ShuranomonTrack2_Jump00

ShuranomonTrack2_Call00:
	dc.b	dKick, $0C, dKick, dSnare, nRst, $0C, dKick, nRst, $0C, dSnare, dKick, nRst
	dc.b	$0C, dKick, dSnare, nRst, $0C, dKick, nRst, $0C, dSnare, nRst, $0C
	smpsReturn

ShuranomonTrack2_Call01:
	dc.b	dKick, $0C, dKick, dSnare, nRst, $0C, dKick, nRst, $0C, dSnare, dKick, nRst
	dc.b	$0C, dKick, dSnare, nRst, $0C, dKick, $85, dSnare, dClap
	smpsReturn

ShuranomonTrack2_Call02:
	dc.b	dKick, $0C, dKick, dSnare, nRst, $0C, dKick, nRst, $0C, dSnare, dKick, nRst
	dc.b	$0C, dKick, dSnare, nRst, $0C, dSnare, $85, $84, dClap
	smpsReturn

ShuranomonTrack2_Call03:
	dc.b	dKick, $0C, $85, dKick, dKick, $85, dKick, dKick, dClap, nRst, $85, $06
	dc.b	$85, $85, $0C, $85, $84, $84, dClap, dSnare
	smpsReturn

ShuranomonTrack2_Call04:
	dc.b	nRst, $0C, dKick, dSnare, nRst, $0C, dKick, nRst, $0C, dSnare, dKick, nRst
	dc.b	$0C, dKick, dSnare, nRst, $0C, dKick, nRst, $0C, dSnare, dKick
	smpsReturn

ShuranomonTrack2_Call05:
	dc.b	nRst, $0C, dKick, dSnare, nRst, $0C, dKick, nRst, $0C, dSnare, dKick, nRst
	dc.b	$0C, dKick, dSnare, nRst, $0C, dKick, $85, dSnare, dKick
	smpsReturn

ShuranomonTrack2_Call06:
	dc.b	nRst, $0C, dKick, dSnare, nRst, $0C, $85, $06, $85, $84, $0C, dSnare
	dc.b	dKick, nRst, $0C, dKick, dSnare, nRst, $0C, dKick, $85, dSnare, dKick
	smpsReturn

ShuranomonTrack2_Call07:
	dc.b	nRst, $0C, dKick, dSnare, nRst, $0C, $85, $06, $85, $84, $0C, dSnare
	dc.b	dClap, dKick, dSnare, dSnare, dClap, nRst, $0C, nRst, $0C, dKick, $0C, dSnare
	dc.b	nRst, $0C, $85, $06, $85, $85, $0C, $85, $84, $84, dClap, dClap
	smpsReturn

ShuranomonTrack2_Voices:
;	Voice $00
;	$3D
;	$01, $62, $03, $21, 	$30, $1F, $13, $26, 	$08, $08, $08, $03
;	$05, $00, $03, $00, 	$0F, $1B, $1B, $1B, 	$1A, $01, $05, $09
	smpsVcAlgorithm     $05
	smpsVcFeedback      $07
	smpsVcUnusedBits    $00
	smpsVcDetune        $02, $00, $06, $00
	smpsVcCoarseFreq    $01, $03, $02, $01
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $26, $13, $1F, $30
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $03, $08, $08, $08
	smpsVcDecayRate2    $00, $03, $00, $05
	smpsVcDecayLevel    $01, $01, $01, $00
	smpsVcReleaseRate   $0B, $0B, $0B, $0F
	smpsVcTotalLevel    $09, $05, $01, $1A

;	Voice $01
;	$03
;	$09, $00, $00, $00, 	$1F, $1F, $1F, $1F, 	$10, $02, $0D, $0D
;	$04, $00, $00, $00, 	$CF, $FF, $FF, $FF, 	$25, $19, $19, $01
	smpsVcAlgorithm     $03
	smpsVcFeedback      $00
	smpsVcUnusedBits    $00
	smpsVcDetune        $00, $00, $00, $00
	smpsVcCoarseFreq    $00, $00, $00, $09
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $1F, $1F, $1F, $1F
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $0D, $0D, $02, $10
	smpsVcDecayRate2    $00, $00, $00, $04
	smpsVcDecayLevel    $0F, $0F, $0F, $0C
	smpsVcReleaseRate   $0F, $0F, $0F, $0F
	smpsVcTotalLevel    $01, $19, $19, $25

;	Voice $02
;	$0C
;	$41, $00, $20, $00, 	$1F, $1F, $1F, $1F, 	$0F, $0D, $0C, $0D
;	$10, $09, $00, $09, 	$4F, $5F, $AF, $8F, 	$1B, $00, $1D, $00
	smpsVcAlgorithm     $04
	smpsVcFeedback      $01
	smpsVcUnusedBits    $00
	smpsVcDetune        $00, $02, $00, $04
	smpsVcCoarseFreq    $00, $00, $00, $01
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $1F, $1F, $1F, $1F
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $0D, $0C, $0D, $0F
	smpsVcDecayRate2    $09, $00, $09, $10
	smpsVcDecayLevel    $08, $0A, $05, $04
	smpsVcReleaseRate   $0F, $0F, $0F, $0F
	smpsVcTotalLevel    $00, $1D, $00, $1B

;	Voice $03
;	$3A
;	$34, $72, $51, $73, 	$1F, $5F, $1F, $5F, 	$10, $10, $10, $00
;	$08, $00, $00, $00, 	$1A, $18, $18, $09, 	$17, $22, $19, $03
	smpsVcAlgorithm     $02
	smpsVcFeedback      $07
	smpsVcUnusedBits    $00
	smpsVcDetune        $07, $05, $07, $03
	smpsVcCoarseFreq    $03, $01, $02, $04
	smpsVcRateScale     $01, $00, $01, $00
	smpsVcAttackRate    $1F, $1F, $1F, $1F
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $00, $10, $10, $10
	smpsVcDecayRate2    $00, $00, $00, $08
	smpsVcDecayLevel    $00, $01, $01, $01
	smpsVcReleaseRate   $09, $08, $08, $0A
	smpsVcTotalLevel    $03, $19, $22, $17

;	Voice $04
;	$2C
;	$41, $00, $22, $00, 	$1F, $1F, $1F, $1F, 	$0D, $0C, $0C, $0C
;	$10, $09, $00, $09, 	$4F, $5F, $AF, $8F, 	$13, $04, $15, $04
	smpsVcAlgorithm     $04
	smpsVcFeedback      $05
	smpsVcUnusedBits    $00
	smpsVcDetune        $00, $02, $00, $04
	smpsVcCoarseFreq    $00, $02, $00, $01
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $1F, $1F, $1F, $1F
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $0C, $0C, $0C, $0D
	smpsVcDecayRate2    $09, $00, $09, $10
	smpsVcDecayLevel    $08, $0A, $05, $04
	smpsVcReleaseRate   $0F, $0F, $0F, $0F
	smpsVcTotalLevel    $04, $15, $04, $13

;	Voice $05
;	$3C
;	$01, $62, $01, $22, 	$17, $1F, $1F, $1F, 	$08, $08, $08, $09
;	$05, $00, $03, $00, 	$0F, $1B, $1B, $1B, 	$18, $00, $08, $00
	smpsVcAlgorithm     $04
	smpsVcFeedback      $07
	smpsVcUnusedBits    $00
	smpsVcDetune        $02, $00, $06, $00
	smpsVcCoarseFreq    $02, $01, $02, $01
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $1F, $1F, $1F, $17
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $09, $08, $08, $08
	smpsVcDecayRate2    $00, $03, $00, $05
	smpsVcDecayLevel    $01, $01, $01, $00
	smpsVcReleaseRate   $0B, $0B, $0B, $0F
	smpsVcTotalLevel    $00, $08, $00, $18

;	Voice $06
;	$4D
;	$42, $00, $21, $00, 	$17, $1D, $1D, $1D, 	$05, $0E, $08, $0C
;	$10, $03, $00, $03, 	$4F, $5F, $AF, $8F, 	$21, $0F, $04, $0F
	smpsVcAlgorithm     $05
	smpsVcFeedback      $01
	smpsVcUnusedBits    $01
	smpsVcDetune        $00, $02, $00, $04
	smpsVcCoarseFreq    $00, $01, $00, $02
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $1D, $1D, $1D, $17
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $0C, $08, $0E, $05
	smpsVcDecayRate2    $03, $00, $03, $10
	smpsVcDecayLevel    $08, $0A, $05, $04
	smpsVcReleaseRate   $0F, $0F, $0F, $0F
	smpsVcTotalLevel    $0F, $04, $0F, $21

;	Voice $07
;	$28
;	$05, $14, $32, $70, 	$1F, $1F, $1F, $1F, 	$0E, $0E, $0C, $0A
;	$00, $00, $00, $00, 	$4F, $4F, $AF, $AB, 	$1D, $1B, $18, $02
	smpsVcAlgorithm     $00
	smpsVcFeedback      $05
	smpsVcUnusedBits    $00
	smpsVcDetune        $07, $03, $01, $00
	smpsVcCoarseFreq    $00, $02, $04, $05
	smpsVcRateScale     $00, $00, $00, $00
	smpsVcAttackRate    $1F, $1F, $1F, $1F
	smpsVcAmpMod        $00, $00, $00, $00
	smpsVcDecayRate1    $0A, $0C, $0E, $0E
	smpsVcDecayRate2    $00, $00, $00, $00
	smpsVcDecayLevel    $0A, $0A, $04, $04
	smpsVcReleaseRate   $0B, $0F, $0F, $0F
	smpsVcTotalLevel    $02, $18, $1B, $1D

