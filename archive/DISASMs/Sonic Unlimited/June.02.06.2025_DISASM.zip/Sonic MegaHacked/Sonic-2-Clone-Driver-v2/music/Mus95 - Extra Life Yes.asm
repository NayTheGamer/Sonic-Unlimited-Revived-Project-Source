CD_Shoes_Header:
    smpsHeaderStartSong 1
    smpsHeaderVoice     CD_Shoes_Voices
    smpsHeaderChan      $01, $00
    smpsHeaderTempo     $01, $03

    smpsHeaderDAC       CD_Shoes_DAC

CD_Shoes_DAC:
    dc.b    dSCDSHOES         ; play BGM sample
    smpsStop

CD_Shoes_Voices: